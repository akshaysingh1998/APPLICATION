package com.google.android.gms.clearcut;

import android.os.Parcel;
import com.google.android.gms.clearcut.zzb.zzc;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzapg.zzd;
import com.google.android.gms.playlog.internal.PlayLoggerContext;
import java.util.Arrays;

public class LogEventParcelable extends AbstractSafeParcelable {
    public static final zzd CREATOR = new zzd();
    public PlayLoggerContext qk;
    public byte[] ql;
    public int[] qm;
    public String[] qn;
    public int[] qo;
    public byte[][] qp;
    public boolean qq;
    public final zzd qr;
    public final zzc qs;
    public final zzc qt;
    public final int versionCode;

    LogEventParcelable(int i, PlayLoggerContext playLoggerContext, byte[] bArr, int[] iArr, String[] strArr, int[] iArr2, byte[][] bArr2, boolean z) {
        this.versionCode = i;
        this.qk = playLoggerContext;
        this.ql = bArr;
        this.qm = iArr;
        this.qn = strArr;
        this.qr = null;
        this.qs = null;
        this.qt = null;
        this.qo = iArr2;
        this.qp = bArr2;
        this.qq = z;
    }

    public LogEventParcelable(PlayLoggerContext playLoggerContext, zzd com_google_android_gms_internal_zzapg_zzd, zzc com_google_android_gms_clearcut_zzb_zzc, zzc com_google_android_gms_clearcut_zzb_zzc2, int[] iArr, String[] strArr, int[] iArr2, byte[][] bArr, boolean z) {
        this.versionCode = 1;
        this.qk = playLoggerContext;
        this.qr = com_google_android_gms_internal_zzapg_zzd;
        this.qs = com_google_android_gms_clearcut_zzb_zzc;
        this.qt = com_google_android_gms_clearcut_zzb_zzc2;
        this.qm = iArr;
        this.qn = strArr;
        this.qo = iArr2;
        this.qp = bArr;
        this.qq = z;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LogEventParcelable)) {
            return false;
        }
        LogEventParcelable logEventParcelable = (LogEventParcelable) obj;
        return this.versionCode == logEventParcelable.versionCode && zzaa.equal(this.qk, logEventParcelable.qk) && Arrays.equals(this.ql, logEventParcelable.ql) && Arrays.equals(this.qm, logEventParcelable.qm) && Arrays.equals(this.qn, logEventParcelable.qn) && zzaa.equal(this.qr, logEventParcelable.qr) && zzaa.equal(this.qs, logEventParcelable.qs) && zzaa.equal(this.qt, logEventParcelable.qt) && Arrays.equals(this.qo, logEventParcelable.qo) && Arrays.deepEquals(this.qp, logEventParcelable.qp) && this.qq == logEventParcelable.qq;
    }

    public int hashCode() {
        return zzaa.hashCode(Integer.valueOf(this.versionCode), this.qk, this.ql, this.qm, this.qn, this.qr, this.qs, this.qt, this.qo, this.qp, Boolean.valueOf(this.qq));
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("LogEventParcelable[");
        stringBuilder.append(this.versionCode);
        stringBuilder.append(", ");
        stringBuilder.append(this.qk);
        stringBuilder.append(", ");
        stringBuilder.append("LogEventBytes: ");
        stringBuilder.append(this.ql == null ? null : new String(this.ql));
        stringBuilder.append(", ");
        stringBuilder.append("TestCodes: ");
        stringBuilder.append(Arrays.toString(this.qm));
        stringBuilder.append(", ");
        stringBuilder.append("MendelPackages: ");
        stringBuilder.append(Arrays.toString(this.qn));
        stringBuilder.append(", ");
        stringBuilder.append("LogEvent: ");
        stringBuilder.append(this.qr);
        stringBuilder.append(", ");
        stringBuilder.append("ExtensionProducer: ");
        stringBuilder.append(this.qs);
        stringBuilder.append(", ");
        stringBuilder.append("VeProducer: ");
        stringBuilder.append(this.qt);
        stringBuilder.append(", ");
        stringBuilder.append("ExperimentIDs: ");
        stringBuilder.append(Arrays.toString(this.qo));
        stringBuilder.append(", ");
        stringBuilder.append("ExperimentTokens: ");
        stringBuilder.append(Arrays.toString(this.qp));
        stringBuilder.append(", ");
        stringBuilder.append("AddPhenotypeExperimentTokens: ");
        stringBuilder.append(this.qq);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzd.zza(this, parcel, i);
    }
}
