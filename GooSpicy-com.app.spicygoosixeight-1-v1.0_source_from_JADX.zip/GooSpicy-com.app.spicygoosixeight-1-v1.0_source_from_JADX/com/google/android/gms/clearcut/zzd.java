package com.google.android.gms.clearcut;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.playlog.internal.PlayLoggerContext;

public class zzd implements Creator<LogEventParcelable> {
    static void zza(LogEventParcelable logEventParcelable, Parcel parcel, int i) {
        int zzcm = zzb.zzcm(parcel);
        zzb.zzc(parcel, 1, logEventParcelable.versionCode);
        zzb.zza(parcel, 2, logEventParcelable.qk, i, false);
        zzb.zza(parcel, 3, logEventParcelable.ql, false);
        zzb.zza(parcel, 4, logEventParcelable.qm, false);
        zzb.zza(parcel, 5, logEventParcelable.qn, false);
        zzb.zza(parcel, 6, logEventParcelable.qo, false);
        zzb.zza(parcel, 7, logEventParcelable.qp, false);
        zzb.zza(parcel, 8, logEventParcelable.qq);
        zzb.zzaj(parcel, zzcm);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbw(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzey(i);
    }

    public LogEventParcelable zzbw(Parcel parcel) {
        int zzcl = zza.zzcl(parcel);
        PlayLoggerContext playLoggerContext = null;
        byte[] bArr = playLoggerContext;
        int[] iArr = bArr;
        String[] strArr = iArr;
        int[] iArr2 = strArr;
        byte[][] bArr2 = iArr2;
        int i = 0;
        boolean z = true;
        while (parcel.dataPosition() < zzcl) {
            int zzck = zza.zzck(parcel);
            switch (zza.zzgi(zzck)) {
                case 1:
                    i = zza.zzg(parcel, zzck);
                    break;
                case 2:
                    playLoggerContext = (PlayLoggerContext) zza.zza(parcel, zzck, PlayLoggerContext.CREATOR);
                    break;
                case 3:
                    bArr = zza.zzt(parcel, zzck);
                    break;
                case 4:
                    iArr = zza.zzw(parcel, zzck);
                    break;
                case 5:
                    strArr = zza.zzac(parcel, zzck);
                    break;
                case 6:
                    iArr2 = zza.zzw(parcel, zzck);
                    break;
                case 7:
                    bArr2 = zza.zzu(parcel, zzck);
                    break;
                case 8:
                    z = zza.zzc(parcel, zzck);
                    break;
                default:
                    zza.zzb(parcel, zzck);
                    break;
            }
        }
        if (parcel.dataPosition() == zzcl) {
            return new LogEventParcelable(i, playLoggerContext, bArr, iArr, strArr, iArr2, bArr2, z);
        }
        StringBuilder stringBuilder = new StringBuilder(37);
        stringBuilder.append("Overread allowed size end=");
        stringBuilder.append(zzcl);
        throw new zza.zza(stringBuilder.toString(), parcel);
    }

    public LogEventParcelable[] zzey(int i) {
        return new LogEventParcelable[i];
    }
}
