package com.google.android.gms.clearcut;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.zzf;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.PendingResults;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzab;
import com.google.android.gms.common.internal.zzg;
import com.google.android.gms.common.util.zze;
import com.google.android.gms.common.util.zzh;
import com.google.android.gms.internal.zzpg;
import com.google.android.gms.internal.zzph;
import com.google.android.gms.internal.zzpl;
import com.google.android.gms.playlog.internal.PlayLoggerContext;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TimeZone;

public final class zzb {
    public static final Api<NoOptions> API = new Api("ClearcutLogger.API", bO, bN);
    public static final zzf<zzph> bN = new zzf();
    public static final com.google.android.gms.common.api.Api.zza<zzph, NoOptions> bO = new C10931();
    public static final zzc pP = new zzpg();
    private final String aQ;
    private final Context mContext;
    private final int pQ;
    private String pR;
    private int pS;
    private String pT;
    private String pU;
    private final boolean pV;
    private int pW;
    private final zzc pX;
    private final zza pY;
    private zzd pZ;
    private final zzb qa;
    private final zze zzaoa;

    public class zza {
        private String pR;
        private int pS;
        private String pT;
        private String pU;
        private int pW;
        private final zzc qb;
        private ArrayList<Integer> qc;
        private ArrayList<String> qd;
        private ArrayList<Integer> qe;
        private ArrayList<byte[]> qf;
        private boolean qg;
        private final com.google.android.gms.internal.zzapg.zzd qh;
        private boolean qi;
        final /* synthetic */ zzb qj;

        private zza(zzb com_google_android_gms_clearcut_zzb, byte[] bArr) {
            this(com_google_android_gms_clearcut_zzb, bArr, null);
        }

        private zza(zzb com_google_android_gms_clearcut_zzb, byte[] bArr, zzc com_google_android_gms_clearcut_zzb_zzc) {
            this.qj = com_google_android_gms_clearcut_zzb;
            this.pS = this.qj.pS;
            this.pR = this.qj.pR;
            this.pT = this.qj.pT;
            this.pU = this.qj.pU;
            this.pW = 0;
            this.qc = null;
            this.qd = null;
            this.qe = null;
            this.qf = null;
            this.qg = true;
            this.qh = new com.google.android.gms.internal.zzapg.zzd();
            this.qi = false;
            this.pT = com_google_android_gms_clearcut_zzb.pT;
            this.pU = com_google_android_gms_clearcut_zzb.pU;
            this.qh.biF = com_google_android_gms_clearcut_zzb.zzaoa.currentTimeMillis();
            this.qh.biG = com_google_android_gms_clearcut_zzb.zzaoa.elapsedRealtime();
            this.qh.biX = (long) com_google_android_gms_clearcut_zzb.pY.zzbk(com_google_android_gms_clearcut_zzb.mContext);
            this.qh.biR = com_google_android_gms_clearcut_zzb.pZ.zzae(this.qh.biF);
            if (bArr != null) {
                this.qh.biM = bArr;
            }
            this.qb = com_google_android_gms_clearcut_zzb_zzc;
        }

        public LogEventParcelable zzamv() {
            return new LogEventParcelable(new PlayLoggerContext(this.qj.aQ, this.qj.pQ, this.pS, this.pR, this.pT, this.pU, this.qj.pV, this.pW), this.qh, this.qb, null, zzb.zzb(null), zzb.zzc(null), zzb.zzb(null), zzb.zzd(null), this.qg);
        }

        public PendingResult<Status> zze(GoogleApiClient googleApiClient) {
            if (this.qi) {
                throw new IllegalStateException("do not reuse LogEventBuilder");
            }
            this.qi = true;
            PlayLoggerContext playLoggerContext = zzamv().qk;
            return this.qj.qa.zzg(playLoggerContext.asm, playLoggerContext.asi) ? this.qj.pX.zza(googleApiClient, zzamv()) : PendingResults.immediatePendingResult(Status.sg);
        }

        public zza zzew(int i) {
            this.qh.biI = i;
            return this;
        }

        public zza zzex(int i) {
            this.qh.zzahl = i;
            return this;
        }
    }

    public interface zzb {
        boolean zzg(String str, int i);
    }

    public interface zzc {
        byte[] zzamw();
    }

    public static class zzd {
        public long zzae(long j) {
            return (long) (TimeZone.getDefault().getOffset(j) / 1000);
        }
    }

    class C10931 extends com.google.android.gms.common.api.Api.zza<zzph, NoOptions> {
        C10931() {
        }

        public /* synthetic */ Api.zze zza(Context context, Looper looper, zzg com_google_android_gms_common_internal_zzg, Object obj, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return zze(context, looper, com_google_android_gms_common_internal_zzg, (NoOptions) obj, connectionCallbacks, onConnectionFailedListener);
        }

        public zzph zze(Context context, Looper looper, zzg com_google_android_gms_common_internal_zzg, NoOptions noOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return new zzph(context, looper, com_google_android_gms_common_internal_zzg, connectionCallbacks, onConnectionFailedListener);
        }
    }

    public zzb(Context context, int i, String str, String str2, String str3, boolean z, zzc com_google_android_gms_clearcut_zzc, zze com_google_android_gms_common_util_zze, zzd com_google_android_gms_clearcut_zzb_zzd, zza com_google_android_gms_clearcut_zza, zzb com_google_android_gms_clearcut_zzb_zzb) {
        this.pS = -1;
        boolean z2 = false;
        this.pW = 0;
        Context applicationContext = context.getApplicationContext();
        if (applicationContext == null) {
            applicationContext = context;
        }
        this.mContext = applicationContext;
        this.aQ = context.getPackageName();
        this.pQ = zzbl(context);
        this.pS = i;
        this.pR = str;
        this.pT = str2;
        this.pU = str3;
        this.pV = z;
        this.pX = com_google_android_gms_clearcut_zzc;
        this.zzaoa = com_google_android_gms_common_util_zze;
        if (com_google_android_gms_clearcut_zzb_zzd == null) {
            com_google_android_gms_clearcut_zzb_zzd = new zzd();
        }
        this.pZ = com_google_android_gms_clearcut_zzb_zzd;
        this.pY = com_google_android_gms_clearcut_zza;
        this.pW = 0;
        this.qa = com_google_android_gms_clearcut_zzb_zzb;
        if (this.pV) {
            if (this.pT == null) {
                z2 = true;
            }
            zzab.zzb(z2, (Object) "can't be anonymous with an upload account");
        }
    }

    public zzb(Context context, String str, String str2) {
        this(context, -1, str, str2, null, false, pP, zzh.zzavi(), null, zza.pO, new zzpl(context));
    }

    private static int[] zzb(ArrayList<Integer> arrayList) {
        if (arrayList == null) {
            return null;
        }
        int[] iArr = new int[arrayList.size()];
        int i = 0;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            int i2 = i + 1;
            iArr[i] = ((Integer) it.next()).intValue();
            i = i2;
        }
        return iArr;
    }

    private int zzbl(android.content.Context r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r0 = 0;
        r1 = r3.getPackageManager();	 Catch:{ NameNotFoundException -> 0x0010 }
        r3 = r3.getPackageName();	 Catch:{ NameNotFoundException -> 0x0010 }
        r3 = r1.getPackageInfo(r3, r0);	 Catch:{ NameNotFoundException -> 0x0010 }
        r3 = r3.versionCode;	 Catch:{ NameNotFoundException -> 0x0010 }
        return r3;
    L_0x0010:
        r3 = "ClearcutLogger";
        r1 = "This can't happen.";
        android.util.Log.wtf(r3, r1);
        r3 = r0;
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.clearcut.zzb.zzbl(android.content.Context):int");
    }

    private static String[] zzc(ArrayList<String> arrayList) {
        return arrayList == null ? null : (String[]) arrayList.toArray(new String[0]);
    }

    private static byte[][] zzd(ArrayList<byte[]> arrayList) {
        return arrayList == null ? null : (byte[][]) arrayList.toArray(new byte[0][]);
    }

    public zza zzl(byte[] bArr) {
        return new zza(bArr);
    }
}
