package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.view.MotionEvent;

public class zzas {
    private static final String[] zzafy = new String[]{"/aclk", "/pcs/click"};
    private String zzafu = "googleads.g.doubleclick.net";
    private String zzafv = "/pagead/ads";
    private String zzafw = "ad.doubleclick.net";
    private String[] zzafx = new String[]{".doubleclick.net", ".googleadservices.com", ".googlesyndication.com"};
    private zzan zzafz;

    public zzas(zzan com_google_android_gms_internal_zzan) {
        this.zzafz = com_google_android_gms_internal_zzan;
    }

    private android.net.Uri zza(android.net.Uri r4, android.content.Context r5, java.lang.String r6, boolean r7) throws com.google.android.gms.internal.zzat {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r3.zzb(r4);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        if (r0 == 0) goto L_0x001a;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x0006:
        r1 = r4.toString();	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r2 = "dc_ms=";	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r1 = r1.contains(r2);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        if (r1 == 0) goto L_0x002a;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x0012:
        r4 = new com.google.android.gms.internal.zzat;	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r5 = "Parameter already exists: dc_ms";	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r4.<init>(r5);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        throw r4;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x001a:
        r1 = "ms";	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r1 = r4.getQueryParameter(r1);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        if (r1 == 0) goto L_0x002a;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x0022:
        r4 = new com.google.android.gms.internal.zzat;	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r5 = "Query parameter already exists: ms";	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r4.<init>(r5);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        throw r4;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x002a:
        if (r7 == 0) goto L_0x0033;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x002c:
        r7 = r3.zzafz;	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r5 = r7.zzb(r5, r6);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        goto L_0x0039;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x0033:
        r6 = r3.zzafz;	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r5 = r6.zzb(r5);	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x0039:
        if (r0 == 0) goto L_0x0042;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x003b:
        r6 = "dc_ms";	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r4 = r3.zzb(r4, r6, r5);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        return r4;	 Catch:{ UnsupportedOperationException -> 0x0049 }
    L_0x0042:
        r6 = "ms";	 Catch:{ UnsupportedOperationException -> 0x0049 }
        r4 = r3.zza(r4, r6, r5);	 Catch:{ UnsupportedOperationException -> 0x0049 }
        return r4;
    L_0x0049:
        r4 = new com.google.android.gms.internal.zzat;
        r5 = "Provided Uri is not in a valid state";
        r4.<init>(r5);
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzas.zza(android.net.Uri, android.content.Context, java.lang.String, boolean):android.net.Uri");
    }

    private Uri zza(Uri uri, String str, String str2) throws UnsupportedOperationException {
        String uri2 = uri.toString();
        int indexOf = uri2.indexOf("&adurl");
        if (indexOf == -1) {
            indexOf = uri2.indexOf("?adurl");
        }
        if (indexOf == -1) {
            return uri.buildUpon().appendQueryParameter(str, str2).build();
        }
        indexOf++;
        StringBuilder stringBuilder = new StringBuilder(uri2.substring(0, indexOf));
        stringBuilder.append(str);
        stringBuilder.append("=");
        stringBuilder.append(str2);
        stringBuilder.append("&");
        stringBuilder.append(uri2.substring(indexOf));
        return Uri.parse(stringBuilder.toString());
    }

    private Uri zzb(Uri uri, String str, String str2) {
        String stringBuilder;
        String uri2 = uri.toString();
        int indexOf = uri2.indexOf(";adurl");
        if (indexOf != -1) {
            indexOf++;
            StringBuilder stringBuilder2 = new StringBuilder(uri2.substring(0, indexOf));
            stringBuilder2.append(str);
            stringBuilder2.append("=");
            stringBuilder2.append(str2);
            stringBuilder2.append(";");
            stringBuilder2.append(uri2.substring(indexOf));
            stringBuilder = stringBuilder2.toString();
        } else {
            stringBuilder = uri.getEncodedPath();
            indexOf = uri2.indexOf(stringBuilder);
            StringBuilder stringBuilder3 = new StringBuilder(uri2.substring(0, stringBuilder.length() + indexOf));
            stringBuilder3.append(";");
            stringBuilder3.append(str);
            stringBuilder3.append("=");
            stringBuilder3.append(str2);
            stringBuilder3.append(";");
            stringBuilder3.append(uri2.substring(indexOf + stringBuilder.length()));
            stringBuilder = stringBuilder3.toString();
        }
        return Uri.parse(stringBuilder);
    }

    public Uri zza(Uri uri, Context context) throws zzat {
        return zza(uri, context, null, false);
    }

    public void zza(MotionEvent motionEvent) {
        this.zzafz.zza(motionEvent);
    }

    public boolean zza(android.net.Uri r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        if (r4 != 0) goto L_0x0008;
    L_0x0002:
        r4 = new java.lang.NullPointerException;
        r4.<init>();
        throw r4;
    L_0x0008:
        r0 = 0;
        r1 = r4.getHost();	 Catch:{ NullPointerException -> 0x0022 }
        r2 = r3.zzafu;	 Catch:{ NullPointerException -> 0x0022 }
        r1 = r1.equals(r2);	 Catch:{ NullPointerException -> 0x0022 }
        if (r1 == 0) goto L_0x0022;	 Catch:{ NullPointerException -> 0x0022 }
    L_0x0015:
        r4 = r4.getPath();	 Catch:{ NullPointerException -> 0x0022 }
        r1 = r3.zzafv;	 Catch:{ NullPointerException -> 0x0022 }
        r4 = r4.equals(r1);	 Catch:{ NullPointerException -> 0x0022 }
        if (r4 == 0) goto L_0x0022;
    L_0x0021:
        r0 = 1;
    L_0x0022:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzas.zza(android.net.Uri):boolean");
    }

    public zzan zzax() {
        return this.zzafz;
    }

    public android.net.Uri zzb(android.net.Uri r3, android.content.Context r4) throws com.google.android.gms.internal.zzat {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r0 = "ai";	 Catch:{ UnsupportedOperationException -> 0x000c }
        r0 = r3.getQueryParameter(r0);	 Catch:{ UnsupportedOperationException -> 0x000c }
        r1 = 1;	 Catch:{ UnsupportedOperationException -> 0x000c }
        r3 = r2.zza(r3, r4, r0, r1);	 Catch:{ UnsupportedOperationException -> 0x000c }
        return r3;
    L_0x000c:
        r3 = new com.google.android.gms.internal.zzat;
        r4 = "Provided Uri is not in a valid state";
        r3.<init>(r4);
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzas.zzb(android.net.Uri, android.content.Context):android.net.Uri");
    }

    public void zzb(String str, String str2) {
        this.zzafu = str;
        this.zzafv = str2;
    }

    public boolean zzb(android.net.Uri r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        if (r2 != 0) goto L_0x0008;
    L_0x0002:
        r2 = new java.lang.NullPointerException;
        r2.<init>();
        throw r2;
    L_0x0008:
        r2 = r2.getHost();	 Catch:{ NullPointerException -> 0x0013 }
        r0 = r1.zzafw;	 Catch:{ NullPointerException -> 0x0013 }
        r2 = r2.equals(r0);	 Catch:{ NullPointerException -> 0x0013 }
        return r2;
    L_0x0013:
        r2 = 0;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzas.zzb(android.net.Uri):boolean");
    }

    public boolean zzc(android.net.Uri r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r5 = this;
        if (r6 != 0) goto L_0x0008;
    L_0x0002:
        r6 = new java.lang.NullPointerException;
        r6.<init>();
        throw r6;
    L_0x0008:
        r0 = 0;
        r6 = r6.getHost();	 Catch:{ NullPointerException -> 0x0020 }
        r1 = r5.zzafx;	 Catch:{ NullPointerException -> 0x0020 }
        r2 = r1.length;	 Catch:{ NullPointerException -> 0x0020 }
        r3 = r0;	 Catch:{ NullPointerException -> 0x0020 }
    L_0x0011:
        if (r3 >= r2) goto L_0x0020;	 Catch:{ NullPointerException -> 0x0020 }
    L_0x0013:
        r4 = r1[r3];	 Catch:{ NullPointerException -> 0x0020 }
        r4 = r6.endsWith(r4);	 Catch:{ NullPointerException -> 0x0020 }
        if (r4 == 0) goto L_0x001d;
    L_0x001b:
        r6 = 1;
        return r6;
    L_0x001d:
        r3 = r3 + 1;
        goto L_0x0011;
    L_0x0020:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzas.zzc(android.net.Uri):boolean");
    }

    public boolean zzd(Uri uri) {
        if (zzc(uri)) {
            for (String endsWith : zzafy) {
                if (uri.getPath().endsWith(endsWith)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void zzk(String str) {
        this.zzafx = str.split(",");
    }
}
