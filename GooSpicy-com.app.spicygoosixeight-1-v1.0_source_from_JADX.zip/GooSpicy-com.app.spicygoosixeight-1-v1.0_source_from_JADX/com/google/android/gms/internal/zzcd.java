package com.google.android.gms.internal;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.zzh;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzu;
import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public abstract class zzcd implements OnGlobalLayoutListener, OnScrollChangedListener {
    protected final Object zzail = new Object();
    private boolean zzanc = false;
    private zzkv zzapz;
    private final WeakReference<zzjy> zzaqf;
    private WeakReference<ViewTreeObserver> zzaqg;
    private final zzck zzaqh;
    protected final zzcf zzaqi;
    private final Context zzaqj;
    private final WindowManager zzaqk;
    private final PowerManager zzaql;
    private final KeyguardManager zzaqm;
    private zzch zzaqn;
    private boolean zzaqo;
    private boolean zzaqp = false;
    private boolean zzaqq;
    private boolean zzaqr;
    private boolean zzaqs;
    BroadcastReceiver zzaqt;
    private final HashSet<zzce> zzaqu = new HashSet();
    private final zzet zzaqv = new C08722(this);
    private final zzet zzaqw = new C08733(this);
    private final zzet zzaqx = new C08744(this);

    class C04031 extends BroadcastReceiver {
        final /* synthetic */ zzcd zzaqy;

        C04031(zzcd com_google_android_gms_internal_zzcd) {
            this.zzaqy = com_google_android_gms_internal_zzcd;
        }

        public void onReceive(Context context, Intent intent) {
            this.zzaqy.zzk(3);
        }
    }

    class C08722 implements zzet {
        final /* synthetic */ zzcd zzaqy;

        C08722(zzcd com_google_android_gms_internal_zzcd) {
            this.zzaqy = com_google_android_gms_internal_zzcd;
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            if (this.zzaqy.zzb((Map) map)) {
                this.zzaqy.zza(com_google_android_gms_internal_zzll.getView(), (Map) map);
            }
        }
    }

    class C08733 implements zzet {
        final /* synthetic */ zzcd zzaqy;

        C08733(zzcd com_google_android_gms_internal_zzcd) {
            this.zzaqy = com_google_android_gms_internal_zzcd;
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            if (this.zzaqy.zzb((Map) map)) {
                String str = "Received request to untrack: ";
                String valueOf = String.valueOf(this.zzaqy.zzaqi.zzhn());
                com.google.android.gms.ads.internal.util.client.zzb.zzcw(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                this.zzaqy.destroy();
            }
        }
    }

    class C08744 implements zzet {
        final /* synthetic */ zzcd zzaqy;

        C08744(zzcd com_google_android_gms_internal_zzcd) {
            this.zzaqy = com_google_android_gms_internal_zzcd;
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            if (this.zzaqy.zzb((Map) map) && map.containsKey("isVisible")) {
                boolean z;
                if (!"1".equals(map.get("isVisible"))) {
                    if (!"true".equals(map.get("isVisible"))) {
                        z = false;
                        this.zzaqy.zzj(Boolean.valueOf(z).booleanValue());
                    }
                }
                z = true;
                this.zzaqy.zzj(Boolean.valueOf(z).booleanValue());
            }
        }
    }

    public static class zza implements zzck {
        private WeakReference<zzh> zzaqz;

        public zza(zzh com_google_android_gms_ads_internal_formats_zzh) {
            this.zzaqz = new WeakReference(com_google_android_gms_ads_internal_formats_zzh);
        }

        public View zzhh() {
            zzh com_google_android_gms_ads_internal_formats_zzh = (zzh) this.zzaqz.get();
            return com_google_android_gms_ads_internal_formats_zzh != null ? com_google_android_gms_ads_internal_formats_zzh.zzle() : null;
        }

        public boolean zzhi() {
            return this.zzaqz.get() == null;
        }

        public zzck zzhj() {
            return new zzb((zzh) this.zzaqz.get());
        }
    }

    public static class zzb implements zzck {
        private zzh zzara;

        public zzb(zzh com_google_android_gms_ads_internal_formats_zzh) {
            this.zzara = com_google_android_gms_ads_internal_formats_zzh;
        }

        public View zzhh() {
            return this.zzara.zzle();
        }

        public boolean zzhi() {
            return this.zzara == null;
        }

        public zzck zzhj() {
            return this;
        }
    }

    public static class zzc implements zzck {
        private final View mView;
        private final zzjy zzarb;

        public zzc(View view, zzjy com_google_android_gms_internal_zzjy) {
            this.mView = view;
            this.zzarb = com_google_android_gms_internal_zzjy;
        }

        public View zzhh() {
            return this.mView;
        }

        public boolean zzhi() {
            if (this.zzarb != null) {
                if (this.mView != null) {
                    return false;
                }
            }
            return true;
        }

        public zzck zzhj() {
            return this;
        }
    }

    public static class zzd implements zzck {
        private final WeakReference<View> zzarc;
        private final WeakReference<zzjy> zzard;

        public zzd(View view, zzjy com_google_android_gms_internal_zzjy) {
            this.zzarc = new WeakReference(view);
            this.zzard = new WeakReference(com_google_android_gms_internal_zzjy);
        }

        public View zzhh() {
            return (View) this.zzarc.get();
        }

        public boolean zzhi() {
            if (this.zzarc.get() != null) {
                if (this.zzard.get() != null) {
                    return false;
                }
            }
            return true;
        }

        public zzck zzhj() {
            return new zzc((View) this.zzarc.get(), (zzjy) this.zzard.get());
        }
    }

    public zzcd(Context context, AdSizeParcel adSizeParcel, zzjy com_google_android_gms_internal_zzjy, VersionInfoParcel versionInfoParcel, zzck com_google_android_gms_internal_zzck) {
        this.zzaqf = new WeakReference(com_google_android_gms_internal_zzjy);
        this.zzaqh = com_google_android_gms_internal_zzck;
        this.zzaqg = new WeakReference(null);
        this.zzaqq = true;
        this.zzaqs = false;
        this.zzapz = new zzkv(200);
        this.zzaqi = new zzcf(UUID.randomUUID().toString(), versionInfoParcel, adSizeParcel.zzaup, com_google_android_gms_internal_zzjy.zzcii, com_google_android_gms_internal_zzjy.zzho(), adSizeParcel.zzaus);
        this.zzaqk = (WindowManager) context.getSystemService("window");
        this.zzaql = (PowerManager) context.getApplicationContext().getSystemService("power");
        this.zzaqm = (KeyguardManager) context.getSystemService("keyguard");
        this.zzaqj = context;
    }

    protected void destroy() {
        synchronized (this.zzail) {
            zzhc();
            zzgx();
            this.zzaqq = false;
            zzgz();
        }
    }

    boolean isScreenOn() {
        return this.zzaql.isScreenOn();
    }

    public void onGlobalLayout() {
        zzk(2);
    }

    public void onScrollChanged() {
        zzk(1);
    }

    public void pause() {
        synchronized (this.zzail) {
            this.zzanc = true;
            zzk(3);
        }
    }

    public void resume() {
        synchronized (this.zzail) {
            this.zzanc = false;
            zzk(3);
        }
    }

    public void stop() {
        synchronized (this.zzail) {
            this.zzaqp = true;
            zzk(3);
        }
    }

    protected int zza(int i, DisplayMetrics displayMetrics) {
        return (int) (((float) i) / displayMetrics.density);
    }

    protected void zza(View view, Map<String, String> map) {
        zzk(3);
    }

    public void zza(zzce com_google_android_gms_internal_zzce) {
        this.zzaqu.add(com_google_android_gms_internal_zzce);
    }

    public void zza(zzch com_google_android_gms_internal_zzch) {
        synchronized (this.zzail) {
            this.zzaqn = com_google_android_gms_internal_zzch;
        }
    }

    protected void zza(JSONObject jSONObject) {
        try {
            JSONArray jSONArray = new JSONArray();
            JSONObject jSONObject2 = new JSONObject();
            jSONArray.put(jSONObject);
            jSONObject2.put("units", jSONArray);
            zzb(jSONObject2);
        } catch (Throwable th) {
            com.google.android.gms.ads.internal.util.client.zzb.zzb("Skipping active view message.", th);
        }
    }

    protected abstract void zzb(JSONObject jSONObject);

    protected boolean zzb(Map<String, String> map) {
        boolean z = false;
        if (map == null) {
            return false;
        }
        String str = (String) map.get("hashCode");
        if (!TextUtils.isEmpty(str) && str.equals(this.zzaqi.zzhn())) {
            z = true;
        }
        return z;
    }

    protected void zzc(zzfx com_google_android_gms_internal_zzfx) {
        com_google_android_gms_internal_zzfx.zza("/updateActiveView", this.zzaqv);
        com_google_android_gms_internal_zzfx.zza("/untrackActiveViewUnit", this.zzaqw);
        com_google_android_gms_internal_zzfx.zza("/visibilityChanged", this.zzaqx);
    }

    protected JSONObject zzd(View view) throws JSONException {
        if (view == null) {
            return zzhf();
        }
        boolean isAttachedToWindow = zzu.zzfs().isAttachedToWindow(view);
        int[] iArr = new int[2];
        int[] iArr2 = new int[2];
        try {
            view.getLocationOnScreen(iArr);
            view.getLocationInWindow(iArr2);
        } catch (Throwable e) {
            com.google.android.gms.ads.internal.util.client.zzb.zzb("Failure getting view location.", e);
        }
        DisplayMetrics displayMetrics = view.getContext().getResources().getDisplayMetrics();
        Rect rect = new Rect();
        rect.left = iArr[0];
        rect.top = iArr[1];
        rect.right = rect.left + view.getWidth();
        rect.bottom = rect.top + view.getHeight();
        Rect rect2 = new Rect();
        rect2.right = this.zzaqk.getDefaultDisplay().getWidth();
        rect2.bottom = this.zzaqk.getDefaultDisplay().getHeight();
        Rect rect3 = new Rect();
        boolean globalVisibleRect = view.getGlobalVisibleRect(rect3, null);
        Rect rect4 = new Rect();
        boolean localVisibleRect = view.getLocalVisibleRect(rect4);
        Rect rect5 = new Rect();
        view.getHitRect(rect5);
        JSONObject zzhd = zzhd();
        zzhd.put("windowVisibility", view.getWindowVisibility()).put("isAttachedToWindow", isAttachedToWindow).put("viewBox", new JSONObject().put("top", zza(rect2.top, displayMetrics)).put("bottom", zza(rect2.bottom, displayMetrics)).put("left", zza(rect2.left, displayMetrics)).put("right", zza(rect2.right, displayMetrics))).put("adBox", new JSONObject().put("top", zza(rect.top, displayMetrics)).put("bottom", zza(rect.bottom, displayMetrics)).put("left", zza(rect.left, displayMetrics)).put("right", zza(rect.right, displayMetrics))).put("globalVisibleBox", new JSONObject().put("top", zza(rect3.top, displayMetrics)).put("bottom", zza(rect3.bottom, displayMetrics)).put("left", zza(rect3.left, displayMetrics)).put("right", zza(rect3.right, displayMetrics))).put("globalVisibleBoxVisible", globalVisibleRect).put("localVisibleBox", new JSONObject().put("top", zza(rect4.top, displayMetrics)).put("bottom", zza(rect4.bottom, displayMetrics)).put("left", zza(rect4.left, displayMetrics)).put("right", zza(rect4.right, displayMetrics))).put("localVisibleBoxVisible", localVisibleRect).put("hitBox", new JSONObject().put("top", zza(rect5.top, displayMetrics)).put("bottom", zza(rect5.bottom, displayMetrics)).put("left", zza(rect5.left, displayMetrics)).put("right", zza(rect5.right, displayMetrics))).put("screenDensity", (double) displayMetrics.density).put("isVisible", zzu.zzfq().zza(view, this.zzaql, this.zzaqm));
        return zzhd;
    }

    protected void zzd(zzfx com_google_android_gms_internal_zzfx) {
        com_google_android_gms_internal_zzfx.zzb("/visibilityChanged", this.zzaqx);
        com_google_android_gms_internal_zzfx.zzb("/untrackActiveViewUnit", this.zzaqw);
        com_google_android_gms_internal_zzfx.zzb("/updateActiveView", this.zzaqv);
    }

    protected void zzgw() {
        synchronized (this.zzail) {
            if (this.zzaqt != null) {
                return;
            }
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.SCREEN_ON");
            intentFilter.addAction("android.intent.action.SCREEN_OFF");
            this.zzaqt = new C04031(this);
            this.zzaqj.registerReceiver(this.zzaqt, intentFilter);
        }
    }

    protected void zzgx() {
        synchronized (this.zzail) {
            if (this.zzaqt != null) {
                try {
                    this.zzaqj.unregisterReceiver(this.zzaqt);
                } catch (Throwable e) {
                    com.google.android.gms.ads.internal.util.client.zzb.zzb("Failed trying to unregister the receiver", e);
                } catch (Throwable e2) {
                    zzu.zzft().zzb(e2, true);
                }
                this.zzaqt = null;
            }
        }
    }

    public void zzgy() {
        String str;
        String str2;
        synchronized (this.zzail) {
            if (this.zzaqq) {
                this.zzaqr = true;
                try {
                    zza(zzhg());
                } catch (JSONException e) {
                    Throwable e2 = e;
                    str = "JSON failure while processing active view data.";
                    com.google.android.gms.ads.internal.util.client.zzb.zzb(str, e2);
                    str2 = "Untracking ad unit: ";
                    str = String.valueOf(this.zzaqi.zzhn());
                    com.google.android.gms.ads.internal.util.client.zzb.zzcw(str.length() != 0 ? new String(str2) : str2.concat(str));
                } catch (RuntimeException e3) {
                    e2 = e3;
                    str = "Failure while processing active view data.";
                    com.google.android.gms.ads.internal.util.client.zzb.zzb(str, e2);
                    str2 = "Untracking ad unit: ";
                    str = String.valueOf(this.zzaqi.zzhn());
                    if (str.length() != 0) {
                    }
                    com.google.android.gms.ads.internal.util.client.zzb.zzcw(str.length() != 0 ? new String(str2) : str2.concat(str));
                }
                str2 = "Untracking ad unit: ";
                str = String.valueOf(this.zzaqi.zzhn());
                if (str.length() != 0) {
                }
                com.google.android.gms.ads.internal.util.client.zzb.zzcw(str.length() != 0 ? new String(str2) : str2.concat(str));
            }
        }
    }

    protected void zzgz() {
        if (this.zzaqn != null) {
            this.zzaqn.zza(this);
        }
    }

    public boolean zzha() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzaqq;
        }
        return z;
    }

    protected void zzhb() {
        View zzhh = this.zzaqh.zzhj().zzhh();
        if (zzhh != null) {
            ViewTreeObserver viewTreeObserver = (ViewTreeObserver) this.zzaqg.get();
            ViewTreeObserver viewTreeObserver2 = zzhh.getViewTreeObserver();
            if (viewTreeObserver2 != viewTreeObserver) {
                zzhc();
                if (!this.zzaqo || (viewTreeObserver != null && viewTreeObserver.isAlive())) {
                    this.zzaqo = true;
                    viewTreeObserver2.addOnScrollChangedListener(this);
                    viewTreeObserver2.addOnGlobalLayoutListener(this);
                }
                this.zzaqg = new WeakReference(viewTreeObserver2);
            }
        }
    }

    protected void zzhc() {
        ViewTreeObserver viewTreeObserver = (ViewTreeObserver) this.zzaqg.get();
        if (viewTreeObserver != null && viewTreeObserver.isAlive()) {
            viewTreeObserver.removeOnScrollChangedListener(this);
            viewTreeObserver.removeGlobalOnLayoutListener(this);
        }
    }

    protected JSONObject zzhd() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("afmaVersion", this.zzaqi.zzhl()).put("activeViewJSON", this.zzaqi.zzhm()).put("timestamp", zzu.zzfu().elapsedRealtime()).put("adFormat", this.zzaqi.zzhk()).put("hashCode", this.zzaqi.zzhn()).put("isMraid", this.zzaqi.zzho()).put("isStopped", this.zzaqp).put("isPaused", this.zzanc).put("isScreenOn", isScreenOn()).put("isNative", this.zzaqi.zzhp());
        return jSONObject;
    }

    protected abstract boolean zzhe();

    protected JSONObject zzhf() throws JSONException {
        return zzhd().put("isAttachedToWindow", false).put("isScreenOn", isScreenOn()).put("isVisible", false);
    }

    protected JSONObject zzhg() throws JSONException {
        JSONObject zzhd = zzhd();
        zzhd.put("doneReasonCode", "u");
        return zzhd;
    }

    protected void zzj(boolean z) {
        Iterator it = this.zzaqu.iterator();
        while (it.hasNext()) {
            ((zzce) it.next()).zza(this, z);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void zzk(int r8) {
        /*
        r7 = this;
        r0 = r7.zzail;
        monitor-enter(r0);
        r1 = r7.zzhe();	 Catch:{ all -> 0x007a }
        if (r1 == 0) goto L_0x0078;
    L_0x0009:
        r1 = r7.zzaqq;	 Catch:{ all -> 0x007a }
        if (r1 != 0) goto L_0x000f;
    L_0x000d:
        goto L_0x0078;
    L_0x000f:
        r1 = r7.zzaqh;	 Catch:{ all -> 0x007a }
        r1 = r1.zzhh();	 Catch:{ all -> 0x007a }
        r2 = 0;
        r3 = 1;
        if (r1 == 0) goto L_0x0035;
    L_0x0019:
        r4 = com.google.android.gms.ads.internal.zzu.zzfq();	 Catch:{ all -> 0x007a }
        r5 = r7.zzaql;	 Catch:{ all -> 0x007a }
        r6 = r7.zzaqm;	 Catch:{ all -> 0x007a }
        r4 = r4.zza(r1, r5, r6);	 Catch:{ all -> 0x007a }
        if (r4 == 0) goto L_0x0035;
    L_0x0027:
        r4 = new android.graphics.Rect;	 Catch:{ all -> 0x007a }
        r4.<init>();	 Catch:{ all -> 0x007a }
        r5 = 0;
        r4 = r1.getGlobalVisibleRect(r4, r5);	 Catch:{ all -> 0x007a }
        if (r4 == 0) goto L_0x0035;
    L_0x0033:
        r4 = r3;
        goto L_0x0036;
    L_0x0035:
        r4 = r2;
    L_0x0036:
        r7.zzaqs = r4;	 Catch:{ all -> 0x007a }
        r5 = r7.zzaqh;	 Catch:{ all -> 0x007a }
        r5 = r5.zzhi();	 Catch:{ all -> 0x007a }
        if (r5 == 0) goto L_0x0045;
    L_0x0040:
        r7.zzgy();	 Catch:{ all -> 0x007a }
        monitor-exit(r0);	 Catch:{ all -> 0x007a }
        return;
    L_0x0045:
        if (r8 != r3) goto L_0x0048;
    L_0x0047:
        r2 = r3;
    L_0x0048:
        if (r2 == 0) goto L_0x0058;
    L_0x004a:
        r2 = r7.zzapz;	 Catch:{ all -> 0x007a }
        r2 = r2.tryAcquire();	 Catch:{ all -> 0x007a }
        if (r2 != 0) goto L_0x0058;
    L_0x0052:
        r2 = r7.zzaqs;	 Catch:{ all -> 0x007a }
        if (r4 != r2) goto L_0x0058;
    L_0x0056:
        monitor-exit(r0);	 Catch:{ all -> 0x007a }
        return;
    L_0x0058:
        if (r4 != 0) goto L_0x0062;
    L_0x005a:
        r2 = r7.zzaqs;	 Catch:{ all -> 0x007a }
        if (r2 != 0) goto L_0x0062;
    L_0x005e:
        if (r8 != r3) goto L_0x0062;
    L_0x0060:
        monitor-exit(r0);	 Catch:{ all -> 0x007a }
        return;
    L_0x0062:
        r8 = r7.zzd(r1);	 Catch:{ JSONException -> 0x006a, JSONException -> 0x006a }
        r7.zza(r8);	 Catch:{ JSONException -> 0x006a, JSONException -> 0x006a }
        goto L_0x0070;
    L_0x006a:
        r8 = move-exception;
        r1 = "Active view update failed.";
        com.google.android.gms.ads.internal.util.client.zzb.zza(r1, r8);	 Catch:{ all -> 0x007a }
    L_0x0070:
        r7.zzhb();	 Catch:{ all -> 0x007a }
        r7.zzgz();	 Catch:{ all -> 0x007a }
        monitor-exit(r0);	 Catch:{ all -> 0x007a }
        return;
    L_0x0078:
        monitor-exit(r0);	 Catch:{ all -> 0x007a }
        return;
    L_0x007a:
        r8 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x007a }
        throw r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzcd.zzk(int):void");
    }
}
