package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class zzaox<M extends zzaow<M>, T> {
    protected final Class<T> bau;
    protected final boolean bic;
    public final int tag;
    protected final int type;

    private zzaox(int i, Class<T> cls, int i2, boolean z) {
        this.type = i;
        this.bau = cls;
        this.tag = i2;
        this.bic = z;
    }

    public static <M extends zzaow<M>, T extends zzapc> zzaox<M, T> zza(int i, Class<T> cls, long j) {
        return new zzaox(i, cls, (int) j, false);
    }

    private T zzaw(List<zzape> list) {
        List arrayList = new ArrayList();
        int i = 0;
        for (int i2 = 0; i2 < list.size(); i2++) {
            zzape com_google_android_gms_internal_zzape = (zzape) list.get(i2);
            if (com_google_android_gms_internal_zzape.bil.length != 0) {
                zza(com_google_android_gms_internal_zzape, arrayList);
            }
        }
        int size = arrayList.size();
        if (size == 0) {
            return null;
        }
        T cast = this.bau.cast(Array.newInstance(this.bau.getComponentType(), size));
        while (i < size) {
            Array.set(cast, i, arrayList.get(i));
            i++;
        }
        return cast;
    }

    private T zzax(List<zzape> list) {
        if (list.isEmpty()) {
            return null;
        }
        return this.bau.cast(zzcf(zzaou.zzaz(((zzape) list.get(list.size() - 1)).bil)));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzaox)) {
            return false;
        }
        zzaox com_google_android_gms_internal_zzaox = (zzaox) obj;
        return this.type == com_google_android_gms_internal_zzaox.type && this.bau == com_google_android_gms_internal_zzaox.bau && this.tag == com_google_android_gms_internal_zzaox.tag && this.bic == com_google_android_gms_internal_zzaox.bic;
    }

    public int hashCode() {
        return (31 * (((((1147 + this.type) * 31) + this.bau.hashCode()) * 31) + this.tag)) + this.bic;
    }

    protected void zza(zzape com_google_android_gms_internal_zzape, List<Object> list) {
        list.add(zzcf(zzaou.zzaz(com_google_android_gms_internal_zzape.bil)));
    }

    void zza(Object obj, zzaov com_google_android_gms_internal_zzaov) throws IOException {
        if (this.bic) {
            zzc(obj, com_google_android_gms_internal_zzaov);
        } else {
            zzb(obj, com_google_android_gms_internal_zzaov);
        }
    }

    final T zzav(List<zzape> list) {
        return list == null ? null : this.bic ? zzaw(list) : zzax(list);
    }

    protected void zzb(Object obj, zzaov com_google_android_gms_internal_zzaov) {
        try {
            com_google_android_gms_internal_zzaov.zzaes(this.tag);
            switch (this.type) {
                case 10:
                    zzapc com_google_android_gms_internal_zzapc = (zzapc) obj;
                    int zzafa = zzapf.zzafa(this.tag);
                    com_google_android_gms_internal_zzaov.zzb(com_google_android_gms_internal_zzapc);
                    com_google_android_gms_internal_zzaov.zzai(zzafa, 4);
                    return;
                case 11:
                    com_google_android_gms_internal_zzaov.zzc((zzapc) obj);
                    return;
                default:
                    int i = this.type;
                    StringBuilder stringBuilder = new StringBuilder(24);
                    stringBuilder.append("Unknown type ");
                    stringBuilder.append(i);
                    throw new IllegalArgumentException(stringBuilder.toString());
            }
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    protected void zzc(Object obj, zzaov com_google_android_gms_internal_zzaov) {
        int length = Array.getLength(obj);
        for (int i = 0; i < length; i++) {
            Object obj2 = Array.get(obj, i);
            if (obj2 != null) {
                zzb(obj2, com_google_android_gms_internal_zzaov);
            }
        }
    }

    protected Object zzcf(zzaou com_google_android_gms_internal_zzaou) {
        StringBuilder stringBuilder;
        String valueOf;
        Class componentType = this.bic ? this.bau.getComponentType() : this.bau;
        try {
            zzapc com_google_android_gms_internal_zzapc;
            switch (this.type) {
                case 10:
                    com_google_android_gms_internal_zzapc = (zzapc) componentType.newInstance();
                    com_google_android_gms_internal_zzaou.zza(com_google_android_gms_internal_zzapc, zzapf.zzafa(this.tag));
                    return com_google_android_gms_internal_zzapc;
                case 11:
                    com_google_android_gms_internal_zzapc = (zzapc) componentType.newInstance();
                    com_google_android_gms_internal_zzaou.zza(com_google_android_gms_internal_zzapc);
                    return com_google_android_gms_internal_zzapc;
                default:
                    int i = this.type;
                    stringBuilder = new StringBuilder(24);
                    stringBuilder.append("Unknown type ");
                    stringBuilder.append(i);
                    throw new IllegalArgumentException(stringBuilder.toString());
            }
        } catch (Throwable e) {
            valueOf = String.valueOf(componentType);
            stringBuilder = new StringBuilder(33 + String.valueOf(valueOf).length());
            stringBuilder.append("Error creating instance of class ");
            stringBuilder.append(valueOf);
            throw new IllegalArgumentException(stringBuilder.toString(), e);
        } catch (Throwable e2) {
            valueOf = String.valueOf(componentType);
            stringBuilder = new StringBuilder(33 + String.valueOf(valueOf).length());
            stringBuilder.append("Error creating instance of class ");
            stringBuilder.append(valueOf);
            throw new IllegalArgumentException(stringBuilder.toString(), e2);
        } catch (Throwable e22) {
            throw new IllegalArgumentException("Error reading extension field", e22);
        }
    }

    int zzcr(Object obj) {
        return this.bic ? zzcs(obj) : zzct(obj);
    }

    protected int zzcs(Object obj) {
        int length = Array.getLength(obj);
        int i = 0;
        int i2 = 0;
        while (i < length) {
            if (Array.get(obj, i) != null) {
                i2 += zzct(Array.get(obj, i));
            }
            i++;
        }
        return i2;
    }

    protected int zzct(Object obj) {
        int zzafa = zzapf.zzafa(this.tag);
        switch (this.type) {
            case 10:
                return zzaov.zzb(zzafa, (zzapc) obj);
            case 11:
                return zzaov.zzc(zzafa, (zzapc) obj);
            default:
                zzafa = this.type;
                StringBuilder stringBuilder = new StringBuilder(24);
                stringBuilder.append("Unknown type ");
                stringBuilder.append(zzafa);
                throw new IllegalArgumentException(stringBuilder.toString());
        }
    }
}
