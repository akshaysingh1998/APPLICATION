package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

@zzir
public class zzcm {
    private final Object zzail = new Object();
    private int zzasf;
    private List<zzcl> zzasg = new LinkedList();

    public boolean zza(zzcl com_google_android_gms_internal_zzcl) {
        synchronized (this.zzail) {
            if (this.zzasg.contains(com_google_android_gms_internal_zzcl)) {
                return true;
            }
            return false;
        }
    }

    public boolean zzb(zzcl com_google_android_gms_internal_zzcl) {
        synchronized (this.zzail) {
            Iterator it = this.zzasg.iterator();
            while (it.hasNext()) {
                zzcl com_google_android_gms_internal_zzcl2 = (zzcl) it.next();
                if (com_google_android_gms_internal_zzcl != com_google_android_gms_internal_zzcl2 && com_google_android_gms_internal_zzcl2.zzhr().equals(com_google_android_gms_internal_zzcl.zzhr())) {
                    it.remove();
                    return true;
                }
            }
            return false;
        }
    }

    public void zzc(zzcl com_google_android_gms_internal_zzcl) {
        synchronized (this.zzail) {
            int size;
            if (this.zzasg.size() >= 10) {
                size = this.zzasg.size();
                StringBuilder stringBuilder = new StringBuilder(41);
                stringBuilder.append("Queue is full, current size = ");
                stringBuilder.append(size);
                zzb.zzcw(stringBuilder.toString());
                this.zzasg.remove(0);
            }
            size = this.zzasf;
            this.zzasf = size + 1;
            com_google_android_gms_internal_zzcl.zzl(size);
            this.zzasg.add(com_google_android_gms_internal_zzcl);
        }
    }

    public zzcl zzhy() {
        synchronized (this.zzail) {
            zzcl com_google_android_gms_internal_zzcl = null;
            if (this.zzasg.size() == 0) {
                zzb.zzcw("Queue empty");
                return null;
            } else if (this.zzasg.size() >= 2) {
                int i = Integer.MIN_VALUE;
                for (zzcl com_google_android_gms_internal_zzcl2 : this.zzasg) {
                    int score = com_google_android_gms_internal_zzcl2.getScore();
                    if (score > i) {
                        com_google_android_gms_internal_zzcl = com_google_android_gms_internal_zzcl2;
                        i = score;
                    }
                }
                this.zzasg.remove(com_google_android_gms_internal_zzcl);
                return com_google_android_gms_internal_zzcl;
            } else {
                zzcl com_google_android_gms_internal_zzcl3 = (zzcl) this.zzasg.get(0);
                com_google_android_gms_internal_zzcl3.zzht();
                return com_google_android_gms_internal_zzcl3;
            }
        }
    }
}
