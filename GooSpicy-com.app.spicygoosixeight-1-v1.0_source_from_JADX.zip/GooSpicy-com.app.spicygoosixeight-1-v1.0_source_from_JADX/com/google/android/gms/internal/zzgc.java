package com.google.android.gms.internal;

import java.util.List;

public interface zzgc {
    void cancel();

    zzgi zzd(List<zzgd> list);

    List<zzgi> zzmi();
}
