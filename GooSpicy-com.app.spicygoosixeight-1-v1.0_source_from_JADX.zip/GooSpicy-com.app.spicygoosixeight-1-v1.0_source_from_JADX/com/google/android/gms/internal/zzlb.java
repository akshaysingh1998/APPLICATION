package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

@zzir
public class zzlb {

    class C04831 implements Runnable {
        final /* synthetic */ zzkz zzcnu;
        final /* synthetic */ zza zzcnv;
        final /* synthetic */ zzlc zzcnw;

        C04831(zzkz com_google_android_gms_internal_zzkz, zza com_google_android_gms_internal_zzlb_zza, zzlc com_google_android_gms_internal_zzlc) {
            this.zzcnu = com_google_android_gms_internal_zzkz;
            this.zzcnv = com_google_android_gms_internal_zzlb_zza;
            this.zzcnw = com_google_android_gms_internal_zzlc;
        }

        public void run() {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            r0 = r3.zzcnu;	 Catch:{ CancellationException -> 0x0012, CancellationException -> 0x0012, CancellationException -> 0x0012 }
            r1 = r3.zzcnv;	 Catch:{ CancellationException -> 0x0012, CancellationException -> 0x0012, CancellationException -> 0x0012 }
            r2 = r3.zzcnw;	 Catch:{ CancellationException -> 0x0012, CancellationException -> 0x0012, CancellationException -> 0x0012 }
            r2 = r2.get();	 Catch:{ CancellationException -> 0x0012, CancellationException -> 0x0012, CancellationException -> 0x0012 }
            r1 = r1.zzh(r2);	 Catch:{ CancellationException -> 0x0012, CancellationException -> 0x0012, CancellationException -> 0x0012 }
            r0.zzi(r1);	 Catch:{ CancellationException -> 0x0012, CancellationException -> 0x0012, CancellationException -> 0x0012 }
            return;
        L_0x0012:
            r0 = r3.zzcnu;
            r1 = 1;
            r0.cancel(r1);
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzlb.1.run():void");
        }
    }

    class C04842 implements Runnable {
        final /* synthetic */ AtomicInteger zzcnx;
        final /* synthetic */ int zzcny;
        final /* synthetic */ zzkz zzcnz;
        final /* synthetic */ List zzcoa;

        C04842(AtomicInteger atomicInteger, int i, zzkz com_google_android_gms_internal_zzkz, List list) {
            this.zzcnx = atomicInteger;
            this.zzcny = i;
            this.zzcnz = com_google_android_gms_internal_zzkz;
            this.zzcoa = list;
        }

        public void run() {
            if (this.zzcnx.incrementAndGet() >= this.zzcny) {
                try {
                    this.zzcnz.zzi(zzlb.zzo(this.zzcoa));
                } catch (Throwable e) {
                    zzb.zzd("Unable to convert list of futures to a future of list", e);
                }
            }
        }
    }

    public interface zza<D, R> {
        R zzh(D d);
    }

    public static <A, B> zzlc<B> zza(zzlc<A> com_google_android_gms_internal_zzlc_A, zza<A, B> com_google_android_gms_internal_zzlb_zza_A__B) {
        zzlc com_google_android_gms_internal_zzkz = new zzkz();
        com_google_android_gms_internal_zzlc_A.zzb(new C04831(com_google_android_gms_internal_zzkz, com_google_android_gms_internal_zzlb_zza_A__B, com_google_android_gms_internal_zzlc_A));
        return com_google_android_gms_internal_zzkz;
    }

    public static <V> zzlc<List<V>> zzn(List<zzlc<V>> list) {
        zzlc com_google_android_gms_internal_zzkz = new zzkz();
        int size = list.size();
        AtomicInteger atomicInteger = new AtomicInteger(0);
        for (zzlc zzb : list) {
            zzb.zzb(new C04842(atomicInteger, size, com_google_android_gms_internal_zzkz, list));
        }
        return com_google_android_gms_internal_zzkz;
    }

    private static <V> List<V> zzo(List<zzlc<V>> list) throws ExecutionException, InterruptedException {
        List<V> arrayList = new ArrayList();
        for (zzlc com_google_android_gms_internal_zzlc : list) {
            Object obj = com_google_android_gms_internal_zzlc.get();
            if (obj != null) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }
}
