package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzq;
import com.google.android.gms.internal.zzfw.zzb;
import com.google.android.gms.internal.zzfw.zze;
import com.google.android.gms.internal.zzle.zzc;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@zzir
public class zzil {
    private static final Object zzamp = new Object();
    private static final long zzbyx = TimeUnit.SECONDS.toMillis(60);
    private static boolean zzbyy = false;
    private static zzfw zzbyz;
    private final Context mContext;
    private final zzq zzbgb;
    private final zzas zzbgh;
    private final com.google.android.gms.internal.zzjy.zza zzbxv;
    private zzfu zzbza;
    private zze zzbzb;
    private zzft zzbzc;
    private boolean zzbzd = false;

    public static abstract class zza {
        public abstract void zze(zzfx com_google_android_gms_internal_zzfx);

        public void zzqr() {
        }
    }

    class C09303 implements zzkp<zzft> {
        final /* synthetic */ zzil zzbzf;

        C09303(zzil com_google_android_gms_internal_zzil) {
            this.zzbzf = com_google_android_gms_internal_zzil;
        }

        public void zza(zzft com_google_android_gms_internal_zzft) {
            com_google_android_gms_internal_zzft.zza(this.zzbzf.zzbgb, this.zzbzf.zzbgb, this.zzbzf.zzbgb, this.zzbzf.zzbgb, false, null, null, null, null);
        }

        public /* synthetic */ void zzd(Object obj) {
            zza((zzft) obj);
        }
    }

    public zzil(Context context, com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza, zzq com_google_android_gms_ads_internal_zzq, zzas com_google_android_gms_internal_zzas) {
        this.mContext = context;
        this.zzbxv = com_google_android_gms_internal_zzjy_zza;
        this.zzbgb = com_google_android_gms_ads_internal_zzq;
        this.zzbgh = com_google_android_gms_internal_zzas;
        this.zzbzd = ((Boolean) zzdc.zzbcd.get()).booleanValue();
    }

    private String zzd(com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza) {
        String str = (String) zzdc.zzbaa.get();
        String valueOf = String.valueOf(com_google_android_gms_internal_zzjy_zza.zzciu.zzbts.indexOf("https") == 0 ? "https:" : "http:");
        str = String.valueOf(str);
        return str.length() != 0 ? valueOf.concat(str) : new String(valueOf);
    }

    private void zzqj() {
        synchronized (zzamp) {
            if (!zzbyy) {
                zzbyz = new zzfw(this.mContext.getApplicationContext() != null ? this.mContext.getApplicationContext() : this.mContext, this.zzbxv.zzcit.zzaou, zzd(this.zzbxv), new C09303(this), new zzb());
                zzbyy = true;
            }
        }
    }

    private void zzqk() {
        this.zzbzb = new zze(zzqp().zzc(this.zzbgh));
    }

    private void zzql() {
        this.zzbza = new zzfu();
    }

    private void zzqm() throws CancellationException, ExecutionException, InterruptedException, TimeoutException {
        this.zzbzc = (zzft) zzqn().zza(this.mContext, this.zzbxv.zzcit.zzaou, zzd(this.zzbxv), this.zzbgh).get(zzbyx, TimeUnit.MILLISECONDS);
        this.zzbzc.zza(this.zzbgb, this.zzbgb, this.zzbgb, this.zzbgb, false, null, null, null, null);
    }

    public void zza(final zza com_google_android_gms_internal_zzil_zza) {
        String str;
        if (this.zzbzd) {
            zze zzqq = zzqq();
            if (zzqq == null) {
                str = "SharedJavascriptEngine not initialized";
            } else {
                zzqq.zza(new zzc<zzfx>(this) {
                    final /* synthetic */ zzil zzbzf;

                    public void zzb(zzfx com_google_android_gms_internal_zzfx) {
                        com_google_android_gms_internal_zzil_zza.zze(com_google_android_gms_internal_zzfx);
                    }

                    public /* synthetic */ void zzd(Object obj) {
                        zzb((zzfx) obj);
                    }
                }, new com.google.android.gms.internal.zzle.zza(this) {
                    final /* synthetic */ zzil zzbzf;

                    public void run() {
                        com_google_android_gms_internal_zzil_zza.zzqr();
                    }
                });
                return;
            }
        }
        zzfx zzqo = zzqo();
        if (zzqo == null) {
            str = "JavascriptEngine not initialized";
        } else {
            com_google_android_gms_internal_zzil_zza.zze(zzqo);
            return;
        }
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(str);
    }

    public void zzqh() {
        if (this.zzbzd) {
            zzqj();
        } else {
            zzql();
        }
    }

    public void zzqi() throws CancellationException, ExecutionException, InterruptedException, TimeoutException {
        if (this.zzbzd) {
            zzqk();
        } else {
            zzqm();
        }
    }

    protected zzfu zzqn() {
        return this.zzbza;
    }

    protected zzft zzqo() {
        return this.zzbzc;
    }

    protected zzfw zzqp() {
        return zzbyz;
    }

    protected zze zzqq() {
        return this.zzbzb;
    }
}
