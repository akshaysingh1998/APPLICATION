package com.google.android.gms.internal;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.zzu;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public class zzka {
    private final long zzcjg;
    private final List<String> zzcjh = new ArrayList();
    private final Map<String, zzb> zzcji = new HashMap();
    private String zzcjj;
    private String zzcjk;
    private boolean zzcjl = false;

    class zza {
        private final List<String> zzcjm;
        private final Bundle zzcjn;
        final /* synthetic */ zzka zzcjo;

        public zza(zzka com_google_android_gms_internal_zzka, List<String> list, Bundle bundle) {
            this.zzcjo = com_google_android_gms_internal_zzka;
            this.zzcjm = list;
            this.zzcjn = bundle;
        }
    }

    class zzb {
        final /* synthetic */ zzka zzcjo;
        final List<zza> zzcjp = new ArrayList();

        zzb(zzka com_google_android_gms_internal_zzka) {
            this.zzcjo = com_google_android_gms_internal_zzka;
        }

        public void zza(zza com_google_android_gms_internal_zzka_zza) {
            this.zzcjp.add(com_google_android_gms_internal_zzka_zza);
        }
    }

    public zzka(String str, long j) {
        this.zzcjk = str;
        this.zzcjg = j;
        zzcm(str);
    }

    private void zzcm(String str) {
        if (!TextUtils.isEmpty(str)) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                int i = 0;
                if (jSONObject.optInt("status", -1) != 1) {
                    this.zzcjl = false;
                    com.google.android.gms.ads.internal.util.client.zzb.zzcy("App settings could not be fetched successfully.");
                    return;
                }
                this.zzcjl = true;
                this.zzcjj = jSONObject.optString("app_id");
                JSONArray optJSONArray = jSONObject.optJSONArray("ad_unit_id_settings");
                if (optJSONArray != null) {
                    while (i < optJSONArray.length()) {
                        zzi(optJSONArray.getJSONObject(i));
                        i++;
                    }
                }
            } catch (Throwable e) {
                com.google.android.gms.ads.internal.util.client.zzb.zzd("Exception occurred while processing app setting json", e);
                zzu.zzft().zzb(e, true);
            }
        }
    }

    private void zzi(JSONObject jSONObject) throws JSONException {
        String optString = jSONObject.optString("format");
        CharSequence optString2 = jSONObject.optString("ad_unit_id");
        if (!TextUtils.isEmpty(optString) && !TextUtils.isEmpty(optString2)) {
            if ("interstitial".equalsIgnoreCase(optString)) {
                this.zzcjh.add(optString2);
                return;
            }
            if ("rewarded".equalsIgnoreCase(optString)) {
                jSONObject = jSONObject.optJSONObject("mediation_config");
                if (jSONObject != null) {
                    JSONArray optJSONArray = jSONObject.optJSONArray("ad_networks");
                    if (optJSONArray != null) {
                        int i = 0;
                        while (i < optJSONArray.length()) {
                            JSONObject jSONObject2 = optJSONArray.getJSONObject(i);
                            JSONArray optJSONArray2 = jSONObject2.optJSONArray("adapters");
                            if (optJSONArray2 != null) {
                                List arrayList = new ArrayList();
                                for (int i2 = 0; i2 < optJSONArray2.length(); i2++) {
                                    arrayList.add(optJSONArray2.getString(i2));
                                }
                                jSONObject2 = jSONObject2.optJSONObject("data");
                                if (jSONObject2 != null) {
                                    Bundle bundle = new Bundle();
                                    Iterator keys = jSONObject2.keys();
                                    while (keys.hasNext()) {
                                        String str = (String) keys.next();
                                        bundle.putString(str, jSONObject2.getString(str));
                                    }
                                    zza com_google_android_gms_internal_zzka_zza = new zza(this, arrayList, bundle);
                                    zzb com_google_android_gms_internal_zzka_zzb = this.zzcji.containsKey(optString2) ? (zzb) this.zzcji.get(optString2) : new zzb(this);
                                    com_google_android_gms_internal_zzka_zzb.zza(com_google_android_gms_internal_zzka_zza);
                                    this.zzcji.put(optString2, com_google_android_gms_internal_zzka_zzb);
                                    i++;
                                } else {
                                    return;
                                }
                            }
                            return;
                        }
                    }
                }
            }
        }
    }

    public long zzsf() {
        return this.zzcjg;
    }

    public boolean zzsg() {
        return this.zzcjl;
    }

    public String zzsh() {
        return this.zzcjk;
    }

    public String zzsi() {
        return this.zzcjj;
    }
}
