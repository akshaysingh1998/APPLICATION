package com.google.android.gms.internal;

import java.util.concurrent.Future;

@zzir
public abstract class zzkg implements zzkn<Future> {
    private volatile Thread zzcko;
    private boolean zzckp;
    private final Runnable zzw;

    class C04701 implements Runnable {
        final /* synthetic */ zzkg zzckq;

        C04701(zzkg com_google_android_gms_internal_zzkg) {
            this.zzckq = com_google_android_gms_internal_zzkg;
        }

        public final void run() {
            this.zzckq.zzcko = Thread.currentThread();
            this.zzckq.zzew();
        }
    }

    public zzkg() {
        this.zzw = new C04701(this);
        this.zzckp = false;
    }

    public zzkg(boolean z) {
        this.zzw = new C04701(this);
        this.zzckp = z;
    }

    public final void cancel() {
        onStop();
        if (this.zzcko != null) {
            this.zzcko.interrupt();
        }
    }

    public abstract void onStop();

    public abstract void zzew();

    public /* synthetic */ Object zzpz() {
        return zzta();
    }

    public final Future zzta() {
        return this.zzckp ? zzkk.zza(1, this.zzw) : zzkk.zza(this.zzw);
    }
}
