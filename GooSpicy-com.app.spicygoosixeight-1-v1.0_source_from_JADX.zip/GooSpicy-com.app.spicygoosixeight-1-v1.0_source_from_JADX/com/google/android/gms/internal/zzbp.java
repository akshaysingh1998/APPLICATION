package com.google.android.gms.internal;

import com.google.android.gms.internal.zzae.zza;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;

public abstract class zzbp implements Callable {
    protected final String TAG = getClass().getSimpleName();
    protected final String className;
    protected final zzax zzaey;
    protected final zza zzaha;
    protected final String zzahf;
    protected Method zzahh;
    protected final int zzahl;
    protected final int zzahm;

    public zzbp(zzax com_google_android_gms_internal_zzax, String str, String str2, zza com_google_android_gms_internal_zzae_zza, int i, int i2) {
        this.zzaey = com_google_android_gms_internal_zzax;
        this.className = str;
        this.zzahf = str2;
        this.zzaha = com_google_android_gms_internal_zzae_zza;
        this.zzahl = i;
        this.zzahm = i2;
    }

    public /* synthetic */ Object call() throws Exception {
        return zzcy();
    }

    protected abstract void zzcv() throws IllegalAccessException, InvocationTargetException;

    public java.lang.Void zzcy() throws java.lang.Exception {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r10 = this;
        r0 = 0;
        r1 = java.lang.System.nanoTime();	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r3 = r10.zzaey;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r4 = r10.className;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r5 = r10.zzahf;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r3 = r3.zzc(r4, r5);	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r10.zzahh = r3;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r3 = r10.zzahh;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        if (r3 != 0) goto L_0x0016;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
    L_0x0015:
        return r0;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
    L_0x0016:
        r10.zzcv();	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r3 = r10.zzaey;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r3 = r3.zzcl();	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        if (r3 == 0) goto L_0x0037;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
    L_0x0021:
        r4 = r10.zzahl;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r5 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        if (r4 == r5) goto L_0x0037;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
    L_0x0027:
        r4 = r10.zzahm;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r5 = r10.zzahl;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r6 = java.lang.System.nanoTime();	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r8 = r6 - r1;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r1 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r8 = r8 / r1;	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
        r3.zza(r4, r5, r8);	 Catch:{ IllegalAccessException -> 0x0037, IllegalAccessException -> 0x0037 }
    L_0x0037:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzbp.zzcy():java.lang.Void");
    }
}
