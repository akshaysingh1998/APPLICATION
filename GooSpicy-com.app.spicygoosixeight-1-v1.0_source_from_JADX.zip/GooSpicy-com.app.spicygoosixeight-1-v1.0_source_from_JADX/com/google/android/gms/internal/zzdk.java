package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.zzu;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@zzir
public class zzdk {
    private final Object zzail = new Object();
    boolean zzbdm;
    private final List<zzdi> zzbed = new LinkedList();
    private final Map<String, String> zzbee = new LinkedHashMap();
    private String zzbef;
    private zzdi zzbeg;
    private zzdk zzbeh;

    public zzdk(boolean z, String str, String str2) {
        this.zzbdm = z;
        this.zzbee.put("action", str);
        this.zzbee.put("ad_format", str2);
    }

    public boolean zza(zzdi com_google_android_gms_internal_zzdi, long j, String... strArr) {
        synchronized (this.zzail) {
            for (String com_google_android_gms_internal_zzdi2 : strArr) {
                this.zzbed.add(new zzdi(j, com_google_android_gms_internal_zzdi2, com_google_android_gms_internal_zzdi));
            }
        }
        return true;
    }

    public boolean zza(@Nullable zzdi com_google_android_gms_internal_zzdi, String... strArr) {
        if (this.zzbdm) {
            if (com_google_android_gms_internal_zzdi != null) {
                return zza(com_google_android_gms_internal_zzdi, zzu.zzfu().elapsedRealtime(), strArr);
            }
        }
        return false;
    }

    public void zzas(String str) {
        if (this.zzbdm) {
            synchronized (this.zzail) {
                this.zzbef = str;
            }
        }
    }

    @Nullable
    public zzdi zzc(long j) {
        return !this.zzbdm ? null : new zzdi(j, null, null);
    }

    public void zzc(zzdk com_google_android_gms_internal_zzdk) {
        synchronized (this.zzail) {
            this.zzbeh = com_google_android_gms_internal_zzdk;
        }
    }

    public void zzh(String str, String str2) {
        if (this.zzbdm && !TextUtils.isEmpty(str2)) {
            zzde zzsm = zzu.zzft().zzsm();
            if (zzsm != null) {
                synchronized (this.zzail) {
                    zzsm.zzaq(str).zza(this.zzbee, str, str2);
                }
            }
        }
    }

    public zzdi zzkg() {
        return zzc(zzu.zzfu().elapsedRealtime());
    }

    public void zzkh() {
        synchronized (this.zzail) {
            this.zzbeg = zzkg();
        }
    }

    public String zzki() {
        String stringBuilder;
        StringBuilder stringBuilder2 = new StringBuilder();
        synchronized (this.zzail) {
            for (zzdi com_google_android_gms_internal_zzdi : this.zzbed) {
                long time = com_google_android_gms_internal_zzdi.getTime();
                String zzkd = com_google_android_gms_internal_zzdi.zzkd();
                zzdi com_google_android_gms_internal_zzdi2 = com_google_android_gms_internal_zzdi2.zzke();
                if (com_google_android_gms_internal_zzdi2 != null && time > 0) {
                    long time2 = time - com_google_android_gms_internal_zzdi2.getTime();
                    stringBuilder2.append(zzkd);
                    stringBuilder2.append('.');
                    stringBuilder2.append(time2);
                    stringBuilder2.append(',');
                }
            }
            this.zzbed.clear();
            if (!TextUtils.isEmpty(this.zzbef)) {
                stringBuilder2.append(this.zzbef);
            } else if (stringBuilder2.length() > 0) {
                stringBuilder2.setLength(stringBuilder2.length() - 1);
            }
            stringBuilder = stringBuilder2.toString();
        }
        return stringBuilder;
    }

    public zzdi zzkj() {
        zzdi com_google_android_gms_internal_zzdi;
        synchronized (this.zzail) {
            com_google_android_gms_internal_zzdi = this.zzbeg;
        }
        return com_google_android_gms_internal_zzdi;
    }

    Map<String, String> zzm() {
        synchronized (this.zzail) {
            Map<String, String> zza;
            zzde zzsm = zzu.zzft().zzsm();
            if (zzsm != null) {
                if (this.zzbeh != null) {
                    zza = zzsm.zza(this.zzbee, this.zzbeh.zzm());
                    return zza;
                }
            }
            zza = this.zzbee;
            return zza;
        }
    }
}
