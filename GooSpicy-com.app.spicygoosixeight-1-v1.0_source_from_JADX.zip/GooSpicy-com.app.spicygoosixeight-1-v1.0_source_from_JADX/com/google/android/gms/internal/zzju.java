package com.google.android.gms.internal;

public interface zzju {
    String zzcl(String str);
}
