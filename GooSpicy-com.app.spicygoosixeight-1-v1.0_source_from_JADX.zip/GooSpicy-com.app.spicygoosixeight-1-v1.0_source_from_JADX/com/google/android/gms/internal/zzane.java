package com.google.android.gms.internal;

import java.math.BigInteger;

public final class zzane extends zzamy {
    private static final Class<?>[] beu = new Class[]{Integer.TYPE, Long.TYPE, Short.TYPE, Float.TYPE, Double.TYPE, Byte.TYPE, Boolean.TYPE, Character.TYPE, Integer.class, Long.class, Short.class, Float.class, Double.class, Byte.class, Boolean.class, Character.class};
    private Object aQx;

    public zzane(Boolean bool) {
        setValue(bool);
    }

    public zzane(Number number) {
        setValue(number);
    }

    public zzane(String str) {
        setValue(str);
    }

    private static boolean zza(zzane com_google_android_gms_internal_zzane) {
        if (!(com_google_android_gms_internal_zzane.aQx instanceof Number)) {
            return false;
        }
        Number number = (Number) com_google_android_gms_internal_zzane.aQx;
        return (number instanceof BigInteger) || (number instanceof Long) || (number instanceof Integer) || (number instanceof Short) || (number instanceof Byte);
    }

    private static boolean zzck(Object obj) {
        if (obj instanceof String) {
            return true;
        }
        Class cls = obj.getClass();
        for (Class isAssignableFrom : beu) {
            if (isAssignableFrom.isAssignableFrom(cls)) {
                return true;
            }
        }
        return false;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzane com_google_android_gms_internal_zzane = (zzane) obj;
        if (this.aQx == null) {
            return com_google_android_gms_internal_zzane.aQx == null;
        } else {
            if (zza(this) && zza(com_google_android_gms_internal_zzane)) {
                return zzczg().longValue() == com_google_android_gms_internal_zzane.zzczg().longValue();
            } else {
                if (!(this.aQx instanceof Number) || !(com_google_android_gms_internal_zzane.aQx instanceof Number)) {
                    return this.aQx.equals(com_google_android_gms_internal_zzane.aQx);
                }
                double doubleValue = zzczg().doubleValue();
                double doubleValue2 = com_google_android_gms_internal_zzane.zzczg().doubleValue();
                if (doubleValue != doubleValue2) {
                    if (Double.isNaN(doubleValue) && Double.isNaN(doubleValue2)) {
                        return true;
                    }
                    z = false;
                }
                return z;
            }
        }
    }

    public int hashCode() {
        if (this.aQx == null) {
            return 31;
        }
        long longValue;
        if (zza(this)) {
            longValue = zzczg().longValue();
            return (int) (longValue ^ (longValue >>> 32));
        } else if (!(this.aQx instanceof Number)) {
            return this.aQx.hashCode();
        } else {
            longValue = Double.doubleToLongBits(zzczg().doubleValue());
            return (int) (longValue ^ (longValue >>> 32));
        }
    }

    void setValue(java.lang.Object r2) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:13:0x0023 in {2, 4, 9, 10, 11, 12} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = r2 instanceof java.lang.Character;
        if (r0 == 0) goto L_0x0011;
    L_0x0004:
        r2 = (java.lang.Character) r2;
        r2 = r2.charValue();
        r2 = java.lang.String.valueOf(r2);
    L_0x000e:
        r1.aQx = r2;
        return;
    L_0x0011:
        r0 = r2 instanceof java.lang.Number;
        if (r0 != 0) goto L_0x001e;
    L_0x0015:
        r0 = zzck(r2);
        if (r0 == 0) goto L_0x001c;
    L_0x001b:
        goto L_0x001e;
    L_0x001c:
        r0 = 0;
        goto L_0x001f;
    L_0x001e:
        r0 = 1;
    L_0x001f:
        com.google.android.gms.internal.zzanq.zzbn(r0);
        goto L_0x000e;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzane.setValue(java.lang.Object):void");
    }

    public Number zzczg() {
        return this.aQx instanceof String ? new zzanv((String) this.aQx) : (Number) this.aQx;
    }

    public String zzczh() {
        return zzczv() ? zzczg().toString() : zzczu() ? zzczt().toString() : (String) this.aQx;
    }

    public double zzczi() {
        return zzczv() ? zzczg().doubleValue() : Double.parseDouble(zzczh());
    }

    public long zzczj() {
        return zzczv() ? zzczg().longValue() : Long.parseLong(zzczh());
    }

    public int zzczk() {
        return zzczv() ? zzczg().intValue() : Integer.parseInt(zzczh());
    }

    public boolean zzczl() {
        return zzczu() ? zzczt().booleanValue() : Boolean.parseBoolean(zzczh());
    }

    Boolean zzczt() {
        return (Boolean) this.aQx;
    }

    public boolean zzczu() {
        return this.aQx instanceof Boolean;
    }

    public boolean zzczv() {
        return this.aQx instanceof Number;
    }

    public boolean zzczw() {
        return this.aQx instanceof String;
    }
}
