package com.google.android.gms.internal;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View.MeasureSpec;
import android.webkit.WebView;
import com.bumptech.glide.load.Key;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;

@zzir
public class zzid implements Runnable {
    private final int zzaie;
    private final int zzaif;
    protected final zzll zzbgj;
    private final Handler zzbyb;
    private final long zzbyc;
    private long zzbyd;
    private com.google.android.gms.internal.zzlm.zza zzbye;
    protected boolean zzbyf;
    protected boolean zzbyg;

    protected final class zza extends AsyncTask<Void, Void, Boolean> {
        private final WebView zzbyh;
        private Bitmap zzbyi;
        final /* synthetic */ zzid zzbyj;

        public zza(zzid com_google_android_gms_internal_zzid, WebView webView) {
            this.zzbyj = com_google_android_gms_internal_zzid;
            this.zzbyh = webView;
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return zzb((Void[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            zza((Boolean) obj);
        }

        protected synchronized void onPreExecute() {
            this.zzbyi = Bitmap.createBitmap(this.zzbyj.zzaie, this.zzbyj.zzaif, Config.ARGB_8888);
            this.zzbyh.setVisibility(0);
            this.zzbyh.measure(MeasureSpec.makeMeasureSpec(this.zzbyj.zzaie, 0), MeasureSpec.makeMeasureSpec(this.zzbyj.zzaif, 0));
            this.zzbyh.layout(0, 0, this.zzbyj.zzaie, this.zzbyj.zzaif);
            this.zzbyh.draw(new Canvas(this.zzbyi));
            this.zzbyh.invalidate();
        }

        protected void zza(Boolean bool) {
            zzid.zzc(this.zzbyj);
            if (!(bool.booleanValue() || this.zzbyj.zzqc())) {
                if (this.zzbyj.zzbyd > 0) {
                    if (this.zzbyj.zzbyd > 0) {
                        if (zzb.zzaz(2)) {
                            zzb.zzcw("Ad not detected, scheduling another run.");
                        }
                        this.zzbyj.zzbyb.postDelayed(this.zzbyj, this.zzbyj.zzbyc);
                        return;
                    }
                }
            }
            this.zzbyj.zzbyg = bool.booleanValue();
            this.zzbyj.zzbye.zza(this.zzbyj.zzbgj, true);
        }

        protected synchronized Boolean zzb(Void... voidArr) {
            int width = this.zzbyi.getWidth();
            int height = this.zzbyi.getHeight();
            boolean z = false;
            if (width != 0) {
                if (height != 0) {
                    int i = 0;
                    int i2 = i;
                    while (i < width) {
                        int i3 = i2;
                        for (i2 = 0; i2 < height; i2 += 10) {
                            if (this.zzbyi.getPixel(i, i2) != 0) {
                                i3++;
                            }
                        }
                        i += 10;
                        i2 = i3;
                    }
                    if (((double) i2) / (((double) (width * height)) / 100.0d) > 0.1d) {
                        z = true;
                    }
                    return Boolean.valueOf(z);
                }
            }
            return Boolean.valueOf(false);
        }
    }

    public zzid(com.google.android.gms.internal.zzlm.zza com_google_android_gms_internal_zzlm_zza, zzll com_google_android_gms_internal_zzll, int i, int i2) {
        this(com_google_android_gms_internal_zzlm_zza, com_google_android_gms_internal_zzll, i, i2, 200, 50);
    }

    public zzid(com.google.android.gms.internal.zzlm.zza com_google_android_gms_internal_zzlm_zza, zzll com_google_android_gms_internal_zzll, int i, int i2, long j, long j2) {
        this.zzbyc = j;
        this.zzbyd = j2;
        this.zzbyb = new Handler(Looper.getMainLooper());
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.zzbye = com_google_android_gms_internal_zzlm_zza;
        this.zzbyf = false;
        this.zzbyg = false;
        this.zzaif = i2;
        this.zzaie = i;
    }

    static /* synthetic */ long zzc(zzid com_google_android_gms_internal_zzid) {
        long j = com_google_android_gms_internal_zzid.zzbyd - 1;
        com_google_android_gms_internal_zzid.zzbyd = j;
        return j;
    }

    public void run() {
        if (this.zzbgj != null) {
            if (!zzqc()) {
                new zza(this, this.zzbgj.getWebView()).execute(new Void[0]);
                return;
            }
        }
        this.zzbye.zza(this.zzbgj, true);
    }

    public void zza(AdResponseParcel adResponseParcel) {
        zza(adResponseParcel, new zzlv(this, this.zzbgj, adResponseParcel.zzccj));
    }

    public void zza(AdResponseParcel adResponseParcel, zzlv com_google_android_gms_internal_zzlv) {
        this.zzbgj.setWebViewClient(com_google_android_gms_internal_zzlv);
        this.zzbgj.loadDataWithBaseURL(TextUtils.isEmpty(adResponseParcel.zzbts) ? null : zzu.zzfq().zzcp(adResponseParcel.zzbts), adResponseParcel.body, "text/html", Key.STRING_CHARSET_NAME, null);
    }

    public void zzqa() {
        this.zzbyb.postDelayed(this, this.zzbyc);
    }

    public synchronized void zzqb() {
        this.zzbyf = true;
    }

    public synchronized boolean zzqc() {
        return this.zzbyf;
    }

    public boolean zzqd() {
        return this.zzbyg;
    }
}
