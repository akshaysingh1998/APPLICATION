package com.google.android.gms.internal;

import java.util.ArrayList;

public interface zzev {
    void zza(String str, ArrayList<String> arrayList);
}
