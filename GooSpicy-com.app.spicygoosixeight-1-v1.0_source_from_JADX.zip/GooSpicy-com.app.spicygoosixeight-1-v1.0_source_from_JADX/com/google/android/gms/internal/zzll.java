package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.overlay.zzd;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzs;
import java.util.Map;
import org.json.JSONObject;

@zzir
public interface zzll extends zzs, zzce, zzfx {
    void destroy();

    Context getContext();

    LayoutParams getLayoutParams();

    void getLocationOnScreen(int[] iArr);

    int getMeasuredHeight();

    int getMeasuredWidth();

    ViewParent getParent();

    String getRequestId();

    int getRequestedOrientation();

    View getView();

    WebView getWebView();

    boolean isDestroyed();

    void loadData(String str, String str2, String str3);

    void loadDataWithBaseURL(String str, String str2, String str3, String str4, @Nullable String str5);

    void loadUrl(String str);

    void measure(int i, int i2);

    void onPause();

    void onResume();

    void setBackgroundColor(int i);

    void setContext(Context context);

    void setOnClickListener(OnClickListener onClickListener);

    void setOnTouchListener(OnTouchListener onTouchListener);

    void setRequestedOrientation(int i);

    void setWebChromeClient(WebChromeClient webChromeClient);

    void setWebViewClient(WebViewClient webViewClient);

    void stopLoading();

    void zza(Context context, AdSizeParcel adSizeParcel, zzdk com_google_android_gms_internal_zzdk);

    void zza(AdSizeParcel adSizeParcel);

    void zza(zzlq com_google_android_gms_internal_zzlq);

    void zza(String str, Map<String, ?> map);

    void zza(String str, JSONObject jSONObject);

    void zzaf(int i);

    void zzah(boolean z);

    void zzai(boolean z);

    void zzaj(boolean z);

    void zzb(zzd com_google_android_gms_ads_internal_overlay_zzd);

    void zzc(zzd com_google_android_gms_ads_internal_overlay_zzd);

    void zzcz(String str);

    void zzda(String str);

    AdSizeParcel zzdo();

    void zzj(String str, String str2);

    void zzoc();

    boolean zzow();

    void zzud();

    void zzue();

    Activity zzuf();

    Context zzug();

    com.google.android.gms.ads.internal.zzd zzuh();

    zzd zzui();

    zzd zzuj();

    zzlm zzuk();

    boolean zzul();

    zzas zzum();

    VersionInfoParcel zzun();

    boolean zzuo();

    void zzup();

    boolean zzuq();

    @Nullable
    zzlk zzur();

    @Nullable
    zzdi zzus();

    zzdj zzut();

    @Nullable
    zzlq zzuu();

    void zzuv();

    void zzuw();

    OnClickListener zzux();
}
