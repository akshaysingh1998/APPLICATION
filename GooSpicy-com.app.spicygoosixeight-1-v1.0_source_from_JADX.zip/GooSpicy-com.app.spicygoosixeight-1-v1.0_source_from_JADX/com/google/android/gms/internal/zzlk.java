package com.google.android.gms.internal;

import android.content.Context;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import com.google.android.gms.ads.internal.overlay.zzk;
import com.google.android.gms.common.internal.zzab;

@zzir
public class zzlk {
    private final Context mContext;
    private final zzll zzbgj;
    private zzk zzbwj;
    private final ViewGroup zzcom;

    public zzlk(Context context, ViewGroup viewGroup, zzll com_google_android_gms_internal_zzll) {
        this(context, viewGroup, com_google_android_gms_internal_zzll, null);
    }

    zzlk(Context context, ViewGroup viewGroup, zzll com_google_android_gms_internal_zzll, zzk com_google_android_gms_ads_internal_overlay_zzk) {
        this.mContext = context;
        this.zzcom = viewGroup;
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.zzbwj = com_google_android_gms_ads_internal_overlay_zzk;
    }

    public void onDestroy() {
        zzab.zzhj("onDestroy must be called from the UI thread.");
        if (this.zzbwj != null) {
            this.zzbwj.destroy();
            this.zzcom.removeView(this.zzbwj);
            this.zzbwj = null;
        }
    }

    public void onPause() {
        zzab.zzhj("onPause must be called from the UI thread.");
        if (this.zzbwj != null) {
            this.zzbwj.pause();
        }
    }

    public void zza(int i, int i2, int i3, int i4, int i5, boolean z) {
        if (this.zzbwj == null) {
            zzdg.zza(r0.zzbgj.zzut().zzkf(), r0.zzbgj.zzus(), "vpr");
            int i6 = i5;
            boolean z2 = z;
            r0.zzbwj = new zzk(r0.mContext, r0.zzbgj, i6, z2, r0.zzbgj.zzut().zzkf(), zzdg.zzb(r0.zzbgj.zzut().zzkf()));
            r0.zzcom.addView(r0.zzbwj, 0, new LayoutParams(-1, -1));
            r0.zzbwj.zzd(i, i2, i3, i4);
            r0.zzbgj.zzuk().zzak(false);
        }
    }

    public void zze(int i, int i2, int i3, int i4) {
        zzab.zzhj("The underlay may only be modified from the UI thread.");
        if (this.zzbwj != null) {
            this.zzbwj.zzd(i, i2, i3, i4);
        }
    }

    public zzk zzuc() {
        zzab.zzhj("getAdVideoUnderlay must be called from the UI thread.");
        return this.zzbwj;
    }
}
