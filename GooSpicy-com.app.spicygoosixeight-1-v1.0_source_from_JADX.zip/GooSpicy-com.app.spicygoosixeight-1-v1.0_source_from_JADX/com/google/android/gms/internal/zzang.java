package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzang<T> {
    zzamy zza(T t, Type type, zzanf com_google_android_gms_internal_zzanf);
}
