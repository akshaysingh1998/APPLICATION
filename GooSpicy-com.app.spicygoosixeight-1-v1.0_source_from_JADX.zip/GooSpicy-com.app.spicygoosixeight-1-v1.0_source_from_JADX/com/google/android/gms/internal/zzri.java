package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.zzro.zza;

public class zzri extends zza {
    public void zzgj(int i) throws RemoteException {
    }
}
