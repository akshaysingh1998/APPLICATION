package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.Map;

@zzir
public final class zzen implements zzet {
    private final zzeo zzbhq;

    public zzen(zzeo com_google_android_gms_internal_zzeo) {
        this.zzbhq = com_google_android_gms_internal_zzeo;
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str = (String) map.get("name");
        if (str == null) {
            zzb.zzcy("App event with no name parameter.");
        } else {
            this.zzbhq.onAppEvent(str, (String) map.get("info"));
        }
    }
}
