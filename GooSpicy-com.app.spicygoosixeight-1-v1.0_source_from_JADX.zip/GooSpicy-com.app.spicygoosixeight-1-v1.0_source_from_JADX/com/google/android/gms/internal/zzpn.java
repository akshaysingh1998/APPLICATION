package com.google.android.gms.internal;

import android.os.DeadObjectException;
import android.support.annotation.NonNull;
import android.util.SparseArray;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.TaskCompletionSource;

public abstract class zzpn {
    public final int it;
    public final int sn;

    public static final class zza extends zzpn {
        public final com.google.android.gms.internal.zzpr.zza<? extends Result, com.google.android.gms.common.api.Api.zzb> so;

        public zza(int i, int i2, com.google.android.gms.internal.zzpr.zza<? extends Result, com.google.android.gms.common.api.Api.zzb> com_google_android_gms_internal_zzpr_zza__extends_com_google_android_gms_common_api_Result__com_google_android_gms_common_api_Api_zzb) {
            super(i, i2);
            this.so = com_google_android_gms_internal_zzpr_zza__extends_com_google_android_gms_common_api_Result__com_google_android_gms_common_api_Api_zzb;
        }

        public boolean cancel() {
            return this.so.zzaos();
        }

        public void zza(SparseArray<zzrd> sparseArray) {
            zzrd com_google_android_gms_internal_zzrd = (zzrd) sparseArray.get(this.sn);
            if (com_google_android_gms_internal_zzrd != null) {
                com_google_android_gms_internal_zzrd.zzg(this.so);
            }
        }

        public void zzb(com.google.android.gms.common.api.Api.zzb com_google_android_gms_common_api_Api_zzb) throws DeadObjectException {
            this.so.zzb(com_google_android_gms_common_api_Api_zzb);
        }

        public void zzx(@NonNull Status status) {
            this.so.zzz(status);
        }
    }

    public static final class zzb<TResult> extends zzpn {
        private static final Status sr = new Status(8, "Connection to Google Play services was lost while executing the API call.");
        private final zzrb<com.google.android.gms.common.api.Api.zzb, TResult> sp;
        private final TaskCompletionSource<TResult> sq;

        public zzb(int i, int i2, zzrb<com.google.android.gms.common.api.Api.zzb, TResult> com_google_android_gms_internal_zzrb_com_google_android_gms_common_api_Api_zzb__TResult, TaskCompletionSource<TResult> taskCompletionSource) {
            super(i, i2);
            this.sq = taskCompletionSource;
            this.sp = com_google_android_gms_internal_zzrb_com_google_android_gms_common_api_Api_zzb__TResult;
        }

        public void zzb(com.google.android.gms.common.api.Api.zzb r3) throws android.os.DeadObjectException {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r2 = this;
            r0 = r2.sp;	 Catch:{ DeadObjectException -> 0x000e, RemoteException -> 0x0008 }
            r1 = r2.sq;	 Catch:{ DeadObjectException -> 0x000e, RemoteException -> 0x0008 }
            r0.zza(r3, r1);	 Catch:{ DeadObjectException -> 0x000e, RemoteException -> 0x0008 }
            return;
        L_0x0008:
            r3 = sr;
            r2.zzx(r3);
            return;
        L_0x000e:
            r3 = move-exception;
            r0 = sr;
            r2.zzx(r0);
            throw r3;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzpn.zzb.zzb(com.google.android.gms.common.api.Api$zzb):void");
        }

        public void zzx(@android.support.annotation.NonNull com.google.android.gms.common.api.Status r3) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:6:0x0023 in {2, 4, 5} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r2 = this;
            r0 = r3.getStatusCode();
            r1 = 8;
            if (r0 != r1) goto L_0x0017;
        L_0x0008:
            r0 = r2.sq;
            r1 = new com.google.firebase.FirebaseException;
            r3 = r3.getStatusMessage();
            r1.<init>(r3);
        L_0x0013:
            r0.setException(r1);
            return;
        L_0x0017:
            r0 = r2.sq;
            r1 = new com.google.firebase.FirebaseApiNotAvailableException;
            r3 = r3.getStatusMessage();
            r1.<init>(r3);
            goto L_0x0013;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzpn.zzb.zzx(com.google.android.gms.common.api.Status):void");
        }
    }

    public zzpn(int i, int i2) {
        this.sn = i;
        this.it = i2;
    }

    public boolean cancel() {
        return true;
    }

    public void zza(SparseArray<zzrd> sparseArray) {
    }

    public abstract void zzb(com.google.android.gms.common.api.Api.zzb com_google_android_gms_common_api_Api_zzb) throws DeadObjectException;

    public abstract void zzx(@NonNull Status status);
}
