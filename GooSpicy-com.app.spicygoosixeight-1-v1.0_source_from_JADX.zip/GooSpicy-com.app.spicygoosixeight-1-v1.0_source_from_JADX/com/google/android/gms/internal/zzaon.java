package com.google.android.gms.internal;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.sql.Timestamp;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.UUID;

public final class zzaon {
    public static final zzanl bgA = zza(Character.TYPE, Character.class, bgz);
    public static final zzank<String> bgB = new C08665();
    public static final zzank<BigDecimal> bgC = new C08676();
    public static final zzank<BigInteger> bgD = new C08687();
    public static final zzanl bgE = zza(String.class, bgB);
    public static final zzank<StringBuilder> bgF = new C08698();
    public static final zzanl bgG = zza(StringBuilder.class, bgF);
    public static final zzank<StringBuffer> bgH = new C08709();
    public static final zzanl bgI = zza(StringBuffer.class, bgH);
    public static final zzank<URL> bgJ = new zzank<URL>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, URL url) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(url == null ? null : url.toExternalForm());
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzv(com_google_android_gms_internal_zzaop);
        }

        public URL zzv(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            String nextString = com_google_android_gms_internal_zzaop.nextString();
            return "null".equals(nextString) ? null : new URL(nextString);
        }
    };
    public static final zzanl bgK = zza(URL.class, bgJ);
    public static final zzank<URI> bgL = new zzank<URI>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, URI uri) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(uri == null ? null : uri.toASCIIString());
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzw(com_google_android_gms_internal_zzaop);
        }

        public URI zzw(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            try {
                String nextString = com_google_android_gms_internal_zzaop.nextString();
                return "null".equals(nextString) ? null : new URI(nextString);
            } catch (Throwable e) {
                throw new zzamz(e);
            }
        }
    };
    public static final zzanl bgM = zza(URI.class, bgL);
    public static final zzank<InetAddress> bgN = new zzank<InetAddress>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, InetAddress inetAddress) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(inetAddress == null ? null : inetAddress.getHostAddress());
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzy(com_google_android_gms_internal_zzaop);
        }

        public InetAddress zzy(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return InetAddress.getByName(com_google_android_gms_internal_zzaop.nextString());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
    };
    public static final zzanl bgO = zzb(InetAddress.class, bgN);
    public static final zzank<UUID> bgP = new zzank<UUID>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, UUID uuid) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(uuid == null ? null : uuid.toString());
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzz(com_google_android_gms_internal_zzaop);
        }

        public UUID zzz(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return UUID.fromString(com_google_android_gms_internal_zzaop.nextString());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
    };
    public static final zzanl bgQ = zza(UUID.class, bgP);
    public static final zzanl bgR = new zzanl() {
        public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
            if (com_google_android_gms_internal_zzaoo_T.m15s() != Timestamp.class) {
                return null;
            }
            final zzank zzk = com_google_android_gms_internal_zzams.zzk(Date.class);
            return new zzank<Timestamp>(this) {
                final /* synthetic */ AnonymousClass15 bha;

                public void zza(zzaor com_google_android_gms_internal_zzaor, Timestamp timestamp) throws IOException {
                    zzk.zza(com_google_android_gms_internal_zzaor, timestamp);
                }

                public Timestamp zzaa(zzaop com_google_android_gms_internal_zzaop) throws IOException {
                    Date date = (Date) zzk.zzb(com_google_android_gms_internal_zzaop);
                    return date != null ? new Timestamp(date.getTime()) : null;
                }

                public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
                    return zzaa(com_google_android_gms_internal_zzaop);
                }
            };
        }
    };
    public static final zzank<Calendar> bgS = new zzank<Calendar>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Calendar calendar) throws IOException {
            if (calendar == null) {
                com_google_android_gms_internal_zzaor.mo2318r();
                return;
            }
            com_google_android_gms_internal_zzaor.mo2316p();
            com_google_android_gms_internal_zzaor.zzta("year");
            com_google_android_gms_internal_zzaor.zzcp((long) calendar.get(1));
            com_google_android_gms_internal_zzaor.zzta("month");
            com_google_android_gms_internal_zzaor.zzcp((long) calendar.get(2));
            com_google_android_gms_internal_zzaor.zzta("dayOfMonth");
            com_google_android_gms_internal_zzaor.zzcp((long) calendar.get(5));
            com_google_android_gms_internal_zzaor.zzta("hourOfDay");
            com_google_android_gms_internal_zzaor.zzcp((long) calendar.get(11));
            com_google_android_gms_internal_zzaor.zzta("minute");
            com_google_android_gms_internal_zzaor.zzcp((long) calendar.get(12));
            com_google_android_gms_internal_zzaor.zzta("second");
            com_google_android_gms_internal_zzaor.zzcp((long) calendar.get(13));
            com_google_android_gms_internal_zzaor.mo2317q();
        }

        public Calendar zzab(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            com_google_android_gms_internal_zzaop.beginObject();
            int i = 0;
            int i2 = i;
            int i3 = i2;
            int i4 = i3;
            int i5 = i4;
            int i6 = i5;
            while (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.END_OBJECT) {
                String nextName = com_google_android_gms_internal_zzaop.nextName();
                int nextInt = com_google_android_gms_internal_zzaop.nextInt();
                if ("year".equals(nextName)) {
                    i = nextInt;
                } else if ("month".equals(nextName)) {
                    i2 = nextInt;
                } else if ("dayOfMonth".equals(nextName)) {
                    i3 = nextInt;
                } else if ("hourOfDay".equals(nextName)) {
                    i4 = nextInt;
                } else if ("minute".equals(nextName)) {
                    i5 = nextInt;
                } else if ("second".equals(nextName)) {
                    i6 = nextInt;
                }
            }
            com_google_android_gms_internal_zzaop.endObject();
            return new GregorianCalendar(i, i2, i3, i4, i5, i6);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzab(com_google_android_gms_internal_zzaop);
        }
    };
    public static final zzanl bgT = zzb(Calendar.class, GregorianCalendar.class, bgS);
    public static final zzank<Locale> bgU = new zzank<Locale>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Locale locale) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(locale == null ? null : locale.toString());
        }

        public Locale zzac(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            String str = null;
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            StringTokenizer stringTokenizer = new StringTokenizer(com_google_android_gms_internal_zzaop.nextString(), "_");
            String nextToken = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
            String nextToken2 = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
            if (stringTokenizer.hasMoreElements()) {
                str = stringTokenizer.nextToken();
            }
            return (nextToken2 == null && str == null) ? new Locale(nextToken) : str == null ? new Locale(nextToken, nextToken2) : new Locale(nextToken, nextToken2, str);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzac(com_google_android_gms_internal_zzaop);
        }
    };
    public static final zzanl bgV = zza(Locale.class, bgU);
    public static final zzank<zzamy> bgW = new zzank<zzamy>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, zzamy com_google_android_gms_internal_zzamy) throws IOException {
            if (com_google_android_gms_internal_zzamy != null) {
                if (!com_google_android_gms_internal_zzamy.zzczp()) {
                    if (com_google_android_gms_internal_zzamy.zzczo()) {
                        zzane zzczs = com_google_android_gms_internal_zzamy.zzczs();
                        if (zzczs.zzczv()) {
                            com_google_android_gms_internal_zzaor.zza(zzczs.zzczg());
                            return;
                        } else if (zzczs.zzczu()) {
                            com_google_android_gms_internal_zzaor.zzcz(zzczs.zzczl());
                            return;
                        } else {
                            com_google_android_gms_internal_zzaor.zztb(zzczs.zzczh());
                            return;
                        }
                    } else if (com_google_android_gms_internal_zzamy.zzczm()) {
                        com_google_android_gms_internal_zzaor.mo2314n();
                        r5 = com_google_android_gms_internal_zzamy.zzczr().iterator();
                        while (r5.hasNext()) {
                            zza(com_google_android_gms_internal_zzaor, (zzamy) r5.next());
                        }
                        com_google_android_gms_internal_zzaor.mo2315o();
                        return;
                    } else if (com_google_android_gms_internal_zzamy.zzczn()) {
                        com_google_android_gms_internal_zzaor.mo2316p();
                        for (Entry entry : com_google_android_gms_internal_zzamy.zzczq().entrySet()) {
                            com_google_android_gms_internal_zzaor.zzta((String) entry.getKey());
                            zza(com_google_android_gms_internal_zzaor, (zzamy) entry.getValue());
                        }
                        com_google_android_gms_internal_zzaor.mo2317q();
                        return;
                    } else {
                        String valueOf = String.valueOf(com_google_android_gms_internal_zzamy.getClass());
                        StringBuilder stringBuilder = new StringBuilder(15 + String.valueOf(valueOf).length());
                        stringBuilder.append("Couldn't write ");
                        stringBuilder.append(valueOf);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                }
            }
            com_google_android_gms_internal_zzaor.mo2318r();
        }

        public zzamy zzad(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            zzamy com_google_android_gms_internal_zzamv;
            switch (com_google_android_gms_internal_zzaop.mo2301h()) {
                case NUMBER:
                    return new zzane(new zzanv(com_google_android_gms_internal_zzaop.nextString()));
                case BOOLEAN:
                    return new zzane(Boolean.valueOf(com_google_android_gms_internal_zzaop.nextBoolean()));
                case STRING:
                    return new zzane(com_google_android_gms_internal_zzaop.nextString());
                case NULL:
                    com_google_android_gms_internal_zzaop.nextNull();
                    return zzana.bes;
                case BEGIN_ARRAY:
                    com_google_android_gms_internal_zzamv = new zzamv();
                    com_google_android_gms_internal_zzaop.beginArray();
                    while (com_google_android_gms_internal_zzaop.hasNext()) {
                        com_google_android_gms_internal_zzamv.zzc((zzamy) zzb(com_google_android_gms_internal_zzaop));
                    }
                    com_google_android_gms_internal_zzaop.endArray();
                    return com_google_android_gms_internal_zzamv;
                case BEGIN_OBJECT:
                    com_google_android_gms_internal_zzamv = new zzanb();
                    com_google_android_gms_internal_zzaop.beginObject();
                    while (com_google_android_gms_internal_zzaop.hasNext()) {
                        com_google_android_gms_internal_zzamv.zza(com_google_android_gms_internal_zzaop.nextName(), (zzamy) zzb(com_google_android_gms_internal_zzaop));
                    }
                    com_google_android_gms_internal_zzaop.endObject();
                    return com_google_android_gms_internal_zzamv;
                default:
                    throw new IllegalArgumentException();
            }
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzad(com_google_android_gms_internal_zzaop);
        }
    };
    public static final zzanl bgX = zzb(zzamy.class, bgW);
    public static final zzanl bgY = new zzanl() {
        public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
            Class s = com_google_android_gms_internal_zzaoo_T.m15s();
            if (Enum.class.isAssignableFrom(s)) {
                if (s != Enum.class) {
                    if (!s.isEnum()) {
                        s = s.getSuperclass();
                    }
                    return new zza(s);
                }
            }
            return null;
        }
    };
    public static final zzank<Class> bgh = new C08621();
    public static final zzanl bgi = zza(Class.class, bgh);
    public static final zzank<BitSet> bgj = new zzank<BitSet>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, BitSet bitSet) throws IOException {
            if (bitSet == null) {
                com_google_android_gms_internal_zzaor.mo2318r();
                return;
            }
            com_google_android_gms_internal_zzaor.mo2314n();
            for (int i = 0; i < bitSet.length(); i++) {
                com_google_android_gms_internal_zzaor.zzcp((long) bitSet.get(i));
            }
            com_google_android_gms_internal_zzaor.mo2315o();
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzx(com_google_android_gms_internal_zzaop);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.util.BitSet zzx(com.google.android.gms.internal.zzaop r7) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r6 = this;
            r0 = r7.mo2301h();
            r1 = com.google.android.gms.internal.zzaoq.NULL;
            if (r0 != r1) goto L_0x000d;
        L_0x0008:
            r7.nextNull();
            r7 = 0;
            return r7;
        L_0x000d:
            r0 = new java.util.BitSet;
            r0.<init>();
            r7.beginArray();
            r1 = r7.mo2301h();
            r2 = 0;
            r3 = r2;
        L_0x001b:
            r4 = com.google.android.gms.internal.zzaoq.END_ARRAY;
            if (r1 == r4) goto L_0x0092;
        L_0x001f:
            r4 = com.google.android.gms.internal.zzaon.AnonymousClass26.bfU;
            r5 = r1.ordinal();
            r4 = r4[r5];
            r5 = 1;
            switch(r4) {
                case 1: goto L_0x0080;
                case 2: goto L_0x007b;
                case 3: goto L_0x0051;
                default: goto L_0x002b;
            };
        L_0x002b:
            r7 = new com.google.android.gms.internal.zzanh;
            r0 = java.lang.String.valueOf(r1);
            r1 = new java.lang.StringBuilder;
            r2 = 27;
            r3 = java.lang.String.valueOf(r0);
            r3 = r3.length();
            r2 = r2 + r3;
            r1.<init>(r2);
            r2 = "Invalid bitset value type: ";
            r1.append(r2);
            r1.append(r0);
            r0 = r1.toString();
            r7.<init>(r0);
            throw r7;
        L_0x0051:
            r1 = r7.nextString();
            r4 = java.lang.Integer.parseInt(r1);	 Catch:{ NumberFormatException -> 0x005e }
            if (r4 == 0) goto L_0x005c;
        L_0x005b:
            goto L_0x0086;
        L_0x005c:
            r5 = r2;
            goto L_0x0086;
        L_0x005e:
            r7 = new com.google.android.gms.internal.zzanh;
            r0 = "Error: Expecting: bitset number value (1, 0), Found: ";
            r1 = java.lang.String.valueOf(r1);
            r2 = r1.length();
            if (r2 == 0) goto L_0x0071;
        L_0x006c:
            r0 = r0.concat(r1);
            goto L_0x0077;
        L_0x0071:
            r1 = new java.lang.String;
            r1.<init>(r0);
            r0 = r1;
        L_0x0077:
            r7.<init>(r0);
            throw r7;
        L_0x007b:
            r5 = r7.nextBoolean();
            goto L_0x0086;
        L_0x0080:
            r1 = r7.nextInt();
            if (r1 == 0) goto L_0x005c;
        L_0x0086:
            if (r5 == 0) goto L_0x008b;
        L_0x0088:
            r0.set(r3);
        L_0x008b:
            r3 = r3 + 1;
            r1 = r7.mo2301h();
            goto L_0x001b;
        L_0x0092:
            r7.endArray();
            return r0;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaon.12.zzx(com.google.android.gms.internal.zzaop):java.util.BitSet");
        }
    };
    public static final zzanl bgk = zza(BitSet.class, bgj);
    public static final zzank<Boolean> bgl = new zzank<Boolean>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Boolean bool) throws IOException {
            if (bool == null) {
                com_google_android_gms_internal_zzaor.mo2318r();
            } else {
                com_google_android_gms_internal_zzaor.zzcz(bool.booleanValue());
            }
        }

        public Boolean zzae(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.STRING ? Boolean.valueOf(Boolean.parseBoolean(com_google_android_gms_internal_zzaop.nextString())) : Boolean.valueOf(com_google_android_gms_internal_zzaop.nextBoolean());
            } else {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzae(com_google_android_gms_internal_zzaop);
        }
    };
    public static final zzank<Boolean> bgm = new zzank<Boolean>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Boolean bool) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(bool == null ? "null" : bool.toString());
        }

        public Boolean zzae(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return Boolean.valueOf(com_google_android_gms_internal_zzaop.nextString());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzae(com_google_android_gms_internal_zzaop);
        }
    };
    public static final zzanl bgn = zza(Boolean.TYPE, Boolean.class, bgl);
    public static final zzank<Number> bgo = new zzank<Number>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Number number) throws IOException {
            com_google_android_gms_internal_zzaor.zza(number);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzg(com_google_android_gms_internal_zzaop);
        }

        public Number zzg(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            try {
                return Byte.valueOf((byte) com_google_android_gms_internal_zzaop.nextInt());
            } catch (Throwable e) {
                throw new zzanh(e);
            }
        }
    };
    public static final zzanl bgp = zza(Byte.TYPE, Byte.class, bgo);
    public static final zzank<Number> bgq = new zzank<Number>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Number number) throws IOException {
            com_google_android_gms_internal_zzaor.zza(number);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzg(com_google_android_gms_internal_zzaop);
        }

        public Number zzg(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            try {
                return Short.valueOf((short) com_google_android_gms_internal_zzaop.nextInt());
            } catch (Throwable e) {
                throw new zzanh(e);
            }
        }
    };
    public static final zzanl bgr = zza(Short.TYPE, Short.class, bgq);
    public static final zzank<Number> bgs = new zzank<Number>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Number number) throws IOException {
            com_google_android_gms_internal_zzaor.zza(number);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzg(com_google_android_gms_internal_zzaop);
        }

        public Number zzg(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            try {
                return Integer.valueOf(com_google_android_gms_internal_zzaop.nextInt());
            } catch (Throwable e) {
                throw new zzanh(e);
            }
        }
    };
    public static final zzanl bgt = zza(Integer.TYPE, Integer.class, bgs);
    public static final zzank<Number> bgu = new zzank<Number>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Number number) throws IOException {
            com_google_android_gms_internal_zzaor.zza(number);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzg(com_google_android_gms_internal_zzaop);
        }

        public Number zzg(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            try {
                return Long.valueOf(com_google_android_gms_internal_zzaop.nextLong());
            } catch (Throwable e) {
                throw new zzanh(e);
            }
        }
    };
    public static final zzank<Number> bgv = new zzank<Number>() {
        public void zza(zzaor com_google_android_gms_internal_zzaor, Number number) throws IOException {
            com_google_android_gms_internal_zzaor.zza(number);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzg(com_google_android_gms_internal_zzaop);
        }

        public Number zzg(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return Float.valueOf((float) com_google_android_gms_internal_zzaop.nextDouble());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
    };
    public static final zzank<Number> bgw = new C08632();
    public static final zzank<Number> bgx = new C08643();
    public static final zzanl bgy = zza(Number.class, bgx);
    public static final zzank<Character> bgz = new C08654();

    static class C08621 extends zzank<Class> {
        C08621() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, Class cls) throws IOException {
            if (cls == null) {
                com_google_android_gms_internal_zzaor.mo2318r();
                return;
            }
            String valueOf = String.valueOf(cls.getName());
            StringBuilder stringBuilder = new StringBuilder(76 + String.valueOf(valueOf).length());
            stringBuilder.append("Attempted to serialize java.lang.Class: ");
            stringBuilder.append(valueOf);
            stringBuilder.append(". Forgot to register a type adapter?");
            throw new UnsupportedOperationException(stringBuilder.toString());
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzo(com_google_android_gms_internal_zzaop);
        }

        public Class zzo(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
        }
    }

    static class C08632 extends zzank<Number> {
        C08632() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, Number number) throws IOException {
            com_google_android_gms_internal_zzaor.zza(number);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzg(com_google_android_gms_internal_zzaop);
        }

        public Number zzg(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return Double.valueOf(com_google_android_gms_internal_zzaop.nextDouble());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
    }

    static class C08643 extends zzank<Number> {
        C08643() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, Number number) throws IOException {
            com_google_android_gms_internal_zzaor.zza(number);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzg(com_google_android_gms_internal_zzaop);
        }

        public Number zzg(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            zzaoq h = com_google_android_gms_internal_zzaop.mo2301h();
            int i = AnonymousClass26.bfU[h.ordinal()];
            if (i == 1) {
                return new zzanv(com_google_android_gms_internal_zzaop.nextString());
            }
            if (i != 4) {
                String valueOf = String.valueOf(h);
                StringBuilder stringBuilder = new StringBuilder(23 + String.valueOf(valueOf).length());
                stringBuilder.append("Expecting number, got: ");
                stringBuilder.append(valueOf);
                throw new zzanh(stringBuilder.toString());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
    }

    static class C08654 extends zzank<Character> {
        C08654() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, Character ch) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(ch == null ? null : String.valueOf(ch));
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzp(com_google_android_gms_internal_zzaop);
        }

        public Character zzp(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            String nextString = com_google_android_gms_internal_zzaop.nextString();
            if (nextString.length() == 1) {
                return Character.valueOf(nextString.charAt(0));
            }
            String str = "Expecting character, got: ";
            nextString = String.valueOf(nextString);
            throw new zzanh(nextString.length() != 0 ? str.concat(nextString) : new String(str));
        }
    }

    static class C08665 extends zzank<String> {
        C08665() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, String str) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(str);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzq(com_google_android_gms_internal_zzaop);
        }

        public String zzq(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            zzaoq h = com_google_android_gms_internal_zzaop.mo2301h();
            if (h != zzaoq.NULL) {
                return h == zzaoq.BOOLEAN ? Boolean.toString(com_google_android_gms_internal_zzaop.nextBoolean()) : com_google_android_gms_internal_zzaop.nextString();
            } else {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
        }
    }

    static class C08676 extends zzank<BigDecimal> {
        C08676() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, BigDecimal bigDecimal) throws IOException {
            com_google_android_gms_internal_zzaor.zza(bigDecimal);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzr(com_google_android_gms_internal_zzaop);
        }

        public BigDecimal zzr(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            try {
                return new BigDecimal(com_google_android_gms_internal_zzaop.nextString());
            } catch (Throwable e) {
                throw new zzanh(e);
            }
        }
    }

    static class C08687 extends zzank<BigInteger> {
        C08687() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, BigInteger bigInteger) throws IOException {
            com_google_android_gms_internal_zzaor.zza(bigInteger);
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzs(com_google_android_gms_internal_zzaop);
        }

        public BigInteger zzs(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            try {
                return new BigInteger(com_google_android_gms_internal_zzaop.nextString());
            } catch (Throwable e) {
                throw new zzanh(e);
            }
        }
    }

    static class C08698 extends zzank<StringBuilder> {
        C08698() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, StringBuilder stringBuilder) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(stringBuilder == null ? null : stringBuilder.toString());
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzt(com_google_android_gms_internal_zzaop);
        }

        public StringBuilder zzt(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return new StringBuilder(com_google_android_gms_internal_zzaop.nextString());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
    }

    static class C08709 extends zzank<StringBuffer> {
        C08709() {
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, StringBuffer stringBuffer) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(stringBuffer == null ? null : stringBuffer.toString());
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzu(com_google_android_gms_internal_zzaop);
        }

        public StringBuffer zzu(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return new StringBuffer(com_google_android_gms_internal_zzaop.nextString());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
    }

    private static final class zza<T extends Enum<T>> extends zzank<T> {
        private final Map<String, T> bhi = new HashMap();
        private final Map<T, String> bhj = new HashMap();

        public zza(java.lang.Class<T> r12) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r11 = this;
            r11.<init>();
            r0 = new java.util.HashMap;
            r0.<init>();
            r11.bhi = r0;
            r0 = new java.util.HashMap;
            r0.<init>();
            r11.bhj = r0;
            r0 = r12.getEnumConstants();	 Catch:{ NoSuchFieldException -> 0x0054 }
            r0 = (java.lang.Enum[]) r0;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r1 = r0.length;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r2 = 0;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r3 = r2;	 Catch:{ NoSuchFieldException -> 0x0054 }
        L_0x001a:
            if (r3 >= r1) goto L_0x0053;	 Catch:{ NoSuchFieldException -> 0x0054 }
        L_0x001c:
            r4 = r0[r3];	 Catch:{ NoSuchFieldException -> 0x0054 }
            r5 = r4.name();	 Catch:{ NoSuchFieldException -> 0x0054 }
            r6 = r12.getField(r5);	 Catch:{ NoSuchFieldException -> 0x0054 }
            r7 = com.google.android.gms.internal.zzann.class;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r6 = r6.getAnnotation(r7);	 Catch:{ NoSuchFieldException -> 0x0054 }
            r6 = (com.google.android.gms.internal.zzann) r6;	 Catch:{ NoSuchFieldException -> 0x0054 }
            if (r6 == 0) goto L_0x0046;	 Catch:{ NoSuchFieldException -> 0x0054 }
        L_0x0030:
            r5 = r6.value();	 Catch:{ NoSuchFieldException -> 0x0054 }
            r6 = r6.zzczy();	 Catch:{ NoSuchFieldException -> 0x0054 }
            r7 = r6.length;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r8 = r2;	 Catch:{ NoSuchFieldException -> 0x0054 }
        L_0x003a:
            if (r8 >= r7) goto L_0x0046;	 Catch:{ NoSuchFieldException -> 0x0054 }
        L_0x003c:
            r9 = r6[r8];	 Catch:{ NoSuchFieldException -> 0x0054 }
            r10 = r11.bhi;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r10.put(r9, r4);	 Catch:{ NoSuchFieldException -> 0x0054 }
            r8 = r8 + 1;	 Catch:{ NoSuchFieldException -> 0x0054 }
            goto L_0x003a;	 Catch:{ NoSuchFieldException -> 0x0054 }
        L_0x0046:
            r6 = r11.bhi;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r6.put(r5, r4);	 Catch:{ NoSuchFieldException -> 0x0054 }
            r6 = r11.bhj;	 Catch:{ NoSuchFieldException -> 0x0054 }
            r6.put(r4, r5);	 Catch:{ NoSuchFieldException -> 0x0054 }
            r3 = r3 + 1;
            goto L_0x001a;
        L_0x0053:
            return;
        L_0x0054:
            r12 = new java.lang.AssertionError;
            r12.<init>();
            throw r12;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaon.zza.<init>(java.lang.Class):void");
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, T t) throws IOException {
            com_google_android_gms_internal_zzaor.zztb(t == null ? null : (String) this.bhj.get(t));
        }

        public T zzaf(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() != zzaoq.NULL) {
                return (Enum) this.bhi.get(com_google_android_gms_internal_zzaop.nextString());
            }
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzaf(com_google_android_gms_internal_zzaop);
        }
    }

    public static <TT> zzanl zza(final zzaoo<TT> com_google_android_gms_internal_zzaoo_TT, final zzank<TT> com_google_android_gms_internal_zzank_TT) {
        return new zzanl() {
            public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
                return com_google_android_gms_internal_zzaoo_T.equals(com_google_android_gms_internal_zzaoo_TT) ? com_google_android_gms_internal_zzank_TT : null;
            }
        };
    }

    public static <TT> zzanl zza(final Class<TT> cls, final zzank<TT> com_google_android_gms_internal_zzank_TT) {
        return new zzanl() {
            public String toString() {
                String valueOf = String.valueOf(cls.getName());
                String valueOf2 = String.valueOf(com_google_android_gms_internal_zzank_TT);
                StringBuilder stringBuilder = new StringBuilder((23 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length());
                stringBuilder.append("Factory[type=");
                stringBuilder.append(valueOf);
                stringBuilder.append(",adapter=");
                stringBuilder.append(valueOf2);
                stringBuilder.append("]");
                return stringBuilder.toString();
            }

            public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
                return com_google_android_gms_internal_zzaoo_T.m15s() == cls ? com_google_android_gms_internal_zzank_TT : null;
            }
        };
    }

    public static <TT> zzanl zza(final Class<TT> cls, final Class<TT> cls2, final zzank<? super TT> com_google_android_gms_internal_zzank__super_TT) {
        return new zzanl() {
            public String toString() {
                String valueOf = String.valueOf(cls2.getName());
                String valueOf2 = String.valueOf(cls.getName());
                String valueOf3 = String.valueOf(com_google_android_gms_internal_zzank__super_TT);
                StringBuilder stringBuilder = new StringBuilder(((24 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length());
                stringBuilder.append("Factory[type=");
                stringBuilder.append(valueOf);
                stringBuilder.append("+");
                stringBuilder.append(valueOf2);
                stringBuilder.append(",adapter=");
                stringBuilder.append(valueOf3);
                stringBuilder.append("]");
                return stringBuilder.toString();
            }

            public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
                Class s = com_google_android_gms_internal_zzaoo_T.m15s();
                if (s != cls) {
                    if (s != cls2) {
                        return null;
                    }
                }
                return com_google_android_gms_internal_zzank__super_TT;
            }
        };
    }

    public static <TT> zzanl zzb(final Class<TT> cls, final zzank<TT> com_google_android_gms_internal_zzank_TT) {
        return new zzanl() {
            public String toString() {
                String valueOf = String.valueOf(cls.getName());
                String valueOf2 = String.valueOf(com_google_android_gms_internal_zzank_TT);
                StringBuilder stringBuilder = new StringBuilder((32 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length());
                stringBuilder.append("Factory[typeHierarchy=");
                stringBuilder.append(valueOf);
                stringBuilder.append(",adapter=");
                stringBuilder.append(valueOf2);
                stringBuilder.append("]");
                return stringBuilder.toString();
            }

            public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
                return cls.isAssignableFrom(com_google_android_gms_internal_zzaoo_T.m15s()) ? com_google_android_gms_internal_zzank_TT : null;
            }
        };
    }

    public static <TT> zzanl zzb(final Class<TT> cls, final Class<? extends TT> cls2, final zzank<? super TT> com_google_android_gms_internal_zzank__super_TT) {
        return new zzanl() {
            public String toString() {
                String valueOf = String.valueOf(cls.getName());
                String valueOf2 = String.valueOf(cls2.getName());
                String valueOf3 = String.valueOf(com_google_android_gms_internal_zzank__super_TT);
                StringBuilder stringBuilder = new StringBuilder(((24 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length());
                stringBuilder.append("Factory[type=");
                stringBuilder.append(valueOf);
                stringBuilder.append("+");
                stringBuilder.append(valueOf2);
                stringBuilder.append(",adapter=");
                stringBuilder.append(valueOf3);
                stringBuilder.append("]");
                return stringBuilder.toString();
            }

            public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
                Class s = com_google_android_gms_internal_zzaoo_T.m15s();
                if (s != cls) {
                    if (s != cls2) {
                        return null;
                    }
                }
                return com_google_android_gms_internal_zzank__super_TT;
            }
        };
    }
}
