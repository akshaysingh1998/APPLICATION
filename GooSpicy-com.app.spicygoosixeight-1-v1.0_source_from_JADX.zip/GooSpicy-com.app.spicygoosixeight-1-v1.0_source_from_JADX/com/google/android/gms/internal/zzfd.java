package com.google.android.gms.internal;

import java.util.Map;
import java.util.WeakHashMap;

@zzir
public final class zzfd implements zzet {
    private final Map<zzll, Integer> zzbjd = new WeakHashMap();
    private boolean zzbje;

    private static int zza(android.content.Context r2, java.util.Map<java.lang.String, java.lang.String> r3, java.lang.String r4, int r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = r3.get(r4);
        r3 = (java.lang.String) r3;
        if (r3 == 0) goto L_0x0045;
    L_0x0008:
        r0 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ NumberFormatException -> 0x0015 }
        r1 = java.lang.Integer.parseInt(r3);	 Catch:{ NumberFormatException -> 0x0015 }
        r2 = r0.zza(r2, r1);	 Catch:{ NumberFormatException -> 0x0015 }
        return r2;
    L_0x0015:
        r2 = new java.lang.StringBuilder;
        r0 = 34;
        r1 = java.lang.String.valueOf(r4);
        r1 = r1.length();
        r0 = r0 + r1;
        r1 = java.lang.String.valueOf(r3);
        r1 = r1.length();
        r0 = r0 + r1;
        r2.<init>(r0);
        r0 = "Could not parse ";
        r2.append(r0);
        r2.append(r4);
        r4 = " in a video GMSG: ";
        r2.append(r4);
        r2.append(r3);
        r2 = r2.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r2);
    L_0x0045:
        r2 = r5;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfd.zza(android.content.Context, java.util.Map, java.lang.String, int):int");
    }

    public void zza(com.google.android.gms.internal.zzll r11, java.util.Map<java.lang.String, java.lang.String> r12) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r10 = this;
        r0 = "action";
        r0 = r12.get(r0);
        r0 = (java.lang.String) r0;
        if (r0 != 0) goto L_0x0010;
    L_0x000a:
        r11 = "Action missing from video GMSG.";
    L_0x000c:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r11);
        return;
    L_0x0010:
        r1 = 3;
        r1 = com.google.android.gms.ads.internal.util.client.zzb.zzaz(r1);
        if (r1 == 0) goto L_0x0059;
    L_0x0017:
        r1 = new org.json.JSONObject;
        r1.<init>(r12);
        r2 = "google.afma.Notify_dt";
        r1.remove(r2);
        r1 = r1.toString();
        r1 = java.lang.String.valueOf(r1);
        r2 = new java.lang.StringBuilder;
        r3 = 13;
        r4 = java.lang.String.valueOf(r0);
        r4 = r4.length();
        r3 = r3 + r4;
        r4 = java.lang.String.valueOf(r1);
        r4 = r4.length();
        r3 = r3 + r4;
        r2.<init>(r3);
        r3 = "Video GMSG: ";
        r2.append(r3);
        r2.append(r0);
        r3 = " ";
        r2.append(r3);
        r2.append(r1);
        r1 = r2.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r1);
    L_0x0059:
        r1 = "background";
        r1 = r1.equals(r0);
        if (r1 == 0) goto L_0x0096;
    L_0x0061:
        r0 = "color";
        r12 = r12.get(r0);
        r12 = (java.lang.String) r12;
        r0 = android.text.TextUtils.isEmpty(r12);
        if (r0 == 0) goto L_0x0072;
    L_0x006f:
        r11 = "Color parameter missing from color video GMSG.";
        goto L_0x000c;
    L_0x0072:
        r12 = android.graphics.Color.parseColor(r12);	 Catch:{ IllegalArgumentException -> 0x0090 }
        r0 = r11.zzur();	 Catch:{ IllegalArgumentException -> 0x0090 }
        if (r0 == 0) goto L_0x0086;	 Catch:{ IllegalArgumentException -> 0x0090 }
    L_0x007c:
        r0 = r0.zzuc();	 Catch:{ IllegalArgumentException -> 0x0090 }
        if (r0 == 0) goto L_0x0086;	 Catch:{ IllegalArgumentException -> 0x0090 }
    L_0x0082:
        r0.setBackgroundColor(r12);	 Catch:{ IllegalArgumentException -> 0x0090 }
        return;	 Catch:{ IllegalArgumentException -> 0x0090 }
    L_0x0086:
        r0 = r10.zzbjd;	 Catch:{ IllegalArgumentException -> 0x0090 }
        r12 = java.lang.Integer.valueOf(r12);	 Catch:{ IllegalArgumentException -> 0x0090 }
        r0.put(r11, r12);	 Catch:{ IllegalArgumentException -> 0x0090 }
        return;
    L_0x0090:
        r11 = "Invalid color parameter in video GMSG.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r11);
        return;
    L_0x0096:
        r7 = r11.zzur();
        if (r7 != 0) goto L_0x00a0;
    L_0x009c:
        r11 = "Could not get underlay container for a video GMSG.";
        goto L_0x000c;
    L_0x00a0:
        r1 = "new";
        r1 = r1.equals(r0);
        r2 = "position";
        r2 = r2.equals(r0);
        r3 = 0;
        if (r1 != 0) goto L_0x022c;
    L_0x00af:
        if (r2 == 0) goto L_0x00b3;
    L_0x00b1:
        goto L_0x022c;
    L_0x00b3:
        r1 = r7.zzuc();
        if (r1 != 0) goto L_0x00bd;
    L_0x00b9:
        com.google.android.gms.ads.internal.overlay.zzk.zzi(r11);
        return;
    L_0x00bd:
        r2 = "click";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x00e9;
    L_0x00c5:
        r11 = r11.getContext();
        r0 = "x";
        r0 = zza(r11, r12, r0, r3);
        r2 = "y";
        r11 = zza(r11, r12, r2, r3);
        r4 = android.os.SystemClock.uptimeMillis();
        r6 = 0;
        r7 = (float) r0;
        r8 = (float) r11;
        r9 = 0;
        r2 = r4;
        r11 = android.view.MotionEvent.obtain(r2, r4, r6, r7, r8, r9);
        r1.zzd(r11);
        r11.recycle();
        return;
    L_0x00e9:
        r2 = "currentTime";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x0124;
    L_0x00f1:
        r11 = "time";
        r11 = r12.get(r11);
        r11 = (java.lang.String) r11;
        if (r11 != 0) goto L_0x00ff;
    L_0x00fb:
        r11 = "Time parameter missing from currentTime video GMSG.";
        goto L_0x000c;
    L_0x00ff:
        r12 = java.lang.Float.parseFloat(r11);	 Catch:{ NumberFormatException -> 0x010b }
        r0 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;	 Catch:{ NumberFormatException -> 0x010b }
        r12 = r12 * r0;	 Catch:{ NumberFormatException -> 0x010b }
        r12 = (int) r12;	 Catch:{ NumberFormatException -> 0x010b }
        r1.seekTo(r12);	 Catch:{ NumberFormatException -> 0x010b }
        return;
    L_0x010b:
        r12 = "Could not parse time parameter from currentTime video GMSG: ";
        r11 = java.lang.String.valueOf(r11);
        r0 = r11.length();
        if (r0 == 0) goto L_0x011d;
    L_0x0117:
        r11 = r12.concat(r11);
        goto L_0x0228;
    L_0x011d:
        r11 = new java.lang.String;
        r11.<init>(r12);
        goto L_0x0228;
    L_0x0124:
        r2 = "hide";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x0131;
    L_0x012c:
        r11 = 4;
        r1.setVisibility(r11);
        return;
    L_0x0131:
        r2 = "load";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x013d;
    L_0x0139:
        r1.zzlx();
        return;
    L_0x013d:
        r2 = "mimetype";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x0151;
    L_0x0145:
        r11 = "mimetype";
        r11 = r12.get(r11);
        r11 = (java.lang.String) r11;
        r1.setMimeType(r11);
        return;
    L_0x0151:
        r2 = "muted";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x016f;
    L_0x0159:
        r11 = "muted";
        r11 = r12.get(r11);
        r11 = (java.lang.String) r11;
        r11 = java.lang.Boolean.parseBoolean(r11);
        if (r11 == 0) goto L_0x016b;
    L_0x0167:
        r1.zznq();
        return;
    L_0x016b:
        r1.zznr();
        return;
    L_0x016f:
        r2 = "pause";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x017b;
    L_0x0177:
        r1.pause();
        return;
    L_0x017b:
        r2 = "play";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x0187;
    L_0x0183:
        r1.play();
        return;
    L_0x0187:
        r2 = "show";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x0193;
    L_0x018f:
        r1.setVisibility(r3);
        return;
    L_0x0193:
        r2 = "src";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x01a7;
    L_0x019b:
        r11 = "src";
        r11 = r12.get(r11);
        r11 = (java.lang.String) r11;
        r1.zzbx(r11);
        return;
    L_0x01a7:
        r2 = "touchMove";
        r2 = r2.equals(r0);
        if (r2 == 0) goto L_0x01d3;
    L_0x01af:
        r0 = r11.getContext();
        r2 = "dx";
        r2 = zza(r0, r12, r2, r3);
        r4 = "dy";
        r12 = zza(r0, r12, r4, r3);
        r0 = (float) r2;
        r12 = (float) r12;
        r1.zza(r0, r12);
        r12 = r10.zzbje;
        if (r12 != 0) goto L_0x0295;
    L_0x01c8:
        r11 = r11.zzui();
        r11.zzod();
        r11 = 1;
        r10.zzbje = r11;
        return;
    L_0x01d3:
        r11 = "volume";
        r11 = r11.equals(r0);
        if (r11 == 0) goto L_0x0205;
    L_0x01db:
        r11 = "volume";
        r11 = r12.get(r11);
        r11 = (java.lang.String) r11;
        if (r11 != 0) goto L_0x01e9;
    L_0x01e5:
        r11 = "Level parameter missing from volume video GMSG.";
        goto L_0x000c;
    L_0x01e9:
        r12 = java.lang.Float.parseFloat(r11);	 Catch:{ NumberFormatException -> 0x01f1 }
        r1.zza(r12);	 Catch:{ NumberFormatException -> 0x01f1 }
        return;
    L_0x01f1:
        r12 = "Could not parse volume parameter from volume video GMSG: ";
        r11 = java.lang.String.valueOf(r11);
        r0 = r11.length();
        if (r0 == 0) goto L_0x01ff;
    L_0x01fd:
        goto L_0x0117;
    L_0x01ff:
        r11 = new java.lang.String;
        r11.<init>(r12);
        goto L_0x0228;
    L_0x0205:
        r11 = "watermark";
        r11 = r11.equals(r0);
        if (r11 == 0) goto L_0x0211;
    L_0x020d:
        r1.zzop();
        return;
    L_0x0211:
        r11 = "Unknown video action: ";
        r12 = java.lang.String.valueOf(r0);
        r0 = r12.length();
        if (r0 == 0) goto L_0x0222;
    L_0x021d:
        r11 = r11.concat(r12);
        goto L_0x0228;
    L_0x0222:
        r12 = new java.lang.String;
        r12.<init>(r11);
        r11 = r12;
    L_0x0228:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r11);
        return;
    L_0x022c:
        r0 = r11.getContext();
        r2 = "x";
        r2 = zza(r0, r12, r2, r3);
        r4 = "y";
        r4 = zza(r0, r12, r4, r3);
        r5 = "w";
        r6 = -1;
        r5 = zza(r0, r12, r5, r6);
        r8 = "h";
        r6 = zza(r0, r12, r8, r6);
        r0 = "player";	 Catch:{ NumberFormatException -> 0x0257 }
        r0 = r12.get(r0);	 Catch:{ NumberFormatException -> 0x0257 }
        r0 = (java.lang.String) r0;	 Catch:{ NumberFormatException -> 0x0257 }
        r0 = java.lang.Integer.parseInt(r0);	 Catch:{ NumberFormatException -> 0x0257 }
        r8 = r0;
        goto L_0x0258;
    L_0x0257:
        r8 = r3;
    L_0x0258:
        r0 = "spherical";
        r12 = r12.get(r0);
        r12 = (java.lang.String) r12;
        r12 = java.lang.Boolean.parseBoolean(r12);
        if (r1 == 0) goto L_0x0292;
    L_0x0266:
        r0 = r7.zzuc();
        if (r0 != 0) goto L_0x0292;
    L_0x026c:
        r0 = r7;
        r1 = r2;
        r2 = r4;
        r3 = r5;
        r4 = r6;
        r5 = r8;
        r6 = r12;
        r0.zza(r1, r2, r3, r4, r5, r6);
        r12 = r10.zzbjd;
        r12 = r12.containsKey(r11);
        if (r12 == 0) goto L_0x0295;
    L_0x027e:
        r12 = r10.zzbjd;
        r11 = r12.get(r11);
        r11 = (java.lang.Integer) r11;
        r11 = r11.intValue();
        r12 = r7.zzuc();
        r12.setBackgroundColor(r11);
        return;
    L_0x0292:
        r7.zze(r2, r4, r5, r6);
    L_0x0295:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfd.zza(com.google.android.gms.internal.zzll, java.util.Map):void");
    }
}
