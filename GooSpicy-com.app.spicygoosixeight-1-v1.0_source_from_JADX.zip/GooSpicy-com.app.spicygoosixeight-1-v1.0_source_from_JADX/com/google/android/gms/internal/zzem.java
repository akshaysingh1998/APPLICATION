package com.google.android.gms.internal;

import com.google.android.gms.ads.formats.NativeCustomTemplateAd.OnCustomTemplateAdLoadedListener;
import com.google.android.gms.internal.zzeh.zza;

@zzir
public class zzem extends zza {
    private final OnCustomTemplateAdLoadedListener zzbhp;

    public zzem(OnCustomTemplateAdLoadedListener onCustomTemplateAdLoadedListener) {
        this.zzbhp = onCustomTemplateAdLoadedListener;
    }

    public void zza(zzec com_google_android_gms_internal_zzec) {
        this.zzbhp.onCustomTemplateAdLoaded(new zzed(com_google_android_gms_internal_zzec));
    }
}
