package com.google.android.gms.internal;

import android.support.v4.media.session.PlaybackStateCompat;
import com.bumptech.glide.load.Key;
import com.google.android.gms.internal.zzae.zzf;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;

final class zzak {
    static boolean zzxe = false;
    private static MessageDigest zzxf;
    private static final Object zzxg = new Object();
    private static final Object zzxh = new Object();
    static CountDownLatch zzxi = new CountDownLatch(1);

    private static final class zza implements Runnable {
        private zza() {
        }

        public void run() {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r2 = this;
            r0 = "MD5";	 Catch:{ NoSuchAlgorithmException -> 0x0011, all -> 0x000a }
            r0 = java.security.MessageDigest.getInstance(r0);	 Catch:{ NoSuchAlgorithmException -> 0x0011, all -> 0x000a }
            com.google.android.gms.internal.zzak.zzxf = r0;	 Catch:{ NoSuchAlgorithmException -> 0x0011, all -> 0x000a }
            goto L_0x0011;
        L_0x000a:
            r0 = move-exception;
            r1 = com.google.android.gms.internal.zzak.zzxi;
            r1.countDown();
            throw r0;
        L_0x0011:
            r0 = com.google.android.gms.internal.zzak.zzxi;
            r0.countDown();
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzak.zza.run():void");
        }
    }

    private static int zza(boolean z) {
        return z ? 239 : 255;
    }

    static String zza(com.google.android.gms.internal.zzae.zza com_google_android_gms_internal_zzae_zza, String str, boolean z) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return zza(zzapc.zzf(com_google_android_gms_internal_zzae_zza), str, z);
    }

    static String zza(String str, String str2, boolean z) {
        byte[] zzb = zzb(str, str2, z);
        return zzb != null ? zzaj.zza(zzb, true) : Integer.toString(7);
    }

    static String zza(byte[] bArr, String str, boolean z) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return zzaj.zza(z ? zzb(bArr, str) : zza(bArr, str), true);
    }

    static java.util.Vector<byte[]> zza(byte[] r6, int r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = 0;
        if (r6 == 0) goto L_0x002a;
    L_0x0003:
        r1 = r6.length;
        if (r1 > 0) goto L_0x0007;
    L_0x0006:
        return r0;
    L_0x0007:
        r1 = r6.length;
        r1 = r1 + r7;
        r1 = r1 + -1;
        r1 = r1 / r7;
        r2 = new java.util.Vector;
        r2.<init>();
        r3 = 0;
    L_0x0012:
        if (r3 >= r1) goto L_0x0029;
    L_0x0014:
        r4 = r3 * r7;
        r5 = r6.length;	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
        r5 = r5 - r4;	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
        if (r5 <= r7) goto L_0x001d;	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
    L_0x001a:
        r5 = r4 + r7;	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
        goto L_0x001e;	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
    L_0x001d:
        r5 = r6.length;	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
    L_0x001e:
        r4 = java.util.Arrays.copyOfRange(r6, r4, r5);	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
        r2.add(r4);	 Catch:{ IndexOutOfBoundsException -> 0x0028 }
        r3 = r3 + 1;
        goto L_0x0012;
    L_0x0028:
        return r0;
    L_0x0029:
        return r2;
    L_0x002a:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzak.zza(byte[], int):java.util.Vector<byte[]>");
    }

    static void zza(String str, byte[] bArr) throws UnsupportedEncodingException {
        if (str.length() > 32) {
            str = str.substring(0, 32);
        }
        new zzaot(str.getBytes(Key.STRING_CHARSET_NAME)).zzay(bArr);
    }

    static byte[] zza(byte[] bArr, String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        Vector zza = zza(bArr, 255);
        if (zza != null) {
            if (zza.size() != 0) {
                zzapc com_google_android_gms_internal_zzae_zzf = new zzf();
                com_google_android_gms_internal_zzae_zzf.zzey = new byte[zza.size()][];
                Iterator it = zza.iterator();
                int i = 0;
                while (it.hasNext()) {
                    int i2 = i + 1;
                    com_google_android_gms_internal_zzae_zzf.zzey[i] = zzb((byte[]) it.next(), str, false);
                    i = i2;
                }
                com_google_android_gms_internal_zzae_zzf.zzet = zzg(bArr);
                return zzapc.zzf(com_google_android_gms_internal_zzae_zzf);
            }
        }
        return zzb(zzapc.zzf(zzb(PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM)), str);
    }

    static void zzas() {
        synchronized (zzxh) {
            if (!zzxe) {
                zzxe = true;
                new Thread(new zza()).start();
            }
        }
    }

    static java.security.MessageDigest zzat() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        zzas();
        r0 = zzxi;	 Catch:{ InterruptedException -> 0x000e }
        r1 = 2;	 Catch:{ InterruptedException -> 0x000e }
        r3 = java.util.concurrent.TimeUnit.SECONDS;	 Catch:{ InterruptedException -> 0x000e }
        r0 = r0.await(r1, r3);	 Catch:{ InterruptedException -> 0x000e }
        goto L_0x000f;
    L_0x000e:
        r0 = 0;
    L_0x000f:
        r1 = 0;
        if (r0 != 0) goto L_0x0013;
    L_0x0012:
        return r1;
    L_0x0013:
        r0 = zzxf;
        if (r0 != 0) goto L_0x0018;
    L_0x0017:
        return r1;
    L_0x0018:
        r0 = zzxf;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzak.zzat():java.security.MessageDigest");
    }

    static com.google.android.gms.internal.zzae.zza zzb(long j) {
        com.google.android.gms.internal.zzae.zza com_google_android_gms_internal_zzae_zza = new com.google.android.gms.internal.zzae.zza();
        com_google_android_gms_internal_zzae_zza.zzdl = Long.valueOf(j);
        return com_google_android_gms_internal_zzae_zza;
    }

    static byte[] zzb(java.lang.String r5, java.lang.String r6, boolean r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = new com.google.android.gms.internal.zzae$zzc;
        r0.<init>();
        r1 = 0;
        r2 = r5.length();	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r3 = 3;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r4 = 1;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        if (r2 >= r3) goto L_0x0015;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x000e:
        r2 = "ISO-8859-1";	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = r5.getBytes(r2);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        goto L_0x0019;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0015:
        r5 = com.google.android.gms.internal.zzaj.zza(r5, r4);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0019:
        r0.zzer = r5;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        if (r7 == 0) goto L_0x002f;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x001d:
        r5 = r6.length();	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        if (r5 >= r3) goto L_0x002a;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0023:
        r5 = "ISO-8859-1";	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = r6.getBytes(r5);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        goto L_0x0052;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x002a:
        r5 = com.google.android.gms.internal.zzaj.zza(r6, r4);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        goto L_0x0052;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x002f:
        if (r6 == 0) goto L_0x0047;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0031:
        r5 = r6.length();	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        if (r5 != 0) goto L_0x0038;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0037:
        goto L_0x0047;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0038:
        r5 = "ISO-8859-1";	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = r6.getBytes(r5);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = zza(r5, r1, r4);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = com.google.android.gms.internal.zzaj.zza(r5, r4);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        goto L_0x0052;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0047:
        r5 = 5;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = java.lang.Integer.toString(r5);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r6 = "ISO-8859-1";	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = r5.getBytes(r6);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
    L_0x0052:
        r0.zzes = r5;	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        r5 = com.google.android.gms.internal.zzapc.zzf(r0);	 Catch:{ UnsupportedEncodingException -> 0x0059, UnsupportedEncodingException -> 0x0059 }
        return r5;
    L_0x0059:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzak.zzb(java.lang.String, java.lang.String, boolean):byte[]");
    }

    static byte[] zzb(byte[] bArr, String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return zzb(bArr, str, true);
    }

    private static byte[] zzb(byte[] bArr, String str, boolean z) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        ByteBuffer put;
        int zza = zza(z);
        if (bArr.length > zza) {
            bArr = zzapc.zzf(zzb(PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM));
        }
        if (bArr.length < zza) {
            byte[] bArr2 = new byte[(zza - bArr.length)];
            new SecureRandom().nextBytes(bArr2);
            put = ByteBuffer.allocate(zza + 1).put((byte) bArr.length).put(bArr).put(bArr2);
        } else {
            put = ByteBuffer.allocate(zza + 1).put((byte) bArr.length).put(bArr);
        }
        bArr = put.array();
        if (z) {
            bArr = ByteBuffer.allocate(256).put(zzg(bArr)).put(bArr).array();
        }
        byte[] bArr3 = new byte[256];
        new zzal().zzb(bArr, bArr3);
        if (str != null && str.length() > 0) {
            zza(str, bArr3);
        }
        return bArr3;
    }

    public static byte[] zzg(byte[] bArr) throws NoSuchAlgorithmException {
        synchronized (zzxg) {
            MessageDigest zzat = zzat();
            if (zzat == null) {
                throw new NoSuchAlgorithmException("Cannot compute hash");
            }
            zzat.reset();
            zzat.update(bArr);
            bArr = zzxf.digest();
        }
        return bArr;
    }
}
