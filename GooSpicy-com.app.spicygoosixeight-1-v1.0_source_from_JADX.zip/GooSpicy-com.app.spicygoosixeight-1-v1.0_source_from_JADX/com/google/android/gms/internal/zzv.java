package com.google.android.gms.internal;

import android.os.SystemClock;
import com.bumptech.glide.load.Key;
import java.io.EOFException;
import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class zzv implements zzb {
    private final Map<String, zza> zzbw;
    private long zzbx;
    private final File zzby;
    private final int zzbz;

    static class zza {
        public String zza;
        public long zzb;
        public long zzc;
        public long zzca;
        public String zzcb;
        public long zzd;
        public long zze;
        public Map<String, String> zzf;

        private zza() {
        }

        public zza(String str, com.google.android.gms.internal.zzb.zza com_google_android_gms_internal_zzb_zza) {
            this.zzcb = str;
            this.zzca = (long) com_google_android_gms_internal_zzb_zza.data.length;
            this.zza = com_google_android_gms_internal_zzb_zza.zza;
            this.zzb = com_google_android_gms_internal_zzb_zza.zzb;
            this.zzc = com_google_android_gms_internal_zzb_zza.zzc;
            this.zzd = com_google_android_gms_internal_zzb_zza.zzd;
            this.zze = com_google_android_gms_internal_zzb_zza.zze;
            this.zzf = com_google_android_gms_internal_zzb_zza.zzf;
        }

        public static zza zzf(InputStream inputStream) throws IOException {
            zza com_google_android_gms_internal_zzv_zza = new zza();
            if (zzv.zzb(inputStream) != 538247942) {
                throw new IOException();
            }
            com_google_android_gms_internal_zzv_zza.zzcb = zzv.zzd(inputStream);
            com_google_android_gms_internal_zzv_zza.zza = zzv.zzd(inputStream);
            if (com_google_android_gms_internal_zzv_zza.zza.equals("")) {
                com_google_android_gms_internal_zzv_zza.zza = null;
            }
            com_google_android_gms_internal_zzv_zza.zzb = zzv.zzc(inputStream);
            com_google_android_gms_internal_zzv_zza.zzc = zzv.zzc(inputStream);
            com_google_android_gms_internal_zzv_zza.zzd = zzv.zzc(inputStream);
            com_google_android_gms_internal_zzv_zza.zze = zzv.zzc(inputStream);
            com_google_android_gms_internal_zzv_zza.zzf = zzv.zze(inputStream);
            return com_google_android_gms_internal_zzv_zza;
        }

        public boolean zza(OutputStream outputStream) {
            try {
                zzv.zza(outputStream, 538247942);
                zzv.zza(outputStream, this.zzcb);
                zzv.zza(outputStream, this.zza == null ? "" : this.zza);
                zzv.zza(outputStream, this.zzb);
                zzv.zza(outputStream, this.zzc);
                zzv.zza(outputStream, this.zzd);
                zzv.zza(outputStream, this.zze);
                zzv.zza(this.zzf, outputStream);
                outputStream.flush();
                return true;
            } catch (IOException e) {
                zzs.zzb("%s", e.toString());
                return false;
            }
        }

        public com.google.android.gms.internal.zzb.zza zzb(byte[] bArr) {
            com.google.android.gms.internal.zzb.zza com_google_android_gms_internal_zzb_zza = new com.google.android.gms.internal.zzb.zza();
            com_google_android_gms_internal_zzb_zza.data = bArr;
            com_google_android_gms_internal_zzb_zza.zza = this.zza;
            com_google_android_gms_internal_zzb_zza.zzb = this.zzb;
            com_google_android_gms_internal_zzb_zza.zzc = this.zzc;
            com_google_android_gms_internal_zzb_zza.zzd = this.zzd;
            com_google_android_gms_internal_zzb_zza.zze = this.zze;
            com_google_android_gms_internal_zzb_zza.zzf = this.zzf;
            return com_google_android_gms_internal_zzb_zza;
        }
    }

    private static class zzb extends FilterInputStream {
        private int zzcc;

        private zzb(InputStream inputStream) {
            super(inputStream);
            this.zzcc = 0;
        }

        public int read() throws IOException {
            int read = super.read();
            if (read != -1) {
                this.zzcc++;
            }
            return read;
        }

        public int read(byte[] bArr, int i, int i2) throws IOException {
            int read = super.read(bArr, i, i2);
            if (read != -1) {
                this.zzcc += read;
            }
            return read;
        }
    }

    public zzv(File file) {
        this(file, 5242880);
    }

    public zzv(File file, int i) {
        this.zzbw = new LinkedHashMap(16, 0.75f, true);
        this.zzbx = 0;
        this.zzby = file;
        this.zzbz = i;
    }

    private void removeEntry(String str) {
        zza com_google_android_gms_internal_zzv_zza = (zza) this.zzbw.get(str);
        if (com_google_android_gms_internal_zzv_zza != null) {
            this.zzbx -= com_google_android_gms_internal_zzv_zza.zzca;
            this.zzbw.remove(str);
        }
    }

    private static int zza(InputStream inputStream) throws IOException {
        int read = inputStream.read();
        if (read != -1) {
            return read;
        }
        throw new EOFException();
    }

    static void zza(OutputStream outputStream, int i) throws IOException {
        outputStream.write((i >> 0) & 255);
        outputStream.write((i >> 8) & 255);
        outputStream.write((i >> 16) & 255);
        outputStream.write((i >> 24) & 255);
    }

    static void zza(OutputStream outputStream, long j) throws IOException {
        outputStream.write((byte) ((int) (j >>> null)));
        outputStream.write((byte) ((int) (j >>> 8)));
        outputStream.write((byte) ((int) (j >>> 16)));
        outputStream.write((byte) ((int) (j >>> 24)));
        outputStream.write((byte) ((int) (j >>> 32)));
        outputStream.write((byte) ((int) (j >>> 40)));
        outputStream.write((byte) ((int) (j >>> 48)));
        outputStream.write((byte) ((int) (j >>> 56)));
    }

    static void zza(OutputStream outputStream, String str) throws IOException {
        byte[] bytes = str.getBytes(Key.STRING_CHARSET_NAME);
        zza(outputStream, (long) bytes.length);
        outputStream.write(bytes, 0, bytes.length);
    }

    private void zza(String str, zza com_google_android_gms_internal_zzv_zza) {
        if (this.zzbw.containsKey(str)) {
            this.zzbx += com_google_android_gms_internal_zzv_zza.zzca - ((zza) this.zzbw.get(str)).zzca;
        } else {
            this.zzbx += com_google_android_gms_internal_zzv_zza.zzca;
        }
        this.zzbw.put(str, com_google_android_gms_internal_zzv_zza);
    }

    static void zza(Map<String, String> map, OutputStream outputStream) throws IOException {
        if (map != null) {
            zza(outputStream, map.size());
            for (Entry entry : map.entrySet()) {
                zza(outputStream, (String) entry.getKey());
                zza(outputStream, (String) entry.getValue());
            }
            return;
        }
        zza(outputStream, 0);
    }

    private static byte[] zza(InputStream inputStream, int i) throws IOException {
        byte[] bArr = new byte[i];
        int i2 = 0;
        while (i2 < i) {
            int read = inputStream.read(bArr, i2, i - i2);
            if (read == -1) {
                break;
            }
            i2 += read;
        }
        if (i2 == i) {
            return bArr;
        }
        StringBuilder stringBuilder = new StringBuilder(50);
        stringBuilder.append("Expected ");
        stringBuilder.append(i);
        stringBuilder.append(" bytes, read ");
        stringBuilder.append(i2);
        stringBuilder.append(" bytes");
        throw new IOException(stringBuilder.toString());
    }

    static int zzb(InputStream inputStream) throws IOException {
        return (zza(inputStream) << 24) | ((((zza(inputStream) << 0) | 0) | (zza(inputStream) << 8)) | (zza(inputStream) << 16));
    }

    static long zzc(InputStream inputStream) throws IOException {
        return (((((((0 | ((((long) zza(inputStream)) & 255) << null)) | ((((long) zza(inputStream)) & 255) << 8)) | ((((long) zza(inputStream)) & 255) << 16)) | ((((long) zza(inputStream)) & 255) << 24)) | ((((long) zza(inputStream)) & 255) << 32)) | ((((long) zza(inputStream)) & 255) << 40)) | ((((long) zza(inputStream)) & 255) << 48)) | ((((long) zza(inputStream)) & 255) << 56);
    }

    private void zzc(int i) {
        long j = (long) i;
        if (this.zzbx + j >= ((long) this.zzbz)) {
            long j2;
            if (zzs.DEBUG) {
                zzs.zza("Pruning old cache entries.", new Object[0]);
            }
            long j3 = r0.zzbx;
            long elapsedRealtime = SystemClock.elapsedRealtime();
            Iterator it = r0.zzbw.entrySet().iterator();
            int i2 = 0;
            while (it.hasNext()) {
                long j4;
                zza com_google_android_gms_internal_zzv_zza = (zza) ((Entry) it.next()).getValue();
                if (zzf(com_google_android_gms_internal_zzv_zza.zzcb).delete()) {
                    j4 = j;
                    j2 = elapsedRealtime;
                    r0.zzbx -= com_google_android_gms_internal_zzv_zza.zzca;
                } else {
                    j4 = j;
                    j2 = elapsedRealtime;
                    zzs.zzb("Could not delete cache entry for key=%s, filename=%s", com_google_android_gms_internal_zzv_zza.zzcb, zze(com_google_android_gms_internal_zzv_zza.zzcb));
                }
                it.remove();
                i2++;
                if (((float) (r0.zzbx + j4)) < ((float) r0.zzbz) * 0.9f) {
                    break;
                }
                j = j4;
                elapsedRealtime = j2;
            }
            j2 = elapsedRealtime;
            if (zzs.DEBUG) {
                zzs.zza("pruned %d files, %d bytes, %d ms", Integer.valueOf(i2), Long.valueOf(r0.zzbx - j3), Long.valueOf(SystemClock.elapsedRealtime() - j2));
            }
        }
    }

    static String zzd(InputStream inputStream) throws IOException {
        return new String(zza(inputStream, (int) zzc(inputStream)), Key.STRING_CHARSET_NAME);
    }

    private String zze(String str) {
        int length = str.length() / 2;
        String valueOf = String.valueOf(String.valueOf(str.substring(0, length).hashCode()));
        str = String.valueOf(String.valueOf(str.substring(length).hashCode()));
        return str.length() != 0 ? valueOf.concat(str) : new String(valueOf);
    }

    static Map<String, String> zze(InputStream inputStream) throws IOException {
        int zzb = zzb(inputStream);
        Map<String, String> emptyMap = zzb == 0 ? Collections.emptyMap() : new HashMap(zzb);
        for (int i = 0; i < zzb; i++) {
            emptyMap.put(zzd(inputStream).intern(), zzd(inputStream).intern());
        }
        return emptyMap;
    }

    public synchronized void initialize() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r8 = this;
        monitor-enter(r8);
        r0 = r8.zzby;	 Catch:{ all -> 0x0070 }
        r0 = r0.exists();	 Catch:{ all -> 0x0070 }
        r1 = 0;	 Catch:{ all -> 0x0070 }
        if (r0 != 0) goto L_0x0024;	 Catch:{ all -> 0x0070 }
    L_0x000a:
        r0 = r8.zzby;	 Catch:{ all -> 0x0070 }
        r0 = r0.mkdirs();	 Catch:{ all -> 0x0070 }
        if (r0 != 0) goto L_0x0022;	 Catch:{ all -> 0x0070 }
    L_0x0012:
        r0 = "Unable to create cache dir %s";	 Catch:{ all -> 0x0070 }
        r2 = 1;	 Catch:{ all -> 0x0070 }
        r2 = new java.lang.Object[r2];	 Catch:{ all -> 0x0070 }
        r3 = r8.zzby;	 Catch:{ all -> 0x0070 }
        r3 = r3.getAbsolutePath();	 Catch:{ all -> 0x0070 }
        r2[r1] = r3;	 Catch:{ all -> 0x0070 }
        com.google.android.gms.internal.zzs.zzc(r0, r2);	 Catch:{ all -> 0x0070 }
    L_0x0022:
        monitor-exit(r8);
        return;
    L_0x0024:
        r0 = r8.zzby;	 Catch:{ all -> 0x0070 }
        r0 = r0.listFiles();	 Catch:{ all -> 0x0070 }
        if (r0 != 0) goto L_0x002e;
    L_0x002c:
        monitor-exit(r8);
        return;
    L_0x002e:
        r2 = r0.length;	 Catch:{ all -> 0x0070 }
    L_0x002f:
        if (r1 >= r2) goto L_0x006e;	 Catch:{ all -> 0x0070 }
    L_0x0031:
        r3 = r0[r1];	 Catch:{ all -> 0x0070 }
        r4 = 0;
        r5 = new java.io.BufferedInputStream;	 Catch:{ IOException -> 0x005a }
        r6 = new java.io.FileInputStream;	 Catch:{ IOException -> 0x005a }
        r6.<init>(r3);	 Catch:{ IOException -> 0x005a }
        r5.<init>(r6);	 Catch:{ IOException -> 0x005a }
        r4 = com.google.android.gms.internal.zzv.zza.zzf(r5);	 Catch:{ IOException -> 0x0056, all -> 0x0053 }
        r6 = r3.length();	 Catch:{ IOException -> 0x0056, all -> 0x0053 }
        r4.zzca = r6;	 Catch:{ IOException -> 0x0056, all -> 0x0053 }
        r6 = r4.zzcb;	 Catch:{ IOException -> 0x0056, all -> 0x0053 }
        r8.zza(r6, r4);	 Catch:{ IOException -> 0x0056, all -> 0x0053 }
        if (r5 == 0) goto L_0x006b;
    L_0x004f:
        r5.close();	 Catch:{ IOException -> 0x006b }
        goto L_0x006b;
    L_0x0053:
        r0 = move-exception;
        r4 = r5;
        goto L_0x0060;
    L_0x0056:
        r4 = r5;
        goto L_0x005a;
    L_0x0058:
        r0 = move-exception;
        goto L_0x0060;
    L_0x005a:
        if (r3 == 0) goto L_0x0066;
    L_0x005c:
        r3.delete();	 Catch:{ all -> 0x0058 }
        goto L_0x0066;
    L_0x0060:
        if (r4 == 0) goto L_0x0065;
    L_0x0062:
        r4.close();	 Catch:{ IOException -> 0x0065 }
    L_0x0065:
        throw r0;	 Catch:{ all -> 0x0070 }
    L_0x0066:
        if (r4 == 0) goto L_0x006b;
    L_0x0068:
        r4.close();	 Catch:{ IOException -> 0x006b }
    L_0x006b:
        r1 = r1 + 1;
        goto L_0x002f;
    L_0x006e:
        monitor-exit(r8);
        return;
    L_0x0070:
        r0 = move-exception;
        monitor-exit(r8);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzv.initialize():void");
    }

    public synchronized void remove(String str) {
        boolean delete = zzf(str).delete();
        removeEntry(str);
        if (!delete) {
            zzs.zzb("Could not delete cache entry for key=%s, filename=%s", str, zze(str));
        }
    }

    public synchronized com.google.android.gms.internal.zzb.zza zza(java.lang.String r11) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r10 = this;
        monitor-enter(r10);
        r0 = r10.zzbw;	 Catch:{ all -> 0x0071 }
        r0 = r0.get(r11);	 Catch:{ all -> 0x0071 }
        r0 = (com.google.android.gms.internal.zzv.zza) r0;	 Catch:{ all -> 0x0071 }
        r1 = 0;
        if (r0 != 0) goto L_0x000e;
    L_0x000c:
        monitor-exit(r10);
        return r1;
    L_0x000e:
        r2 = r10.zzf(r11);	 Catch:{ all -> 0x0071 }
        r3 = new com.google.android.gms.internal.zzv$zzb;	 Catch:{ IOException -> 0x0042, all -> 0x003f }
        r4 = new java.io.FileInputStream;	 Catch:{ IOException -> 0x0042, all -> 0x003f }
        r4.<init>(r2);	 Catch:{ IOException -> 0x0042, all -> 0x003f }
        r3.<init>(r4);	 Catch:{ IOException -> 0x0042, all -> 0x003f }
        com.google.android.gms.internal.zzv.zza.zzf(r3);	 Catch:{ IOException -> 0x003d }
        r4 = r2.length();	 Catch:{ IOException -> 0x003d }
        r6 = r3.zzcc;	 Catch:{ IOException -> 0x003d }
        r6 = (long) r6;	 Catch:{ IOException -> 0x003d }
        r8 = r4 - r6;	 Catch:{ IOException -> 0x003d }
        r4 = (int) r8;	 Catch:{ IOException -> 0x003d }
        r4 = zza(r3, r4);	 Catch:{ IOException -> 0x003d }
        r0 = r0.zzb(r4);	 Catch:{ IOException -> 0x003d }
        if (r3 == 0) goto L_0x003b;
    L_0x0035:
        r3.close();	 Catch:{ IOException -> 0x0039 }
        goto L_0x003b;
    L_0x0039:
        monitor-exit(r10);
        return r1;
    L_0x003b:
        monitor-exit(r10);
        return r0;
    L_0x003d:
        r0 = move-exception;
        goto L_0x0044;
    L_0x003f:
        r11 = move-exception;
        r3 = r1;
        goto L_0x0068;
    L_0x0042:
        r0 = move-exception;
        r3 = r1;
    L_0x0044:
        r4 = "%s: %s";	 Catch:{ all -> 0x0067 }
        r5 = 2;	 Catch:{ all -> 0x0067 }
        r5 = new java.lang.Object[r5];	 Catch:{ all -> 0x0067 }
        r6 = 0;	 Catch:{ all -> 0x0067 }
        r2 = r2.getAbsolutePath();	 Catch:{ all -> 0x0067 }
        r5[r6] = r2;	 Catch:{ all -> 0x0067 }
        r2 = 1;	 Catch:{ all -> 0x0067 }
        r0 = r0.toString();	 Catch:{ all -> 0x0067 }
        r5[r2] = r0;	 Catch:{ all -> 0x0067 }
        com.google.android.gms.internal.zzs.zzb(r4, r5);	 Catch:{ all -> 0x0067 }
        r10.remove(r11);	 Catch:{ all -> 0x0067 }
        if (r3 == 0) goto L_0x0065;
    L_0x005f:
        r3.close();	 Catch:{ IOException -> 0x0063 }
        goto L_0x0065;
    L_0x0063:
        monitor-exit(r10);
        return r1;
    L_0x0065:
        monitor-exit(r10);
        return r1;
    L_0x0067:
        r11 = move-exception;
    L_0x0068:
        if (r3 == 0) goto L_0x0070;
    L_0x006a:
        r3.close();	 Catch:{ IOException -> 0x006e }
        goto L_0x0070;
    L_0x006e:
        monitor-exit(r10);
        return r1;
    L_0x0070:
        throw r11;	 Catch:{ all -> 0x0071 }
    L_0x0071:
        r11 = move-exception;
        monitor-exit(r10);
        throw r11;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzv.zza(java.lang.String):com.google.android.gms.internal.zzb$zza");
    }

    public synchronized void zza(java.lang.String r7, com.google.android.gms.internal.zzb.zza r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r6 = this;
        monitor-enter(r6);
        r0 = r8.data;	 Catch:{ all -> 0x0055 }
        r0 = r0.length;	 Catch:{ all -> 0x0055 }
        r6.zzc(r0);	 Catch:{ all -> 0x0055 }
        r0 = r6.zzf(r7);	 Catch:{ all -> 0x0055 }
        r1 = 0;
        r2 = 1;
        r3 = new java.io.FileOutputStream;	 Catch:{ IOException -> 0x0040 }
        r3.<init>(r0);	 Catch:{ IOException -> 0x0040 }
        r4 = new com.google.android.gms.internal.zzv$zza;	 Catch:{ IOException -> 0x0040 }
        r4.<init>(r7, r8);	 Catch:{ IOException -> 0x0040 }
        r5 = r4.zza(r3);	 Catch:{ IOException -> 0x0040 }
        if (r5 != 0) goto L_0x0033;	 Catch:{ IOException -> 0x0040 }
    L_0x001d:
        r3.close();	 Catch:{ IOException -> 0x0040 }
        r7 = "Failed to write header for %s";	 Catch:{ IOException -> 0x0040 }
        r8 = new java.lang.Object[r2];	 Catch:{ IOException -> 0x0040 }
        r3 = r0.getAbsolutePath();	 Catch:{ IOException -> 0x0040 }
        r8[r1] = r3;	 Catch:{ IOException -> 0x0040 }
        com.google.android.gms.internal.zzs.zzb(r7, r8);	 Catch:{ IOException -> 0x0040 }
        r7 = new java.io.IOException;	 Catch:{ IOException -> 0x0040 }
        r7.<init>();	 Catch:{ IOException -> 0x0040 }
        throw r7;	 Catch:{ IOException -> 0x0040 }
    L_0x0033:
        r8 = r8.data;	 Catch:{ IOException -> 0x0040 }
        r3.write(r8);	 Catch:{ IOException -> 0x0040 }
        r3.close();	 Catch:{ IOException -> 0x0040 }
        r6.zza(r7, r4);	 Catch:{ IOException -> 0x0040 }
        monitor-exit(r6);
        return;
    L_0x0040:
        r7 = r0.delete();	 Catch:{ all -> 0x0055 }
        if (r7 != 0) goto L_0x0053;	 Catch:{ all -> 0x0055 }
    L_0x0046:
        r7 = "Could not clean up file %s";	 Catch:{ all -> 0x0055 }
        r8 = new java.lang.Object[r2];	 Catch:{ all -> 0x0055 }
        r0 = r0.getAbsolutePath();	 Catch:{ all -> 0x0055 }
        r8[r1] = r0;	 Catch:{ all -> 0x0055 }
        com.google.android.gms.internal.zzs.zzb(r7, r8);	 Catch:{ all -> 0x0055 }
    L_0x0053:
        monitor-exit(r6);
        return;
    L_0x0055:
        r7 = move-exception;
        monitor-exit(r6);
        throw r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzv.zza(java.lang.String, com.google.android.gms.internal.zzb$zza):void");
    }

    public File zzf(String str) {
        return new File(this.zzby, zze(str));
    }
}
