package com.google.android.gms.internal;

@zzir
public class zzis {
    public final zzju zzcdt;
    public final zzcx zzcdu;
    public final zzjb zzcdv;
    public final zzga zzcdw;
    public final zzjx zzcdx;
    public final zzjd zzcdy;
    public final zzjc zzcdz;
    public final zzix zzcea;

    zzis(zzju com_google_android_gms_internal_zzju, zzcx com_google_android_gms_internal_zzcx, zzjb com_google_android_gms_internal_zzjb, zzga com_google_android_gms_internal_zzga, zzjx com_google_android_gms_internal_zzjx, zzjd com_google_android_gms_internal_zzjd, zzjc com_google_android_gms_internal_zzjc, zzix com_google_android_gms_internal_zzix) {
        this.zzcdt = com_google_android_gms_internal_zzju;
        this.zzcdu = com_google_android_gms_internal_zzcx;
        this.zzcdv = com_google_android_gms_internal_zzjb;
        this.zzcdw = com_google_android_gms_internal_zzga;
        this.zzcdx = com_google_android_gms_internal_zzjx;
        this.zzcdy = com_google_android_gms_internal_zzjd;
        this.zzcdz = com_google_android_gms_internal_zzjc;
        this.zzcea = com_google_android_gms_internal_zzix;
    }

    public static zzis zzrg() {
        return new zzis(new zzjv(), new zzcw(), new zzje(), new zzgb(), new zzjw(), new zzjg(), new zzjf(), null);
    }
}
