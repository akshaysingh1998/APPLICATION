package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;
import org.json.JSONObject;

@zzir
public class zzey implements zzet {
    final HashMap<String, zzkz<JSONObject>> zzbiw = new HashMap();

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        zzi((String) map.get("request_id"), (String) map.get("fetched_ad"));
    }

    public Future<JSONObject> zzax(String str) {
        Future com_google_android_gms_internal_zzkz = new zzkz();
        this.zzbiw.put(str, com_google_android_gms_internal_zzkz);
        return com_google_android_gms_internal_zzkz;
    }

    public void zzay(String str) {
        zzkz com_google_android_gms_internal_zzkz = (zzkz) this.zzbiw.get(str);
        if (com_google_android_gms_internal_zzkz == null) {
            zzb.m9e("Could not find the ad request for the corresponding ad response.");
            return;
        }
        if (!com_google_android_gms_internal_zzkz.isDone()) {
            com_google_android_gms_internal_zzkz.cancel(true);
        }
        this.zzbiw.remove(str);
    }

    public void zzi(java.lang.String r3, java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:14:0x0030 in {3, 5, 7, 13, 16} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r0 = "Received ad from the cache.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r0);
        r0 = r2.zzbiw;
        r0 = r0.get(r3);
        r0 = (com.google.android.gms.internal.zzkz) r0;
        if (r0 != 0) goto L_0x0015;
    L_0x000f:
        r3 = "Could not find the ad request for the corresponding ad response.";
        com.google.android.gms.ads.internal.util.client.zzb.m9e(r3);
        return;
    L_0x0015:
        r1 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x0025 }
        r1.<init>(r4);	 Catch:{ JSONException -> 0x0025 }
        r0.zzi(r1);	 Catch:{ JSONException -> 0x0025 }
    L_0x001d:
        r4 = r2.zzbiw;
        r4.remove(r3);
        return;
    L_0x0023:
        r4 = move-exception;
        goto L_0x0031;
    L_0x0025:
        r4 = move-exception;
        r1 = "Failed constructing JSON object from value passed from javascript";	 Catch:{ all -> 0x0023 }
        com.google.android.gms.ads.internal.util.client.zzb.zzb(r1, r4);	 Catch:{ all -> 0x0023 }
        r4 = 0;	 Catch:{ all -> 0x0023 }
        r0.zzi(r4);	 Catch:{ all -> 0x0023 }
        goto L_0x001d;
        return;
    L_0x0031:
        r0 = r2.zzbiw;
        r0.remove(r3);
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzey.zzi(java.lang.String, java.lang.String):void");
    }
}
