package com.google.android.gms.internal;

import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;

@zzir
public class zzlg {
    public void zza(View view, OnGlobalLayoutListener onGlobalLayoutListener) {
        new zzlh(view, onGlobalLayoutListener).zzub();
    }

    public void zza(View view, OnScrollChangedListener onScrollChangedListener) {
        new zzli(view, onScrollChangedListener).zzub();
    }
}
