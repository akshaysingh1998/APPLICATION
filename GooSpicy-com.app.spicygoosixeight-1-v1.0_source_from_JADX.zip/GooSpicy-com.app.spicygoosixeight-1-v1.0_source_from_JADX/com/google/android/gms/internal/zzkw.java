package com.google.android.gms.internal;

@zzir
public class zzkw<T> {
    private T zzcmy;

    public T get() {
        return this.zzcmy;
    }

    public void set(T t) {
        this.zzcmy = t;
    }
}
