package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.customtabs.CustomTabsClient;
import android.support.customtabs.CustomTabsServiceConnection;
import android.support.customtabs.CustomTabsSession;
import java.util.List;

@zzir
public class zzdq implements zzapj {
    private CustomTabsSession zzbem;
    private CustomTabsClient zzben;
    private CustomTabsServiceConnection zzbeo;
    private zza zzbep;

    public interface zza {
        void zzkn();

        void zzko();
    }

    public static boolean zzo(Context context) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager == null) {
            return false;
        }
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://www.example.com"));
        ResolveInfo resolveActivity = packageManager.resolveActivity(intent, 0);
        List queryIntentActivities = packageManager.queryIntentActivities(intent, 65536);
        if (!(queryIntentActivities == null || resolveActivity == null)) {
            for (int i = 0; i < queryIntentActivities.size(); i++) {
                if (resolveActivity.activityInfo.name.equals(((ResolveInfo) queryIntentActivities.get(i)).activityInfo.name)) {
                    return resolveActivity.activityInfo.packageName.equals(zzaph.zzeu(context));
                }
            }
        }
        return false;
    }

    public boolean mayLaunchUrl(Uri uri, Bundle bundle, List<Bundle> list) {
        if (this.zzben == null) {
            return false;
        }
        CustomTabsSession zzkl = zzkl();
        return zzkl == null ? false : zzkl.mayLaunchUrl(uri, bundle, list);
    }

    public void zza(CustomTabsClient customTabsClient) {
        this.zzben = customTabsClient;
        this.zzben.warmup(0);
        if (this.zzbep != null) {
            this.zzbep.zzkn();
        }
    }

    public void zza(zza com_google_android_gms_internal_zzdq_zza) {
        this.zzbep = com_google_android_gms_internal_zzdq_zza;
    }

    public void zzd(Activity activity) {
        if (this.zzbeo != null) {
            activity.unbindService(this.zzbeo);
            this.zzben = null;
            this.zzbem = null;
            this.zzbeo = null;
        }
    }

    public void zze(Activity activity) {
        if (this.zzben == null) {
            String zzeu = zzaph.zzeu(activity);
            if (zzeu != null) {
                this.zzbeo = new zzapi(this);
                CustomTabsClient.bindCustomTabsService(activity, zzeu, this.zzbeo);
            }
        }
    }

    public CustomTabsSession zzkl() {
        if (this.zzben == null) {
            this.zzbem = null;
        } else if (this.zzbem == null) {
            this.zzbem = this.zzben.newSession(null);
        }
        return this.zzbem;
    }

    public void zzkm() {
        this.zzben = null;
        this.zzbem = null;
        if (this.zzbep != null) {
            this.zzbep.zzko();
        }
    }
}
