package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.dynamic.zzg;
import com.google.android.gms.internal.zzdx.zza;

@zzir
public class zzei extends zzg<zzdx> {
    public zzei() {
        super("com.google.android.gms.ads.NativeAdViewDelegateCreatorImpl");
    }

    protected zzdx zzai(IBinder iBinder) {
        return zza.zzaa(iBinder);
    }

    public zzdw zzb(Context context, FrameLayout frameLayout, FrameLayout frameLayout2) {
        try {
            return zzdw.zza.zzz(((zzdx) zzcr(context)).zza(zze.zzae(context), zze.zzae(frameLayout), zze.zzae(frameLayout2), com.google.android.gms.common.internal.zze.xB));
        } catch (Throwable e) {
            zzb.zzd("Could not create remote NativeAdViewDelegate.", e);
            return null;
        }
    }

    protected /* synthetic */ Object zzc(IBinder iBinder) {
        return zzai(iBinder);
    }
}
