package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.ArrayList;
import java.util.Iterator;

@zzir
public class zzcl {
    private final Object zzail = new Object();
    private final int zzart;
    private final int zzaru;
    private final int zzarv;
    private final zzcq zzarw;
    private ArrayList<String> zzarx = new ArrayList();
    private ArrayList<String> zzary = new ArrayList();
    private int zzarz = 0;
    private int zzasa = 0;
    private int zzasb = 0;
    private int zzasc;
    private String zzasd = "";
    private String zzase = "";

    public zzcl(int i, int i2, int i3, int i4) {
        this.zzart = i;
        this.zzaru = i2;
        this.zzarv = i3;
        this.zzarw = new zzcq(i4);
    }

    private String zza(ArrayList<String> arrayList, int i) {
        if (arrayList.isEmpty()) {
            return "";
        }
        StringBuffer stringBuffer = new StringBuffer();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            stringBuffer.append((String) it.next());
            stringBuffer.append(' ');
            if (stringBuffer.length() > i) {
                break;
            }
        }
        stringBuffer.deleteCharAt(stringBuffer.length() - 1);
        String stringBuffer2 = stringBuffer.toString();
        return stringBuffer2.length() < i ? stringBuffer2 : stringBuffer2.substring(0, i);
    }

    private void zzf(String str, boolean z) {
        if (str != null && str.length() >= this.zzarv) {
            synchronized (this.zzail) {
                this.zzarx.add(str);
                this.zzarz += str.length();
                if (z) {
                    this.zzary.add(str);
                }
            }
        }
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zzcl)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zzcl com_google_android_gms_internal_zzcl = (zzcl) obj;
        return com_google_android_gms_internal_zzcl.zzhr() != null && com_google_android_gms_internal_zzcl.zzhr().equals(zzhr());
    }

    public int getScore() {
        return this.zzasc;
    }

    public int hashCode() {
        return zzhr().hashCode();
    }

    public String toString() {
        int i = this.zzasa;
        int i2 = this.zzasc;
        int i3 = this.zzarz;
        String valueOf = String.valueOf(zza(this.zzarx, 100));
        String valueOf2 = String.valueOf(zza(this.zzary, 100));
        String str = this.zzasd;
        String str2 = this.zzase;
        StringBuilder stringBuilder = new StringBuilder((((133 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length()) + String.valueOf(str).length()) + String.valueOf(str2).length());
        stringBuilder.append("ActivityContent fetchId: ");
        stringBuilder.append(i);
        stringBuilder.append(" score:");
        stringBuilder.append(i2);
        stringBuilder.append(" total_length:");
        stringBuilder.append(i3);
        stringBuilder.append("\n text: ");
        stringBuilder.append(valueOf);
        stringBuilder.append("\n viewableText");
        stringBuilder.append(valueOf2);
        stringBuilder.append("\n signture: ");
        stringBuilder.append(str);
        stringBuilder.append("\n viewableSignture: ");
        stringBuilder.append(str2);
        return stringBuilder.toString();
    }

    int zza(int i, int i2) {
        return (i * this.zzart) + (i2 * this.zzaru);
    }

    public void zzd(String str, boolean z) {
        zzf(str, z);
        synchronized (this.zzail) {
            if (this.zzasb < 0) {
                zzb.zzcw("ActivityContent: negative number of WebViews.");
            }
            zzhw();
        }
    }

    public void zze(String str, boolean z) {
        zzf(str, z);
    }

    public boolean zzhq() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzasb == 0;
        }
        return z;
    }

    public String zzhr() {
        return this.zzasd;
    }

    public String zzhs() {
        return this.zzase;
    }

    public void zzht() {
        synchronized (this.zzail) {
            this.zzasc -= 100;
        }
    }

    public void zzhu() {
        synchronized (this.zzail) {
            this.zzasb--;
        }
    }

    public void zzhv() {
        synchronized (this.zzail) {
            this.zzasb++;
        }
    }

    public void zzhw() {
        synchronized (this.zzail) {
            int zza = zza(this.zzarz, this.zzasa);
            if (zza > this.zzasc) {
                this.zzasc = zza;
                this.zzasd = this.zzarw.zza(this.zzarx);
                this.zzase = this.zzarw.zza(this.zzary);
            }
        }
    }

    int zzhx() {
        return this.zzarz;
    }

    public void zzl(int i) {
        this.zzasa = i;
    }
}
