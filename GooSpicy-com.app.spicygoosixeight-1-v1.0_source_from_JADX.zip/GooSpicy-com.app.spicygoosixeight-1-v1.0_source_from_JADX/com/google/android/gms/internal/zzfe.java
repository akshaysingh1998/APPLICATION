package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.util.Map;

@zzir
class zzfe implements zzet {
    zzfe() {
    }

    private int zzg(Map<String, String> map) throws NullPointerException, NumberFormatException {
        int parseInt = Integer.parseInt((String) map.get("playbackState"));
        if (parseInt >= 0) {
            if (3 >= parseInt) {
                return parseInt;
            }
        }
        return 0;
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        if (((Boolean) zzdc.zzbaz.get()).booleanValue()) {
            zzlq zzuu = com_google_android_gms_internal_zzll.zzuu();
            if (zzuu == null) {
                try {
                    zzlq com_google_android_gms_internal_zzlq = new zzlq(com_google_android_gms_internal_zzll, Float.parseFloat((String) map.get("duration")));
                    com_google_android_gms_internal_zzll.zza(com_google_android_gms_internal_zzlq);
                    zzuu = com_google_android_gms_internal_zzlq;
                } catch (Throwable e) {
                    zzb.zzb("Unable to parse videoMeta message.", e);
                    zzu.zzft().zzb(e, true);
                    return;
                }
            }
            zzuu.zza(Float.parseFloat((String) map.get("currentTime")), zzg(map), "1".equals(map.get("muted")));
        }
    }
}
