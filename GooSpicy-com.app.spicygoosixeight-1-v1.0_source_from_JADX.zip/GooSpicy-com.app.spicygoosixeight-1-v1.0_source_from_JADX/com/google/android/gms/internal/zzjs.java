package com.google.android.gms.internal;

import android.view.View;

public interface zzjs {
    void zzcj(String str);

    void zzck(String str);

    void zzj(View view);

    void zzry();
}
