package com.google.android.gms.internal;

public interface zzjo {
    void zza(String str, int i);

    void zzch(String str);
}
