package com.google.android.gms.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class zzaoi extends zzank<Object> {
    public static final zzanl bfE = new C08571();
    private final zzams beA;

    static class C08571 implements zzanl {
        C08571() {
        }

        public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
            return com_google_android_gms_internal_zzaoo_T.m15s() == Object.class ? new zzaoi(com_google_android_gms_internal_zzams) : null;
        }
    }

    private zzaoi(zzams com_google_android_gms_internal_zzams) {
        this.beA = com_google_android_gms_internal_zzams;
    }

    public void zza(zzaor com_google_android_gms_internal_zzaor, Object obj) throws IOException {
        if (obj == null) {
            com_google_android_gms_internal_zzaor.mo2318r();
            return;
        }
        zzank zzk = this.beA.zzk(obj.getClass());
        if (zzk instanceof zzaoi) {
            com_google_android_gms_internal_zzaor.mo2316p();
            com_google_android_gms_internal_zzaor.mo2317q();
            return;
        }
        zzk.zza(com_google_android_gms_internal_zzaor, obj);
    }

    public Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
        switch (com_google_android_gms_internal_zzaop.mo2301h()) {
            case BEGIN_ARRAY:
                List arrayList = new ArrayList();
                com_google_android_gms_internal_zzaop.beginArray();
                while (com_google_android_gms_internal_zzaop.hasNext()) {
                    arrayList.add(zzb(com_google_android_gms_internal_zzaop));
                }
                com_google_android_gms_internal_zzaop.endArray();
                return arrayList;
            case BEGIN_OBJECT:
                Map com_google_android_gms_internal_zzanw = new zzanw();
                com_google_android_gms_internal_zzaop.beginObject();
                while (com_google_android_gms_internal_zzaop.hasNext()) {
                    com_google_android_gms_internal_zzanw.put(com_google_android_gms_internal_zzaop.nextName(), zzb(com_google_android_gms_internal_zzaop));
                }
                com_google_android_gms_internal_zzaop.endObject();
                return com_google_android_gms_internal_zzanw;
            case STRING:
                return com_google_android_gms_internal_zzaop.nextString();
            case NUMBER:
                return Double.valueOf(com_google_android_gms_internal_zzaop.nextDouble());
            case BOOLEAN:
                return Boolean.valueOf(com_google_android_gms_internal_zzaop.nextBoolean());
            case NULL:
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            default:
                throw new IllegalStateException();
        }
    }
}
