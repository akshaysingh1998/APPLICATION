package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.internal.zzq;
import com.google.android.gms.signin.internal.zzd;

public interface zzvx extends zze {
    void connect();

    void zza(zzq com_google_android_gms_common_internal_zzq, boolean z);

    void zza(zzd com_google_android_gms_signin_internal_zzd);

    void zzbzk();
}
