package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import com.google.android.gms.common.zzc;
import com.google.android.gms.dynamic.zzg;
import com.google.android.gms.internal.zzcb.zza;

public final class zzbz extends zzg<zzcb> {
    private static final zzbz zzaiu = new zzbz();

    private zzbz() {
        super("com.google.android.gms.ads.adshield.AdShieldCreatorImpl");
    }

    public static zzca zzb(String str, Context context, boolean z) {
        if (zzc.zzand().isGooglePlayServicesAvailable(context) == 0) {
            zzca zzc = zzaiu.zzc(str, context, z);
            if (zzc != null) {
                return zzc;
            }
        }
        return new zzby(str, context, z);
    }

    private com.google.android.gms.internal.zzca zzc(java.lang.String r2, android.content.Context r3, boolean r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = com.google.android.gms.dynamic.zze.zzae(r3);
        if (r4 == 0) goto L_0x0011;
    L_0x0006:
        r3 = r1.zzcr(r3);	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
        r3 = (com.google.android.gms.internal.zzcb) r3;	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
        r2 = r3.zza(r2, r0);	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
        goto L_0x001b;	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
    L_0x0011:
        r3 = r1.zzcr(r3);	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
        r3 = (com.google.android.gms.internal.zzcb) r3;	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
        r2 = r3.zzb(r2, r0);	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
    L_0x001b:
        r2 = com.google.android.gms.internal.zzca.zza.zzd(r2);	 Catch:{ RemoteException -> 0x0020, RemoteException -> 0x0020 }
        return r2;
    L_0x0020:
        r2 = 0;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzbz.zzc(java.lang.String, android.content.Context, boolean):com.google.android.gms.internal.zzca");
    }

    protected zzcb zzb(IBinder iBinder) {
        return zza.zze(iBinder);
    }

    protected /* synthetic */ Object zzc(IBinder iBinder) {
        return zzb(iBinder);
    }
}
