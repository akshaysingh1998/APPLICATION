package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.zzq;
import com.google.android.gms.internal.zzig.zza;
import java.util.concurrent.Future;
import org.json.JSONObject;

@zzir
public class zzik extends zzkg {
    private final Object zzail;
    private final zza zzbxu;
    private final zzjy.zza zzbxv;
    private final AdResponseParcel zzbxw;
    private final zzim zzbyu;
    private Future<zzjy> zzbyv;

    public zzik(Context context, zzq com_google_android_gms_ads_internal_zzq, zzjy.zza com_google_android_gms_internal_zzjy_zza, zzas com_google_android_gms_internal_zzas, zza com_google_android_gms_internal_zzig_zza) {
        this(com_google_android_gms_internal_zzjy_zza, com_google_android_gms_internal_zzig_zza, new zzim(context, com_google_android_gms_ads_internal_zzq, new zzkr(context), com_google_android_gms_internal_zzas, com_google_android_gms_internal_zzjy_zza));
    }

    zzik(zzjy.zza com_google_android_gms_internal_zzjy_zza, zza com_google_android_gms_internal_zzig_zza, zzim com_google_android_gms_internal_zzim) {
        this.zzail = new Object();
        this.zzbxv = com_google_android_gms_internal_zzjy_zza;
        this.zzbxw = com_google_android_gms_internal_zzjy_zza.zzciu;
        this.zzbxu = com_google_android_gms_internal_zzig_zza;
        this.zzbyu = com_google_android_gms_internal_zzim;
    }

    private zzjy zzam(int i) {
        AdRequestParcel adRequestParcel = this.zzbxv.zzcit.zzcav;
        int i2 = this.zzbxw.orientation;
        long j = this.zzbxw.zzbnw;
        String str = this.zzbxv.zzcit.zzcay;
        long j2 = this.zzbxw.zzccd;
        AdSizeParcel adSizeParcel = this.zzbxv.zzaoy;
        long j3 = this.zzbxw.zzccb;
        long j4 = this.zzbxv.zzcio;
        long j5 = j2;
        j2 = this.zzbxw.zzccg;
        String str2 = this.zzbxw.zzcch;
        JSONObject jSONObject = this.zzbxv.zzcii;
        JSONObject jSONObject2 = jSONObject;
        long j6 = j4;
        long j7 = j3;
        String str3 = str2;
        AdSizeParcel adSizeParcel2 = adSizeParcel;
        long j8 = j5;
        j5 = j2;
        return new zzjy(adRequestParcel, null, null, i, null, null, i2, j, str, false, null, null, null, null, null, j8, adSizeParcel2, j7, j6, j5, str3, jSONObject2, null, null, null, null, this.zzbxv.zzciu.zzccu, this.zzbxv.zzciu.zzccv, null, null);
    }

    public void onStop() {
        synchronized (this.zzail) {
            if (this.zzbyv != null) {
                this.zzbyv.cancel(true);
            }
        }
    }

    public void zzew() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r6 = this;
        r0 = 0;
        r1 = 0;
        r2 = r6.zzail;	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
        monitor-enter(r2);	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
        r3 = r6.zzbyu;	 Catch:{ all -> 0x001e }
        r3 = com.google.android.gms.internal.zzkk.zza(r3);	 Catch:{ all -> 0x001e }
        r6.zzbyv = r3;	 Catch:{ all -> 0x001e }
        monitor-exit(r2);	 Catch:{ all -> 0x001e }
        r2 = r6.zzbyv;	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
        r3 = 60000; // 0xea60 float:8.4078E-41 double:2.9644E-319;	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
        r5 = java.util.concurrent.TimeUnit.MILLISECONDS;	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
        r2 = r2.get(r3, r5);	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
        r2 = (com.google.android.gms.internal.zzjy) r2;	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
        r0 = -2;
        r1 = r2;
        goto L_0x002d;
    L_0x001e:
        r3 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x001e }
        throw r3;	 Catch:{ TimeoutException -> 0x0021, ExecutionException -> 0x002d, ExecutionException -> 0x002d, ExecutionException -> 0x002d }
    L_0x0021:
        r0 = "Timed out waiting for native ad.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r0);
        r0 = 2;
        r2 = r6.zzbyv;
        r3 = 1;
        r2.cancel(r3);
    L_0x002d:
        if (r1 == 0) goto L_0x0030;
    L_0x002f:
        goto L_0x0034;
    L_0x0030:
        r1 = r6.zzam(r0);
    L_0x0034:
        r0 = com.google.android.gms.internal.zzkl.zzclg;
        r2 = new com.google.android.gms.internal.zzik$1;
        r2.<init>(r6, r1);
        r0.post(r2);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzik.zzew():void");
    }
}
