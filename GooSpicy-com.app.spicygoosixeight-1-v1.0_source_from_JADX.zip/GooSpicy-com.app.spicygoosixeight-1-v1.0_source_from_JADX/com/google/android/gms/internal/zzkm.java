package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DownloadManager.Request;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.http.SslError;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Callable;

@TargetApi(8)
@zzir
public class zzkm {

    @TargetApi(9)
    public static class zza extends zzkm {
        public zza() {
            super();
        }

        public boolean zza(Request request) {
            request.setShowRunningNotification(true);
            return true;
        }

        public int zztk() {
            return 6;
        }

        public int zztl() {
            return 7;
        }
    }

    @TargetApi(11)
    public static class zzb extends zza {
        public boolean zza(Request request) {
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(1);
            return true;
        }

        public boolean zza(final Context context, final WebSettings webSettings) {
            super.zza(context, webSettings);
            return ((Boolean) zzkx.zzb(new Callable<Boolean>(this) {
                final /* synthetic */ zzb zzclo;

                public /* synthetic */ Object call() throws Exception {
                    return zzto();
                }

                public Boolean zzto() {
                    if (context.getCacheDir() != null) {
                        webSettings.setAppCachePath(context.getCacheDir().getAbsolutePath());
                        webSettings.setAppCacheMaxSize(0);
                        webSettings.setAppCacheEnabled(true);
                    }
                    webSettings.setDatabasePath(context.getDatabasePath("com.google.android.gms.ads.db").getAbsolutePath());
                    webSettings.setDatabaseEnabled(true);
                    webSettings.setDomStorageEnabled(true);
                    webSettings.setDisplayZoomControls(false);
                    webSettings.setBuiltInZoomControls(true);
                    webSettings.setSupportZoom(true);
                    webSettings.setAllowContentAccess(false);
                    return Boolean.valueOf(true);
                }
            })).booleanValue();
        }

        public boolean zza(Window window) {
            window.setFlags(16777216, 16777216);
            return true;
        }

        public zzlm zzb(zzll com_google_android_gms_internal_zzll, boolean z) {
            return new zzlt(com_google_android_gms_internal_zzll, z);
        }

        public Set<String> zzg(Uri uri) {
            return uri.getQueryParameterNames();
        }

        public WebChromeClient zzl(zzll com_google_android_gms_internal_zzll) {
            return new zzls(com_google_android_gms_internal_zzll);
        }

        public boolean zzo(View view) {
            view.setLayerType(0, null);
            return true;
        }

        public boolean zzp(View view) {
            view.setLayerType(1, null);
            return true;
        }
    }

    @TargetApi(14)
    public static class zzc extends zzb {
        public String zza(SslError sslError) {
            return sslError.getUrl();
        }

        public WebChromeClient zzl(zzll com_google_android_gms_internal_zzll) {
            return new zzlu(com_google_android_gms_internal_zzll);
        }
    }

    @TargetApi(16)
    public static class zzf extends zzc {
        public void zza(View view, Drawable drawable) {
            view.setBackground(drawable);
        }

        public void zza(ViewTreeObserver viewTreeObserver, OnGlobalLayoutListener onGlobalLayoutListener) {
            viewTreeObserver.removeOnGlobalLayoutListener(onGlobalLayoutListener);
        }

        public boolean zza(Context context, WebSettings webSettings) {
            super.zza(context, webSettings);
            webSettings.setAllowFileAccessFromFileURLs(false);
            webSettings.setAllowUniversalAccessFromFileURLs(false);
            return true;
        }

        public void zzb(Activity activity, OnGlobalLayoutListener onGlobalLayoutListener) {
            Window window = activity.getWindow();
            if (window != null && window.getDecorView() != null && window.getDecorView().getViewTreeObserver() != null) {
                zza(window.getDecorView().getViewTreeObserver(), onGlobalLayoutListener);
            }
        }
    }

    @TargetApi(17)
    public static class zzd extends zzf {
        public String getDefaultUserAgent(Context context) {
            return WebSettings.getDefaultUserAgent(context);
        }

        public android.graphics.drawable.Drawable zza(android.content.Context r4, android.graphics.Bitmap r5, boolean r6, float r7) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            if (r6 == 0) goto L_0x0053;
        L_0x0002:
            r6 = 0;
            r6 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1));
            if (r6 <= 0) goto L_0x0053;
        L_0x0007:
            r6 = 1103626240; // 0x41c80000 float:25.0 double:5.45263811E-315;
            r6 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1));
            if (r6 <= 0) goto L_0x000e;
        L_0x000d:
            goto L_0x0053;
        L_0x000e:
            r6 = r5.getWidth();	 Catch:{ RuntimeException -> 0x0049 }
            r0 = r5.getHeight();	 Catch:{ RuntimeException -> 0x0049 }
            r1 = 0;	 Catch:{ RuntimeException -> 0x0049 }
            r6 = android.graphics.Bitmap.createScaledBitmap(r5, r6, r0, r1);	 Catch:{ RuntimeException -> 0x0049 }
            r0 = android.graphics.Bitmap.createBitmap(r6);	 Catch:{ RuntimeException -> 0x0049 }
            r1 = android.renderscript.RenderScript.create(r4);	 Catch:{ RuntimeException -> 0x0049 }
            r2 = android.renderscript.Element.U8_4(r1);	 Catch:{ RuntimeException -> 0x0049 }
            r2 = android.renderscript.ScriptIntrinsicBlur.create(r1, r2);	 Catch:{ RuntimeException -> 0x0049 }
            r6 = android.renderscript.Allocation.createFromBitmap(r1, r6);	 Catch:{ RuntimeException -> 0x0049 }
            r1 = android.renderscript.Allocation.createFromBitmap(r1, r0);	 Catch:{ RuntimeException -> 0x0049 }
            r2.setRadius(r7);	 Catch:{ RuntimeException -> 0x0049 }
            r2.setInput(r6);	 Catch:{ RuntimeException -> 0x0049 }
            r2.forEach(r1);	 Catch:{ RuntimeException -> 0x0049 }
            r1.copyTo(r0);	 Catch:{ RuntimeException -> 0x0049 }
            r6 = new android.graphics.drawable.BitmapDrawable;	 Catch:{ RuntimeException -> 0x0049 }
            r7 = r4.getResources();	 Catch:{ RuntimeException -> 0x0049 }
            r6.<init>(r7, r0);	 Catch:{ RuntimeException -> 0x0049 }
            return r6;
        L_0x0049:
            r6 = new android.graphics.drawable.BitmapDrawable;
            r4 = r4.getResources();
            r6.<init>(r4, r5);
            return r6;
        L_0x0053:
            r6 = new android.graphics.drawable.BitmapDrawable;
            r4 = r4.getResources();
            r6.<init>(r4, r5);
            return r6;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkm.zzd.zza(android.content.Context, android.graphics.Bitmap, boolean, float):android.graphics.drawable.Drawable");
        }

        public boolean zza(Context context, WebSettings webSettings) {
            super.zza(context, webSettings);
            webSettings.setMediaPlaybackRequiresUserGesture(false);
            return true;
        }
    }

    @TargetApi(18)
    public static class zze extends zzd {
        public boolean isAttachedToWindow(View view) {
            if (!super.isAttachedToWindow(view)) {
                if (view.getWindowId() == null) {
                    return false;
                }
            }
            return true;
        }

        public int zztm() {
            return 14;
        }
    }

    @TargetApi(19)
    public static class zzg extends zze {
        public boolean isAttachedToWindow(View view) {
            return view.isAttachedToWindow();
        }

        public LayoutParams zztn() {
            return new LayoutParams(-1, -1);
        }
    }

    @TargetApi(21)
    public static class zzh extends zzg {
        public CookieManager zzao(Context context) {
            return CookieManager.getInstance();
        }
    }

    private zzkm() {
    }

    public static zzkm zzay(int i) {
        return i >= 21 ? new zzh() : i >= 19 ? new zzg() : i >= 18 ? new zze() : i >= 17 ? new zzd() : i >= 16 ? new zzf() : i >= 14 ? new zzc() : i >= 11 ? new zzb() : i >= 9 ? new zza() : new zzkm();
    }

    public String getDefaultUserAgent(Context context) {
        return "";
    }

    public boolean isAttachedToWindow(View view) {
        if (view.getWindowToken() == null) {
            if (view.getWindowVisibility() == 8) {
                return false;
            }
        }
        return true;
    }

    public Drawable zza(Context context, Bitmap bitmap, boolean z, float f) {
        return new BitmapDrawable(context.getResources(), bitmap);
    }

    public String zza(SslError sslError) {
        return "";
    }

    public void zza(View view, Drawable drawable) {
        view.setBackgroundDrawable(drawable);
    }

    public void zza(ViewTreeObserver viewTreeObserver, OnGlobalLayoutListener onGlobalLayoutListener) {
        viewTreeObserver.removeGlobalOnLayoutListener(onGlobalLayoutListener);
    }

    public boolean zza(Request request) {
        return false;
    }

    public boolean zza(Context context, WebSettings webSettings) {
        return false;
    }

    public boolean zza(Window window) {
        return false;
    }

    public CookieManager zzao(Context context) {
        CookieSyncManager.createInstance(context);
        return CookieManager.getInstance();
    }

    public zzlm zzb(zzll com_google_android_gms_internal_zzll, boolean z) {
        return new zzlm(com_google_android_gms_internal_zzll, z);
    }

    public void zzb(Activity activity, OnGlobalLayoutListener onGlobalLayoutListener) {
        Window window = activity.getWindow();
        if (window != null && window.getDecorView() != null && window.getDecorView().getViewTreeObserver() != null) {
            zza(window.getDecorView().getViewTreeObserver(), onGlobalLayoutListener);
        }
    }

    public Set<String> zzg(Uri uri) {
        if (uri.isOpaque()) {
            return Collections.emptySet();
        }
        String encodedQuery = uri.getEncodedQuery();
        if (encodedQuery == null) {
            return Collections.emptySet();
        }
        Set linkedHashSet = new LinkedHashSet();
        int i = 0;
        do {
            int indexOf = encodedQuery.indexOf(38, i);
            if (indexOf == -1) {
                indexOf = encodedQuery.length();
            }
            int indexOf2 = encodedQuery.indexOf(61, i);
            if (indexOf2 > indexOf || indexOf2 == -1) {
                indexOf2 = indexOf;
            }
            linkedHashSet.add(Uri.decode(encodedQuery.substring(i, indexOf2)));
            i = indexOf + 1;
        } while (i < encodedQuery.length());
        return Collections.unmodifiableSet(linkedHashSet);
    }

    public boolean zzj(zzll com_google_android_gms_internal_zzll) {
        if (com_google_android_gms_internal_zzll == null) {
            return false;
        }
        com_google_android_gms_internal_zzll.onPause();
        return true;
    }

    public boolean zzk(zzll com_google_android_gms_internal_zzll) {
        if (com_google_android_gms_internal_zzll == null) {
            return false;
        }
        com_google_android_gms_internal_zzll.onResume();
        return true;
    }

    public WebChromeClient zzl(zzll com_google_android_gms_internal_zzll) {
        return null;
    }

    public boolean zzo(View view) {
        return false;
    }

    public boolean zzp(View view) {
        return false;
    }

    public int zztk() {
        return 0;
    }

    public int zztl() {
        return 1;
    }

    public int zztm() {
        return 5;
    }

    public LayoutParams zztn() {
        return new LayoutParams(-2, -2);
    }
}
