package com.google.android.gms.internal;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@zzir
public class zzkz<T> implements zzlc<T> {
    private final Object zzail = new Object();
    private boolean zzbpb;
    private T zzcnr;
    private boolean zzcns;
    private final zzld zzcnt = new zzld();

    private boolean zztz() {
        return this.zzcns;
    }

    public boolean cancel(boolean z) {
        if (!z) {
            return false;
        }
        synchronized (this.zzail) {
            if (zztz()) {
                return false;
            }
            this.zzbpb = true;
            this.zzcns = true;
            this.zzail.notifyAll();
            this.zzcnt.zzua();
            return true;
        }
    }

    public T get() throws CancellationException, ExecutionException, InterruptedException {
        T t;
        synchronized (this.zzail) {
            if (!zztz()) {
                try {
                    this.zzail.wait();
                } catch (InterruptedException e) {
                    throw e;
                }
            }
            if (this.zzbpb) {
                throw new CancellationException("CallbackFuture was cancelled.");
            }
            t = this.zzcnr;
        }
        return t;
    }

    public T get(long j, TimeUnit timeUnit) throws CancellationException, ExecutionException, InterruptedException, TimeoutException {
        T t;
        synchronized (this.zzail) {
            if (!zztz()) {
                try {
                    j = timeUnit.toMillis(j);
                    if (j != 0) {
                        this.zzail.wait(j);
                    }
                } catch (InterruptedException e) {
                    throw e;
                }
            }
            if (!this.zzcns) {
                throw new TimeoutException("CallbackFuture timed out.");
            } else if (this.zzbpb) {
                throw new CancellationException("CallbackFuture was cancelled.");
            } else {
                t = this.zzcnr;
            }
        }
        return t;
    }

    public boolean isCancelled() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzbpb;
        }
        return z;
    }

    public boolean isDone() {
        boolean zztz;
        synchronized (this.zzail) {
            zztz = zztz();
        }
        return zztz;
    }

    public void zzb(Runnable runnable) {
        this.zzcnt.zzb(runnable);
    }

    public void zzc(Runnable runnable) {
        this.zzcnt.zzc(runnable);
    }

    public void zzi(T t) {
        synchronized (this.zzail) {
            if (this.zzbpb) {
            } else if (zztz()) {
                throw new IllegalStateException("Provided CallbackFuture with multiple values.");
            } else {
                this.zzcns = true;
                this.zzcnr = t;
                this.zzail.notifyAll();
                this.zzcnt.zzua();
            }
        }
    }
}
