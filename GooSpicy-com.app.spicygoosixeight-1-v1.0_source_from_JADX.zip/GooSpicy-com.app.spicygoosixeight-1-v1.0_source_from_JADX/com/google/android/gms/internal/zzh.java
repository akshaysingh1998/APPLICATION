package com.google.android.gms.internal;

public class zzh extends zzr {
    public zzh(zzi com_google_android_gms_internal_zzi) {
        super(com_google_android_gms_internal_zzi);
    }

    public zzh(Throwable th) {
        super(th);
    }
}
