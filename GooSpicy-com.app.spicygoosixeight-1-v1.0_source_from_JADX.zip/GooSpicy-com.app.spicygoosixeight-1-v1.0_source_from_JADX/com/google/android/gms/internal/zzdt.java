package com.google.android.gms.internal;

import android.app.DownloadManager;
import android.app.DownloadManager.Request;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.common.util.zzh;
import com.google.android.gms.common.util.zzs;
import java.io.File;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@zzir
public class zzdt {
    private static final Object zzamp = new Object();
    private static AtomicInteger zzbeu = new AtomicInteger();
    private static zzdt zzbev;

    protected zzdt() {
    }

    public static zzdt zzkq() {
        zzdt com_google_android_gms_internal_zzdt;
        synchronized (zzamp) {
            if (zzbev == null) {
                zzbev = new zzdt();
            }
            com_google_android_gms_internal_zzdt = zzbev;
        }
        return com_google_android_gms_internal_zzdt;
    }

    protected Request zza(Context context, Request request, String str) {
        String valueOf = String.valueOf(Environment.getExternalStorageDirectory().toString());
        String valueOf2 = String.valueOf("/directappinstall/");
        request.setDestinationInExternalFilesDir(context, valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf), str).setVisibleInDownloadsUi(true).setAllowedNetworkTypes(3);
        return zzs.zzavj() ? request.setNotificationVisibility(1) : request.setShowRunningNotification(true);
    }

    public void zza(Context context, Map<String, String> map) {
        String str = (String) map.get("url");
        String str2 = (String) map.get("package_name");
        if (TextUtils.isEmpty(str)) {
            zzb.m9e("Download URL provided by creative is null or empty.");
            return;
        }
        try {
            Request zza = zza(context, new Request(Uri.parse(str)), str2);
            String str3 = (String) map.get("tracking_url");
            StringBuilder stringBuilder = new StringBuilder((32 + String.valueOf(str2).length()) + String.valueOf(str).length());
            stringBuilder.append("Start downloading package ");
            stringBuilder.append(str2);
            stringBuilder.append(" from ");
            stringBuilder.append(str);
            zzb.zzcw(stringBuilder.toString());
            zzds.zza(context, zzh.zzavi()).zza(((DownloadManager) context.getSystemService("download")).enqueue(zza), str2, str3);
        } catch (Throwable e) {
            zzb.zzb("Download URL is not a valid HTTP/HTTPS URI. Abort downloading task.", e);
        }
    }

    public java.lang.String zzb(android.content.Context r3, java.util.Map<java.lang.String, java.lang.String> r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r0 = "package_name";
        r0 = r4.get(r0);
        r0 = (java.lang.String) r0;
        r3 = r3.getPackageManager();
        r1 = 1;
        r3 = r3.getPackageInfo(r0, r1);	 Catch:{ NameNotFoundException -> 0x0085 }
        r1 = "app_version";	 Catch:{ NameNotFoundException -> 0x0085 }
        r4 = r4.get(r1);	 Catch:{ NameNotFoundException -> 0x0085 }
        r4 = (java.lang.String) r4;	 Catch:{ NameNotFoundException -> 0x0085 }
        r1 = android.text.TextUtils.isEmpty(r4);	 Catch:{ NameNotFoundException -> 0x0085 }
        if (r1 == 0) goto L_0x0027;	 Catch:{ NameNotFoundException -> 0x0085 }
    L_0x001f:
        r3 = "No app version provided by creative.";	 Catch:{ NameNotFoundException -> 0x0085 }
        com.google.android.gms.ads.internal.util.client.zzb.m9e(r3);	 Catch:{ NameNotFoundException -> 0x0085 }
        r3 = "installed_unknown_version";	 Catch:{ NameNotFoundException -> 0x0085 }
        return r3;
    L_0x0027:
        r4 = java.lang.Integer.parseInt(r4);	 Catch:{ NumberFormatException -> 0x007d }
        r3 = r3.versionCode;	 Catch:{ NameNotFoundException -> 0x0085 }
        if (r4 <= r3) goto L_0x0056;	 Catch:{ NameNotFoundException -> 0x0085 }
    L_0x002f:
        r3 = new java.lang.StringBuilder;	 Catch:{ NameNotFoundException -> 0x0085 }
        r4 = 34;	 Catch:{ NameNotFoundException -> 0x0085 }
        r1 = java.lang.String.valueOf(r0);	 Catch:{ NameNotFoundException -> 0x0085 }
        r1 = r1.length();	 Catch:{ NameNotFoundException -> 0x0085 }
        r4 = r4 + r1;	 Catch:{ NameNotFoundException -> 0x0085 }
        r3.<init>(r4);	 Catch:{ NameNotFoundException -> 0x0085 }
        r4 = "App ";	 Catch:{ NameNotFoundException -> 0x0085 }
        r3.append(r4);	 Catch:{ NameNotFoundException -> 0x0085 }
        r3.append(r0);	 Catch:{ NameNotFoundException -> 0x0085 }
        r4 = " installed but need an update.";	 Catch:{ NameNotFoundException -> 0x0085 }
        r3.append(r4);	 Catch:{ NameNotFoundException -> 0x0085 }
        r3 = r3.toString();	 Catch:{ NameNotFoundException -> 0x0085 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r3);	 Catch:{ NameNotFoundException -> 0x0085 }
        r3 = "installed_older_version";	 Catch:{ NameNotFoundException -> 0x0085 }
        return r3;
    L_0x0056:
        r3 = new java.lang.StringBuilder;
        r4 = 52;
        r1 = java.lang.String.valueOf(r0);
        r1 = r1.length();
        r4 = r4 + r1;
        r3.<init>(r4);
        r4 = "App ";
        r3.append(r4);
        r3.append(r0);
        r4 = " already installed with current / newer version.";
        r3.append(r4);
        r3 = r3.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r3);
        r3 = "installed_given_version";
        return r3;
    L_0x007d:
        r3 = "Malformated app version is provided by creative.";	 Catch:{ NameNotFoundException -> 0x0085 }
        com.google.android.gms.ads.internal.util.client.zzb.m9e(r3);	 Catch:{ NameNotFoundException -> 0x0085 }
        r3 = "installed_unknown_version";	 Catch:{ NameNotFoundException -> 0x0085 }
        return r3;
    L_0x0085:
        r3 = new java.lang.StringBuilder;
        r4 = 19;
        r1 = java.lang.String.valueOf(r0);
        r1 = r1.length();
        r4 = r4 + r1;
        r3.<init>(r4);
        r4 = "App ";
        r3.append(r4);
        r3.append(r0);
        r4 = " not installed.";
        r3.append(r4);
        r3 = r3.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r3);
        r3 = "not_installed";
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzdt.zzb(android.content.Context, java.util.Map):java.lang.String");
    }

    public void zzd(Context context, @NonNull String str) {
        String str2 = "Deleting downloaded file: ";
        String valueOf = String.valueOf(str);
        zzb.zzcw(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        File file = new File(str);
        if (file.exists()) {
            file.delete();
            if (file.exists()) {
                str2 = "Error deleting file: ";
                valueOf = String.valueOf(str);
                if (valueOf.length() == 0) {
                    valueOf = new String(str2);
                    str2 = valueOf;
                }
            } else {
                str2 = "File deleted successfully from path: ";
                valueOf = String.valueOf(str);
                if (valueOf.length() == 0) {
                    valueOf = new String(str2);
                    str2 = valueOf;
                }
            }
            str2 = str2.concat(valueOf);
        } else {
            StringBuilder stringBuilder = new StringBuilder(21 + String.valueOf(str).length());
            stringBuilder.append("File: ");
            stringBuilder.append(str);
            stringBuilder.append(" doesn't exist!");
            str2 = stringBuilder.toString();
        }
        zzb.zzcw(str2);
        zzds.zza(context, zzh.zzavi()).zzat(str);
    }
}
