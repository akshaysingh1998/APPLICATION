package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.NativeAdMapper;
import com.google.android.gms.common.internal.zzab;

@zzir
public final class zzgv implements MediationBannerListener, MediationInterstitialListener, MediationNativeListener {
    private final zzgp zzbpo;
    private NativeAdMapper zzbpp;

    public zzgv(zzgp com_google_android_gms_internal_zzgp) {
        this.zzbpo = com_google_android_gms_internal_zzgp;
    }

    public void onAdClicked(MediationBannerAdapter mediationBannerAdapter) {
        zzab.zzhj("onAdClicked must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdClicked.");
        try {
            this.zzbpo.onAdClicked();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdClicked.", e);
        }
    }

    public void onAdClicked(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzab.zzhj("onAdClicked must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdClicked.");
        try {
            this.zzbpo.onAdClicked();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdClicked.", e);
        }
    }

    public void onAdClicked(MediationNativeAdapter mediationNativeAdapter) {
        zzab.zzhj("onAdClicked must be called on the main UI thread.");
        NativeAdMapper zzmu = zzmu();
        if (zzmu == null) {
            zzb.zzcy("Could not call onAdClicked since NativeAdMapper is null.");
        } else if (zzmu.getOverrideClickHandling()) {
            zzb.zzcw("Adapter called onAdClicked.");
            try {
                this.zzbpo.onAdClicked();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdClicked.", e);
            }
        } else {
            zzb.zzcw("Could not call onAdClicked since setOverrideClickHandling is not set to true");
        }
    }

    public void onAdClosed(MediationBannerAdapter mediationBannerAdapter) {
        zzab.zzhj("onAdClosed must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdClosed.");
        try {
            this.zzbpo.onAdClosed();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdClosed.", e);
        }
    }

    public void onAdClosed(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzab.zzhj("onAdClosed must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdClosed.");
        try {
            this.zzbpo.onAdClosed();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdClosed.", e);
        }
    }

    public void onAdClosed(MediationNativeAdapter mediationNativeAdapter) {
        zzab.zzhj("onAdClosed must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdClosed.");
        try {
            this.zzbpo.onAdClosed();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdClosed.", e);
        }
    }

    public void onAdFailedToLoad(MediationBannerAdapter mediationBannerAdapter, int i) {
        zzab.zzhj("onAdFailedToLoad must be called on the main UI thread.");
        StringBuilder stringBuilder = new StringBuilder(55);
        stringBuilder.append("Adapter called onAdFailedToLoad with error. ");
        stringBuilder.append(i);
        zzb.zzcw(stringBuilder.toString());
        try {
            this.zzbpo.onAdFailedToLoad(i);
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdFailedToLoad.", e);
        }
    }

    public void onAdFailedToLoad(MediationInterstitialAdapter mediationInterstitialAdapter, int i) {
        zzab.zzhj("onAdFailedToLoad must be called on the main UI thread.");
        StringBuilder stringBuilder = new StringBuilder(55);
        stringBuilder.append("Adapter called onAdFailedToLoad with error ");
        stringBuilder.append(i);
        stringBuilder.append(".");
        zzb.zzcw(stringBuilder.toString());
        try {
            this.zzbpo.onAdFailedToLoad(i);
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdFailedToLoad.", e);
        }
    }

    public void onAdFailedToLoad(MediationNativeAdapter mediationNativeAdapter, int i) {
        zzab.zzhj("onAdFailedToLoad must be called on the main UI thread.");
        StringBuilder stringBuilder = new StringBuilder(55);
        stringBuilder.append("Adapter called onAdFailedToLoad with error ");
        stringBuilder.append(i);
        stringBuilder.append(".");
        zzb.zzcw(stringBuilder.toString());
        try {
            this.zzbpo.onAdFailedToLoad(i);
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdFailedToLoad.", e);
        }
    }

    public void onAdImpression(MediationNativeAdapter mediationNativeAdapter) {
        zzab.zzhj("onAdImpression must be called on the main UI thread.");
        NativeAdMapper zzmu = zzmu();
        if (zzmu == null) {
            zzb.zzcy("Could not call onAdImpression since NativeAdMapper is null. ");
        } else if (zzmu.getOverrideImpressionRecording()) {
            zzb.zzcw("Adapter called onAdImpression.");
            try {
                this.zzbpo.onAdImpression();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdImpression.", e);
            }
        } else {
            zzb.zzcw("Could not call onAdImpression since setOverrideImpressionRecording is not set to true");
        }
    }

    public void onAdLeftApplication(MediationBannerAdapter mediationBannerAdapter) {
        zzab.zzhj("onAdLeftApplication must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdLeftApplication.");
        try {
            this.zzbpo.onAdLeftApplication();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdLeftApplication.", e);
        }
    }

    public void onAdLeftApplication(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzab.zzhj("onAdLeftApplication must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdLeftApplication.");
        try {
            this.zzbpo.onAdLeftApplication();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdLeftApplication.", e);
        }
    }

    public void onAdLeftApplication(MediationNativeAdapter mediationNativeAdapter) {
        zzab.zzhj("onAdLeftApplication must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdLeftApplication.");
        try {
            this.zzbpo.onAdLeftApplication();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdLeftApplication.", e);
        }
    }

    public void onAdLoaded(MediationBannerAdapter mediationBannerAdapter) {
        zzab.zzhj("onAdLoaded must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdLoaded.");
        try {
            this.zzbpo.onAdLoaded();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdLoaded.", e);
        }
    }

    public void onAdLoaded(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzab.zzhj("onAdLoaded must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdLoaded.");
        try {
            this.zzbpo.onAdLoaded();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdLoaded.", e);
        }
    }

    public void onAdLoaded(MediationNativeAdapter mediationNativeAdapter, NativeAdMapper nativeAdMapper) {
        zzab.zzhj("onAdLoaded must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdLoaded.");
        this.zzbpp = nativeAdMapper;
        try {
            this.zzbpo.onAdLoaded();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdLoaded.", e);
        }
    }

    public void onAdOpened(MediationBannerAdapter mediationBannerAdapter) {
        zzab.zzhj("onAdOpened must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdOpened.");
        try {
            this.zzbpo.onAdOpened();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdOpened.", e);
        }
    }

    public void onAdOpened(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzab.zzhj("onAdOpened must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdOpened.");
        try {
            this.zzbpo.onAdOpened();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdOpened.", e);
        }
    }

    public void onAdOpened(MediationNativeAdapter mediationNativeAdapter) {
        zzab.zzhj("onAdOpened must be called on the main UI thread.");
        zzb.zzcw("Adapter called onAdOpened.");
        try {
            this.zzbpo.onAdOpened();
        } catch (Throwable e) {
            zzb.zzd("Could not call onAdOpened.", e);
        }
    }

    public NativeAdMapper zzmu() {
        return this.zzbpp;
    }
}
