package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.ResultCallbacks;
import com.google.android.gms.common.api.ResultTransform;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.TransformedResult;
import com.google.android.gms.common.internal.zzab;
import java.lang.ref.WeakReference;

public class zzrc<R extends Result> extends TransformedResult<R> implements ResultCallback<R> {
    private final Object sJ = new Object();
    private final WeakReference<GoogleApiClient> sL;
    private ResultTransform<? super R, ? extends Result> vk = null;
    private zzrc<? extends Result> vl = null;
    private volatile ResultCallbacks<? super R> vm = null;
    private PendingResult<R> vn = null;
    private Status vo = null;
    private final zza vp;
    private boolean vq = false;

    private final class zza extends Handler {
        final /* synthetic */ zzrc vs;

        public zza(zzrc com_google_android_gms_internal_zzrc, Looper looper) {
            this.vs = com_google_android_gms_internal_zzrc;
            super(looper);
        }

        public void handleMessage(android.os.Message r5) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:25:0x0088 in {3, 6, 7, 9, 14, 19, 20, 22, 24} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r4 = this;
            r0 = r5.what;
            switch(r0) {
                case 0: goto L_0x0045;
                case 1: goto L_0x0020;
                default: goto L_0x0005;
            };
        L_0x0005:
            r0 = "TransformedResultImpl";
            r5 = r5.what;
            r1 = new java.lang.StringBuilder;
            r2 = 70;
            r1.<init>(r2);
            r2 = "TransformationResultHandler received unknown message type: ";
            r1.append(r2);
            r1.append(r5);
            r5 = r1.toString();
            android.util.Log.e(r0, r5);
            return;
        L_0x0020:
            r5 = r5.obj;
            r5 = (java.lang.RuntimeException) r5;
            r0 = "TransformedResultImpl";
            r1 = "Runtime exception on the transformation worker thread: ";
            r2 = r5.getMessage();
            r2 = java.lang.String.valueOf(r2);
            r3 = r2.length();
            if (r3 == 0) goto L_0x003b;
        L_0x0036:
            r1 = r1.concat(r2);
            goto L_0x0041;
        L_0x003b:
            r2 = new java.lang.String;
            r2.<init>(r1);
            r1 = r2;
        L_0x0041:
            android.util.Log.e(r0, r1);
            throw r5;
        L_0x0045:
            r5 = r5.obj;
            r5 = (com.google.android.gms.common.api.PendingResult) r5;
            r0 = r4.vs;
            r0 = r0.sJ;
            monitor-enter(r0);
            if (r5 != 0) goto L_0x0067;
        L_0x0052:
            r5 = r4.vs;	 Catch:{ all -> 0x0065 }
            r5 = r5.vl;	 Catch:{ all -> 0x0065 }
            r1 = new com.google.android.gms.common.api.Status;	 Catch:{ all -> 0x0065 }
            r2 = 13;	 Catch:{ all -> 0x0065 }
            r3 = "Transform returned null";	 Catch:{ all -> 0x0065 }
            r1.<init>(r2, r3);	 Catch:{ all -> 0x0065 }
            r5.zzac(r1);	 Catch:{ all -> 0x0065 }
            goto L_0x0084;	 Catch:{ all -> 0x0065 }
        L_0x0065:
            r5 = move-exception;	 Catch:{ all -> 0x0065 }
            goto L_0x0086;	 Catch:{ all -> 0x0065 }
        L_0x0067:
            r1 = r5 instanceof com.google.android.gms.internal.zzqx;	 Catch:{ all -> 0x0065 }
            if (r1 == 0) goto L_0x007b;	 Catch:{ all -> 0x0065 }
        L_0x006b:
            r1 = r4.vs;	 Catch:{ all -> 0x0065 }
            r1 = r1.vl;	 Catch:{ all -> 0x0065 }
            r5 = (com.google.android.gms.internal.zzqx) r5;	 Catch:{ all -> 0x0065 }
            r5 = r5.getStatus();	 Catch:{ all -> 0x0065 }
            r1.zzac(r5);	 Catch:{ all -> 0x0065 }
            goto L_0x0084;	 Catch:{ all -> 0x0065 }
        L_0x007b:
            r1 = r4.vs;	 Catch:{ all -> 0x0065 }
            r1 = r1.vl;	 Catch:{ all -> 0x0065 }
            r1.zza(r5);	 Catch:{ all -> 0x0065 }
        L_0x0084:
            monitor-exit(r0);	 Catch:{ all -> 0x0065 }
            return;	 Catch:{ all -> 0x0065 }
        L_0x0086:
            monitor-exit(r0);	 Catch:{ all -> 0x0065 }
            throw r5;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzrc.zza.handleMessage(android.os.Message):void");
        }
    }

    public zzrc(WeakReference<GoogleApiClient> weakReference) {
        zzab.zzb((Object) weakReference, (Object) "GoogleApiClient reference must not be null");
        this.sL = weakReference;
        GoogleApiClient googleApiClient = (GoogleApiClient) this.sL.get();
        this.vp = new zza(this, googleApiClient != null ? googleApiClient.getLooper() : Looper.getMainLooper());
    }

    private void zzac(Status status) {
        synchronized (this.sJ) {
            this.vo = status;
            zzad(this.vo);
        }
    }

    private void zzad(Status status) {
        synchronized (this.sJ) {
            if (this.vk != null) {
                Object onFailure = this.vk.onFailure(status);
                zzab.zzb(onFailure, (Object) "onFailure must not return null");
                this.vl.zzac(onFailure);
            } else if (zzaqu()) {
                this.vm.onFailure(status);
            }
        }
    }

    private void zzaqs() {
        if (this.vk != null || this.vm != null) {
            GoogleApiClient googleApiClient = (GoogleApiClient) this.sL.get();
            if (!(this.vq || this.vk == null || googleApiClient == null)) {
                googleApiClient.zza(this);
                this.vq = true;
            }
            if (this.vo != null) {
                zzad(this.vo);
                return;
            }
            if (this.vn != null) {
                this.vn.setResultCallback(this);
            }
        }
    }

    private boolean zzaqu() {
        return (this.vm == null || ((GoogleApiClient) this.sL.get()) == null) ? false : true;
    }

    private void zze(Result result) {
        if (result instanceof Releasable) {
            try {
                ((Releasable) result).release();
            } catch (Throwable e) {
                String valueOf = String.valueOf(result);
                StringBuilder stringBuilder = new StringBuilder(18 + String.valueOf(valueOf).length());
                stringBuilder.append("Unable to release ");
                stringBuilder.append(valueOf);
                Log.w("TransformedResultImpl", stringBuilder.toString(), e);
            }
        }
    }

    public void andFinally(@NonNull ResultCallbacks<? super R> resultCallbacks) {
        synchronized (this.sJ) {
            boolean z = false;
            zzab.zza(this.vm == null, (Object) "Cannot call andFinally() twice.");
            if (this.vk == null) {
                z = true;
            }
            zzab.zza(z, (Object) "Cannot call then() and andFinally() on the same TransformedResult.");
            this.vm = resultCallbacks;
            zzaqs();
        }
    }

    public void onResult(final R r) {
        synchronized (this.sJ) {
            if (!r.getStatus().isSuccess()) {
                zzac(r.getStatus());
                zze((Result) r);
            } else if (this.vk != null) {
                zzqw.zzapz().submit(new Runnable(this) {
                    final /* synthetic */ zzrc vs;

                    /* JADX WARNING: inconsistent code. */
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    @android.support.annotation.WorkerThread
                    public void run() {
                        /*
                        r5 = this;
                        r0 = 1;
                        r1 = 0;
                        r2 = com.google.android.gms.internal.zzpt.sI;	 Catch:{ RuntimeException -> 0x0050 }
                        r3 = java.lang.Boolean.valueOf(r0);	 Catch:{ RuntimeException -> 0x0050 }
                        r2.set(r3);	 Catch:{ RuntimeException -> 0x0050 }
                        r2 = r5.vs;	 Catch:{ RuntimeException -> 0x0050 }
                        r2 = r2.vk;	 Catch:{ RuntimeException -> 0x0050 }
                        r3 = r4;	 Catch:{ RuntimeException -> 0x0050 }
                        r2 = r2.onSuccess(r3);	 Catch:{ RuntimeException -> 0x0050 }
                        r3 = r5.vs;	 Catch:{ RuntimeException -> 0x0050 }
                        r3 = r3.vp;	 Catch:{ RuntimeException -> 0x0050 }
                        r4 = r5.vs;	 Catch:{ RuntimeException -> 0x0050 }
                        r4 = r4.vp;	 Catch:{ RuntimeException -> 0x0050 }
                        r2 = r4.obtainMessage(r1, r2);	 Catch:{ RuntimeException -> 0x0050 }
                        r3.sendMessage(r2);	 Catch:{ RuntimeException -> 0x0050 }
                        r0 = com.google.android.gms.internal.zzpt.sI;
                        r1 = java.lang.Boolean.valueOf(r1);
                        r0.set(r1);
                        r0 = r5.vs;
                        r1 = r4;
                        r0.zze(r1);
                        r0 = r5.vs;
                        r0 = r0.sL;
                        r0 = r0.get();
                        r0 = (com.google.android.gms.common.api.GoogleApiClient) r0;
                        if (r0 == 0) goto L_0x0083;
                    L_0x0048:
                        r1 = r5.vs;
                        r0.zzb(r1);
                        return;
                    L_0x004e:
                        r0 = move-exception;
                        goto L_0x0084;
                    L_0x0050:
                        r2 = move-exception;
                        r3 = r5.vs;	 Catch:{ all -> 0x004e }
                        r3 = r3.vp;	 Catch:{ all -> 0x004e }
                        r4 = r5.vs;	 Catch:{ all -> 0x004e }
                        r4 = r4.vp;	 Catch:{ all -> 0x004e }
                        r0 = r4.obtainMessage(r0, r2);	 Catch:{ all -> 0x004e }
                        r3.sendMessage(r0);	 Catch:{ all -> 0x004e }
                        r0 = com.google.android.gms.internal.zzpt.sI;
                        r1 = java.lang.Boolean.valueOf(r1);
                        r0.set(r1);
                        r0 = r5.vs;
                        r1 = r4;
                        r0.zze(r1);
                        r0 = r5.vs;
                        r0 = r0.sL;
                        r0 = r0.get();
                        r0 = (com.google.android.gms.common.api.GoogleApiClient) r0;
                        if (r0 == 0) goto L_0x0083;
                    L_0x0082:
                        goto L_0x0048;
                    L_0x0083:
                        return;
                    L_0x0084:
                        r2 = com.google.android.gms.internal.zzpt.sI;
                        r1 = java.lang.Boolean.valueOf(r1);
                        r2.set(r1);
                        r1 = r5.vs;
                        r2 = r4;
                        r1.zze(r2);
                        r1 = r5.vs;
                        r1 = r1.sL;
                        r1 = r1.get();
                        r1 = (com.google.android.gms.common.api.GoogleApiClient) r1;
                        if (r1 == 0) goto L_0x00a7;
                    L_0x00a2:
                        r2 = r5.vs;
                        r1.zzb(r2);
                    L_0x00a7:
                        throw r0;
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzrc.1.run():void");
                    }
                });
            } else if (zzaqu()) {
                this.vm.onSuccess(r);
            }
        }
    }

    @NonNull
    public <S extends Result> TransformedResult<S> then(@NonNull ResultTransform<? super R, ? extends S> resultTransform) {
        TransformedResult com_google_android_gms_internal_zzrc;
        synchronized (this.sJ) {
            boolean z = false;
            zzab.zza(this.vk == null, (Object) "Cannot call then() twice.");
            if (this.vm == null) {
                z = true;
            }
            zzab.zza(z, (Object) "Cannot call then() and andFinally() on the same TransformedResult.");
            this.vk = resultTransform;
            com_google_android_gms_internal_zzrc = new zzrc(this.sL);
            this.vl = com_google_android_gms_internal_zzrc;
            zzaqs();
        }
        return com_google_android_gms_internal_zzrc;
    }

    public void zza(PendingResult<?> pendingResult) {
        synchronized (this.sJ) {
            this.vn = pendingResult;
            zzaqs();
        }
    }

    void zzaqt() {
        this.vm = null;
    }
}
