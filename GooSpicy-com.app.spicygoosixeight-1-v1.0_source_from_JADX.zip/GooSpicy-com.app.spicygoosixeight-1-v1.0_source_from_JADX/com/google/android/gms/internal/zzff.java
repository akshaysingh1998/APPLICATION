package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzu;

@zzir
public class zzff extends zzkg {
    final zzll zzbgj;
    final zzfh zzbjf;
    private final String zzbjg;

    class C04141 implements Runnable {
        final /* synthetic */ zzff zzbjh;

        C04141(zzff com_google_android_gms_internal_zzff) {
            this.zzbjh = com_google_android_gms_internal_zzff;
        }

        public void run() {
            zzu.zzgj().zzb(this.zzbjh);
        }
    }

    zzff(zzll com_google_android_gms_internal_zzll, zzfh com_google_android_gms_internal_zzfh, String str) {
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.zzbjf = com_google_android_gms_internal_zzfh;
        this.zzbjg = str;
        zzu.zzgj().zza(this);
    }

    public void onStop() {
        this.zzbjf.abort();
    }

    public void zzew() {
        try {
            this.zzbjf.zzba(this.zzbjg);
        } finally {
            zzkl.zzclg.post(new C04141(this));
        }
    }
}
