package com.google.android.gms.internal;

import android.content.Context;
import android.os.SystemClock;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.util.client.zzb;

@zzir
public abstract class zzif extends zzkg {
    protected final Context mContext;
    protected final Object zzail = new Object();
    protected final com.google.android.gms.internal.zzig.zza zzbxu;
    protected final com.google.android.gms.internal.zzjy.zza zzbxv;
    protected AdResponseParcel zzbxw;
    protected final Object zzbxy = new Object();

    class C04551 implements Runnable {
        final /* synthetic */ zzif zzbyl;

        C04551(zzif com_google_android_gms_internal_zzif) {
            this.zzbyl = com_google_android_gms_internal_zzif;
        }

        public void run() {
            this.zzbyl.onStop();
        }
    }

    protected static final class zza extends Exception {
        private final int zzbym;

        public zza(String str, int i) {
            super(str);
            this.zzbym = i;
        }

        public int getErrorCode() {
            return this.zzbym;
        }
    }

    protected zzif(Context context, com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza, com.google.android.gms.internal.zzig.zza com_google_android_gms_internal_zzig_zza) {
        super(true);
        this.mContext = context;
        this.zzbxv = com_google_android_gms_internal_zzjy_zza;
        this.zzbxw = com_google_android_gms_internal_zzjy_zza.zzciu;
        this.zzbxu = com_google_android_gms_internal_zzig_zza;
    }

    public void onStop() {
    }

    protected abstract zzjy zzak(int i);

    public void zzew() {
        int errorCode;
        synchronized (this.zzail) {
            zzb.zzcw("AdRendererBackgroundTask started.");
            int i = this.zzbxv.errorCode;
            try {
                zzh(SystemClock.elapsedRealtime());
            } catch (zza e) {
                errorCode = e.getErrorCode();
                if (errorCode != 3) {
                    if (errorCode != -1) {
                        zzb.zzcy(e.getMessage());
                        this.zzbxw = this.zzbxw != null ? new AdResponseParcel(errorCode) : new AdResponseParcel(errorCode, this.zzbxw.zzbnw);
                        zzkl.zzclg.post(new C04551(this));
                        i = errorCode;
                    }
                }
                zzb.zzcx(e.getMessage());
                if (this.zzbxw != null) {
                }
                this.zzbxw = this.zzbxw != null ? new AdResponseParcel(errorCode) : new AdResponseParcel(errorCode, this.zzbxw.zzbnw);
                zzkl.zzclg.post(new C04551(this));
                i = errorCode;
            }
            final zzjy zzak = zzak(i);
            zzkl.zzclg.post(new Runnable(this) {
                final /* synthetic */ zzif zzbyl;

                public void run() {
                    synchronized (this.zzbyl.zzail) {
                        this.zzbyl.zzm(zzak);
                    }
                }
            });
        }
    }

    protected abstract void zzh(long j) throws zza;

    protected void zzm(zzjy com_google_android_gms_internal_zzjy) {
        this.zzbxu.zzb(com_google_android_gms_internal_zzjy);
    }
}
