package com.google.android.gms.internal;

import android.content.Context;
import android.os.Handler;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzjy.zza;

@zzir
public class zzjk extends zzkg implements zzjl, zzjo {
    private final Context mContext;
    private final Object zzail;
    private final String zzbog;
    private final zza zzbxv;
    private int zzbym = 3;
    private final zzjq zzchq;
    private final zzjo zzchr;
    private final String zzchs;
    private final String zzcht;
    private int zzchu = 0;

    public zzjk(Context context, String str, String str2, String str3, zza com_google_android_gms_internal_zzjy_zza, zzjq com_google_android_gms_internal_zzjq, zzjo com_google_android_gms_internal_zzjo) {
        this.mContext = context;
        this.zzbog = str;
        this.zzchs = str2;
        this.zzcht = str3;
        this.zzbxv = com_google_android_gms_internal_zzjy_zza;
        this.zzchq = com_google_android_gms_internal_zzjq;
        this.zzail = new Object();
        this.zzchr = com_google_android_gms_internal_zzjo;
    }

    private void zza(AdRequestParcel adRequestParcel, zzgo com_google_android_gms_internal_zzgo) {
        try {
            if ("com.google.ads.mediation.admob.AdMobAdapter".equals(this.zzbog)) {
                com_google_android_gms_internal_zzgo.zza(adRequestParcel, this.zzchs, this.zzcht);
            } else {
                com_google_android_gms_internal_zzgo.zzc(adRequestParcel, this.zzchs);
            }
        } catch (Throwable e) {
            zzb.zzd("Fail to load ad from adapter.", e);
            zza(this.zzbog, 0);
        }
    }

    private void zzk(long j) {
        while (true) {
            synchronized (this.zzail) {
                if (this.zzchu != 0) {
                    return;
                } else if (!zzf(j)) {
                    return;
                }
            }
        }
    }

    public void onStop() {
    }

    public void zza(String str, int i) {
        synchronized (this.zzail) {
            this.zzchu = 2;
            this.zzbym = i;
            this.zzail.notify();
        }
    }

    public void zzaw(int i) {
        zza(this.zzbog, 0);
    }

    public void zzch(String str) {
        synchronized (this.zzail) {
            this.zzchu = 1;
            this.zzail.notify();
        }
    }

    public void zzew() {
        if (this.zzchq != null && this.zzchq.zzrw() != null && this.zzchq.zzrv() != null) {
            final zzjn zzrw = this.zzchq.zzrw();
            zzrw.zza((zzjo) this);
            zzrw.zza((zzjl) this);
            final AdRequestParcel adRequestParcel = this.zzbxv.zzcit.zzcav;
            final zzgo zzrv = this.zzchq.zzrv();
            try {
                Handler handler;
                Runnable c04651;
                if (zzrv.isInitialized()) {
                    handler = com.google.android.gms.ads.internal.util.client.zza.zzcnf;
                    c04651 = new Runnable(this) {
                        final /* synthetic */ zzjk zzchw;

                        public void run() {
                            this.zzchw.zza(adRequestParcel, zzrv);
                        }
                    };
                } else {
                    handler = com.google.android.gms.ads.internal.util.client.zza.zzcnf;
                    c04651 = new Runnable(this) {
                        final /* synthetic */ zzjk zzchw;

                        public void run() {
                            try {
                                zzrv.zza(zze.zzae(this.zzchw.mContext), adRequestParcel, null, zzrw, this.zzchw.zzchs);
                            } catch (Throwable e) {
                                String str = "Fail to initialize adapter ";
                                String valueOf = String.valueOf(this.zzchw.zzbog);
                                zzb.zzd(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), e);
                                this.zzchw.zza(this.zzchw.zzbog, 0);
                            }
                        }
                    };
                }
                handler.post(c04651);
            } catch (Throwable e) {
                zzb.zzd("Fail to check if adapter is initialized.", e);
                zza(this.zzbog, 0);
            }
            zzk(zzu.zzfu().elapsedRealtime());
            zzrw.zza(null);
            zzrw.zza(null);
            if (this.zzchu == 1) {
                this.zzchr.zzch(this.zzbog);
            } else {
                this.zzchr.zza(this.zzbog, this.zzbym);
            }
        }
    }

    protected boolean zzf(long r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = com.google.android.gms.ads.internal.zzu.zzfu();
        r0 = r0.elapsedRealtime();
        r2 = r0 - r5;
        r5 = 20000; // 0x4e20 float:2.8026E-41 double:9.8813E-320;
        r0 = r5 - r2;
        r5 = 0;
        r2 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1));
        r5 = 0;
        if (r2 > 0) goto L_0x0016;
    L_0x0015:
        return r5;
    L_0x0016:
        r6 = r4.zzail;	 Catch:{ InterruptedException -> 0x001c }
        r6.wait(r0);	 Catch:{ InterruptedException -> 0x001c }
        r5 = 1;
    L_0x001c:
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzjk.zzf(long):boolean");
    }

    public void zzrt() {
        zza(this.zzbxv.zzcit.zzcav, this.zzchq.zzrv());
    }
}
