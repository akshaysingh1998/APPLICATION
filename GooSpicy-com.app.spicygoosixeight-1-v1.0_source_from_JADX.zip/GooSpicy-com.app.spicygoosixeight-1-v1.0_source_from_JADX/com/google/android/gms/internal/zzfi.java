package com.google.android.gms.internal;

@zzir
public class zzfi implements zzet {
    public void zza(com.google.android.gms.internal.zzll r5, java.util.Map<java.lang.String, java.lang.String> r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = com.google.android.gms.ads.internal.zzu.zzgj();
        r1 = "abort";
        r1 = r6.containsKey(r1);
        if (r1 == 0) goto L_0x0018;
    L_0x000c:
        r5 = r0.zze(r5);
        if (r5 != 0) goto L_0x0017;
    L_0x0012:
        r5 = "Precache abort but no preload task running.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r5);
    L_0x0017:
        return;
    L_0x0018:
        r1 = "src";
        r1 = r6.get(r1);
        r1 = (java.lang.String) r1;
        if (r1 != 0) goto L_0x0028;
    L_0x0022:
        r5 = "Precache video action is missing the src parameter.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r5);
        return;
    L_0x0028:
        r2 = "player";	 Catch:{ NumberFormatException -> 0x0035 }
        r2 = r6.get(r2);	 Catch:{ NumberFormatException -> 0x0035 }
        r2 = (java.lang.String) r2;	 Catch:{ NumberFormatException -> 0x0035 }
        r2 = java.lang.Integer.parseInt(r2);	 Catch:{ NumberFormatException -> 0x0035 }
        goto L_0x0036;
    L_0x0035:
        r2 = 0;
    L_0x0036:
        r3 = "mimetype";
        r3 = r6.containsKey(r3);
        if (r3 == 0) goto L_0x0047;
    L_0x003e:
        r3 = "mimetype";
        r6 = r6.get(r3);
        r6 = (java.lang.String) r6;
        goto L_0x0049;
    L_0x0047:
        r6 = "";
    L_0x0049:
        r0 = r0.zzf(r5);
        if (r0 == 0) goto L_0x0055;
    L_0x004f:
        r5 = "Precache task already running.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r5);
        return;
    L_0x0055:
        r0 = r5.zzuh();
        com.google.android.gms.common.internal.zzb.zzw(r0);
        r0 = r5.zzuh();
        r0 = r0.zzakj;
        r6 = r0.zza(r5, r2, r6);
        r0 = new com.google.android.gms.internal.zzff;
        r0.<init>(r5, r6, r1);
        r5 = r0.zzpz();
        r5 = (java.util.concurrent.Future) r5;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfi.zza(com.google.android.gms.internal.zzll, java.util.Map):void");
    }
}
