package com.google.android.gms.internal;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

final class zzamn implements zzamx<Date>, zzang<Date> {
    private final DateFormat bdO;
    private final DateFormat bdP;
    private final DateFormat bdQ;

    zzamn() {
        this(DateFormat.getDateTimeInstance(2, 2, Locale.US), DateFormat.getDateTimeInstance(2, 2));
    }

    public zzamn(int i, int i2) {
        this(DateFormat.getDateTimeInstance(i, i2, Locale.US), DateFormat.getDateTimeInstance(i, i2));
    }

    zzamn(String str) {
        this(new SimpleDateFormat(str, Locale.US), new SimpleDateFormat(str));
    }

    zzamn(DateFormat dateFormat, DateFormat dateFormat2) {
        this.bdO = dateFormat;
        this.bdP = dateFormat2;
        this.bdQ = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        this.bdQ.setTimeZone(TimeZone.getTimeZone("UTC"));
    }

    private java.util.Date zza(com.google.android.gms.internal.zzamy r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r3.bdP;
        monitor-enter(r0);
        r1 = r3.bdP;	 Catch:{ ParseException -> 0x0011 }
        r2 = r4.zzczh();	 Catch:{ ParseException -> 0x0011 }
        r1 = r1.parse(r2);	 Catch:{ ParseException -> 0x0011 }
        monitor-exit(r0);	 Catch:{ all -> 0x000f }
        return r1;
    L_0x000f:
        r4 = move-exception;
        goto L_0x0034;
    L_0x0011:
        r1 = r3.bdO;	 Catch:{ ParseException -> 0x001d }
        r2 = r4.zzczh();	 Catch:{ ParseException -> 0x001d }
        r1 = r1.parse(r2);	 Catch:{ ParseException -> 0x001d }
        monitor-exit(r0);	 Catch:{ all -> 0x000f }
        return r1;
    L_0x001d:
        r1 = r3.bdQ;	 Catch:{ ParseException -> 0x0029 }
        r2 = r4.zzczh();	 Catch:{ ParseException -> 0x0029 }
        r1 = r1.parse(r2);	 Catch:{ ParseException -> 0x0029 }
        monitor-exit(r0);	 Catch:{ all -> 0x000f }
        return r1;	 Catch:{ all -> 0x000f }
    L_0x0029:
        r1 = move-exception;	 Catch:{ all -> 0x000f }
        r2 = new com.google.android.gms.internal.zzanh;	 Catch:{ all -> 0x000f }
        r4 = r4.zzczh();	 Catch:{ all -> 0x000f }
        r2.<init>(r4, r1);	 Catch:{ all -> 0x000f }
        throw r2;	 Catch:{ all -> 0x000f }
    L_0x0034:
        monitor-exit(r0);	 Catch:{ all -> 0x000f }
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzamn.zza(com.google.android.gms.internal.zzamy):java.util.Date");
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(zzamn.class.getSimpleName());
        stringBuilder.append('(');
        stringBuilder.append(this.bdP.getClass().getSimpleName());
        stringBuilder.append(')');
        return stringBuilder.toString();
    }

    public zzamy zza(Date date, Type type, zzanf com_google_android_gms_internal_zzanf) {
        zzamy com_google_android_gms_internal_zzane;
        synchronized (this.bdP) {
            com_google_android_gms_internal_zzane = new zzane(this.bdO.format(date));
        }
        return com_google_android_gms_internal_zzane;
    }

    public Date zza(zzamy com_google_android_gms_internal_zzamy, Type type, zzamw com_google_android_gms_internal_zzamw) throws zzanc {
        if (com_google_android_gms_internal_zzamy instanceof zzane) {
            Date zza = zza(com_google_android_gms_internal_zzamy);
            if (type == Date.class) {
                return zza;
            }
            if (type == Timestamp.class) {
                return new Timestamp(zza.getTime());
            }
            if (type == java.sql.Date.class) {
                return new java.sql.Date(zza.getTime());
            }
            String valueOf = String.valueOf(getClass());
            String valueOf2 = String.valueOf(type);
            StringBuilder stringBuilder = new StringBuilder((23 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length());
            stringBuilder.append(valueOf);
            stringBuilder.append(" cannot deserialize to ");
            stringBuilder.append(valueOf2);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        throw new zzanc("The date should be a string value");
    }

    public /* synthetic */ Object zzb(zzamy com_google_android_gms_internal_zzamy, Type type, zzamw com_google_android_gms_internal_zzamw) throws zzanc {
        return zza(com_google_android_gms_internal_zzamy, type, com_google_android_gms_internal_zzamw);
    }
}
