package com.google.android.gms.internal;

import com.google.android.gms.internal.zzb.zza;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import org.apache.http.Header;
import org.apache.http.StatusLine;
import org.apache.http.impl.cookie.DateUtils;

public class zzt implements zzf {
    protected static final boolean DEBUG = zzs.DEBUG;
    private static int zzbn = 3000;
    private static int zzbo = 4096;
    protected final zzy zzbp;
    protected final zzu zzbq;

    public zzt(zzy com_google_android_gms_internal_zzy) {
        this(com_google_android_gms_internal_zzy, new zzu(zzbo));
    }

    public zzt(zzy com_google_android_gms_internal_zzy, zzu com_google_android_gms_internal_zzu) {
        this.zzbp = com_google_android_gms_internal_zzy;
        this.zzbq = com_google_android_gms_internal_zzu;
    }

    protected static Map<String, String> zza(Header[] headerArr) {
        Map<String, String> treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        for (int i = 0; i < headerArr.length; i++) {
            treeMap.put(headerArr[i].getName(), headerArr[i].getValue());
        }
        return treeMap;
    }

    private void zza(long j, zzk<?> com_google_android_gms_internal_zzk_, byte[] bArr, StatusLine statusLine) {
        if (DEBUG || j > ((long) zzbn)) {
            String str = "HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]";
            Object[] objArr = new Object[5];
            objArr[0] = com_google_android_gms_internal_zzk_;
            objArr[1] = Long.valueOf(j);
            objArr[2] = bArr != null ? Integer.valueOf(bArr.length) : "null";
            objArr[3] = Integer.valueOf(statusLine.getStatusCode());
            objArr[4] = Integer.valueOf(com_google_android_gms_internal_zzk_.zzt().zzd());
            zzs.zzb(str, objArr);
        }
    }

    private static void zza(String str, zzk<?> com_google_android_gms_internal_zzk_, zzr com_google_android_gms_internal_zzr) throws zzr {
        zzo zzt = com_google_android_gms_internal_zzk_.zzt();
        int zzs = com_google_android_gms_internal_zzk_.zzs();
        try {
            zzt.zza(com_google_android_gms_internal_zzr);
            com_google_android_gms_internal_zzk_.zzc(String.format("%s-retry [timeout=%s]", new Object[]{str, Integer.valueOf(zzs)}));
        } catch (zzr com_google_android_gms_internal_zzr2) {
            com_google_android_gms_internal_zzk_.zzc(String.format("%s-timeout-giveup [timeout=%s]", new Object[]{str, Integer.valueOf(zzs)}));
            throw com_google_android_gms_internal_zzr2;
        }
    }

    private void zza(Map<String, String> map, zza com_google_android_gms_internal_zzb_zza) {
        if (com_google_android_gms_internal_zzb_zza != null) {
            if (com_google_android_gms_internal_zzb_zza.zza != null) {
                map.put("If-None-Match", com_google_android_gms_internal_zzb_zza.zza);
            }
            if (com_google_android_gms_internal_zzb_zza.zzc > 0) {
                map.put("If-Modified-Since", DateUtils.formatDate(new Date(com_google_android_gms_internal_zzb_zza.zzc)));
            }
        }
    }

    private byte[] zza(org.apache.http.HttpEntity r7) throws java.io.IOException, com.google.android.gms.internal.zzp {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r6 = this;
        r0 = new com.google.android.gms.internal.zzaa;
        r1 = r6.zzbq;
        r2 = r7.getContentLength();
        r2 = (int) r2;
        r0.<init>(r1, r2);
        r1 = 0;
        r2 = 0;
        r3 = r7.getContent();	 Catch:{ all -> 0x0048 }
        if (r3 != 0) goto L_0x001a;	 Catch:{ all -> 0x0048 }
    L_0x0014:
        r3 = new com.google.android.gms.internal.zzp;	 Catch:{ all -> 0x0048 }
        r3.<init>();	 Catch:{ all -> 0x0048 }
        throw r3;	 Catch:{ all -> 0x0048 }
    L_0x001a:
        r4 = r6.zzbq;	 Catch:{ all -> 0x0048 }
        r5 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;	 Catch:{ all -> 0x0048 }
        r4 = r4.zzb(r5);	 Catch:{ all -> 0x0048 }
    L_0x0022:
        r2 = r3.read(r4);	 Catch:{ all -> 0x0045 }
        r5 = -1;	 Catch:{ all -> 0x0045 }
        if (r2 == r5) goto L_0x002d;	 Catch:{ all -> 0x0045 }
    L_0x0029:
        r0.write(r4, r1, r2);	 Catch:{ all -> 0x0045 }
        goto L_0x0022;	 Catch:{ all -> 0x0045 }
    L_0x002d:
        r2 = r0.toByteArray();	 Catch:{ all -> 0x0045 }
        r7.consumeContent();	 Catch:{ IOException -> 0x0035 }
        goto L_0x003c;
    L_0x0035:
        r7 = "Error occured when calling consumingContent";
        r1 = new java.lang.Object[r1];
        com.google.android.gms.internal.zzs.zza(r7, r1);
    L_0x003c:
        r7 = r6.zzbq;
        r7.zza(r4);
        r0.close();
        return r2;
    L_0x0045:
        r3 = move-exception;
        r2 = r4;
        goto L_0x0049;
    L_0x0048:
        r3 = move-exception;
    L_0x0049:
        r7.consumeContent();	 Catch:{ IOException -> 0x004d }
        goto L_0x0054;
    L_0x004d:
        r7 = "Error occured when calling consumingContent";
        r1 = new java.lang.Object[r1];
        com.google.android.gms.internal.zzs.zza(r7, r1);
    L_0x0054:
        r7 = r6.zzbq;
        r7.zza(r2);
        r0.close();
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzt.zza(org.apache.http.HttpEntity):byte[]");
    }

    public com.google.android.gms.internal.zzi zza(com.google.android.gms.internal.zzk<?> r24) throws com.google.android.gms.internal.zzr {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r23 = this;
        r7 = r23;
        r8 = r24;
        r9 = android.os.SystemClock.elapsedRealtime();
    L_0x0008:
        r1 = java.util.Collections.emptyMap();
        r11 = 0;
        r12 = 0;
        r2 = new java.util.HashMap;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00d3 }
        r2.<init>();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00d3 }
        r3 = r24.zzh();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00d3 }
        r7.zza(r2, r3);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00d3 }
        r3 = r7.zzbp;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00d3 }
        r13 = r3.zza(r8, r2);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00d3 }
        r6 = r13.getStatusLine();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00cd }
        r15 = r6.getStatusCode();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00cd }
        r2 = r13.getAllHeaders();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00cd }
        r14 = zza(r2);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00cd }
        r1 = 304; // 0x130 float:4.26E-43 double:1.5E-321;
        if (r15 != r1) goto L_0x0076;
    L_0x0034:
        r1 = r24.zzh();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        if (r1 != 0) goto L_0x0050;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
    L_0x003a:
        r1 = new com.google.android.gms.internal.zzi;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r17 = 304; // 0x130 float:4.26E-43 double:1.5E-321;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r18 = 0;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r20 = 1;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r2 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r21 = r2 - r9;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r16 = r1;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r19 = r14;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r16.<init>(r17, r18, r19, r20, r21);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        return r1;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
    L_0x0050:
        r2 = r1.zzf;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r2.putAll(r14);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r2 = new com.google.android.gms.internal.zzi;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r16 = 304; // 0x130 float:4.26E-43 double:1.5E-321;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r3 = r1.data;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r1 = r1.zzf;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r19 = 1;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r4 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r20 = r4 - r9;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r15 = r2;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r17 = r3;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r18 = r1;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r15.<init>(r16, r17, r18, r19, r20);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        return r2;
    L_0x006e:
        r0 = move-exception;
        r1 = r0;
        r16 = r12;
        r17 = r14;
        goto L_0x00da;
    L_0x0076:
        r1 = r13.getEntity();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00c5 }
        if (r1 == 0) goto L_0x0085;
    L_0x007c:
        r1 = r13.getEntity();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        r1 = r7.zza(r1);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x006e }
        goto L_0x0087;
    L_0x0085:
        r1 = new byte[r11];	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00c5 }
    L_0x0087:
        r21 = r1;
        r1 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r3 = r1 - r9;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r1 = r7;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r2 = r3;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r4 = r8;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r5 = r21;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r1.zza(r2, r4, r5, r6);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r1 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        if (r15 < r1) goto L_0x00b4;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
    L_0x009b:
        r1 = 299; // 0x12b float:4.19E-43 double:1.477E-321;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        if (r15 <= r1) goto L_0x00a0;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
    L_0x009f:
        goto L_0x00b4;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
    L_0x00a0:
        r1 = new com.google.android.gms.internal.zzi;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r18 = 0;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r2 = android.os.SystemClock.elapsedRealtime();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bd }
        r19 = r2 - r9;
        r2 = r14;
        r14 = r1;
        r16 = r21;
        r17 = r2;
        r14.<init>(r15, r16, r17, r18, r19);	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bb }
        return r1;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bb }
    L_0x00b4:
        r2 = r14;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bb }
        r1 = new java.io.IOException;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bb }
        r1.<init>();	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bb }
        throw r1;	 Catch:{ SocketTimeoutException -> 0x015c, ConnectTimeoutException -> 0x0154, MalformedURLException -> 0x0131, IOException -> 0x00bb }
    L_0x00bb:
        r0 = move-exception;
        goto L_0x00bf;
    L_0x00bd:
        r0 = move-exception;
        r2 = r14;
    L_0x00bf:
        r1 = r0;
        r17 = r2;
        r16 = r21;
        goto L_0x00da;
    L_0x00c5:
        r0 = move-exception;
        r2 = r14;
        r1 = r0;
        r17 = r2;
        r16 = r12;
        goto L_0x00da;
    L_0x00cd:
        r0 = move-exception;
        r17 = r1;
        r16 = r12;
        goto L_0x00d9;
    L_0x00d3:
        r0 = move-exception;
        r17 = r1;
        r13 = r12;
        r16 = r13;
    L_0x00d9:
        r1 = r0;
    L_0x00da:
        if (r13 == 0) goto L_0x012b;
    L_0x00dc:
        r1 = r13.getStatusLine();
        r1 = r1.getStatusCode();
        r2 = "Unexpected response code %d for %s";
        r3 = 2;
        r3 = new java.lang.Object[r3];
        r4 = java.lang.Integer.valueOf(r1);
        r3[r11] = r4;
        r4 = 1;
        r5 = r24.getUrl();
        r3[r4] = r5;
        com.google.android.gms.internal.zzs.zzc(r2, r3);
        if (r16 == 0) goto L_0x0125;
    L_0x00fb:
        r2 = new com.google.android.gms.internal.zzi;
        r18 = 0;
        r3 = android.os.SystemClock.elapsedRealtime();
        r19 = r3 - r9;
        r14 = r2;
        r15 = r1;
        r14.<init>(r15, r16, r17, r18, r19);
        r3 = 401; // 0x191 float:5.62E-43 double:1.98E-321;
        if (r1 == r3) goto L_0x0119;
    L_0x010e:
        r3 = 403; // 0x193 float:5.65E-43 double:1.99E-321;
        if (r1 != r3) goto L_0x0113;
    L_0x0112:
        goto L_0x0119;
    L_0x0113:
        r1 = new com.google.android.gms.internal.zzp;
        r1.<init>(r2);
        throw r1;
    L_0x0119:
        r1 = "auth";
        r3 = new com.google.android.gms.internal.zza;
        r3.<init>(r2);
        zza(r1, r8, r3);
        goto L_0x0008;
    L_0x0125:
        r1 = new com.google.android.gms.internal.zzh;
        r1.<init>(r12);
        throw r1;
    L_0x012b:
        r2 = new com.google.android.gms.internal.zzj;
        r2.<init>(r1);
        throw r2;
    L_0x0131:
        r0 = move-exception;
        r1 = r0;
        r2 = new java.lang.RuntimeException;
        r3 = "Bad URL ";
        r4 = r24.getUrl();
        r4 = java.lang.String.valueOf(r4);
        r5 = r4.length();
        if (r5 == 0) goto L_0x014a;
    L_0x0145:
        r3 = r3.concat(r4);
        goto L_0x0150;
    L_0x014a:
        r4 = new java.lang.String;
        r4.<init>(r3);
        r3 = r4;
    L_0x0150:
        r2.<init>(r3, r1);
        throw r2;
    L_0x0154:
        r1 = "connection";
        r2 = new com.google.android.gms.internal.zzq;
        r2.<init>();
        goto L_0x0163;
    L_0x015c:
        r1 = "socket";
        r2 = new com.google.android.gms.internal.zzq;
        r2.<init>();
    L_0x0163:
        zza(r1, r8, r2);
        goto L_0x0008;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzt.zza(com.google.android.gms.internal.zzk):com.google.android.gms.internal.zzi");
    }
}
