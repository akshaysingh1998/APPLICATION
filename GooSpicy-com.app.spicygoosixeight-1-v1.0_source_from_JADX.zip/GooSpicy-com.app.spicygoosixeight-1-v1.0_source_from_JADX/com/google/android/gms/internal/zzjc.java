package com.google.android.gms.internal;

public interface zzjc {
    void zzrp();

    void zzrq();
}
