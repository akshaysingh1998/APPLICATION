package com.google.android.gms.internal;

import android.content.Context;
import android.os.Build.VERSION;
import com.google.android.gms.ads.internal.zzu;
import java.util.LinkedHashMap;
import java.util.Map;

@zzir
public class zzdd {
    private Context mContext = null;
    private String zzarh = null;
    private boolean zzbdm;
    private String zzbdn;
    private Map<String, String> zzbdo;

    public zzdd(Context context, String str) {
        this.mContext = context;
        this.zzarh = str;
        this.zzbdm = ((Boolean) zzdc.zzazc.get()).booleanValue();
        this.zzbdn = (String) zzdc.zzazd.get();
        this.zzbdo = new LinkedHashMap();
        this.zzbdo.put("s", "gmob_sdk");
        this.zzbdo.put("v", "3");
        this.zzbdo.put("os", VERSION.RELEASE);
        this.zzbdo.put("sdk", VERSION.SDK);
        this.zzbdo.put("device", zzu.zzfq().zzth());
        this.zzbdo.put("app", context.getApplicationContext() != null ? context.getApplicationContext().getPackageName() : context.getPackageName());
        this.zzbdo.put("is_lite_sdk", zzu.zzfq().zzan(context) ? "1" : "0");
        zziz zzy = zzu.zzfw().zzy(this.mContext);
        this.zzbdo.put("network_coarse", Integer.toString(zzy.zzcgt));
        this.zzbdo.put("network_fine", Integer.toString(zzy.zzcgu));
    }

    Context getContext() {
        return this.mContext;
    }

    String zzhl() {
        return this.zzarh;
    }

    boolean zzjz() {
        return this.zzbdm;
    }

    String zzka() {
        return this.zzbdn;
    }

    Map<String, String> zzkb() {
        return this.zzbdo;
    }
}
