package com.google.android.gms.internal;

import com.google.android.gms.ads.formats.NativeAppInstallAd.OnAppInstallAdLoadedListener;
import com.google.android.gms.internal.zzee.zza;

@zzir
public class zzej extends zza {
    private final OnAppInstallAdLoadedListener zzbhm;

    public zzej(OnAppInstallAdLoadedListener onAppInstallAdLoadedListener) {
        this.zzbhm = onAppInstallAdLoadedListener;
    }

    public void zza(zzdy com_google_android_gms_internal_zzdy) {
        this.zzbhm.onAppInstallAdLoaded(zzb(com_google_android_gms_internal_zzdy));
    }

    zzdz zzb(zzdy com_google_android_gms_internal_zzdy) {
        return new zzdz(com_google_android_gms_internal_zzdy);
    }
}
