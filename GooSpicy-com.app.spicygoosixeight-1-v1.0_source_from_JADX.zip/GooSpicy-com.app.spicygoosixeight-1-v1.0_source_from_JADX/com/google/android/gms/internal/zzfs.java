package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.client.AdRequestParcel;

@zzir
class zzfs {
    final String zzall;
    final AdRequestParcel zzana;
    final int zzbkx;

    zzfs(AdRequestParcel adRequestParcel, String str, int i) {
        this.zzana = adRequestParcel;
        this.zzall = str;
        this.zzbkx = i;
    }

    zzfs(zzfq com_google_android_gms_internal_zzfq) {
        this(com_google_android_gms_internal_zzfq.zzls(), com_google_android_gms_internal_zzfq.getAdUnitId(), com_google_android_gms_internal_zzfq.getNetworkType());
    }

    zzfs(java.lang.String r6) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r5 = this;
        r5.<init>();
        r0 = "\u0000";
        r6 = r6.split(r0);
        r0 = 3;
        r1 = r6.length;
        if (r1 == r0) goto L_0x0015;
    L_0x000d:
        r6 = new java.io.IOException;
        r0 = "Incorrect field count for QueueSeed.";
        r6.<init>(r0);
        throw r6;
    L_0x0015:
        r0 = android.os.Parcel.obtain();
        r1 = 0;
        r2 = r6[r1];	 Catch:{ IllegalArgumentException -> 0x0050 }
        r2 = android.util.Base64.decode(r2, r1);	 Catch:{ IllegalArgumentException -> 0x0050 }
        r3 = new java.lang.String;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r4 = "UTF-8";	 Catch:{ IllegalArgumentException -> 0x0050 }
        r3.<init>(r2, r4);	 Catch:{ IllegalArgumentException -> 0x0050 }
        r5.zzall = r3;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r2 = 1;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r2 = r6[r2];	 Catch:{ IllegalArgumentException -> 0x0050 }
        r2 = java.lang.Integer.parseInt(r2);	 Catch:{ IllegalArgumentException -> 0x0050 }
        r5.zzbkx = r2;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r2 = 2;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r6 = r6[r2];	 Catch:{ IllegalArgumentException -> 0x0050 }
        r6 = android.util.Base64.decode(r6, r1);	 Catch:{ IllegalArgumentException -> 0x0050 }
        r2 = r6.length;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r0.unmarshall(r6, r1, r2);	 Catch:{ IllegalArgumentException -> 0x0050 }
        r0.setDataPosition(r1);	 Catch:{ IllegalArgumentException -> 0x0050 }
        r6 = com.google.android.gms.ads.internal.client.AdRequestParcel.CREATOR;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r6 = r6.createFromParcel(r0);	 Catch:{ IllegalArgumentException -> 0x0050 }
        r6 = (com.google.android.gms.ads.internal.client.AdRequestParcel) r6;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r5.zzana = r6;	 Catch:{ IllegalArgumentException -> 0x0050 }
        r0.recycle();
        return;
    L_0x004e:
        r6 = move-exception;
        goto L_0x0058;
    L_0x0050:
        r6 = new java.io.IOException;	 Catch:{ all -> 0x004e }
        r1 = "Malformed QueueSeed encoding.";	 Catch:{ all -> 0x004e }
        r6.<init>(r1);	 Catch:{ all -> 0x004e }
        throw r6;	 Catch:{ all -> 0x004e }
    L_0x0058:
        r0.recycle();
        throw r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfs.<init>(java.lang.String):void");
    }

    java.lang.String zzlz() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r7 = this;
        r0 = android.os.Parcel.obtain();
        r1 = r7.zzall;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r2 = "UTF-8";	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r1 = r1.getBytes(r2);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r2 = 0;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r1 = android.util.Base64.encodeToString(r1, r2);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r3 = r7.zzbkx;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r3 = java.lang.Integer.toString(r3);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4 = r7.zzana;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4.writeToParcel(r0, r2);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4 = r0.marshall();	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r2 = android.util.Base64.encodeToString(r4, r2);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4 = new java.lang.StringBuilder;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r5 = 2;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r6 = java.lang.String.valueOf(r1);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r6 = r6.length();	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r5 = r5 + r6;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r6 = java.lang.String.valueOf(r3);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r6 = r6.length();	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r5 = r5 + r6;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r6 = java.lang.String.valueOf(r2);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r6 = r6.length();	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r5 = r5 + r6;	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4.<init>(r5);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4.append(r1);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r1 = "\u0000";	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4.append(r1);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4.append(r3);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r1 = "\u0000";	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4.append(r1);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r4.append(r2);	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r1 = r4.toString();	 Catch:{ UnsupportedEncodingException -> 0x0062 }
        r0.recycle();
        return r1;
    L_0x0060:
        r1 = move-exception;
        goto L_0x006d;
    L_0x0062:
        r1 = "QueueSeed encode failed because UTF-8 is not available.";	 Catch:{ all -> 0x0060 }
        com.google.android.gms.ads.internal.util.client.zzb.m9e(r1);	 Catch:{ all -> 0x0060 }
        r0.recycle();
        r0 = "";
        return r0;
    L_0x006d:
        r0.recycle();
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfs.zzlz():java.lang.String");
    }
}
