package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzd;
import com.google.android.gms.ads.internal.zzs;
import com.google.android.gms.ads.internal.zzu;

@zzir
public class zzln {
    public zzll zza(Context context, AdSizeParcel adSizeParcel, boolean z, boolean z2, zzas com_google_android_gms_internal_zzas, VersionInfoParcel versionInfoParcel) {
        return zza(context, adSizeParcel, z, z2, com_google_android_gms_internal_zzas, versionInfoParcel, null, null, null);
    }

    public zzll zza(Context context, AdSizeParcel adSizeParcel, boolean z, boolean z2, zzas com_google_android_gms_internal_zzas, VersionInfoParcel versionInfoParcel, zzdk com_google_android_gms_internal_zzdk, zzs com_google_android_gms_ads_internal_zzs, zzd com_google_android_gms_ads_internal_zzd) {
        zzll com_google_android_gms_internal_zzlo = new zzlo(zzlp.zzb(context, adSizeParcel, z, z2, com_google_android_gms_internal_zzas, versionInfoParcel, com_google_android_gms_internal_zzdk, com_google_android_gms_ads_internal_zzs, com_google_android_gms_ads_internal_zzd));
        com_google_android_gms_internal_zzlo.setWebViewClient(zzu.zzfs().zzb(com_google_android_gms_internal_zzlo, z2));
        com_google_android_gms_internal_zzlo.setWebChromeClient(zzu.zzfs().zzl(com_google_android_gms_internal_zzlo));
        return com_google_android_gms_internal_zzlo;
    }
}
