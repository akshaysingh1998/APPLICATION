package com.google.android.gms.internal;

import java.lang.reflect.Field;
import java.util.Locale;

public enum zzamq implements zzamr {
    IDENTITY {
        public String zzc(Field field) {
            return field.getName();
        }
    },
    UPPER_CAMEL_CASE {
        public String zzc(Field field) {
            return zzamq.zzsv(field.getName());
        }
    },
    UPPER_CAMEL_CASE_WITH_SPACES {
        public String zzc(Field field) {
            return zzamq.zzsv(zzamq.zzbw(field.getName(), " "));
        }
    },
    LOWER_CASE_WITH_UNDERSCORES {
        public String zzc(Field field) {
            return zzamq.zzbw(field.getName(), "_").toLowerCase(Locale.ENGLISH);
        }
    },
    LOWER_CASE_WITH_DASHES {
        public String zzc(Field field) {
            return zzamq.zzbw(field.getName(), "-").toLowerCase(Locale.ENGLISH);
        }
    };

    private static String zza(char c, String str, int i) {
        if (i >= str.length()) {
            return String.valueOf(c);
        }
        str = String.valueOf(str.substring(i));
        StringBuilder stringBuilder = new StringBuilder(1 + String.valueOf(str).length());
        stringBuilder.append(c);
        stringBuilder.append(str);
        return stringBuilder.toString();
    }

    private static String zzbw(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char charAt = str.charAt(i);
            if (Character.isUpperCase(charAt) && stringBuilder.length() != 0) {
                stringBuilder.append(str2);
            }
            stringBuilder.append(charAt);
        }
        return stringBuilder.toString();
    }

    private static String zzsv(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        int i = 0;
        while (true) {
            char charAt = str.charAt(i);
            if (i >= str.length() - 1) {
                break;
            } else if (Character.isLetter(charAt)) {
                break;
            } else {
                stringBuilder.append(charAt);
                i++;
            }
        }
        if (i == str.length()) {
            return stringBuilder.toString();
        }
        if (!Character.isUpperCase(charAt)) {
            stringBuilder.append(zza(Character.toUpperCase(charAt), str, i + 1));
            str = stringBuilder.toString();
        }
        return str;
    }
}
