package com.google.android.gms.internal;

import android.support.v4.media.TransportMediator;
import java.io.IOException;

public final class zzaou {
    private int bhR;
    private int bhS;
    private int bhT;
    private int bhU;
    private int bhV;
    private int bhW = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
    private int bhX;
    private int bhY = 64;
    private int bhZ = 67108864;
    private final byte[] buffer;

    private zzaou(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.bhR = i;
        this.bhS = i2 + i;
        this.bhU = i;
    }

    private void m38W() {
        this.bhS += this.bhT;
        int i = this.bhS;
        if (i > this.bhW) {
            this.bhT = i - this.bhW;
            this.bhS -= this.bhT;
            return;
        }
        this.bhT = 0;
    }

    public static int zzaeh(int i) {
        return (-(i & 1)) ^ (i >>> 1);
    }

    public static zzaou zzaz(byte[] bArr) {
        return zzb(bArr, 0, bArr.length);
    }

    public static zzaou zzb(byte[] bArr, int i, int i2) {
        return new zzaou(bArr, i, i2);
    }

    public static long zzcq(long j) {
        return (j >>> 1) ^ (-(j & 1));
    }

    public int m39J() throws IOException {
        if (m53Y()) {
            this.bhV = 0;
            return 0;
        }
        this.bhV = m48S();
        if (this.bhV != 0) {
            return this.bhV;
        }
        throw zzapb.aj();
    }

    public void m40K() throws IOException {
        int J;
        do {
            J = m39J();
            if (J == 0) {
                return;
            }
        } while (zzaeg(J));
    }

    public long m41L() throws IOException {
        return m49T();
    }

    public long m42M() throws IOException {
        return m49T();
    }

    public int m43N() throws IOException {
        return m48S();
    }

    public long m44O() throws IOException {
        return m51V();
    }

    public boolean m45P() throws IOException {
        return m48S() != 0;
    }

    public int m46Q() throws IOException {
        return zzaeh(m48S());
    }

    public long m47R() throws IOException {
        return zzcq(m49T());
    }

    public int m48S() throws IOException {
        byte Z = m54Z();
        if (Z >= (byte) 0) {
            return Z;
        }
        int i;
        int i2 = Z & TransportMediator.KEYCODE_MEDIA_PAUSE;
        byte Z2 = m54Z();
        if (Z2 >= (byte) 0) {
            i = Z2 << 7;
        } else {
            i2 |= (Z2 & TransportMediator.KEYCODE_MEDIA_PAUSE) << 7;
            Z2 = m54Z();
            if (Z2 >= (byte) 0) {
                i = Z2 << 14;
            } else {
                i2 |= (Z2 & TransportMediator.KEYCODE_MEDIA_PAUSE) << 14;
                Z2 = m54Z();
                if (Z2 >= (byte) 0) {
                    i = Z2 << 21;
                } else {
                    i2 |= (Z2 & TransportMediator.KEYCODE_MEDIA_PAUSE) << 21;
                    Z2 = m54Z();
                    i2 |= Z2 << 28;
                    if (Z2 >= (byte) 0) {
                        return i2;
                    }
                    for (i = 0; i < 5; i++) {
                        if (m54Z() >= (byte) 0) {
                            return i2;
                        }
                    }
                    throw zzapb.ai();
                }
            }
        }
        return i2 | i;
    }

    public long m49T() throws IOException {
        int i = 0;
        long j = 0;
        while (i < 64) {
            byte Z = m54Z();
            long j2 = j | (((long) (Z & TransportMediator.KEYCODE_MEDIA_PAUSE)) << i);
            if ((Z & 128) == 0) {
                return j2;
            }
            i += 7;
            j = j2;
        }
        throw zzapb.ai();
    }

    public int m50U() throws IOException {
        return (((m54Z() & 255) | ((m54Z() & 255) << 8)) | ((m54Z() & 255) << 16)) | ((m54Z() & 255) << 24);
    }

    public long m51V() throws IOException {
        return (((((((((long) m54Z()) & 255) | ((((long) m54Z()) & 255) << 8)) | ((((long) m54Z()) & 255) << 16)) | ((((long) m54Z()) & 255) << 24)) | ((((long) m54Z()) & 255) << 32)) | ((((long) m54Z()) & 255) << 40)) | ((((long) m54Z()) & 255) << 48)) | ((((long) m54Z()) & 255) << 56);
    }

    public int m52X() {
        if (this.bhW == ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED) {
            return -1;
        }
        return this.bhW - this.bhU;
    }

    public boolean m53Y() {
        return this.bhU == this.bhS;
    }

    public byte m54Z() throws IOException {
        if (this.bhU == this.bhS) {
            throw zzapb.ag();
        }
        byte[] bArr = this.buffer;
        int i = this.bhU;
        this.bhU = i + 1;
        return bArr[i];
    }

    public int getPosition() {
        return this.bhU - this.bhR;
    }

    public byte[] readBytes() throws IOException {
        int S = m48S();
        if (S < 0) {
            throw zzapb.ah();
        } else if (S == 0) {
            return zzapf.bit;
        } else {
            if (S > this.bhS - this.bhU) {
                throw zzapb.ag();
            }
            Object obj = new byte[S];
            System.arraycopy(this.buffer, this.bhU, obj, 0, S);
            this.bhU += S;
            return obj;
        }
    }

    public double readDouble() throws IOException {
        return Double.longBitsToDouble(m51V());
    }

    public float readFloat() throws IOException {
        return Float.intBitsToFloat(m50U());
    }

    public String readString() throws IOException {
        int S = m48S();
        if (S < 0) {
            throw zzapb.ah();
        } else if (S > this.bhS - this.bhU) {
            throw zzapb.ag();
        } else {
            String str = new String(this.buffer, this.bhU, S, zzapa.UTF_8);
            this.bhU += S;
            return str;
        }
    }

    public void zza(zzapc com_google_android_gms_internal_zzapc) throws IOException {
        int S = m48S();
        if (this.bhX >= this.bhY) {
            throw zzapb.am();
        }
        S = zzaei(S);
        this.bhX++;
        com_google_android_gms_internal_zzapc.zzb(this);
        zzaef(0);
        this.bhX--;
        zzaej(S);
    }

    public void zza(zzapc com_google_android_gms_internal_zzapc, int i) throws IOException {
        if (this.bhX >= this.bhY) {
            throw zzapb.am();
        }
        this.bhX++;
        com_google_android_gms_internal_zzapc.zzb(this);
        zzaef(zzapf.zzaj(i, 4));
        this.bhX--;
    }

    public byte[] zzad(int i, int i2) {
        if (i2 == 0) {
            return zzapf.bit;
        }
        Object obj = new byte[i2];
        System.arraycopy(this.buffer, this.bhR + i, obj, 0, i2);
        return obj;
    }

    public void zzaef(int i) throws zzapb {
        if (this.bhV != i) {
            throw zzapb.ak();
        }
    }

    public boolean zzaeg(int i) throws IOException {
        switch (zzapf.zzaez(i)) {
            case 0:
                m43N();
                return true;
            case 1:
                m51V();
                return true;
            case 2:
                zzael(m48S());
                return true;
            case 3:
                m40K();
                zzaef(zzapf.zzaj(zzapf.zzafa(i), 4));
                return true;
            case 4:
                return false;
            case 5:
                m50U();
                return true;
            default:
                throw zzapb.al();
        }
    }

    public int zzaei(int i) throws zzapb {
        if (i < 0) {
            throw zzapb.ah();
        }
        i += this.bhU;
        int i2 = this.bhW;
        if (i > i2) {
            throw zzapb.ag();
        }
        this.bhW = i;
        m38W();
        return i2;
    }

    public void zzaej(int i) {
        this.bhW = i;
        m38W();
    }

    public void zzaek(int i) {
        if (i > this.bhU - this.bhR) {
            int i2 = this.bhU - this.bhR;
            StringBuilder stringBuilder = new StringBuilder(50);
            stringBuilder.append("Position ");
            stringBuilder.append(i);
            stringBuilder.append(" is beyond current ");
            stringBuilder.append(i2);
            throw new IllegalArgumentException(stringBuilder.toString());
        } else if (i < 0) {
            StringBuilder stringBuilder2 = new StringBuilder(24);
            stringBuilder2.append("Bad position ");
            stringBuilder2.append(i);
            throw new IllegalArgumentException(stringBuilder2.toString());
        } else {
            this.bhU = this.bhR + i;
        }
    }

    public void zzael(int i) throws IOException {
        if (i < 0) {
            throw zzapb.ah();
        } else if (this.bhU + i > this.bhW) {
            zzael(this.bhW - this.bhU);
            throw zzapb.ag();
        } else if (i <= this.bhS - this.bhU) {
            this.bhU += i;
        } else {
            throw zzapb.ag();
        }
    }
}
