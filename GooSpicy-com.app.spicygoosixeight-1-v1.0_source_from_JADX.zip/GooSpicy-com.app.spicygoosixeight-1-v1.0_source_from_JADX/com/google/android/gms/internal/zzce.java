package com.google.android.gms.internal;

public interface zzce {
    void zza(zzcd com_google_android_gms_internal_zzcd, boolean z);
}
