package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class zzant implements zzanl, Cloneable {
    public static final zzant beU = new zzant();
    private double beV = -1.0d;
    private int beW = 136;
    private boolean beX = true;
    private List<zzamo> beY = Collections.emptyList();
    private List<zzamo> beZ = Collections.emptyList();

    private boolean zza(zzano com_google_android_gms_internal_zzano) {
        return com_google_android_gms_internal_zzano == null || com_google_android_gms_internal_zzano.zzczz() <= this.beV;
    }

    private boolean zza(zzano com_google_android_gms_internal_zzano, zzanp com_google_android_gms_internal_zzanp) {
        return zza(com_google_android_gms_internal_zzano) && zza(com_google_android_gms_internal_zzanp);
    }

    private boolean zza(zzanp com_google_android_gms_internal_zzanp) {
        return com_google_android_gms_internal_zzanp == null || com_google_android_gms_internal_zzanp.zzczz() > this.beV;
    }

    private boolean zzm(Class<?> cls) {
        return !Enum.class.isAssignableFrom(cls) && (cls.isAnonymousClass() || cls.isLocalClass());
    }

    private boolean zzn(Class<?> cls) {
        return cls.isMemberClass() && !zzo(cls);
    }

    private boolean zzo(Class<?> cls) {
        return (cls.getModifiers() & 8) != 0;
    }

    protected com.google.android.gms.internal.zzant m70b() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = super.clone();	 Catch:{ CloneNotSupportedException -> 0x0007 }
        r0 = (com.google.android.gms.internal.zzant) r0;	 Catch:{ CloneNotSupportedException -> 0x0007 }
        return r0;
    L_0x0007:
        r0 = new java.lang.AssertionError;
        r0.<init>();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzant.b():com.google.android.gms.internal.zzant");
    }

    protected /* synthetic */ Object clone() throws CloneNotSupportedException {
        return m70b();
    }

    public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
        Class s = com_google_android_gms_internal_zzaoo_T.m15s();
        final boolean zza = zza(s, true);
        final boolean zza2 = zza(s, false);
        if (!zza && !zza2) {
            return null;
        }
        final zzams com_google_android_gms_internal_zzams2 = com_google_android_gms_internal_zzams;
        final zzaoo<T> com_google_android_gms_internal_zzaoo_T2 = com_google_android_gms_internal_zzaoo_T;
        return new zzank<T>(this) {
            private zzank<T> bej;
            final /* synthetic */ zzant bfe;

            private zzank<T> zzczx() {
                zzank<T> com_google_android_gms_internal_zzank_T = this.bej;
                if (com_google_android_gms_internal_zzank_T != null) {
                    return com_google_android_gms_internal_zzank_T;
                }
                com_google_android_gms_internal_zzank_T = com_google_android_gms_internal_zzams2.zza(this.bfe, com_google_android_gms_internal_zzaoo_T2);
                this.bej = com_google_android_gms_internal_zzank_T;
                return com_google_android_gms_internal_zzank_T;
            }

            public void zza(zzaor com_google_android_gms_internal_zzaor, T t) throws IOException {
                if (zza) {
                    com_google_android_gms_internal_zzaor.mo2318r();
                } else {
                    zzczx().zza(com_google_android_gms_internal_zzaor, t);
                }
            }

            public T zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
                if (!zza2) {
                    return zzczx().zzb(com_google_android_gms_internal_zzaop);
                }
                com_google_android_gms_internal_zzaop.skipValue();
                return null;
            }
        };
    }

    public zzant zza(zzamo com_google_android_gms_internal_zzamo, boolean z, boolean z2) {
        zzant b = m70b();
        if (z) {
            b.beY = new ArrayList(this.beY);
            b.beY.add(com_google_android_gms_internal_zzamo);
        }
        if (z2) {
            b.beZ = new ArrayList(this.beZ);
            b.beZ.add(com_google_android_gms_internal_zzamo);
        }
        return b;
    }

    public boolean zza(Class<?> cls, boolean z) {
        if (this.beV != -1.0d && !zza((zzano) cls.getAnnotation(zzano.class), (zzanp) cls.getAnnotation(zzanp.class))) {
            return true;
        }
        if ((!this.beX && zzn(cls)) || zzm(cls)) {
            return true;
        }
        for (zzamo zzh : z ? this.beY : this.beZ) {
            if (zzh.zzh(cls)) {
                return true;
            }
        }
        return false;
    }

    public boolean zza(Field field, boolean z) {
        if ((this.beW & field.getModifiers()) != 0) {
            return true;
        }
        if ((this.beV != -1.0d && !zza((zzano) field.getAnnotation(zzano.class), (zzanp) field.getAnnotation(zzanp.class))) || field.isSynthetic()) {
            return true;
        }
        if ((!this.beX && zzn(field.getType())) || zzm(field.getType())) {
            return true;
        }
        List<zzamo> list = z ? this.beY : this.beZ;
        if (!list.isEmpty()) {
            zzamp com_google_android_gms_internal_zzamp = new zzamp(field);
            for (zzamo zza : list) {
                if (zza.zza(com_google_android_gms_internal_zzamp)) {
                    return true;
                }
            }
        }
        return false;
    }

    public zzant zze(int... iArr) {
        zzant b = m70b();
        int i = 0;
        b.beW = 0;
        int length = iArr.length;
        while (i < length) {
            b.beW = iArr[i] | b.beW;
            i++;
        }
        return b;
    }
}
