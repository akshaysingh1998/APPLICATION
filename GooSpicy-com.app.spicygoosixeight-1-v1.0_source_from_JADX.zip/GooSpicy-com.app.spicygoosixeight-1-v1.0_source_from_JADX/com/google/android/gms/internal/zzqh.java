package com.google.android.gms.internal;

import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.WorkerThread;
import android.util.Log;
import android.util.Pair;
import android.util.SparseArray;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions;
import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.api.Api.zzh;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzah;
import com.google.android.gms.common.internal.zzd.zzf;
import com.google.android.gms.common.internal.zzg;
import com.google.android.gms.tasks.TaskCompletionSource;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class zzqh implements Callback {
    private static zzqh uw;
    private static final Object zzamp = new Object();
    private final Context mContext;
    private final Handler mHandler;
    private final GoogleApiAvailability rX;
    private long tU;
    private long tV;
    private final Map<zzpo<?>, zzc<?>> uA;
    private zzpw uB;
    private final Set<zzpo<?>> uC;
    private final ReferenceQueue<com.google.android.gms.common.api.zzc<?>> uD;
    private final SparseArray<zza> uE;
    private zzb uF;
    private long uv;
    private int ux;
    private final AtomicInteger uy;
    private final SparseArray<zzc<?>> uz;

    private final class zza extends PhantomReference<com.google.android.gms.common.api.zzc<?>> {
        private final int sn;
        final /* synthetic */ zzqh uG;

        public zza(zzqh com_google_android_gms_internal_zzqh, com.google.android.gms.common.api.zzc com_google_android_gms_common_api_zzc, int i, ReferenceQueue<com.google.android.gms.common.api.zzc<?>> referenceQueue) {
            this.uG = com_google_android_gms_internal_zzqh;
            super(com_google_android_gms_common_api_zzc, referenceQueue);
            this.sn = i;
        }

        public void zzaqd() {
            this.uG.mHandler.sendMessage(this.uG.mHandler.obtainMessage(2, this.sn, 2));
        }
    }

    private static final class zzb extends Thread {
        private final ReferenceQueue<com.google.android.gms.common.api.zzc<?>> uD;
        private final SparseArray<zza> uE;
        private final AtomicBoolean uH = new AtomicBoolean();

        public zzb(ReferenceQueue<com.google.android.gms.common.api.zzc<?>> referenceQueue, SparseArray<zza> sparseArray) {
            super("GoogleApiCleanup");
            this.uD = referenceQueue;
            this.uE = sparseArray;
        }

        public void run() {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r4 = this;
            r0 = r4.uH;
            r1 = 1;
            r0.set(r1);
            r0 = 10;
            android.os.Process.setThreadPriority(r0);
        L_0x000b:
            r0 = 0;
            r1 = r4.uH;	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            r1 = r1.get();	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            if (r1 == 0) goto L_0x0030;	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
        L_0x0014:
            r1 = r4.uD;	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            r1 = r1.remove();	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            r1 = (com.google.android.gms.internal.zzqh.zza) r1;	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            r2 = r4.uE;	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            r3 = r1.sn;	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            r2.remove(r3);	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            r1.zzaqd();	 Catch:{ InterruptedException -> 0x0030, all -> 0x0029 }
            goto L_0x000b;
        L_0x0029:
            r1 = move-exception;
            r2 = r4.uH;
            r2.set(r0);
            throw r1;
        L_0x0030:
            r1 = r4.uH;
            r1.set(r0);
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzqh.zzb.run():void");
        }
    }

    private class zzc<O extends ApiOptions> implements ConnectionCallbacks, OnConnectionFailedListener {
        private final zzpo<O> rG;
        private boolean tT;
        final /* synthetic */ zzqh uG;
        private final Queue<zzpn> uI = new LinkedList();
        private final zze uJ;
        private final com.google.android.gms.common.api.Api.zzb uK;
        private final SparseArray<zzrd> uL = new SparseArray();
        private final Set<zzpq> uM = new HashSet();
        private final SparseArray<Map<Object, com.google.android.gms.internal.zzpr.zza>> uN = new SparseArray();
        private ConnectionResult uO = null;

        @WorkerThread
        public zzc(zzqh com_google_android_gms_internal_zzqh, com.google.android.gms.common.api.zzc<O> com_google_android_gms_common_api_zzc_O) {
            this.uG = com_google_android_gms_internal_zzqh;
            this.uJ = zzb((com.google.android.gms.common.api.zzc) com_google_android_gms_common_api_zzc_O);
            this.uK = this.uJ instanceof zzah ? ((zzah) this.uJ).zzatj() : this.uJ;
            this.rG = com_google_android_gms_common_api_zzc_O.zzany();
        }

        @WorkerThread
        private void connect() {
            if (!this.uJ.isConnected() && !this.uJ.isConnecting()) {
                if (this.uJ.zzanr() && this.uG.ux != 0) {
                    this.uG.ux = this.uG.rX.isGooglePlayServicesAvailable(this.uG.mContext);
                    if (this.uG.ux != 0) {
                        onConnectionFailed(new ConnectionResult(this.uG.ux, null));
                        return;
                    }
                }
                this.uJ.zza(new zzd(this.uG, this.uJ, this.rG));
            }
        }

        @WorkerThread
        private void resume() {
            if (this.tT) {
                connect();
            }
        }

        @WorkerThread
        private void zzab(Status status) {
            for (zzpn zzx : this.uI) {
                zzx.zzx(status);
            }
            this.uI.clear();
        }

        @WorkerThread
        private void zzapr() {
            if (this.tT) {
                zzaqh();
                zzab(this.uG.rX.isGooglePlayServicesAvailable(this.uG.mContext) == 18 ? new Status(8, "Connection timed out while waiting for Google Play services update to complete.") : new Status(8, "API failed to connect while resuming due to an unknown error."));
                this.uJ.disconnect();
            }
        }

        @WorkerThread
        private void zzaqh() {
            if (this.tT) {
                this.uG.mHandler.removeMessages(9, this.rG);
                this.uG.mHandler.removeMessages(8, this.rG);
                this.tT = false;
            }
        }

        private void zzaqi() {
            this.uG.mHandler.removeMessages(10, this.rG);
            this.uG.mHandler.sendMessageDelayed(this.uG.mHandler.obtainMessage(10, this.rG), this.uG.uv);
        }

        private void zzaqj() {
            if (this.uJ.isConnected() && this.uN.size() == 0) {
                for (int i = 0; i < this.uL.size(); i++) {
                    if (((zzrd) this.uL.get(this.uL.keyAt(i))).zzaqw()) {
                        zzaqi();
                        return;
                    }
                }
                this.uJ.disconnect();
            }
        }

        @WorkerThread
        private zze zzb(com.google.android.gms.common.api.zzc com_google_android_gms_common_api_zzc) {
            Api zzanw = com_google_android_gms_common_api_zzc.zzanw();
            if (!zzanw.zzanq()) {
                return com_google_android_gms_common_api_zzc.zzanw().zzann().zza(com_google_android_gms_common_api_zzc.getApplicationContext(), this.uG.mHandler.getLooper(), zzg.zzcd(com_google_android_gms_common_api_zzc.getApplicationContext()), com_google_android_gms_common_api_zzc.zzanx(), this, this);
            }
            zzh zzano = zzanw.zzano();
            return new zzah(com_google_android_gms_common_api_zzc.getApplicationContext(), this.uG.mHandler.getLooper(), zzano.zzant(), this, this, zzg.zzcd(com_google_android_gms_common_api_zzc.getApplicationContext()), zzano.zzs(com_google_android_gms_common_api_zzc.zzanx()));
        }

        @android.support.annotation.WorkerThread
        private void zzc(com.google.android.gms.internal.zzpn r5) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r4 = this;
            r0 = r4.uL;
            r5.zza(r0);
            r0 = r5.it;
            r1 = 1;
            r2 = 3;
            if (r0 != r2) goto L_0x003b;
        L_0x000b:
            r0 = r4.uN;	 Catch:{ ClassCastException -> 0x0033 }
            r2 = r5.sn;	 Catch:{ ClassCastException -> 0x0033 }
            r0 = r0.get(r2);	 Catch:{ ClassCastException -> 0x0033 }
            r0 = (java.util.Map) r0;	 Catch:{ ClassCastException -> 0x0033 }
            if (r0 != 0) goto L_0x0023;	 Catch:{ ClassCastException -> 0x0033 }
        L_0x0017:
            r0 = new android.support.v4.util.ArrayMap;	 Catch:{ ClassCastException -> 0x0033 }
            r0.<init>(r1);	 Catch:{ ClassCastException -> 0x0033 }
            r2 = r4.uN;	 Catch:{ ClassCastException -> 0x0033 }
            r3 = r5.sn;	 Catch:{ ClassCastException -> 0x0033 }
            r2.put(r3, r0);	 Catch:{ ClassCastException -> 0x0033 }
        L_0x0023:
            r2 = r5;	 Catch:{ ClassCastException -> 0x0033 }
            r2 = (com.google.android.gms.internal.zzpn.zza) r2;	 Catch:{ ClassCastException -> 0x0033 }
            r2 = r2.so;	 Catch:{ ClassCastException -> 0x0033 }
            r3 = r2;	 Catch:{ ClassCastException -> 0x0033 }
            r3 = (com.google.android.gms.internal.zzqr) r3;	 Catch:{ ClassCastException -> 0x0033 }
            r3 = r3.zzaqq();	 Catch:{ ClassCastException -> 0x0033 }
            r0.put(r3, r2);	 Catch:{ ClassCastException -> 0x0033 }
            goto L_0x006b;
        L_0x0033:
            r5 = new java.lang.IllegalStateException;
            r0 = "Listener registration methods must implement ListenerApiMethod";
            r5.<init>(r0);
            throw r5;
        L_0x003b:
            r0 = r5.it;
            r2 = 4;
            if (r0 != r2) goto L_0x006b;
        L_0x0040:
            r0 = r4.uN;	 Catch:{ ClassCastException -> 0x0063 }
            r2 = r5.sn;	 Catch:{ ClassCastException -> 0x0063 }
            r0 = r0.get(r2);	 Catch:{ ClassCastException -> 0x0063 }
            r0 = (java.util.Map) r0;	 Catch:{ ClassCastException -> 0x0063 }
            r2 = r5;	 Catch:{ ClassCastException -> 0x0063 }
            r2 = (com.google.android.gms.internal.zzpn.zza) r2;	 Catch:{ ClassCastException -> 0x0063 }
            r2 = r2.so;	 Catch:{ ClassCastException -> 0x0063 }
            r2 = (com.google.android.gms.internal.zzqr) r2;	 Catch:{ ClassCastException -> 0x0063 }
            if (r0 == 0) goto L_0x005b;	 Catch:{ ClassCastException -> 0x0063 }
        L_0x0053:
            r2 = r2.zzaqq();	 Catch:{ ClassCastException -> 0x0063 }
            r0.remove(r2);	 Catch:{ ClassCastException -> 0x0063 }
            goto L_0x006b;	 Catch:{ ClassCastException -> 0x0063 }
        L_0x005b:
            r0 = "GoogleApiManager";	 Catch:{ ClassCastException -> 0x0063 }
            r2 = "Received call to unregister a listener without a matching registration call.";	 Catch:{ ClassCastException -> 0x0063 }
            android.util.Log.w(r0, r2);	 Catch:{ ClassCastException -> 0x0063 }
            goto L_0x006b;
        L_0x0063:
            r5 = new java.lang.IllegalStateException;
            r0 = "Listener unregistration methods must implement ListenerApiMethod";
            r5.<init>(r0);
            throw r5;
        L_0x006b:
            r0 = r4.uK;	 Catch:{ DeadObjectException -> 0x0071 }
            r5.zzb(r0);	 Catch:{ DeadObjectException -> 0x0071 }
            return;
        L_0x0071:
            r5 = r4.uJ;
            r5.disconnect();
            r4.onConnectionSuspended(r1);
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzqh.zzc.zzc(com.google.android.gms.internal.zzpn):void");
        }

        @WorkerThread
        private void zzj(ConnectionResult connectionResult) {
            for (zzpq zza : this.uM) {
                zza.zza(this.rG, connectionResult);
            }
            this.uM.clear();
        }

        boolean isConnected() {
            return this.uJ.isConnected();
        }

        @android.support.annotation.WorkerThread
        public void onConnected(@android.support.annotation.Nullable android.os.Bundle r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            r3.zzaqf();
            r4 = com.google.android.gms.common.ConnectionResult.qR;
            r3.zzj(r4);
            r3.zzaqh();
            r4 = 0;
        L_0x000c:
            r0 = r3.uN;
            r0 = r0.size();
            if (r4 >= r0) goto L_0x0049;
        L_0x0014:
            r0 = r3.uN;
            r1 = r3.uN;
            r1 = r1.keyAt(r4);
            r0 = r0.get(r1);
            r0 = (java.util.Map) r0;
            r0 = r0.values();
            r0 = r0.iterator();
        L_0x002a:
            r1 = r0.hasNext();
            if (r1 == 0) goto L_0x0046;
        L_0x0030:
            r1 = r0.next();
            r1 = (com.google.android.gms.internal.zzpr.zza) r1;
            r2 = r3.uK;	 Catch:{ DeadObjectException -> 0x003c }
            r1.zzb(r2);	 Catch:{ DeadObjectException -> 0x003c }
            goto L_0x002a;
        L_0x003c:
            r1 = r3.uJ;
            r1.disconnect();
            r1 = 1;
            r3.onConnectionSuspended(r1);
            goto L_0x002a;
        L_0x0046:
            r4 = r4 + 1;
            goto L_0x000c;
        L_0x0049:
            r3.zzaqe();
            r3.zzaqi();
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzqh.zzc.onConnected(android.os.Bundle):void");
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        @android.support.annotation.WorkerThread
        public void onConnectionFailed(@android.support.annotation.NonNull com.google.android.gms.common.ConnectionResult r6) {
            /*
            r5 = this;
            r5.zzaqf();
            r0 = r5.uG;
            r1 = -1;
            r0.ux = r1;
            r5.zzj(r6);
            r0 = r5.uL;
            r1 = 0;
            r0 = r0.keyAt(r1);
            r1 = r5.uI;
            r1 = r1.isEmpty();
            if (r1 == 0) goto L_0x001e;
        L_0x001b:
            r5.uO = r6;
            return;
        L_0x001e:
            r1 = com.google.android.gms.internal.zzqh.zzamp;
            monitor-enter(r1);
            r2 = r5.uG;	 Catch:{ all -> 0x00b0 }
            r2 = null;	 Catch:{ all -> 0x00b0 }
            if (r2 == 0) goto L_0x0044;
        L_0x002b:
            r2 = r5.uG;	 Catch:{ all -> 0x00b0 }
            r2 = r2.uC;	 Catch:{ all -> 0x00b0 }
            r3 = r5.rG;	 Catch:{ all -> 0x00b0 }
            r2 = r2.contains(r3);	 Catch:{ all -> 0x00b0 }
            if (r2 == 0) goto L_0x0044;
        L_0x0039:
            r2 = r5.uG;	 Catch:{ all -> 0x00b0 }
            r2 = null;	 Catch:{ all -> 0x00b0 }
            r2.zzb(r6, r0);	 Catch:{ all -> 0x00b0 }
            monitor-exit(r1);	 Catch:{ all -> 0x00b0 }
            return;
        L_0x0044:
            monitor-exit(r1);	 Catch:{ all -> 0x00b0 }
            r1 = r5.uG;
            r0 = r1.zzc(r6, r0);
            if (r0 != 0) goto L_0x00af;
        L_0x004d:
            r6 = r6.getErrorCode();
            r0 = 18;
            if (r6 != r0) goto L_0x0058;
        L_0x0055:
            r6 = 1;
            r5.tT = r6;
        L_0x0058:
            r6 = r5.tT;
            if (r6 == 0) goto L_0x007a;
        L_0x005c:
            r6 = r5.uG;
            r6 = r6.mHandler;
            r0 = r5.uG;
            r0 = r0.mHandler;
            r1 = 8;
            r2 = r5.rG;
            r0 = android.os.Message.obtain(r0, r1, r2);
            r1 = r5.uG;
            r1 = r1.tV;
            r6.sendMessageDelayed(r0, r1);
            return;
        L_0x007a:
            r6 = new com.google.android.gms.common.api.Status;
            r0 = 17;
            r1 = r5.rG;
            r1 = r1.zzaok();
            r1 = java.lang.String.valueOf(r1);
            r2 = new java.lang.StringBuilder;
            r3 = 38;
            r4 = java.lang.String.valueOf(r1);
            r4 = r4.length();
            r3 = r3 + r4;
            r2.<init>(r3);
            r3 = "API: ";
            r2.append(r3);
            r2.append(r1);
            r1 = " is not available on this device.";
            r2.append(r1);
            r1 = r2.toString();
            r6.<init>(r0, r1);
            r5.zzab(r6);
        L_0x00af:
            return;
        L_0x00b0:
            r6 = move-exception;
            monitor-exit(r1);	 Catch:{ all -> 0x00b0 }
            throw r6;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzqh.zzc.onConnectionFailed(com.google.android.gms.common.ConnectionResult):void");
        }

        @WorkerThread
        public void onConnectionSuspended(int i) {
            zzaqf();
            this.tT = true;
            this.uG.mHandler.sendMessageDelayed(Message.obtain(this.uG.mHandler, 8, this.rG), this.uG.tV);
            this.uG.mHandler.sendMessageDelayed(Message.obtain(this.uG.mHandler, 9, this.rG), this.uG.tU);
            this.uG.ux = -1;
        }

        @WorkerThread
        public void zzaqe() {
            while (this.uJ.isConnected() && !this.uI.isEmpty()) {
                zzc((zzpn) this.uI.remove());
            }
        }

        @WorkerThread
        public void zzaqf() {
            this.uO = null;
        }

        ConnectionResult zzaqg() {
            return this.uO;
        }

        @WorkerThread
        public void zzb(zzpn com_google_android_gms_internal_zzpn) {
            if (this.uJ.isConnected()) {
                zzc(com_google_android_gms_internal_zzpn);
                zzaqi();
                return;
            }
            this.uI.add(com_google_android_gms_internal_zzpn);
            if (this.uO == null || !this.uO.hasResolution()) {
                connect();
            } else {
                onConnectionFailed(this.uO);
            }
        }

        @WorkerThread
        public void zzb(zzpq com_google_android_gms_internal_zzpq) {
            this.uM.add(com_google_android_gms_internal_zzpq);
        }

        @WorkerThread
        public void zzf(int i, boolean z) {
            Iterator it = this.uI.iterator();
            while (it.hasNext()) {
                zzpn com_google_android_gms_internal_zzpn = (zzpn) it.next();
                if (com_google_android_gms_internal_zzpn.sn == i && com_google_android_gms_internal_zzpn.it != 1 && com_google_android_gms_internal_zzpn.cancel()) {
                    it.remove();
                }
            }
            ((zzrd) this.uL.get(i)).release();
            this.uN.delete(i);
            if (!z) {
                this.uL.remove(i);
                this.uG.uE.remove(i);
                if (this.uL.size() == 0 && this.uI.isEmpty()) {
                    zzaqh();
                    this.uJ.disconnect();
                    this.uG.uA.remove(this.rG);
                    synchronized (zzqh.zzamp) {
                        this.uG.uC.remove(this.rG);
                    }
                }
            }
        }

        @WorkerThread
        public void zzfk(int i) {
            this.uL.put(i, new zzrd(this.rG.zzanp(), this.uJ));
        }
    }

    private class zzd implements zzf {
        private final zzpo<?> rG;
        final /* synthetic */ zzqh uG;
        private final zze uJ;

        public zzd(zzqh com_google_android_gms_internal_zzqh, zze com_google_android_gms_common_api_Api_zze, zzpo<?> com_google_android_gms_internal_zzpo_) {
            this.uG = com_google_android_gms_internal_zzqh;
            this.uJ = com_google_android_gms_common_api_Api_zze;
            this.rG = com_google_android_gms_internal_zzpo_;
        }

        @WorkerThread
        public void zzh(@NonNull ConnectionResult connectionResult) {
            if (connectionResult.isSuccess()) {
                this.uJ.zza(null, Collections.emptySet());
            } else {
                ((zzc) this.uG.uA.get(this.rG)).onConnectionFailed(connectionResult);
            }
        }
    }

    private zzqh(Context context) {
        this(context, GoogleApiAvailability.getInstance());
    }

    private zzqh(Context context, GoogleApiAvailability googleApiAvailability) {
        this.tV = 5000;
        this.tU = 120000;
        this.uv = 10000;
        this.ux = -1;
        this.uy = new AtomicInteger(1);
        this.uz = new SparseArray();
        this.uA = new ConcurrentHashMap(5, 0.75f, 1);
        this.uB = null;
        this.uC = new com.google.android.gms.common.util.zza();
        this.uD = new ReferenceQueue();
        this.uE = new SparseArray();
        this.mContext = context;
        HandlerThread handlerThread = new HandlerThread("GoogleApiHandler", 9);
        handlerThread.start();
        this.mHandler = new Handler(handlerThread.getLooper(), this);
        this.rX = googleApiAvailability;
    }

    private int zza(com.google.android.gms.common.api.zzc<?> com_google_android_gms_common_api_zzc_) {
        int andIncrement = this.uy.getAndIncrement();
        this.mHandler.sendMessage(this.mHandler.obtainMessage(6, andIncrement, 0, com_google_android_gms_common_api_zzc_));
        return andIncrement;
    }

    public static Pair<zzqh, Integer> zza(Context context, com.google.android.gms.common.api.zzc<?> com_google_android_gms_common_api_zzc_) {
        Pair<zzqh, Integer> create;
        synchronized (zzamp) {
            if (uw == null) {
                uw = new zzqh(context.getApplicationContext());
            }
            create = Pair.create(uw, Integer.valueOf(uw.zza((com.google.android.gms.common.api.zzc) com_google_android_gms_common_api_zzc_)));
        }
        return create;
    }

    @WorkerThread
    private void zza(com.google.android.gms.common.api.zzc<?> com_google_android_gms_common_api_zzc_, int i) {
        zzpo zzany = com_google_android_gms_common_api_zzc_.zzany();
        if (!this.uA.containsKey(zzany)) {
            this.uA.put(zzany, new zzc(this, com_google_android_gms_common_api_zzc_));
        }
        zzc com_google_android_gms_internal_zzqh_zzc = (zzc) this.uA.get(zzany);
        com_google_android_gms_internal_zzqh_zzc.zzfk(i);
        this.uz.put(i, com_google_android_gms_internal_zzqh_zzc);
        com_google_android_gms_internal_zzqh_zzc.connect();
        this.uE.put(i, new zza(this, com_google_android_gms_common_api_zzc_, i, this.uD));
        if (this.uF == null || !this.uF.uH.get()) {
            this.uF = new zzb(this.uD, this.uE);
            this.uF.start();
        }
    }

    @WorkerThread
    private void zza(zzpn com_google_android_gms_internal_zzpn) {
        ((zzc) this.uz.get(com_google_android_gms_internal_zzpn.sn)).zzb(com_google_android_gms_internal_zzpn);
    }

    public static zzqh zzaqa() {
        zzqh com_google_android_gms_internal_zzqh;
        synchronized (zzamp) {
            com_google_android_gms_internal_zzqh = uw;
        }
        return com_google_android_gms_internal_zzqh;
    }

    @WorkerThread
    private void zzaqb() {
        for (zzc com_google_android_gms_internal_zzqh_zzc : this.uA.values()) {
            com_google_android_gms_internal_zzqh_zzc.zzaqf();
            com_google_android_gms_internal_zzqh_zzc.connect();
        }
    }

    @WorkerThread
    private void zze(int i, boolean z) {
        zzc com_google_android_gms_internal_zzqh_zzc = (zzc) this.uz.get(i);
        if (com_google_android_gms_internal_zzqh_zzc != null) {
            if (!z) {
                this.uz.delete(i);
            }
            com_google_android_gms_internal_zzqh_zzc.zzf(i, z);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder(52);
        stringBuilder.append("onRelease received for unknown instance: ");
        stringBuilder.append(i);
        Log.wtf("GoogleApiManager", stringBuilder.toString(), new Exception());
    }

    @WorkerThread
    public boolean handleMessage(Message message) {
        boolean z = false;
        switch (message.what) {
            case 1:
                zza((zzpq) message.obj);
                break;
            case 2:
            case 7:
                int i = message.arg1;
                if (message.arg2 == 1) {
                    z = true;
                }
                zze(i, z);
                return true;
            case 3:
                zzaqb();
                return true;
            case 4:
                zza((zzpn) message.obj);
                return true;
            case 5:
                if (this.uz.get(message.arg1) != null) {
                    ((zzc) this.uz.get(message.arg1)).zzab(new Status(17, "Error resolution was canceled by the user."));
                    return true;
                }
                break;
            case 6:
                zza((com.google.android.gms.common.api.zzc) message.obj, message.arg1);
                return true;
            case 8:
                if (this.uA.containsKey(message.obj)) {
                    ((zzc) this.uA.get(message.obj)).resume();
                    return true;
                }
                break;
            case 9:
                if (this.uA.containsKey(message.obj)) {
                    ((zzc) this.uA.get(message.obj)).zzapr();
                    return true;
                }
                break;
            case 10:
                if (this.uA.containsKey(message.obj)) {
                    ((zzc) this.uA.get(message.obj)).zzaqj();
                    return true;
                }
                break;
            default:
                int i2 = message.what;
                StringBuilder stringBuilder = new StringBuilder(31);
                stringBuilder.append("Unknown message id: ");
                stringBuilder.append(i2);
                Log.w("GoogleApiManager", stringBuilder.toString());
                return false;
        }
        return true;
    }

    public void zza(ConnectionResult connectionResult, int i) {
        if (!zzc(connectionResult, i)) {
            this.mHandler.sendMessage(this.mHandler.obtainMessage(5, i, 0));
        }
    }

    public <O extends ApiOptions> void zza(com.google.android.gms.common.api.zzc<O> com_google_android_gms_common_api_zzc_O, int i, com.google.android.gms.internal.zzpr.zza<? extends Result, com.google.android.gms.common.api.Api.zzb> com_google_android_gms_internal_zzpr_zza__extends_com_google_android_gms_common_api_Result__com_google_android_gms_common_api_Api_zzb) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(4, new com.google.android.gms.internal.zzpn.zza(com_google_android_gms_common_api_zzc_O.getInstanceId(), i, com_google_android_gms_internal_zzpr_zza__extends_com_google_android_gms_common_api_Result__com_google_android_gms_common_api_Api_zzb)));
    }

    public <O extends ApiOptions, TResult> void zza(com.google.android.gms.common.api.zzc<O> com_google_android_gms_common_api_zzc_O, int i, zzrb<com.google.android.gms.common.api.Api.zzb, TResult> com_google_android_gms_internal_zzrb_com_google_android_gms_common_api_Api_zzb__TResult, TaskCompletionSource<TResult> taskCompletionSource) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(4, new com.google.android.gms.internal.zzpn.zzb(com_google_android_gms_common_api_zzc_O.getInstanceId(), i, com_google_android_gms_internal_zzrb_com_google_android_gms_common_api_Api_zzb__TResult, taskCompletionSource)));
    }

    @WorkerThread
    public void zza(zzpq com_google_android_gms_internal_zzpq) {
        for (zzpo com_google_android_gms_internal_zzpo : com_google_android_gms_internal_zzpq.zzaon()) {
            zzc com_google_android_gms_internal_zzqh_zzc = (zzc) this.uA.get(com_google_android_gms_internal_zzpo);
            if (com_google_android_gms_internal_zzqh_zzc == null) {
                com_google_android_gms_internal_zzpq.cancel();
                return;
            }
            ConnectionResult connectionResult;
            if (com_google_android_gms_internal_zzqh_zzc.isConnected()) {
                connectionResult = ConnectionResult.qR;
            } else if (com_google_android_gms_internal_zzqh_zzc.zzaqg() != null) {
                connectionResult = com_google_android_gms_internal_zzqh_zzc.zzaqg();
            } else {
                com_google_android_gms_internal_zzqh_zzc.zzb(com_google_android_gms_internal_zzpq);
            }
            com_google_android_gms_internal_zzpq.zza(com_google_android_gms_internal_zzpo, connectionResult);
        }
    }

    public void zza(zzpw com_google_android_gms_internal_zzpw) {
        synchronized (zzamp) {
            if (com_google_android_gms_internal_zzpw == null) {
                this.uB = null;
                this.uC.clear();
            }
        }
    }

    public void zzaol() {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3));
    }

    boolean zzc(ConnectionResult connectionResult, int i) {
        if (!connectionResult.hasResolution()) {
            if (!this.rX.isUserResolvableError(connectionResult.getErrorCode())) {
                return false;
            }
        }
        this.rX.zza(this.mContext, connectionResult, i);
        return true;
    }

    public void zzd(int i, boolean z) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(7, i, z ? 1 : 2));
    }
}
