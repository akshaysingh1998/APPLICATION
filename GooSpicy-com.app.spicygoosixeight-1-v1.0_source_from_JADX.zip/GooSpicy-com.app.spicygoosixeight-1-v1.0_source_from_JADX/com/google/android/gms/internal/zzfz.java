package com.google.android.gms.internal;

import java.util.AbstractMap.SimpleEntry;
import java.util.HashSet;
import java.util.Iterator;
import org.json.JSONObject;

@zzir
public class zzfz implements zzfy {
    private final zzfx zzbmw;
    private final HashSet<SimpleEntry<String, zzet>> zzbmx = new HashSet();

    public zzfz(zzfx com_google_android_gms_internal_zzfx) {
        this.zzbmw = com_google_android_gms_internal_zzfx;
    }

    public void zza(String str, zzet com_google_android_gms_internal_zzet) {
        this.zzbmw.zza(str, com_google_android_gms_internal_zzet);
        this.zzbmx.add(new SimpleEntry(str, com_google_android_gms_internal_zzet));
    }

    public void zza(String str, JSONObject jSONObject) {
        this.zzbmw.zza(str, jSONObject);
    }

    public void zzb(String str, zzet com_google_android_gms_internal_zzet) {
        this.zzbmw.zzb(str, com_google_android_gms_internal_zzet);
        this.zzbmx.remove(new SimpleEntry(str, com_google_android_gms_internal_zzet));
    }

    public void zzb(String str, JSONObject jSONObject) {
        this.zzbmw.zzb(str, jSONObject);
    }

    public void zzj(String str, String str2) {
        this.zzbmw.zzj(str, str2);
    }

    public void zzmh() {
        Iterator it = this.zzbmx.iterator();
        while (it.hasNext()) {
            SimpleEntry simpleEntry = (SimpleEntry) it.next();
            String str = "Unregistering eventhandler: ";
            String valueOf = String.valueOf(((zzet) simpleEntry.getValue()).toString());
            zzkh.m83v(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            this.zzbmw.zzb((String) simpleEntry.getKey(), (zzet) simpleEntry.getValue());
        }
        this.zzbmx.clear();
    }
}
