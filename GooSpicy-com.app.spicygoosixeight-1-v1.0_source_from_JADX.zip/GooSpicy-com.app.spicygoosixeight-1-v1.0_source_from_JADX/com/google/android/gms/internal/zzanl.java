package com.google.android.gms.internal;

public interface zzanl {
    <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T);
}
