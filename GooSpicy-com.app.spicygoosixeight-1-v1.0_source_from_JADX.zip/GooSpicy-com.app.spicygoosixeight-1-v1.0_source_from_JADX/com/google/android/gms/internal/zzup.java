package com.google.android.gms.internal;

import android.support.v4.media.TransportMediator;
import java.io.IOException;

public interface zzup {

    public static final class zza extends zzapc {
        private static volatile zza[] aoF;
        public Integer anW;
        public zzf aoG;
        public zzf aoH;
        public Boolean aoI;

        public zza() {
            zzbwp();
        }

        public static zza[] zzbwo() {
            if (aoF == null) {
                synchronized (zzapa.bij) {
                    if (aoF == null) {
                        aoF = new zza[0];
                    }
                }
            }
            return aoF;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zza)) {
                return false;
            }
            zza com_google_android_gms_internal_zzup_zza = (zza) obj;
            if (this.anW == null) {
                if (com_google_android_gms_internal_zzup_zza.anW != null) {
                    return false;
                }
            } else if (!this.anW.equals(com_google_android_gms_internal_zzup_zza.anW)) {
                return false;
            }
            if (this.aoG == null) {
                if (com_google_android_gms_internal_zzup_zza.aoG != null) {
                    return false;
                }
            } else if (!this.aoG.equals(com_google_android_gms_internal_zzup_zza.aoG)) {
                return false;
            }
            if (this.aoH == null) {
                if (com_google_android_gms_internal_zzup_zza.aoH != null) {
                    return false;
                }
            } else if (!this.aoH.equals(com_google_android_gms_internal_zzup_zza.aoH)) {
                return false;
            }
            if (this.aoI == null) {
                if (com_google_android_gms_internal_zzup_zza.aoI != null) {
                    return false;
                }
            } else if (!this.aoI.equals(com_google_android_gms_internal_zzup_zza.aoI)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((527 + getClass().getName().hashCode()) * 31) + (this.anW == null ? 0 : this.anW.hashCode())) * 31) + (this.aoG == null ? 0 : this.aoG.hashCode())) * 31) + (this.aoH == null ? 0 : this.aoH.hashCode()));
            if (this.aoI != null) {
                i = this.aoI.hashCode();
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.anW != null) {
                com_google_android_gms_internal_zzaov.zzae(1, this.anW.intValue());
            }
            if (this.aoG != null) {
                com_google_android_gms_internal_zzaov.zza(2, this.aoG);
            }
            if (this.aoH != null) {
                com_google_android_gms_internal_zzaov.zza(3, this.aoH);
            }
            if (this.aoI != null) {
                com_google_android_gms_internal_zzaov.zzj(4, this.aoI.booleanValue());
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbm(com_google_android_gms_internal_zzaou);
        }

        public zza zzbm(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J != 8) {
                    zzapc com_google_android_gms_internal_zzapc;
                    if (J == 18) {
                        if (this.aoG == null) {
                            this.aoG = new zzf();
                        }
                        com_google_android_gms_internal_zzapc = this.aoG;
                    } else if (J == 26) {
                        if (this.aoH == null) {
                            this.aoH = new zzf();
                        }
                        com_google_android_gms_internal_zzapc = this.aoH;
                    } else if (J == 32) {
                        this.aoI = Boolean.valueOf(com_google_android_gms_internal_zzaou.m45P());
                    } else if (!zzapf.zzb(com_google_android_gms_internal_zzaou, J)) {
                        return this;
                    }
                    com_google_android_gms_internal_zzaou.zza(com_google_android_gms_internal_zzapc);
                } else {
                    this.anW = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                }
            }
        }

        public zza zzbwp() {
            this.anW = null;
            this.aoG = null;
            this.aoH = null;
            this.aoI = null;
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (this.anW != null) {
                zzy += zzaov.zzag(1, this.anW.intValue());
            }
            if (this.aoG != null) {
                zzy += zzaov.zzc(2, this.aoG);
            }
            if (this.aoH != null) {
                zzy += zzaov.zzc(3, this.aoH);
            }
            return this.aoI != null ? zzy + zzaov.zzk(4, this.aoI.booleanValue()) : zzy;
        }
    }

    public static final class zzb extends zzapc {
        private static volatile zzb[] aoJ;
        public zzc[] aoK;
        public Long aoL;
        public Long aoM;
        public Integer count;
        public String name;

        public zzb() {
            zzbwr();
        }

        public static zzb[] zzbwq() {
            if (aoJ == null) {
                synchronized (zzapa.bij) {
                    if (aoJ == null) {
                        aoJ = new zzb[0];
                    }
                }
            }
            return aoJ;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzb)) {
                return false;
            }
            zzb com_google_android_gms_internal_zzup_zzb = (zzb) obj;
            if (!zzapa.equals(this.aoK, com_google_android_gms_internal_zzup_zzb.aoK)) {
                return false;
            }
            if (this.name == null) {
                if (com_google_android_gms_internal_zzup_zzb.name != null) {
                    return false;
                }
            } else if (!this.name.equals(com_google_android_gms_internal_zzup_zzb.name)) {
                return false;
            }
            if (this.aoL == null) {
                if (com_google_android_gms_internal_zzup_zzb.aoL != null) {
                    return false;
                }
            } else if (!this.aoL.equals(com_google_android_gms_internal_zzup_zzb.aoL)) {
                return false;
            }
            if (this.aoM == null) {
                if (com_google_android_gms_internal_zzup_zzb.aoM != null) {
                    return false;
                }
            } else if (!this.aoM.equals(com_google_android_gms_internal_zzup_zzb.aoM)) {
                return false;
            }
            if (this.count == null) {
                if (com_google_android_gms_internal_zzup_zzb.count != null) {
                    return false;
                }
            } else if (!this.count.equals(com_google_android_gms_internal_zzup_zzb.count)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((((527 + getClass().getName().hashCode()) * 31) + zzapa.hashCode(this.aoK)) * 31) + (this.name == null ? 0 : this.name.hashCode())) * 31) + (this.aoL == null ? 0 : this.aoL.hashCode())) * 31) + (this.aoM == null ? 0 : this.aoM.hashCode()));
            if (this.count != null) {
                i = this.count.hashCode();
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.aoK != null && this.aoK.length > 0) {
                for (zzapc com_google_android_gms_internal_zzapc : this.aoK) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        com_google_android_gms_internal_zzaov.zza(1, com_google_android_gms_internal_zzapc);
                    }
                }
            }
            if (this.name != null) {
                com_google_android_gms_internal_zzaov.zzr(2, this.name);
            }
            if (this.aoL != null) {
                com_google_android_gms_internal_zzaov.zzb(3, this.aoL.longValue());
            }
            if (this.aoM != null) {
                com_google_android_gms_internal_zzaov.zzb(4, this.aoM.longValue());
            }
            if (this.count != null) {
                com_google_android_gms_internal_zzaov.zzae(5, this.count.intValue());
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbn(com_google_android_gms_internal_zzaou);
        }

        public zzb zzbn(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J == 10) {
                    J = zzapf.zzc(com_google_android_gms_internal_zzaou, 10);
                    int length = this.aoK == null ? 0 : this.aoK.length;
                    Object obj = new zzc[(J + length)];
                    if (length != 0) {
                        System.arraycopy(this.aoK, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = new zzc();
                        com_google_android_gms_internal_zzaou.zza(obj[length]);
                        com_google_android_gms_internal_zzaou.m39J();
                        length++;
                    }
                    obj[length] = new zzc();
                    com_google_android_gms_internal_zzaou.zza(obj[length]);
                    this.aoK = obj;
                } else if (J == 18) {
                    this.name = com_google_android_gms_internal_zzaou.readString();
                } else if (J == 24) {
                    this.aoL = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                } else if (J == 32) {
                    this.aoM = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                } else if (J == 40) {
                    this.count = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                } else if (!zzapf.zzb(com_google_android_gms_internal_zzaou, J)) {
                    return this;
                }
            }
        }

        public zzb zzbwr() {
            this.aoK = zzc.zzbws();
            this.name = null;
            this.aoL = null;
            this.aoM = null;
            this.count = null;
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (this.aoK != null && this.aoK.length > 0) {
                for (zzapc com_google_android_gms_internal_zzapc : this.aoK) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        zzy += zzaov.zzc(1, com_google_android_gms_internal_zzapc);
                    }
                }
            }
            if (this.name != null) {
                zzy += zzaov.zzs(2, this.name);
            }
            if (this.aoL != null) {
                zzy += zzaov.zze(3, this.aoL.longValue());
            }
            if (this.aoM != null) {
                zzy += zzaov.zze(4, this.aoM.longValue());
            }
            return this.count != null ? zzy + zzaov.zzag(5, this.count.intValue()) : zzy;
        }
    }

    public static final class zzc extends zzapc {
        private static volatile zzc[] aoN;
        public Float anS;
        public Double anT;
        public Long aoO;
        public String name;
        public String zr;

        public zzc() {
            zzbwt();
        }

        public static zzc[] zzbws() {
            if (aoN == null) {
                synchronized (zzapa.bij) {
                    if (aoN == null) {
                        aoN = new zzc[0];
                    }
                }
            }
            return aoN;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzc)) {
                return false;
            }
            zzc com_google_android_gms_internal_zzup_zzc = (zzc) obj;
            if (this.name == null) {
                if (com_google_android_gms_internal_zzup_zzc.name != null) {
                    return false;
                }
            } else if (!this.name.equals(com_google_android_gms_internal_zzup_zzc.name)) {
                return false;
            }
            if (this.zr == null) {
                if (com_google_android_gms_internal_zzup_zzc.zr != null) {
                    return false;
                }
            } else if (!this.zr.equals(com_google_android_gms_internal_zzup_zzc.zr)) {
                return false;
            }
            if (this.aoO == null) {
                if (com_google_android_gms_internal_zzup_zzc.aoO != null) {
                    return false;
                }
            } else if (!this.aoO.equals(com_google_android_gms_internal_zzup_zzc.aoO)) {
                return false;
            }
            if (this.anS == null) {
                if (com_google_android_gms_internal_zzup_zzc.anS != null) {
                    return false;
                }
            } else if (!this.anS.equals(com_google_android_gms_internal_zzup_zzc.anS)) {
                return false;
            }
            if (this.anT == null) {
                if (com_google_android_gms_internal_zzup_zzc.anT != null) {
                    return false;
                }
            } else if (!this.anT.equals(com_google_android_gms_internal_zzup_zzc.anT)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((((527 + getClass().getName().hashCode()) * 31) + (this.name == null ? 0 : this.name.hashCode())) * 31) + (this.zr == null ? 0 : this.zr.hashCode())) * 31) + (this.aoO == null ? 0 : this.aoO.hashCode())) * 31) + (this.anS == null ? 0 : this.anS.hashCode()));
            if (this.anT != null) {
                i = this.anT.hashCode();
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.name != null) {
                com_google_android_gms_internal_zzaov.zzr(1, this.name);
            }
            if (this.zr != null) {
                com_google_android_gms_internal_zzaov.zzr(2, this.zr);
            }
            if (this.aoO != null) {
                com_google_android_gms_internal_zzaov.zzb(3, this.aoO.longValue());
            }
            if (this.anS != null) {
                com_google_android_gms_internal_zzaov.zzc(4, this.anS.floatValue());
            }
            if (this.anT != null) {
                com_google_android_gms_internal_zzaov.zza(5, this.anT.doubleValue());
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbo(com_google_android_gms_internal_zzaou);
        }

        public zzc zzbo(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J == 10) {
                    this.name = com_google_android_gms_internal_zzaou.readString();
                } else if (J == 18) {
                    this.zr = com_google_android_gms_internal_zzaou.readString();
                } else if (J == 24) {
                    this.aoO = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                } else if (J == 37) {
                    this.anS = Float.valueOf(com_google_android_gms_internal_zzaou.readFloat());
                } else if (J == 41) {
                    this.anT = Double.valueOf(com_google_android_gms_internal_zzaou.readDouble());
                } else if (!zzapf.zzb(com_google_android_gms_internal_zzaou, J)) {
                    return this;
                }
            }
        }

        public zzc zzbwt() {
            this.name = null;
            this.zr = null;
            this.aoO = null;
            this.anS = null;
            this.anT = null;
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (this.name != null) {
                zzy += zzaov.zzs(1, this.name);
            }
            if (this.zr != null) {
                zzy += zzaov.zzs(2, this.zr);
            }
            if (this.aoO != null) {
                zzy += zzaov.zze(3, this.aoO.longValue());
            }
            if (this.anS != null) {
                zzy += zzaov.zzd(4, this.anS.floatValue());
            }
            return this.anT != null ? zzy + zzaov.zzb(5, this.anT.doubleValue()) : zzy;
        }
    }

    public static final class zzd extends zzapc {
        public zze[] aoP;

        public zzd() {
            zzbwu();
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzd)) {
                return false;
            }
            return zzapa.equals(this.aoP, ((zzd) obj).aoP);
        }

        public int hashCode() {
            return (31 * (527 + getClass().getName().hashCode())) + zzapa.hashCode(this.aoP);
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.aoP != null && this.aoP.length > 0) {
                for (zzapc com_google_android_gms_internal_zzapc : this.aoP) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        com_google_android_gms_internal_zzaov.zza(1, com_google_android_gms_internal_zzapc);
                    }
                }
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbp(com_google_android_gms_internal_zzaou);
        }

        public zzd zzbp(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J == 10) {
                    J = zzapf.zzc(com_google_android_gms_internal_zzaou, 10);
                    int length = this.aoP == null ? 0 : this.aoP.length;
                    Object obj = new zze[(J + length)];
                    if (length != 0) {
                        System.arraycopy(this.aoP, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = new zze();
                        com_google_android_gms_internal_zzaou.zza(obj[length]);
                        com_google_android_gms_internal_zzaou.m39J();
                        length++;
                    }
                    obj[length] = new zze();
                    com_google_android_gms_internal_zzaou.zza(obj[length]);
                    this.aoP = obj;
                } else if (!zzapf.zzb(com_google_android_gms_internal_zzaou, J)) {
                    return this;
                }
            }
        }

        public zzd zzbwu() {
            this.aoP = zze.zzbwv();
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (this.aoP != null && this.aoP.length > 0) {
                for (zzapc com_google_android_gms_internal_zzapc : this.aoP) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        zzy += zzaov.zzc(1, com_google_android_gms_internal_zzapc);
                    }
                }
            }
            return zzy;
        }
    }

    public static final class zze extends zzapc {
        private static volatile zze[] aoQ;
        public String abU;
        public String ajA;
        public String ajD;
        public String ajH;
        public String ajz;
        public Integer aoR;
        public zzb[] aoS;
        public zzg[] aoT;
        public Long aoU;
        public Long aoV;
        public Long aoW;
        public Long aoX;
        public Long aoY;
        public String aoZ;
        public String apa;
        public String apb;
        public Integer apc;
        public Long apd;
        public Long ape;
        public String apf;
        public Boolean apg;
        public String aph;
        public Long api;
        public Integer apj;
        public Boolean apk;
        public zza[] apl;
        public Integer apm;
        public Integer apn;
        public Integer apo;
        public String app;
        public String zzck;
        public String zzct;

        public zze() {
            zzbww();
        }

        public static zze[] zzbwv() {
            if (aoQ == null) {
                synchronized (zzapa.bij) {
                    if (aoQ == null) {
                        aoQ = new zze[0];
                    }
                }
            }
            return aoQ;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zze)) {
                return false;
            }
            zze com_google_android_gms_internal_zzup_zze = (zze) obj;
            if (this.aoR == null) {
                if (com_google_android_gms_internal_zzup_zze.aoR != null) {
                    return false;
                }
            } else if (!this.aoR.equals(com_google_android_gms_internal_zzup_zze.aoR)) {
                return false;
            }
            if (!zzapa.equals(this.aoS, com_google_android_gms_internal_zzup_zze.aoS) || !zzapa.equals(this.aoT, com_google_android_gms_internal_zzup_zze.aoT)) {
                return false;
            }
            if (this.aoU == null) {
                if (com_google_android_gms_internal_zzup_zze.aoU != null) {
                    return false;
                }
            } else if (!this.aoU.equals(com_google_android_gms_internal_zzup_zze.aoU)) {
                return false;
            }
            if (this.aoV == null) {
                if (com_google_android_gms_internal_zzup_zze.aoV != null) {
                    return false;
                }
            } else if (!this.aoV.equals(com_google_android_gms_internal_zzup_zze.aoV)) {
                return false;
            }
            if (this.aoW == null) {
                if (com_google_android_gms_internal_zzup_zze.aoW != null) {
                    return false;
                }
            } else if (!this.aoW.equals(com_google_android_gms_internal_zzup_zze.aoW)) {
                return false;
            }
            if (this.aoX == null) {
                if (com_google_android_gms_internal_zzup_zze.aoX != null) {
                    return false;
                }
            } else if (!this.aoX.equals(com_google_android_gms_internal_zzup_zze.aoX)) {
                return false;
            }
            if (this.aoY == null) {
                if (com_google_android_gms_internal_zzup_zze.aoY != null) {
                    return false;
                }
            } else if (!this.aoY.equals(com_google_android_gms_internal_zzup_zze.aoY)) {
                return false;
            }
            if (this.aoZ == null) {
                if (com_google_android_gms_internal_zzup_zze.aoZ != null) {
                    return false;
                }
            } else if (!this.aoZ.equals(com_google_android_gms_internal_zzup_zze.aoZ)) {
                return false;
            }
            if (this.zzct == null) {
                if (com_google_android_gms_internal_zzup_zze.zzct != null) {
                    return false;
                }
            } else if (!this.zzct.equals(com_google_android_gms_internal_zzup_zze.zzct)) {
                return false;
            }
            if (this.apa == null) {
                if (com_google_android_gms_internal_zzup_zze.apa != null) {
                    return false;
                }
            } else if (!this.apa.equals(com_google_android_gms_internal_zzup_zze.apa)) {
                return false;
            }
            if (this.apb == null) {
                if (com_google_android_gms_internal_zzup_zze.apb != null) {
                    return false;
                }
            } else if (!this.apb.equals(com_google_android_gms_internal_zzup_zze.apb)) {
                return false;
            }
            if (this.apc == null) {
                if (com_google_android_gms_internal_zzup_zze.apc != null) {
                    return false;
                }
            } else if (!this.apc.equals(com_google_android_gms_internal_zzup_zze.apc)) {
                return false;
            }
            if (this.ajA == null) {
                if (com_google_android_gms_internal_zzup_zze.ajA != null) {
                    return false;
                }
            } else if (!this.ajA.equals(com_google_android_gms_internal_zzup_zze.ajA)) {
                return false;
            }
            if (this.zzck == null) {
                if (com_google_android_gms_internal_zzup_zze.zzck != null) {
                    return false;
                }
            } else if (!this.zzck.equals(com_google_android_gms_internal_zzup_zze.zzck)) {
                return false;
            }
            if (this.abU == null) {
                if (com_google_android_gms_internal_zzup_zze.abU != null) {
                    return false;
                }
            } else if (!this.abU.equals(com_google_android_gms_internal_zzup_zze.abU)) {
                return false;
            }
            if (this.apd == null) {
                if (com_google_android_gms_internal_zzup_zze.apd != null) {
                    return false;
                }
            } else if (!this.apd.equals(com_google_android_gms_internal_zzup_zze.apd)) {
                return false;
            }
            if (this.ape == null) {
                if (com_google_android_gms_internal_zzup_zze.ape != null) {
                    return false;
                }
            } else if (!this.ape.equals(com_google_android_gms_internal_zzup_zze.ape)) {
                return false;
            }
            if (this.apf == null) {
                if (com_google_android_gms_internal_zzup_zze.apf != null) {
                    return false;
                }
            } else if (!this.apf.equals(com_google_android_gms_internal_zzup_zze.apf)) {
                return false;
            }
            if (this.apg == null) {
                if (com_google_android_gms_internal_zzup_zze.apg != null) {
                    return false;
                }
            } else if (!this.apg.equals(com_google_android_gms_internal_zzup_zze.apg)) {
                return false;
            }
            if (this.aph == null) {
                if (com_google_android_gms_internal_zzup_zze.aph != null) {
                    return false;
                }
            } else if (!this.aph.equals(com_google_android_gms_internal_zzup_zze.aph)) {
                return false;
            }
            if (this.api == null) {
                if (com_google_android_gms_internal_zzup_zze.api != null) {
                    return false;
                }
            } else if (!this.api.equals(com_google_android_gms_internal_zzup_zze.api)) {
                return false;
            }
            if (this.apj == null) {
                if (com_google_android_gms_internal_zzup_zze.apj != null) {
                    return false;
                }
            } else if (!this.apj.equals(com_google_android_gms_internal_zzup_zze.apj)) {
                return false;
            }
            if (this.ajD == null) {
                if (com_google_android_gms_internal_zzup_zze.ajD != null) {
                    return false;
                }
            } else if (!this.ajD.equals(com_google_android_gms_internal_zzup_zze.ajD)) {
                return false;
            }
            if (this.ajz == null) {
                if (com_google_android_gms_internal_zzup_zze.ajz != null) {
                    return false;
                }
            } else if (!this.ajz.equals(com_google_android_gms_internal_zzup_zze.ajz)) {
                return false;
            }
            if (this.apk == null) {
                if (com_google_android_gms_internal_zzup_zze.apk != null) {
                    return false;
                }
            } else if (!this.apk.equals(com_google_android_gms_internal_zzup_zze.apk)) {
                return false;
            }
            if (!zzapa.equals(this.apl, com_google_android_gms_internal_zzup_zze.apl)) {
                return false;
            }
            if (this.ajH == null) {
                if (com_google_android_gms_internal_zzup_zze.ajH != null) {
                    return false;
                }
            } else if (!this.ajH.equals(com_google_android_gms_internal_zzup_zze.ajH)) {
                return false;
            }
            if (this.apm == null) {
                if (com_google_android_gms_internal_zzup_zze.apm != null) {
                    return false;
                }
            } else if (!this.apm.equals(com_google_android_gms_internal_zzup_zze.apm)) {
                return false;
            }
            if (this.apn == null) {
                if (com_google_android_gms_internal_zzup_zze.apn != null) {
                    return false;
                }
            } else if (!this.apn.equals(com_google_android_gms_internal_zzup_zze.apn)) {
                return false;
            }
            if (this.apo == null) {
                if (com_google_android_gms_internal_zzup_zze.apo != null) {
                    return false;
                }
            } else if (!this.apo.equals(com_google_android_gms_internal_zzup_zze.apo)) {
                return false;
            }
            if (this.app == null) {
                if (com_google_android_gms_internal_zzup_zze.app != null) {
                    return false;
                }
            } else if (!this.app.equals(com_google_android_gms_internal_zzup_zze.app)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((527 + getClass().getName().hashCode()) * 31) + (this.aoR == null ? 0 : this.aoR.hashCode())) * 31) + zzapa.hashCode(this.aoS)) * 31) + zzapa.hashCode(this.aoT)) * 31) + (this.aoU == null ? 0 : this.aoU.hashCode())) * 31) + (this.aoV == null ? 0 : this.aoV.hashCode())) * 31) + (this.aoW == null ? 0 : this.aoW.hashCode())) * 31) + (this.aoX == null ? 0 : this.aoX.hashCode())) * 31) + (this.aoY == null ? 0 : this.aoY.hashCode())) * 31) + (this.aoZ == null ? 0 : this.aoZ.hashCode())) * 31) + (this.zzct == null ? 0 : this.zzct.hashCode())) * 31) + (this.apa == null ? 0 : this.apa.hashCode())) * 31) + (this.apb == null ? 0 : this.apb.hashCode())) * 31) + (this.apc == null ? 0 : this.apc.hashCode())) * 31) + (this.ajA == null ? 0 : this.ajA.hashCode())) * 31) + (this.zzck == null ? 0 : this.zzck.hashCode())) * 31) + (this.abU == null ? 0 : this.abU.hashCode())) * 31) + (this.apd == null ? 0 : this.apd.hashCode())) * 31) + (this.ape == null ? 0 : this.ape.hashCode())) * 31) + (this.apf == null ? 0 : this.apf.hashCode())) * 31) + (this.apg == null ? 0 : this.apg.hashCode())) * 31) + (this.aph == null ? 0 : this.aph.hashCode())) * 31) + (this.api == null ? 0 : this.api.hashCode())) * 31) + (this.apj == null ? 0 : this.apj.hashCode())) * 31) + (this.ajD == null ? 0 : this.ajD.hashCode())) * 31) + (this.ajz == null ? 0 : this.ajz.hashCode())) * 31) + (this.apk == null ? 0 : this.apk.hashCode())) * 31) + zzapa.hashCode(this.apl)) * 31) + (this.ajH == null ? 0 : this.ajH.hashCode())) * 31) + (this.apm == null ? 0 : this.apm.hashCode())) * 31) + (this.apn == null ? 0 : this.apn.hashCode())) * 31) + (this.apo == null ? 0 : this.apo.hashCode()));
            if (this.app != null) {
                i = this.app.hashCode();
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.aoR != null) {
                com_google_android_gms_internal_zzaov.zzae(1, this.aoR.intValue());
            }
            int i = 0;
            if (this.aoS != null && this.aoS.length > 0) {
                for (zzapc com_google_android_gms_internal_zzapc : this.aoS) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        com_google_android_gms_internal_zzaov.zza(2, com_google_android_gms_internal_zzapc);
                    }
                }
            }
            if (this.aoT != null && this.aoT.length > 0) {
                for (zzapc com_google_android_gms_internal_zzapc2 : this.aoT) {
                    if (com_google_android_gms_internal_zzapc2 != null) {
                        com_google_android_gms_internal_zzaov.zza(3, com_google_android_gms_internal_zzapc2);
                    }
                }
            }
            if (this.aoU != null) {
                com_google_android_gms_internal_zzaov.zzb(4, this.aoU.longValue());
            }
            if (this.aoV != null) {
                com_google_android_gms_internal_zzaov.zzb(5, this.aoV.longValue());
            }
            if (this.aoW != null) {
                com_google_android_gms_internal_zzaov.zzb(6, this.aoW.longValue());
            }
            if (this.aoY != null) {
                com_google_android_gms_internal_zzaov.zzb(7, this.aoY.longValue());
            }
            if (this.aoZ != null) {
                com_google_android_gms_internal_zzaov.zzr(8, this.aoZ);
            }
            if (this.zzct != null) {
                com_google_android_gms_internal_zzaov.zzr(9, this.zzct);
            }
            if (this.apa != null) {
                com_google_android_gms_internal_zzaov.zzr(10, this.apa);
            }
            if (this.apb != null) {
                com_google_android_gms_internal_zzaov.zzr(11, this.apb);
            }
            if (this.apc != null) {
                com_google_android_gms_internal_zzaov.zzae(12, this.apc.intValue());
            }
            if (this.ajA != null) {
                com_google_android_gms_internal_zzaov.zzr(13, this.ajA);
            }
            if (this.zzck != null) {
                com_google_android_gms_internal_zzaov.zzr(14, this.zzck);
            }
            if (this.abU != null) {
                com_google_android_gms_internal_zzaov.zzr(16, this.abU);
            }
            if (this.apd != null) {
                com_google_android_gms_internal_zzaov.zzb(17, this.apd.longValue());
            }
            if (this.ape != null) {
                com_google_android_gms_internal_zzaov.zzb(18, this.ape.longValue());
            }
            if (this.apf != null) {
                com_google_android_gms_internal_zzaov.zzr(19, this.apf);
            }
            if (this.apg != null) {
                com_google_android_gms_internal_zzaov.zzj(20, this.apg.booleanValue());
            }
            if (this.aph != null) {
                com_google_android_gms_internal_zzaov.zzr(21, this.aph);
            }
            if (this.api != null) {
                com_google_android_gms_internal_zzaov.zzb(22, this.api.longValue());
            }
            if (this.apj != null) {
                com_google_android_gms_internal_zzaov.zzae(23, this.apj.intValue());
            }
            if (this.ajD != null) {
                com_google_android_gms_internal_zzaov.zzr(24, this.ajD);
            }
            if (this.ajz != null) {
                com_google_android_gms_internal_zzaov.zzr(25, this.ajz);
            }
            if (this.aoX != null) {
                com_google_android_gms_internal_zzaov.zzb(26, this.aoX.longValue());
            }
            if (this.apk != null) {
                com_google_android_gms_internal_zzaov.zzj(28, this.apk.booleanValue());
            }
            if (this.apl != null && this.apl.length > 0) {
                while (i < this.apl.length) {
                    zzapc com_google_android_gms_internal_zzapc3 = this.apl[i];
                    if (com_google_android_gms_internal_zzapc3 != null) {
                        com_google_android_gms_internal_zzaov.zza(29, com_google_android_gms_internal_zzapc3);
                    }
                    i++;
                }
            }
            if (this.ajH != null) {
                com_google_android_gms_internal_zzaov.zzr(30, this.ajH);
            }
            if (this.apm != null) {
                com_google_android_gms_internal_zzaov.zzae(31, this.apm.intValue());
            }
            if (this.apn != null) {
                com_google_android_gms_internal_zzaov.zzae(32, this.apn.intValue());
            }
            if (this.apo != null) {
                com_google_android_gms_internal_zzaov.zzae(33, this.apo.intValue());
            }
            if (this.app != null) {
                com_google_android_gms_internal_zzaov.zzr(34, this.app);
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbq(com_google_android_gms_internal_zzaou);
        }

        public zze zzbq(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                int length;
                Object obj;
                switch (J) {
                    case 0:
                        return this;
                    case 8:
                        this.aoR = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                        break;
                    case 18:
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 18);
                        length = this.aoS == null ? 0 : this.aoS.length;
                        obj = new zzb[(J + length)];
                        if (length != 0) {
                            System.arraycopy(this.aoS, 0, obj, 0, length);
                        }
                        while (length < obj.length - 1) {
                            obj[length] = new zzb();
                            com_google_android_gms_internal_zzaou.zza(obj[length]);
                            com_google_android_gms_internal_zzaou.m39J();
                            length++;
                        }
                        obj[length] = new zzb();
                        com_google_android_gms_internal_zzaou.zza(obj[length]);
                        this.aoS = obj;
                        break;
                    case 26:
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 26);
                        length = this.aoT == null ? 0 : this.aoT.length;
                        obj = new zzg[(J + length)];
                        if (length != 0) {
                            System.arraycopy(this.aoT, 0, obj, 0, length);
                        }
                        while (length < obj.length - 1) {
                            obj[length] = new zzg();
                            com_google_android_gms_internal_zzaou.zza(obj[length]);
                            com_google_android_gms_internal_zzaou.m39J();
                            length++;
                        }
                        obj[length] = new zzg();
                        com_google_android_gms_internal_zzaou.zza(obj[length]);
                        this.aoT = obj;
                        break;
                    case 32:
                        this.aoU = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 40:
                        this.aoV = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 48:
                        this.aoW = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 56:
                        this.aoY = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 66:
                        this.aoZ = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 74:
                        this.zzct = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 82:
                        this.apa = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 90:
                        this.apb = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 96:
                        this.apc = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                        break;
                    case 106:
                        this.ajA = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 114:
                        this.zzck = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case TransportMediator.KEYCODE_MEDIA_RECORD /*130*/:
                        this.abU = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 136:
                        this.apd = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 144:
                        this.ape = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 154:
                        this.apf = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 160:
                        this.apg = Boolean.valueOf(com_google_android_gms_internal_zzaou.m45P());
                        break;
                    case 170:
                        this.aph = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 176:
                        this.api = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 184:
                        this.apj = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                        break;
                    case 194:
                        this.ajD = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 202:
                        this.ajz = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 208:
                        this.aoX = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                        break;
                    case 224:
                        this.apk = Boolean.valueOf(com_google_android_gms_internal_zzaou.m45P());
                        break;
                    case 234:
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 234);
                        length = this.apl == null ? 0 : this.apl.length;
                        obj = new zza[(J + length)];
                        if (length != 0) {
                            System.arraycopy(this.apl, 0, obj, 0, length);
                        }
                        while (length < obj.length - 1) {
                            obj[length] = new zza();
                            com_google_android_gms_internal_zzaou.zza(obj[length]);
                            com_google_android_gms_internal_zzaou.m39J();
                            length++;
                        }
                        obj[length] = new zza();
                        com_google_android_gms_internal_zzaou.zza(obj[length]);
                        this.apl = obj;
                        break;
                    case 242:
                        this.ajH = com_google_android_gms_internal_zzaou.readString();
                        break;
                    case 248:
                        this.apm = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                        break;
                    case 256:
                        this.apn = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                        break;
                    case 264:
                        this.apo = Integer.valueOf(com_google_android_gms_internal_zzaou.m43N());
                        break;
                    case 274:
                        this.app = com_google_android_gms_internal_zzaou.readString();
                        break;
                    default:
                        if (zzapf.zzb(com_google_android_gms_internal_zzaou, J)) {
                            break;
                        }
                        return this;
                }
            }
        }

        public zze zzbww() {
            this.aoR = null;
            this.aoS = zzb.zzbwq();
            this.aoT = zzg.zzbwy();
            this.aoU = null;
            this.aoV = null;
            this.aoW = null;
            this.aoX = null;
            this.aoY = null;
            this.aoZ = null;
            this.zzct = null;
            this.apa = null;
            this.apb = null;
            this.apc = null;
            this.ajA = null;
            this.zzck = null;
            this.abU = null;
            this.apd = null;
            this.ape = null;
            this.apf = null;
            this.apg = null;
            this.aph = null;
            this.api = null;
            this.apj = null;
            this.ajD = null;
            this.ajz = null;
            this.apk = null;
            this.apl = zza.zzbwo();
            this.ajH = null;
            this.apm = null;
            this.apn = null;
            this.apo = null;
            this.app = null;
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int i;
            int zzy = super.zzy();
            if (this.aoR != null) {
                zzy += zzaov.zzag(1, this.aoR.intValue());
            }
            int i2 = 0;
            if (this.aoS != null && this.aoS.length > 0) {
                i = zzy;
                for (zzapc com_google_android_gms_internal_zzapc : this.aoS) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        i += zzaov.zzc(2, com_google_android_gms_internal_zzapc);
                    }
                }
                zzy = i;
            }
            if (this.aoT != null && this.aoT.length > 0) {
                i = zzy;
                for (zzapc com_google_android_gms_internal_zzapc2 : this.aoT) {
                    if (com_google_android_gms_internal_zzapc2 != null) {
                        i += zzaov.zzc(3, com_google_android_gms_internal_zzapc2);
                    }
                }
                zzy = i;
            }
            if (this.aoU != null) {
                zzy += zzaov.zze(4, this.aoU.longValue());
            }
            if (this.aoV != null) {
                zzy += zzaov.zze(5, this.aoV.longValue());
            }
            if (this.aoW != null) {
                zzy += zzaov.zze(6, this.aoW.longValue());
            }
            if (this.aoY != null) {
                zzy += zzaov.zze(7, this.aoY.longValue());
            }
            if (this.aoZ != null) {
                zzy += zzaov.zzs(8, this.aoZ);
            }
            if (this.zzct != null) {
                zzy += zzaov.zzs(9, this.zzct);
            }
            if (this.apa != null) {
                zzy += zzaov.zzs(10, this.apa);
            }
            if (this.apb != null) {
                zzy += zzaov.zzs(11, this.apb);
            }
            if (this.apc != null) {
                zzy += zzaov.zzag(12, this.apc.intValue());
            }
            if (this.ajA != null) {
                zzy += zzaov.zzs(13, this.ajA);
            }
            if (this.zzck != null) {
                zzy += zzaov.zzs(14, this.zzck);
            }
            if (this.abU != null) {
                zzy += zzaov.zzs(16, this.abU);
            }
            if (this.apd != null) {
                zzy += zzaov.zze(17, this.apd.longValue());
            }
            if (this.ape != null) {
                zzy += zzaov.zze(18, this.ape.longValue());
            }
            if (this.apf != null) {
                zzy += zzaov.zzs(19, this.apf);
            }
            if (this.apg != null) {
                zzy += zzaov.zzk(20, this.apg.booleanValue());
            }
            if (this.aph != null) {
                zzy += zzaov.zzs(21, this.aph);
            }
            if (this.api != null) {
                zzy += zzaov.zze(22, this.api.longValue());
            }
            if (this.apj != null) {
                zzy += zzaov.zzag(23, this.apj.intValue());
            }
            if (this.ajD != null) {
                zzy += zzaov.zzs(24, this.ajD);
            }
            if (this.ajz != null) {
                zzy += zzaov.zzs(25, this.ajz);
            }
            if (this.aoX != null) {
                zzy += zzaov.zze(26, this.aoX.longValue());
            }
            if (this.apk != null) {
                zzy += zzaov.zzk(28, this.apk.booleanValue());
            }
            if (this.apl != null && this.apl.length > 0) {
                while (i2 < this.apl.length) {
                    zzapc com_google_android_gms_internal_zzapc3 = this.apl[i2];
                    if (com_google_android_gms_internal_zzapc3 != null) {
                        zzy += zzaov.zzc(29, com_google_android_gms_internal_zzapc3);
                    }
                    i2++;
                }
            }
            if (this.ajH != null) {
                zzy += zzaov.zzs(30, this.ajH);
            }
            if (this.apm != null) {
                zzy += zzaov.zzag(31, this.apm.intValue());
            }
            if (this.apn != null) {
                zzy += zzaov.zzag(32, this.apn.intValue());
            }
            if (this.apo != null) {
                zzy += zzaov.zzag(33, this.apo.intValue());
            }
            return this.app != null ? zzy + zzaov.zzs(34, this.app) : zzy;
        }
    }

    public static final class zzf extends zzapc {
        public long[] apq;
        public long[] apr;

        public zzf() {
            zzbwx();
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzf)) {
                return false;
            }
            zzf com_google_android_gms_internal_zzup_zzf = (zzf) obj;
            return zzapa.equals(this.apq, com_google_android_gms_internal_zzup_zzf.apq) && zzapa.equals(this.apr, com_google_android_gms_internal_zzup_zzf.apr);
        }

        public int hashCode() {
            return (31 * (((527 + getClass().getName().hashCode()) * 31) + zzapa.hashCode(this.apq))) + zzapa.hashCode(this.apr);
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            int i = 0;
            if (this.apq != null && this.apq.length > 0) {
                for (long zza : this.apq) {
                    com_google_android_gms_internal_zzaov.zza(1, zza);
                }
            }
            if (this.apr != null && this.apr.length > 0) {
                while (i < this.apr.length) {
                    com_google_android_gms_internal_zzaov.zza(2, this.apr[i]);
                    i++;
                }
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbr(com_google_android_gms_internal_zzaou);
        }

        public zzf zzbr(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                int position;
                Object obj;
                if (J != 8) {
                    int i;
                    Object obj2;
                    if (J == 10) {
                        J = com_google_android_gms_internal_zzaou.zzaei(com_google_android_gms_internal_zzaou.m48S());
                        position = com_google_android_gms_internal_zzaou.getPosition();
                        i = 0;
                        while (com_google_android_gms_internal_zzaou.m52X() > 0) {
                            com_google_android_gms_internal_zzaou.m41L();
                            i++;
                        }
                        com_google_android_gms_internal_zzaou.zzaek(position);
                        position = this.apq == null ? 0 : this.apq.length;
                        obj2 = new long[(i + position)];
                        if (position != 0) {
                            System.arraycopy(this.apq, 0, obj2, 0, position);
                        }
                        while (position < obj2.length) {
                            obj2[position] = com_google_android_gms_internal_zzaou.m41L();
                            position++;
                        }
                        this.apq = obj2;
                    } else if (J == 16) {
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 16);
                        position = this.apr == null ? 0 : this.apr.length;
                        obj = new long[(J + position)];
                        if (position != 0) {
                            System.arraycopy(this.apr, 0, obj, 0, position);
                        }
                        while (position < obj.length - 1) {
                            obj[position] = com_google_android_gms_internal_zzaou.m41L();
                            com_google_android_gms_internal_zzaou.m39J();
                            position++;
                        }
                        obj[position] = com_google_android_gms_internal_zzaou.m41L();
                        this.apr = obj;
                    } else if (J == 18) {
                        J = com_google_android_gms_internal_zzaou.zzaei(com_google_android_gms_internal_zzaou.m48S());
                        position = com_google_android_gms_internal_zzaou.getPosition();
                        i = 0;
                        while (com_google_android_gms_internal_zzaou.m52X() > 0) {
                            com_google_android_gms_internal_zzaou.m41L();
                            i++;
                        }
                        com_google_android_gms_internal_zzaou.zzaek(position);
                        position = this.apr == null ? 0 : this.apr.length;
                        obj2 = new long[(i + position)];
                        if (position != 0) {
                            System.arraycopy(this.apr, 0, obj2, 0, position);
                        }
                        while (position < obj2.length) {
                            obj2[position] = com_google_android_gms_internal_zzaou.m41L();
                            position++;
                        }
                        this.apr = obj2;
                    } else if (!zzapf.zzb(com_google_android_gms_internal_zzaou, J)) {
                        return this;
                    }
                    com_google_android_gms_internal_zzaou.zzaej(J);
                } else {
                    J = zzapf.zzc(com_google_android_gms_internal_zzaou, 8);
                    position = this.apq == null ? 0 : this.apq.length;
                    obj = new long[(J + position)];
                    if (position != 0) {
                        System.arraycopy(this.apq, 0, obj, 0, position);
                    }
                    while (position < obj.length - 1) {
                        obj[position] = com_google_android_gms_internal_zzaou.m41L();
                        com_google_android_gms_internal_zzaou.m39J();
                        position++;
                    }
                    obj[position] = com_google_android_gms_internal_zzaou.m41L();
                    this.apq = obj;
                }
            }
        }

        public zzf zzbwx() {
            this.apq = zzapf.bin;
            this.apr = zzapf.bin;
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int i;
            int zzy = super.zzy();
            int i2 = 0;
            if (this.apq != null && this.apq.length > 0) {
                i = 0;
                int i3 = i;
                while (i < this.apq.length) {
                    i3 += zzaov.zzcv(this.apq[i]);
                    i++;
                }
                zzy = (zzy + i3) + (this.apq.length * 1);
            }
            if (this.apr == null || this.apr.length <= 0) {
                return zzy;
            }
            i = 0;
            while (i2 < this.apr.length) {
                i += zzaov.zzcv(this.apr[i2]);
                i2++;
            }
            return (zzy + i) + (1 * this.apr.length);
        }
    }

    public static final class zzg extends zzapc {
        private static volatile zzg[] aps;
        public Float anS;
        public Double anT;
        public Long aoO;
        public Long apt;
        public String name;
        public String zr;

        public zzg() {
            zzbwz();
        }

        public static zzg[] zzbwy() {
            if (aps == null) {
                synchronized (zzapa.bij) {
                    if (aps == null) {
                        aps = new zzg[0];
                    }
                }
            }
            return aps;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzg)) {
                return false;
            }
            zzg com_google_android_gms_internal_zzup_zzg = (zzg) obj;
            if (this.apt == null) {
                if (com_google_android_gms_internal_zzup_zzg.apt != null) {
                    return false;
                }
            } else if (!this.apt.equals(com_google_android_gms_internal_zzup_zzg.apt)) {
                return false;
            }
            if (this.name == null) {
                if (com_google_android_gms_internal_zzup_zzg.name != null) {
                    return false;
                }
            } else if (!this.name.equals(com_google_android_gms_internal_zzup_zzg.name)) {
                return false;
            }
            if (this.zr == null) {
                if (com_google_android_gms_internal_zzup_zzg.zr != null) {
                    return false;
                }
            } else if (!this.zr.equals(com_google_android_gms_internal_zzup_zzg.zr)) {
                return false;
            }
            if (this.aoO == null) {
                if (com_google_android_gms_internal_zzup_zzg.aoO != null) {
                    return false;
                }
            } else if (!this.aoO.equals(com_google_android_gms_internal_zzup_zzg.aoO)) {
                return false;
            }
            if (this.anS == null) {
                if (com_google_android_gms_internal_zzup_zzg.anS != null) {
                    return false;
                }
            } else if (!this.anS.equals(com_google_android_gms_internal_zzup_zzg.anS)) {
                return false;
            }
            if (this.anT == null) {
                if (com_google_android_gms_internal_zzup_zzg.anT != null) {
                    return false;
                }
            } else if (!this.anT.equals(com_google_android_gms_internal_zzup_zzg.anT)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((((((527 + getClass().getName().hashCode()) * 31) + (this.apt == null ? 0 : this.apt.hashCode())) * 31) + (this.name == null ? 0 : this.name.hashCode())) * 31) + (this.zr == null ? 0 : this.zr.hashCode())) * 31) + (this.aoO == null ? 0 : this.aoO.hashCode())) * 31) + (this.anS == null ? 0 : this.anS.hashCode()));
            if (this.anT != null) {
                i = this.anT.hashCode();
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.apt != null) {
                com_google_android_gms_internal_zzaov.zzb(1, this.apt.longValue());
            }
            if (this.name != null) {
                com_google_android_gms_internal_zzaov.zzr(2, this.name);
            }
            if (this.zr != null) {
                com_google_android_gms_internal_zzaov.zzr(3, this.zr);
            }
            if (this.aoO != null) {
                com_google_android_gms_internal_zzaov.zzb(4, this.aoO.longValue());
            }
            if (this.anS != null) {
                com_google_android_gms_internal_zzaov.zzc(5, this.anS.floatValue());
            }
            if (this.anT != null) {
                com_google_android_gms_internal_zzaov.zza(6, this.anT.doubleValue());
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbs(com_google_android_gms_internal_zzaou);
        }

        public zzg zzbs(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J == 8) {
                    this.apt = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                } else if (J == 18) {
                    this.name = com_google_android_gms_internal_zzaou.readString();
                } else if (J == 26) {
                    this.zr = com_google_android_gms_internal_zzaou.readString();
                } else if (J == 32) {
                    this.aoO = Long.valueOf(com_google_android_gms_internal_zzaou.m42M());
                } else if (J == 45) {
                    this.anS = Float.valueOf(com_google_android_gms_internal_zzaou.readFloat());
                } else if (J == 49) {
                    this.anT = Double.valueOf(com_google_android_gms_internal_zzaou.readDouble());
                } else if (!zzapf.zzb(com_google_android_gms_internal_zzaou, J)) {
                    return this;
                }
            }
        }

        public zzg zzbwz() {
            this.apt = null;
            this.name = null;
            this.zr = null;
            this.aoO = null;
            this.anS = null;
            this.anT = null;
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (this.apt != null) {
                zzy += zzaov.zze(1, this.apt.longValue());
            }
            if (this.name != null) {
                zzy += zzaov.zzs(2, this.name);
            }
            if (this.zr != null) {
                zzy += zzaov.zzs(3, this.zr);
            }
            if (this.aoO != null) {
                zzy += zzaov.zze(4, this.aoO.longValue());
            }
            if (this.anS != null) {
                zzy += zzaov.zzd(5, this.anS.floatValue());
            }
            return this.anT != null ? zzy + zzaov.zzb(6, this.anT.doubleValue()) : zzy;
        }
    }
}
