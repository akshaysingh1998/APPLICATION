package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.Looper;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@zzir
public class zziq implements UncaughtExceptionHandler {
    private Context mContext;
    private VersionInfoParcel zzamu;
    private UncaughtExceptionHandler zzcag;
    private UncaughtExceptionHandler zzcah;

    public zziq(Context context, VersionInfoParcel versionInfoParcel, UncaughtExceptionHandler uncaughtExceptionHandler, UncaughtExceptionHandler uncaughtExceptionHandler2) {
        this.zzcag = uncaughtExceptionHandler;
        this.zzcah = uncaughtExceptionHandler2;
        this.mContext = context;
        this.zzamu = versionInfoParcel;
    }

    public static zziq zza(Context context, Thread thread, VersionInfoParcel versionInfoParcel) {
        if (context == null || thread == null || versionInfoParcel == null || !zzu(context)) {
            return null;
        }
        UncaughtExceptionHandler uncaughtExceptionHandler = thread.getUncaughtExceptionHandler();
        Object com_google_android_gms_internal_zziq = new zziq(context, versionInfoParcel, uncaughtExceptionHandler, Thread.getDefaultUncaughtExceptionHandler());
        if (uncaughtExceptionHandler != null) {
            if (uncaughtExceptionHandler instanceof zziq) {
                return (zziq) uncaughtExceptionHandler;
            }
        }
        try {
            thread.setUncaughtExceptionHandler(com_google_android_gms_internal_zziq);
            return com_google_android_gms_internal_zziq;
        } catch (Throwable e) {
            zzb.zzc("Fail to set UncaughtExceptionHandler.", e);
            return null;
        }
    }

    private Throwable zzc(Throwable th) {
        if (((Boolean) zzdc.zzayc.get()).booleanValue()) {
            return th;
        }
        LinkedList linkedList = new LinkedList();
        while (th != null) {
            linkedList.push(th);
            th = th.getCause();
        }
        th = null;
        while (!linkedList.isEmpty()) {
            Throwable th2 = (Throwable) linkedList.pop();
            StackTraceElement[] stackTrace = th2.getStackTrace();
            ArrayList arrayList = new ArrayList();
            arrayList.add(new StackTraceElement(th2.getClass().getName(), "<filtered>", "<filtered>", 1));
            int length = stackTrace.length;
            int i = 0;
            int i2 = i;
            while (i < length) {
                Object obj = stackTrace[i];
                if (zzcd(obj.getClassName())) {
                    arrayList.add(obj);
                    i2 = 1;
                } else {
                    if (!zzce(obj.getClassName())) {
                        obj = new StackTraceElement("<filtered>", "<filtered>", "<filtered>", 1);
                    }
                    arrayList.add(obj);
                }
                i++;
            }
            if (i2 != 0) {
                th = th == null ? new Throwable(th2.getMessage()) : new Throwable(th2.getMessage(), th);
                th.setStackTrace((StackTraceElement[]) arrayList.toArray(new StackTraceElement[0]));
            }
        }
        return th;
    }

    private static boolean zzu(Context context) {
        return ((Boolean) zzdc.zzayb.get()).booleanValue();
    }

    public void uncaughtException(Thread thread, Throwable th) {
        UncaughtExceptionHandler uncaughtExceptionHandler;
        if (zzb(th)) {
            if (Looper.getMainLooper().getThread() != thread) {
                zza(th, true);
                return;
            }
            zza(th, false);
        }
        if (this.zzcag != null) {
            uncaughtExceptionHandler = this.zzcag;
        } else if (this.zzcah != null) {
            uncaughtExceptionHandler = this.zzcah;
        } else {
            return;
        }
        uncaughtExceptionHandler.uncaughtException(thread, th);
    }

    String zza(Class cls, Throwable th, boolean z) {
        Writer stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        return new Builder().scheme("https").path("//pagead2.googlesyndication.com/pagead/gen_204").appendQueryParameter("id", "gmob-apps-report-exception").appendQueryParameter("os", VERSION.RELEASE).appendQueryParameter("api", String.valueOf(VERSION.SDK_INT)).appendQueryParameter("device", zzu.zzfq().zzth()).appendQueryParameter("js", this.zzamu.zzcs).appendQueryParameter("appid", this.mContext.getApplicationContext().getPackageName()).appendQueryParameter("exceptiontype", cls.getName()).appendQueryParameter("stacktrace", stringWriter.toString()).appendQueryParameter("eids", TextUtils.join(",", zzdc.zzjx())).appendQueryParameter("trapped", String.valueOf(z)).toString();
    }

    public void zza(Throwable th, boolean z) {
        if (zzu(this.mContext)) {
            Throwable zzc = zzc(th);
            if (zzc != null) {
                Class cls = th.getClass();
                List arrayList = new ArrayList();
                arrayList.add(zza(cls, zzc, z));
                zzu.zzfq().zza(arrayList, zzu.zzft().zzsp());
            }
        }
    }

    protected boolean zzb(Throwable th) {
        boolean z = false;
        if (th == null) {
            return false;
        }
        boolean z2 = false;
        boolean z3 = z2;
        while (th != null) {
            boolean z4 = z3;
            z3 = z2;
            for (StackTraceElement stackTraceElement : th.getStackTrace()) {
                if (zzcd(stackTraceElement.getClassName())) {
                    z3 = true;
                }
                if (getClass().getName().equals(stackTraceElement.getClassName())) {
                    z4 = true;
                }
            }
            th = th.getCause();
            z2 = z3;
            z3 = z4;
        }
        if (z2 && !z3) {
            z = true;
        }
        return z;
    }

    protected boolean zzcd(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        if (str.startsWith((String) zzdc.zzayd.get())) {
            return true;
        }
        try {
            return Class.forName(str).isAnnotationPresent(zzir.class);
        } catch (Throwable e) {
            String str2 = "Fail to check class type for class ";
            str = String.valueOf(str);
            zzb.zza(str.length() != 0 ? str2.concat(str) : new String(str2), e);
            return false;
        }
    }

    protected boolean zzce(String str) {
        boolean z = false;
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        if (str.startsWith("android.") || str.startsWith("java.")) {
            z = true;
        }
        return z;
    }
}
