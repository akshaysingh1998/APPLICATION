package com.google.android.gms.internal;

public final class zzuh {
    private static zzuh Qr;
    private final zzue Qs = new zzue();
    private final zzuf Qt = new zzuf();

    static {
        zza(new zzuh());
    }

    private zzuh() {
    }

    protected static void zza(zzuh com_google_android_gms_internal_zzuh) {
        synchronized (zzuh.class) {
            Qr = com_google_android_gms_internal_zzuh;
        }
    }

    private static zzuh zzbfq() {
        zzuh com_google_android_gms_internal_zzuh;
        synchronized (zzuh.class) {
            com_google_android_gms_internal_zzuh = Qr;
        }
        return com_google_android_gms_internal_zzuh;
    }

    public static zzue zzbfr() {
        return zzbfq().Qs;
    }

    public static zzuf zzbfs() {
        return zzbfq().Qt;
    }
}
