package com.google.android.gms.internal;

import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.util.client.zza;
import com.google.android.gms.ads.internal.util.client.zzb;

@zzir
public final class zzha<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> implements MediationBannerListener, MediationInterstitialListener {
    private final zzgp zzbpo;

    class C04351 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04351(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdClicked();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdClicked.", e);
            }
        }
    }

    class C04362 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04362(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdOpened();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdOpened.", e);
            }
        }
    }

    class C04373 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04373(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdLoaded();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdLoaded.", e);
            }
        }
    }

    class C04384 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04384(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdClosed();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdClosed.", e);
            }
        }
    }

    class C04406 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04406(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdLeftApplication();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdLeftApplication.", e);
            }
        }
    }

    class C04417 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04417(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdOpened();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdOpened.", e);
            }
        }
    }

    class C04428 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04428(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdLoaded();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdLoaded.", e);
            }
        }
    }

    class C04439 implements Runnable {
        final /* synthetic */ zzha zzbpu;

        C04439(zzha com_google_android_gms_internal_zzha) {
            this.zzbpu = com_google_android_gms_internal_zzha;
        }

        public void run() {
            try {
                this.zzbpu.zzbpo.onAdClosed();
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdClosed.", e);
            }
        }
    }

    public zzha(zzgp com_google_android_gms_internal_zzgp) {
        this.zzbpo = com_google_android_gms_internal_zzgp;
    }

    public void onClick(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        zzb.zzcw("Adapter called onClick.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdClicked();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdClicked.", e);
                return;
            }
        }
        zzb.zzcy("onClick must be called on the main UI thread.");
        zza.zzcnf.post(new C04351(this));
    }

    public void onDismissScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        zzb.zzcw("Adapter called onDismissScreen.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdClosed();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdClosed.", e);
                return;
            }
        }
        zzb.zzcy("onDismissScreen must be called on the main UI thread.");
        zza.zzcnf.post(new C04384(this));
    }

    public void onDismissScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        zzb.zzcw("Adapter called onDismissScreen.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdClosed();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdClosed.", e);
                return;
            }
        }
        zzb.zzcy("onDismissScreen must be called on the main UI thread.");
        zza.zzcnf.post(new C04439(this));
    }

    public void onFailedToReceiveAd(MediationBannerAdapter<?, ?> mediationBannerAdapter, final ErrorCode errorCode) {
        String valueOf = String.valueOf(errorCode);
        StringBuilder stringBuilder = new StringBuilder(47 + String.valueOf(valueOf).length());
        stringBuilder.append("Adapter called onFailedToReceiveAd with error. ");
        stringBuilder.append(valueOf);
        zzb.zzcw(stringBuilder.toString());
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdFailedToLoad(zzhb.zza(errorCode));
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        zzb.zzcy("onFailedToReceiveAd must be called on the main UI thread.");
        zza.zzcnf.post(new Runnable(this) {
            final /* synthetic */ zzha zzbpu;

            public void run() {
                try {
                    this.zzbpu.zzbpo.onAdFailedToLoad(zzhb.zza(errorCode));
                } catch (Throwable e) {
                    zzb.zzd("Could not call onAdFailedToLoad.", e);
                }
            }
        });
    }

    public void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter, final ErrorCode errorCode) {
        String valueOf = String.valueOf(errorCode);
        StringBuilder stringBuilder = new StringBuilder(47 + String.valueOf(valueOf).length());
        stringBuilder.append("Adapter called onFailedToReceiveAd with error ");
        stringBuilder.append(valueOf);
        stringBuilder.append(".");
        zzb.zzcw(stringBuilder.toString());
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdFailedToLoad(zzhb.zza(errorCode));
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        zzb.zzcy("onFailedToReceiveAd must be called on the main UI thread.");
        zza.zzcnf.post(new Runnable(this) {
            final /* synthetic */ zzha zzbpu;

            public void run() {
                try {
                    this.zzbpu.zzbpo.onAdFailedToLoad(zzhb.zza(errorCode));
                } catch (Throwable e) {
                    zzb.zzd("Could not call onAdFailedToLoad.", e);
                }
            }
        });
    }

    public void onLeaveApplication(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        zzb.zzcw("Adapter called onLeaveApplication.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        zzb.zzcy("onLeaveApplication must be called on the main UI thread.");
        zza.zzcnf.post(new C04406(this));
    }

    public void onLeaveApplication(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        zzb.zzcw("Adapter called onLeaveApplication.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        zzb.zzcy("onLeaveApplication must be called on the main UI thread.");
        zza.zzcnf.post(new Runnable(this) {
            final /* synthetic */ zzha zzbpu;

            {
                this.zzbpu = r1;
            }

            public void run() {
                try {
                    this.zzbpu.zzbpo.onAdLeftApplication();
                } catch (Throwable e) {
                    zzb.zzd("Could not call onAdLeftApplication.", e);
                }
            }
        });
    }

    public void onPresentScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        zzb.zzcw("Adapter called onPresentScreen.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdOpened();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdOpened.", e);
                return;
            }
        }
        zzb.zzcy("onPresentScreen must be called on the main UI thread.");
        zza.zzcnf.post(new C04417(this));
    }

    public void onPresentScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        zzb.zzcw("Adapter called onPresentScreen.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdOpened();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdOpened.", e);
                return;
            }
        }
        zzb.zzcy("onPresentScreen must be called on the main UI thread.");
        zza.zzcnf.post(new C04362(this));
    }

    public void onReceivedAd(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        zzb.zzcw("Adapter called onReceivedAd.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdLoaded();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdLoaded.", e);
                return;
            }
        }
        zzb.zzcy("onReceivedAd must be called on the main UI thread.");
        zza.zzcnf.post(new C04428(this));
    }

    public void onReceivedAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        zzb.zzcw("Adapter called onReceivedAd.");
        if (zzm.zziw().zzty()) {
            try {
                this.zzbpo.onAdLoaded();
                return;
            } catch (Throwable e) {
                zzb.zzd("Could not call onAdLoaded.", e);
                return;
            }
        }
        zzb.zzcy("onReceivedAd must be called on the main UI thread.");
        zza.zzcnf.post(new C04373(this));
    }
}
