package com.google.android.gms.internal;

import android.content.Context;

public interface zzjd {

    public static class zza {
    }

    zza zzz(Context context);
}
