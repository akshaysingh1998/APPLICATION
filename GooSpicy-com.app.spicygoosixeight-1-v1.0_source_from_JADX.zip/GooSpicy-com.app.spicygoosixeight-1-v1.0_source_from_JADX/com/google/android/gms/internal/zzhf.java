package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;

@zzir
public class zzhf {
    private final zzll zzbgj;
    private final boolean zzbqw;
    private final String zzbqx;

    public zzhf(com.google.android.gms.internal.zzll r1, java.util.Map<java.lang.String, java.lang.String> r2) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:6:0x0028 in {2, 4, 5} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = this;
        r0.<init>();
        r0.zzbgj = r1;
        r1 = "forceOrientation";
        r1 = r2.get(r1);
        r1 = (java.lang.String) r1;
        r0.zzbqx = r1;
        r1 = "allowOrientationChange";
        r1 = r2.containsKey(r1);
        if (r1 == 0) goto L_0x0026;
    L_0x0017:
        r1 = "allowOrientationChange";
        r1 = r2.get(r1);
        r1 = (java.lang.String) r1;
        r1 = java.lang.Boolean.parseBoolean(r1);
    L_0x0023:
        r0.zzbqw = r1;
        return;
    L_0x0026:
        r1 = 1;
        goto L_0x0023;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhf.<init>(com.google.android.gms.internal.zzll, java.util.Map):void");
    }

    public void execute() {
        if (this.zzbgj == null) {
            zzb.zzcy("AdWebView is null");
            return;
        }
        int zztl = "portrait".equalsIgnoreCase(this.zzbqx) ? zzu.zzfs().zztl() : "landscape".equalsIgnoreCase(this.zzbqx) ? zzu.zzfs().zztk() : this.zzbqw ? -1 : zzu.zzfs().zztm();
        this.zzbgj.setRequestedOrientation(zztl);
    }
}
