package com.google.android.gms.internal;

import android.os.Process;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

@zzir
public final class zzkk {
    private static final ExecutorService zzcky = Executors.newFixedThreadPool(10, zzco("Default"));
    private static final ExecutorService zzckz = Executors.newFixedThreadPool(5, zzco("Loader"));

    class C04711 implements Callable<Void> {
        final /* synthetic */ Runnable zzcla;

        C04711(Runnable runnable) {
            this.zzcla = runnable;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzcy();
        }

        public Void zzcy() {
            this.zzcla.run();
            return null;
        }
    }

    class C04722 implements Callable<Void> {
        final /* synthetic */ Runnable zzcla;

        C04722(Runnable runnable) {
            this.zzcla = runnable;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzcy();
        }

        public Void zzcy() {
            this.zzcla.run();
            return null;
        }
    }

    class C04733 implements Runnable {
        final /* synthetic */ zzkz zzclb;
        final /* synthetic */ Callable zzclc;

        C04733(zzkz com_google_android_gms_internal_zzkz, Callable callable) {
            this.zzclb = com_google_android_gms_internal_zzkz;
            this.zzclc = callable;
        }

        public void run() {
            try {
                Process.setThreadPriority(10);
                this.zzclb.zzi(this.zzclc.call());
            } catch (Throwable e) {
                zzu.zzft().zzb(e, true);
                this.zzclb.cancel(true);
            }
        }
    }

    class C04744 implements Runnable {
        final /* synthetic */ zzkz zzclb;
        final /* synthetic */ Future zzcld;

        C04744(zzkz com_google_android_gms_internal_zzkz, Future future) {
            this.zzclb = com_google_android_gms_internal_zzkz;
            this.zzcld = future;
        }

        public void run() {
            if (this.zzclb.isCancelled()) {
                this.zzcld.cancel(true);
            }
        }
    }

    class C04755 implements ThreadFactory {
        private final AtomicInteger zzcle = new AtomicInteger(1);
        final /* synthetic */ String zzclf;

        C04755(String str) {
            this.zzclf = str;
        }

        public Thread newThread(Runnable runnable) {
            String str = this.zzclf;
            int andIncrement = this.zzcle.getAndIncrement();
            StringBuilder stringBuilder = new StringBuilder(23 + String.valueOf(str).length());
            stringBuilder.append("AdWorker(");
            stringBuilder.append(str);
            stringBuilder.append(") #");
            stringBuilder.append(andIncrement);
            return new Thread(runnable, stringBuilder.toString());
        }
    }

    public static zzlc<Void> zza(int i, Runnable runnable) {
        ExecutorService executorService;
        Callable c04711;
        if (i == 1) {
            executorService = zzckz;
            c04711 = new C04711(runnable);
        } else {
            executorService = zzcky;
            c04711 = new C04722(runnable);
        }
        return zza(executorService, c04711);
    }

    public static zzlc<Void> zza(Runnable runnable) {
        return zza(0, runnable);
    }

    public static <T> zzlc<T> zza(Callable<T> callable) {
        return zza(zzcky, (Callable) callable);
    }

    public static <T> zzlc<T> zza(ExecutorService executorService, Callable<T> callable) {
        zzlc<T> com_google_android_gms_internal_zzkz = new zzkz();
        try {
            com_google_android_gms_internal_zzkz.zzc(new C04744(com_google_android_gms_internal_zzkz, executorService.submit(new C04733(com_google_android_gms_internal_zzkz, callable))));
            return com_google_android_gms_internal_zzkz;
        } catch (Throwable e) {
            zzb.zzd("Thread execution is rejected.", e);
            com_google_android_gms_internal_zzkz.cancel(true);
            return com_google_android_gms_internal_zzkz;
        }
    }

    private static ThreadFactory zzco(String str) {
        return new C04755(str);
    }
}
