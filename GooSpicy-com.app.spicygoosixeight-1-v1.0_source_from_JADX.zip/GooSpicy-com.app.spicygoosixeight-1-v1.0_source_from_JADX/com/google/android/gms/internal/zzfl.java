package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzd;
import com.google.android.gms.ads.internal.zzl;

@zzir
public class zzfl {
    private Context mContext;
    private final zzd zzajv;
    private final zzgn zzajz;
    private final VersionInfoParcel zzalm;

    zzfl(Context context, zzgn com_google_android_gms_internal_zzgn, VersionInfoParcel versionInfoParcel, zzd com_google_android_gms_ads_internal_zzd) {
        this.mContext = context;
        this.zzajz = com_google_android_gms_internal_zzgn;
        this.zzalm = versionInfoParcel;
        this.zzajv = com_google_android_gms_ads_internal_zzd;
    }

    public Context getApplicationContext() {
        return this.mContext.getApplicationContext();
    }

    public zzl zzbd(String str) {
        return new zzl(this.mContext, new AdSizeParcel(), str, this.zzajz, this.zzalm, this.zzajv);
    }

    public zzl zzbe(String str) {
        return new zzl(this.mContext.getApplicationContext(), new AdSizeParcel(), str, this.zzajz, this.zzalm, this.zzajv);
    }

    public zzfl zzlp() {
        return new zzfl(getApplicationContext(), this.zzajz, this.zzalm, this.zzajv);
    }
}
