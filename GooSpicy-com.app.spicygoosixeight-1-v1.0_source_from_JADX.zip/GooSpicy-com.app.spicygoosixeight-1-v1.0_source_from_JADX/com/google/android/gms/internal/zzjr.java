package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.request.AdResponseParcel;

public class zzjr implements zzjt {
    public zzjs zza(Context context, AdResponseParcel adResponseParcel) {
        return null;
    }
}
