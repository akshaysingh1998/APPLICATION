package com.google.android.gms.internal;

import com.google.android.gms.internal.zzae.zza;
import java.lang.reflect.InvocationTargetException;

public class zzbh extends zzbp {
    public zzbh(zzax com_google_android_gms_internal_zzax, String str, String str2, zza com_google_android_gms_internal_zzae_zza, int i, int i2) {
        super(com_google_android_gms_internal_zzax, str, str2, com_google_android_gms_internal_zzae_zza, i, i2);
    }

    private void zzcw() throws IllegalAccessException, InvocationTargetException {
        synchronized (this.zzaha) {
            this.zzaha.zzeg = (String) this.zzahh.invoke(null, new Object[]{this.zzaey.getContext()});
        }
    }

    private void zzcx() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = r4.zzaey;
        r0 = r0.zzcs();
        if (r0 != 0) goto L_0x000e;
    L_0x0008:
        r0 = "E1";
    L_0x000a:
        r4.zzp(r0);
        return;
    L_0x000e:
        r0 = r0.getInfo();	 Catch:{ IOException -> 0x0043 }
        r1 = r0.getId();	 Catch:{ IOException -> 0x0043 }
        r1 = com.google.android.gms.internal.zzay.zzo(r1);	 Catch:{ IOException -> 0x0043 }
        if (r1 == 0) goto L_0x003d;	 Catch:{ IOException -> 0x0043 }
    L_0x001c:
        r2 = r4.zzaha;	 Catch:{ IOException -> 0x0043 }
        monitor-enter(r2);	 Catch:{ IOException -> 0x0043 }
        r3 = r4.zzaha;	 Catch:{ all -> 0x003a }
        r3.zzeg = r1;	 Catch:{ all -> 0x003a }
        r1 = r4.zzaha;	 Catch:{ all -> 0x003a }
        r0 = r0.isLimitAdTrackingEnabled();	 Catch:{ all -> 0x003a }
        r0 = java.lang.Boolean.valueOf(r0);	 Catch:{ all -> 0x003a }
        r1.zzei = r0;	 Catch:{ all -> 0x003a }
        r0 = r4.zzaha;	 Catch:{ all -> 0x003a }
        r1 = 5;	 Catch:{ all -> 0x003a }
        r1 = java.lang.Integer.valueOf(r1);	 Catch:{ all -> 0x003a }
        r0.zzeh = r1;	 Catch:{ all -> 0x003a }
        monitor-exit(r2);	 Catch:{ all -> 0x003a }
        return;	 Catch:{ all -> 0x003a }
    L_0x003a:
        r0 = move-exception;	 Catch:{ all -> 0x003a }
        monitor-exit(r2);	 Catch:{ all -> 0x003a }
        throw r0;	 Catch:{ IOException -> 0x0043 }
    L_0x003d:
        r0 = "E";	 Catch:{ IOException -> 0x0043 }
        r4.zzp(r0);	 Catch:{ IOException -> 0x0043 }
        return;
    L_0x0043:
        r0 = "E";
        goto L_0x000a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzbh.zzcx():void");
    }

    private void zzp(String str) {
    }

    protected void zzcv() throws IllegalAccessException, InvocationTargetException {
        if (this.zzaey.zzcj()) {
            zzcx();
        } else {
            zzcw();
        }
    }
}
