package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.overlay.zzd;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import java.util.Map;
import org.json.JSONObject;

@zzir
class zzlo extends FrameLayout implements zzll {
    private final zzll zzcpd;
    private final zzlk zzcpe;

    public zzlo(zzll com_google_android_gms_internal_zzll) {
        super(com_google_android_gms_internal_zzll.getContext());
        this.zzcpd = com_google_android_gms_internal_zzll;
        this.zzcpe = new zzlk(com_google_android_gms_internal_zzll.zzug(), this, this);
        zzlm zzuk = this.zzcpd.zzuk();
        if (zzuk != null) {
            zzuk.zzm(this);
        }
        addView(this.zzcpd.getView());
    }

    public void destroy() {
        this.zzcpd.destroy();
    }

    public String getRequestId() {
        return this.zzcpd.getRequestId();
    }

    public int getRequestedOrientation() {
        return this.zzcpd.getRequestedOrientation();
    }

    public View getView() {
        return this;
    }

    public WebView getWebView() {
        return this.zzcpd.getWebView();
    }

    public boolean isDestroyed() {
        return this.zzcpd.isDestroyed();
    }

    public void loadData(String str, String str2, String str3) {
        this.zzcpd.loadData(str, str2, str3);
    }

    public void loadDataWithBaseURL(String str, String str2, String str3, String str4, String str5) {
        this.zzcpd.loadDataWithBaseURL(str, str2, str3, str4, str5);
    }

    public void loadUrl(String str) {
        this.zzcpd.loadUrl(str);
    }

    public void onPause() {
        this.zzcpe.onPause();
        this.zzcpd.onPause();
    }

    public void onResume() {
        this.zzcpd.onResume();
    }

    public void setBackgroundColor(int i) {
        this.zzcpd.setBackgroundColor(i);
    }

    public void setContext(Context context) {
        this.zzcpd.setContext(context);
    }

    public void setOnClickListener(OnClickListener onClickListener) {
        this.zzcpd.setOnClickListener(onClickListener);
    }

    public void setOnTouchListener(OnTouchListener onTouchListener) {
        this.zzcpd.setOnTouchListener(onTouchListener);
    }

    public void setRequestedOrientation(int i) {
        this.zzcpd.setRequestedOrientation(i);
    }

    public void setWebChromeClient(WebChromeClient webChromeClient) {
        this.zzcpd.setWebChromeClient(webChromeClient);
    }

    public void setWebViewClient(WebViewClient webViewClient) {
        this.zzcpd.setWebViewClient(webViewClient);
    }

    public void stopLoading() {
        this.zzcpd.stopLoading();
    }

    public void zza(Context context, AdSizeParcel adSizeParcel, zzdk com_google_android_gms_internal_zzdk) {
        this.zzcpe.onDestroy();
        this.zzcpd.zza(context, adSizeParcel, com_google_android_gms_internal_zzdk);
    }

    public void zza(AdSizeParcel adSizeParcel) {
        this.zzcpd.zza(adSizeParcel);
    }

    public void zza(zzcd com_google_android_gms_internal_zzcd, boolean z) {
        this.zzcpd.zza(com_google_android_gms_internal_zzcd, z);
    }

    public void zza(zzlq com_google_android_gms_internal_zzlq) {
        this.zzcpd.zza(com_google_android_gms_internal_zzlq);
    }

    public void zza(String str, zzet com_google_android_gms_internal_zzet) {
        this.zzcpd.zza(str, com_google_android_gms_internal_zzet);
    }

    public void zza(String str, Map<String, ?> map) {
        this.zzcpd.zza(str, (Map) map);
    }

    public void zza(String str, JSONObject jSONObject) {
        this.zzcpd.zza(str, jSONObject);
    }

    public void zzaf(int i) {
        this.zzcpd.zzaf(i);
    }

    public void zzah(boolean z) {
        this.zzcpd.zzah(z);
    }

    public void zzai(boolean z) {
        this.zzcpd.zzai(z);
    }

    public void zzaj(boolean z) {
        this.zzcpd.zzaj(z);
    }

    public void zzb(zzd com_google_android_gms_ads_internal_overlay_zzd) {
        this.zzcpd.zzb(com_google_android_gms_ads_internal_overlay_zzd);
    }

    public void zzb(String str, zzet com_google_android_gms_internal_zzet) {
        this.zzcpd.zzb(str, com_google_android_gms_internal_zzet);
    }

    public void zzb(String str, JSONObject jSONObject) {
        this.zzcpd.zzb(str, jSONObject);
    }

    public void zzc(zzd com_google_android_gms_ads_internal_overlay_zzd) {
        this.zzcpd.zzc(com_google_android_gms_ads_internal_overlay_zzd);
    }

    public void zzcz(String str) {
        this.zzcpd.zzcz(str);
    }

    public void zzda(String str) {
        this.zzcpd.zzda(str);
    }

    public AdSizeParcel zzdo() {
        return this.zzcpd.zzdo();
    }

    public void zzeg() {
        this.zzcpd.zzeg();
    }

    public void zzeh() {
        this.zzcpd.zzeh();
    }

    public void zzj(String str, String str2) {
        this.zzcpd.zzj(str, str2);
    }

    public void zzoc() {
        this.zzcpd.zzoc();
    }

    public boolean zzow() {
        return this.zzcpd.zzow();
    }

    public void zzud() {
        this.zzcpd.zzud();
    }

    public void zzue() {
        this.zzcpd.zzue();
    }

    public Activity zzuf() {
        return this.zzcpd.zzuf();
    }

    public Context zzug() {
        return this.zzcpd.zzug();
    }

    public com.google.android.gms.ads.internal.zzd zzuh() {
        return this.zzcpd.zzuh();
    }

    public zzd zzui() {
        return this.zzcpd.zzui();
    }

    public zzd zzuj() {
        return this.zzcpd.zzuj();
    }

    public zzlm zzuk() {
        return this.zzcpd.zzuk();
    }

    public boolean zzul() {
        return this.zzcpd.zzul();
    }

    public zzas zzum() {
        return this.zzcpd.zzum();
    }

    public VersionInfoParcel zzun() {
        return this.zzcpd.zzun();
    }

    public boolean zzuo() {
        return this.zzcpd.zzuo();
    }

    public void zzup() {
        this.zzcpe.onDestroy();
        this.zzcpd.zzup();
    }

    public boolean zzuq() {
        return this.zzcpd.zzuq();
    }

    public zzlk zzur() {
        return this.zzcpe;
    }

    public zzdi zzus() {
        return this.zzcpd.zzus();
    }

    public zzdj zzut() {
        return this.zzcpd.zzut();
    }

    public zzlq zzuu() {
        return this.zzcpd.zzuu();
    }

    public void zzuv() {
        this.zzcpd.zzuv();
    }

    public void zzuw() {
        this.zzcpd.zzuw();
    }

    public OnClickListener zzux() {
        return this.zzcpd.zzux();
    }
}
