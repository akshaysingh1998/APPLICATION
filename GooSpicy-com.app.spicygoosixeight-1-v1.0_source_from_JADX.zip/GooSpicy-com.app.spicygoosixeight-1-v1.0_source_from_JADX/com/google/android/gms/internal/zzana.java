package com.google.android.gms.internal;

public final class zzana extends zzamy {
    public static final zzana bes = new zzana();

    public boolean equals(Object obj) {
        if (this != obj) {
            if (!(obj instanceof zzana)) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        return zzana.class.hashCode();
    }
}
