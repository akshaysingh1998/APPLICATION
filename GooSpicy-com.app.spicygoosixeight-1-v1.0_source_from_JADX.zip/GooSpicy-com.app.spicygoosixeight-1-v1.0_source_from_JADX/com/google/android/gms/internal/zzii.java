package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.widget.PopupWindow;
import com.google.android.gms.internal.zzjy.zza;

@TargetApi(19)
@zzir
public class zzii extends zzih {
    private Object zzbyn = new Object();
    private PopupWindow zzbyo;
    private boolean zzbyp = false;

    zzii(Context context, zza com_google_android_gms_internal_zzjy_zza, zzll com_google_android_gms_internal_zzll, zzig.zza com_google_android_gms_internal_zzig_zza) {
        super(context, com_google_android_gms_internal_zzjy_zza, com_google_android_gms_internal_zzll, com_google_android_gms_internal_zzig_zza);
    }

    private void zzqf() {
        synchronized (this.zzbyn) {
            this.zzbyp = true;
            if ((this.mContext instanceof Activity) && ((Activity) this.mContext).isDestroyed()) {
                this.zzbyo = null;
            }
            if (this.zzbyo != null) {
                if (this.zzbyo.isShowing()) {
                    this.zzbyo.dismiss();
                }
                this.zzbyo = null;
            }
        }
    }

    public void cancel() {
        zzqf();
        super.cancel();
    }

    protected void zzaj(int i) {
        zzqf();
        super.zzaj(i);
    }

    protected void zzqe() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r8 = this;
        r0 = r8.mContext;
        r0 = r0 instanceof android.app.Activity;
        r1 = 0;
        if (r0 == 0) goto L_0x0010;
    L_0x0007:
        r0 = r8.mContext;
        r0 = (android.app.Activity) r0;
        r0 = r0.getWindow();
        goto L_0x0011;
    L_0x0010:
        r0 = r1;
    L_0x0011:
        if (r0 == 0) goto L_0x0070;
    L_0x0013:
        r2 = r0.getDecorView();
        if (r2 != 0) goto L_0x001a;
    L_0x0019:
        return;
    L_0x001a:
        r2 = r8.mContext;
        r2 = (android.app.Activity) r2;
        r2 = r2.isDestroyed();
        if (r2 == 0) goto L_0x0025;
    L_0x0024:
        return;
    L_0x0025:
        r2 = new android.widget.FrameLayout;
        r3 = r8.mContext;
        r2.<init>(r3);
        r3 = new android.view.ViewGroup$LayoutParams;
        r4 = -1;
        r3.<init>(r4, r4);
        r2.setLayoutParams(r3);
        r3 = r8.zzbgj;
        r3 = r3.getView();
        r2.addView(r3, r4, r4);
        r3 = r8.zzbyn;
        monitor-enter(r3);
        r5 = r8.zzbyp;	 Catch:{ all -> 0x006d }
        if (r5 == 0) goto L_0x0047;	 Catch:{ all -> 0x006d }
    L_0x0045:
        monitor-exit(r3);	 Catch:{ all -> 0x006d }
        return;	 Catch:{ all -> 0x006d }
    L_0x0047:
        r5 = new android.widget.PopupWindow;	 Catch:{ all -> 0x006d }
        r6 = 0;	 Catch:{ all -> 0x006d }
        r7 = 1;	 Catch:{ all -> 0x006d }
        r5.<init>(r2, r7, r7, r6);	 Catch:{ all -> 0x006d }
        r8.zzbyo = r5;	 Catch:{ all -> 0x006d }
        r2 = r8.zzbyo;	 Catch:{ all -> 0x006d }
        r2.setOutsideTouchable(r7);	 Catch:{ all -> 0x006d }
        r2 = r8.zzbyo;	 Catch:{ all -> 0x006d }
        r2.setClippingEnabled(r6);	 Catch:{ all -> 0x006d }
        r2 = "Displaying the 1x1 popup off the screen.";	 Catch:{ all -> 0x006d }
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r2);	 Catch:{ all -> 0x006d }
        r2 = r8.zzbyo;	 Catch:{ Exception -> 0x0069 }
        r0 = r0.getDecorView();	 Catch:{ Exception -> 0x0069 }
        r2.showAtLocation(r0, r6, r4, r4);	 Catch:{ Exception -> 0x0069 }
        goto L_0x006b;
    L_0x0069:
        r8.zzbyo = r1;	 Catch:{ all -> 0x006d }
    L_0x006b:
        monitor-exit(r3);	 Catch:{ all -> 0x006d }
        return;	 Catch:{ all -> 0x006d }
    L_0x006d:
        r0 = move-exception;	 Catch:{ all -> 0x006d }
        monitor-exit(r3);	 Catch:{ all -> 0x006d }
        throw r0;
    L_0x0070:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzii.zzqe():void");
    }
}
