package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IBinder;
import com.google.android.gms.ads.formats.NativeAd.Image;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzdu.zza;
import java.util.ArrayList;
import java.util.List;

@zzir
public class zzdz extends NativeAppInstallAd {
    private final zzdy zzbhg;
    private final List<Image> zzbhh = new ArrayList();
    private final zzdv zzbhi;

    public zzdz(zzdy com_google_android_gms_internal_zzdy) {
        zzdu zze;
        this.zzbhg = com_google_android_gms_internal_zzdy;
        try {
            List<Object> images = this.zzbhg.getImages();
            if (images != null) {
                for (Object zze2 : images) {
                    zze = zze(zze2);
                    if (zze != null) {
                        this.zzbhh.add(new zzdv(zze));
                    }
                }
            }
        } catch (Throwable e) {
            zzb.zzb("Failed to get image.", e);
        }
        zzdv com_google_android_gms_internal_zzdv = null;
        try {
            zze = this.zzbhg.zzkw();
            if (zze != null) {
                com_google_android_gms_internal_zzdv = new zzdv(zze);
            }
        } catch (Throwable e2) {
            zzb.zzb("Failed to get icon.", e2);
        }
        this.zzbhi = com_google_android_gms_internal_zzdv;
    }

    public void destroy() {
        try {
            this.zzbhg.destroy();
        } catch (Throwable e) {
            zzb.zzb("Failed to destroy", e);
        }
    }

    public CharSequence getBody() {
        try {
            return this.zzbhg.getBody();
        } catch (Throwable e) {
            zzb.zzb("Failed to get body.", e);
            return null;
        }
    }

    public CharSequence getCallToAction() {
        try {
            return this.zzbhg.getCallToAction();
        } catch (Throwable e) {
            zzb.zzb("Failed to get call to action.", e);
            return null;
        }
    }

    public Bundle getExtras() {
        try {
            return this.zzbhg.getExtras();
        } catch (Throwable e) {
            zzb.zzb("Failed to get extras", e);
            return null;
        }
    }

    public CharSequence getHeadline() {
        try {
            return this.zzbhg.getHeadline();
        } catch (Throwable e) {
            zzb.zzb("Failed to get headline.", e);
            return null;
        }
    }

    public Image getIcon() {
        return this.zzbhi;
    }

    public List<Image> getImages() {
        return this.zzbhh;
    }

    public CharSequence getPrice() {
        try {
            return this.zzbhg.getPrice();
        } catch (Throwable e) {
            zzb.zzb("Failed to get price.", e);
            return null;
        }
    }

    public Double getStarRating() {
        try {
            double starRating = this.zzbhg.getStarRating();
            return starRating == -1.0d ? null : Double.valueOf(starRating);
        } catch (Throwable e) {
            zzb.zzb("Failed to get star rating.", e);
            return null;
        }
    }

    public CharSequence getStore() {
        try {
            return this.zzbhg.getStore();
        } catch (Throwable e) {
            zzb.zzb("Failed to get store", e);
            return null;
        }
    }

    protected /* synthetic */ Object zzdh() {
        return zzkx();
    }

    zzdu zze(Object obj) {
        return obj instanceof IBinder ? zza.zzy((IBinder) obj) : null;
    }

    protected zzd zzkx() {
        try {
            return this.zzbhg.zzkx();
        } catch (Throwable e) {
            zzb.zzb("Failed to retrieve native ad engine.", e);
            return null;
        }
    }
}
