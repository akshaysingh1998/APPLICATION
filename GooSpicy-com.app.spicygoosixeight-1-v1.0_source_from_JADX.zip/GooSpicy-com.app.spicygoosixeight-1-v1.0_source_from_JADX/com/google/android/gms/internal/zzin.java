package com.google.android.gms.internal;

import android.os.Bundle;
import com.google.android.gms.ads.internal.formats.zzc;
import com.google.android.gms.ads.internal.formats.zzd;
import com.google.android.gms.ads.internal.formats.zzh;
import com.google.android.gms.internal.zzim.zza;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public class zzin implements zza<zzd> {
    private final boolean zzcae;
    private final boolean zzcaf;

    public zzin(boolean z, boolean z2) {
        this.zzcae = z;
        this.zzcaf = z2;
    }

    public /* synthetic */ zzh.zza zza(zzim com_google_android_gms_internal_zzim, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        return zzb(com_google_android_gms_internal_zzim, jSONObject);
    }

    public zzd zzb(zzim com_google_android_gms_internal_zzim, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        JSONObject jSONObject2 = jSONObject;
        List<zzlc> zza = com_google_android_gms_internal_zzim.zza(jSONObject2, "images", true, this.zzcae, this.zzcaf);
        Future zza2 = com_google_android_gms_internal_zzim.zza(jSONObject2, "app_icon", true, this.zzcae);
        Future zzg = com_google_android_gms_internal_zzim.zzg(jSONObject);
        List arrayList = new ArrayList();
        for (zzlc com_google_android_gms_internal_zzlc : zza) {
            arrayList.add((zzc) com_google_android_gms_internal_zzlc.get());
        }
        return new zzd(jSONObject2.getString("headline"), arrayList, jSONObject2.getString("body"), (zzdu) zza2.get(), jSONObject2.getString("call_to_action"), jSONObject2.optDouble("rating", -1.0d), jSONObject2.optString("store"), jSONObject2.optString(Param.PRICE), (com.google.android.gms.ads.internal.formats.zza) zzg.get(), new Bundle());
    }
}
