package com.google.android.gms.internal;

import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.bumptech.glide.load.Key;
import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@zzir
public class zzhq implements zzho {
    private final Context mContext;
    final Set<WebView> zzbwl = Collections.synchronizedSet(new HashSet());

    public zzhq(Context context) {
        this.mContext = context;
    }

    public void zza(String str, final String str2, final String str3) {
        zzb.zzcw("Fetching assets for the given html");
        zzkl.zzclg.post(new Runnable(this) {
            final /* synthetic */ zzhq zzbwo;

            public void run() {
                final WebView zzpn = this.zzbwo.zzpn();
                zzpn.setWebViewClient(new WebViewClient(this) {
                    final /* synthetic */ C04531 zzbwp;

                    public void onPageFinished(WebView webView, String str) {
                        zzb.zzcw("Loading assets have finished");
                        this.zzbwp.zzbwo.zzbwl.remove(zzpn);
                    }

                    public void onReceivedError(WebView webView, int i, String str, String str2) {
                        zzb.zzcy("Loading assets have failed.");
                        this.zzbwp.zzbwo.zzbwl.remove(zzpn);
                    }
                });
                this.zzbwo.zzbwl.add(zzpn);
                zzpn.loadDataWithBaseURL(str2, str3, "text/html", Key.STRING_CHARSET_NAME, null);
                zzb.zzcw("Fetching assets finished.");
            }
        });
    }

    public WebView zzpn() {
        WebView webView = new WebView(this.mContext);
        webView.getSettings().setJavaScriptEnabled(true);
        return webView;
    }
}
