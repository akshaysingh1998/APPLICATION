package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.Map;

@zzir
public final class zzeq implements zzet {
    private void zzb(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str = (String) map.get("label");
        String str2 = (String) map.get("start_label");
        String str3 = (String) map.get("timestamp");
        if (TextUtils.isEmpty(str)) {
            zzb.zzcy("No label given for CSI tick.");
        } else if (TextUtils.isEmpty(str3)) {
            zzb.zzcy("No timestamp given for CSI tick.");
        } else {
            try {
                long zzd = zzd(Long.parseLong(str3));
                if (TextUtils.isEmpty(str2)) {
                    str2 = "native:view_load";
                }
                com_google_android_gms_internal_zzll.zzut().zza(str, str2, zzd);
            } catch (Throwable e) {
                zzb.zzd("Malformed timestamp for CSI tick.", e);
            }
        }
    }

    private void zzc(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str = (String) map.get(Param.VALUE);
        if (TextUtils.isEmpty(str)) {
            zzb.zzcy("No value given for CSI experiment.");
            return;
        }
        zzdk zzkf = com_google_android_gms_internal_zzll.zzut().zzkf();
        if (zzkf == null) {
            zzb.zzcy("No ticker for WebView, dropping experiment ID.");
        } else {
            zzkf.zzh("e", str);
        }
    }

    private long zzd(long j) {
        return zzu.zzfu().elapsedRealtime() + (j - zzu.zzfu().currentTimeMillis());
    }

    private void zzd(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str;
        String str2 = (String) map.get("name");
        String str3 = (String) map.get(Param.VALUE);
        if (TextUtils.isEmpty(str3)) {
            str = "No value given for CSI extra.";
        } else if (TextUtils.isEmpty(str2)) {
            str = "No name given for CSI extra.";
        } else {
            zzdk zzkf = com_google_android_gms_internal_zzll.zzut().zzkf();
            if (zzkf == null) {
                str = "No ticker for WebView, dropping extra parameter.";
            } else {
                zzkf.zzh(str2, str3);
                return;
            }
        }
        zzb.zzcy(str);
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str = (String) map.get("action");
        if ("tick".equals(str)) {
            zzb(com_google_android_gms_internal_zzll, map);
        } else if ("experiment".equals(str)) {
            zzc(com_google_android_gms_internal_zzll, map);
        } else {
            if ("extra".equals(str)) {
                zzd(com_google_android_gms_internal_zzll, map);
            }
        }
    }
}
