package com.google.android.gms.internal;

import android.content.ComponentName;
import android.support.customtabs.CustomTabsClient;
import android.support.customtabs.CustomTabsServiceConnection;
import java.lang.ref.WeakReference;

public class zzapi extends CustomTabsServiceConnection {
    private WeakReference<zzapj> bjc;

    public zzapi(zzapj com_google_android_gms_internal_zzapj) {
        this.bjc = new WeakReference(com_google_android_gms_internal_zzapj);
    }

    public void onCustomTabsServiceConnected(ComponentName componentName, CustomTabsClient customTabsClient) {
        zzapj com_google_android_gms_internal_zzapj = (zzapj) this.bjc.get();
        if (com_google_android_gms_internal_zzapj != null) {
            com_google_android_gms_internal_zzapj.zza(customTabsClient);
        }
    }

    public void onServiceDisconnected(ComponentName componentName) {
        zzapj com_google_android_gms_internal_zzapj = (zzapj) this.bjc.get();
        if (com_google_android_gms_internal_zzapj != null) {
            com_google_android_gms_internal_zzapj.zzkm();
        }
    }
}
