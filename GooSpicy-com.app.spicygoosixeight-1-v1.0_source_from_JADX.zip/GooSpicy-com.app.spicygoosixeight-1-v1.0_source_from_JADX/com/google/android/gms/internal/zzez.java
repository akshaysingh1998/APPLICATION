package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zze;
import com.google.android.gms.common.util.zzf;
import java.util.Map;

@zzir
public class zzez implements zzet {
    static final Map<String, Integer> zzbiz = zzf.zza("resize", Integer.valueOf(1), "playVideo", Integer.valueOf(2), "storePicture", Integer.valueOf(3), "createCalendarEvent", Integer.valueOf(4), "setOrientationProperties", Integer.valueOf(5), "closeResizedAd", Integer.valueOf(6));
    private final zze zzbix;
    private final zzhe zzbiy;

    public zzez(zze com_google_android_gms_ads_internal_zze, zzhe com_google_android_gms_internal_zzhe) {
        this.zzbix = com_google_android_gms_ads_internal_zze;
        this.zzbiy = com_google_android_gms_internal_zzhe;
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        int intValue = ((Integer) zzbiz.get((String) map.get("a"))).intValue();
        if (intValue != 5 && this.zzbix != null && !this.zzbix.zzem()) {
            this.zzbix.zzt(null);
        } else if (intValue != 1) {
            switch (intValue) {
                case 3:
                    new zzhg(com_google_android_gms_internal_zzll, map).execute();
                    return;
                case 4:
                    new zzhd(com_google_android_gms_internal_zzll, map).execute();
                    return;
                case 5:
                    new zzhf(com_google_android_gms_internal_zzll, map).execute();
                    return;
                case 6:
                    this.zzbiy.zzs(true);
                    return;
                default:
                    zzb.zzcx("Unknown MRAID command called.");
                    return;
            }
        } else {
            this.zzbiy.execute(map);
        }
    }
}
