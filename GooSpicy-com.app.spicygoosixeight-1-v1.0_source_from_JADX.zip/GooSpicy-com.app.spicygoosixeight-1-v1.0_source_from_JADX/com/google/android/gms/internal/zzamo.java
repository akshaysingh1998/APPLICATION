package com.google.android.gms.internal;

public interface zzamo {
    boolean zza(zzamp com_google_android_gms_internal_zzamp);

    boolean zzh(Class<?> cls);
}
