package com.google.android.gms.internal;

import java.util.concurrent.TimeUnit;

@zzir
public class zzla<T> implements zzlc<T> {
    private final T zzcnr;
    private final zzld zzcnt = new zzld();

    public zzla(T t) {
        this.zzcnr = t;
        this.zzcnt.zzua();
    }

    public boolean cancel(boolean z) {
        return false;
    }

    public T get() {
        return this.zzcnr;
    }

    public T get(long j, TimeUnit timeUnit) {
        return this.zzcnr;
    }

    public boolean isCancelled() {
        return false;
    }

    public boolean isDone() {
        return true;
    }

    public void zzb(Runnable runnable) {
        this.zzcnt.zzb(runnable);
    }
}
