package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import android.view.View;
import com.google.android.gms.ads.internal.zzh;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzdn.zza;

@zzir
public final class zzdl extends zza {
    private final zzh zzbei;
    @Nullable
    private final String zzbej;
    private final String zzbek;

    public zzdl(zzh com_google_android_gms_ads_internal_zzh, @Nullable String str, String str2) {
        this.zzbei = com_google_android_gms_ads_internal_zzh;
        this.zzbej = str;
        this.zzbek = str2;
    }

    public String getContent() {
        return this.zzbek;
    }

    public void recordClick() {
        this.zzbei.zzei();
    }

    public void recordImpression() {
        this.zzbei.zzej();
    }

    public void zzi(zzd com_google_android_gms_dynamic_zzd) {
        if (com_google_android_gms_dynamic_zzd != null) {
            this.zzbei.zzc((View) zze.zzad(com_google_android_gms_dynamic_zzd));
        }
    }

    public String zzkk() {
        return this.zzbej;
    }
}
