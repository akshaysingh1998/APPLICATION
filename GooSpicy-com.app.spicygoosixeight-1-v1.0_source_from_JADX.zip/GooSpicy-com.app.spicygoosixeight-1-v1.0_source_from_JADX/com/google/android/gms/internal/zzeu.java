package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzu;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.io.BufferedOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.json.JSONArray;
import org.json.JSONObject;

@zzir
public class zzeu implements zzet {
    private final Context mContext;
    private final VersionInfoParcel zzalm;

    @zzir
    static class zza {
        private final String mValue;
        private final String zzaxn;

        public zza(String str, String str2) {
            this.zzaxn = str;
            this.mValue = str2;
        }

        public String getKey() {
            return this.zzaxn;
        }

        public String getValue() {
            return this.mValue;
        }
    }

    @zzir
    static class zzb {
        private final String zzbim;
        private final URL zzbin;
        private final ArrayList<zza> zzbio;
        private final String zzbip;

        public zzb(String str, URL url, ArrayList<zza> arrayList, String str2) {
            this.zzbim = str;
            this.zzbin = url;
            if (arrayList == null) {
                this.zzbio = new ArrayList();
            } else {
                this.zzbio = arrayList;
            }
            this.zzbip = str2;
        }

        public String zzlg() {
            return this.zzbim;
        }

        public URL zzlh() {
            return this.zzbin;
        }

        public ArrayList<zza> zzli() {
            return this.zzbio;
        }

        public String zzlj() {
            return this.zzbip;
        }
    }

    @zzir
    class zzc {
        final /* synthetic */ zzeu zzbij;
        private final zzd zzbiq;
        private final boolean zzbir;
        private final String zzbis;

        public zzc(zzeu com_google_android_gms_internal_zzeu, boolean z, zzd com_google_android_gms_internal_zzeu_zzd, String str) {
            this.zzbij = com_google_android_gms_internal_zzeu;
            this.zzbir = z;
            this.zzbiq = com_google_android_gms_internal_zzeu_zzd;
            this.zzbis = str;
        }

        public String getReason() {
            return this.zzbis;
        }

        public boolean isSuccess() {
            return this.zzbir;
        }

        public zzd zzlk() {
            return this.zzbiq;
        }
    }

    @zzir
    static class zzd {
        private final String zzbfm;
        private final String zzbim;
        private final int zzbit;
        private final List<zza> zzbiu;

        public zzd(String str, int i, List<zza> list, String str2) {
            this.zzbim = str;
            this.zzbit = i;
            if (list == null) {
                this.zzbiu = new ArrayList();
            } else {
                this.zzbiu = list;
            }
            this.zzbfm = str2;
        }

        public String getBody() {
            return this.zzbfm;
        }

        public int getResponseCode() {
            return this.zzbit;
        }

        public String zzlg() {
            return this.zzbim;
        }

        public Iterable<zza> zzll() {
            return this.zzbiu;
        }
    }

    public zzeu(Context context, VersionInfoParcel versionInfoParcel) {
        this.mContext = context;
        this.zzalm = versionInfoParcel;
    }

    protected zzc zza(zzb com_google_android_gms_internal_zzeu_zzb) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) com_google_android_gms_internal_zzeu_zzb.zzlh().openConnection();
            zzu.zzfq().zza(this.mContext, this.zzalm.zzcs, false, httpURLConnection);
            Iterator it = com_google_android_gms_internal_zzeu_zzb.zzli().iterator();
            while (it.hasNext()) {
                zza com_google_android_gms_internal_zzeu_zza = (zza) it.next();
                httpURLConnection.addRequestProperty(com_google_android_gms_internal_zzeu_zza.getKey(), com_google_android_gms_internal_zzeu_zza.getValue());
            }
            if (!TextUtils.isEmpty(com_google_android_gms_internal_zzeu_zzb.zzlj())) {
                httpURLConnection.setDoOutput(true);
                byte[] bytes = com_google_android_gms_internal_zzeu_zzb.zzlj().getBytes();
                httpURLConnection.setFixedLengthStreamingMode(bytes.length);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
                bufferedOutputStream.write(bytes);
                bufferedOutputStream.close();
            }
            List arrayList = new ArrayList();
            if (httpURLConnection.getHeaderFields() != null) {
                for (Entry entry : httpURLConnection.getHeaderFields().entrySet()) {
                    for (String com_google_android_gms_internal_zzeu_zza2 : (List) entry.getValue()) {
                        arrayList.add(new zza((String) entry.getKey(), com_google_android_gms_internal_zzeu_zza2));
                    }
                }
            }
            return new zzc(this, true, new zzd(com_google_android_gms_internal_zzeu_zzb.zzlg(), httpURLConnection.getResponseCode(), arrayList, zzu.zzfq().zza(new InputStreamReader(httpURLConnection.getInputStream()))), null);
        } catch (Exception e) {
            return new zzc(this, false, null, e.toString());
        }
    }

    protected JSONObject zza(zzd com_google_android_gms_internal_zzeu_zzd) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("http_request_id", com_google_android_gms_internal_zzeu_zzd.zzlg());
            if (com_google_android_gms_internal_zzeu_zzd.getBody() != null) {
                jSONObject.put("body", com_google_android_gms_internal_zzeu_zzd.getBody());
            }
            JSONArray jSONArray = new JSONArray();
            for (zza com_google_android_gms_internal_zzeu_zza : com_google_android_gms_internal_zzeu_zzd.zzll()) {
                jSONArray.put(new JSONObject().put("key", com_google_android_gms_internal_zzeu_zza.getKey()).put(Param.VALUE, com_google_android_gms_internal_zzeu_zza.getValue()));
            }
            jSONObject.put("headers", jSONArray);
            jSONObject.put("response_code", com_google_android_gms_internal_zzeu_zzd.getResponseCode());
            return jSONObject;
        } catch (Throwable e) {
            com.google.android.gms.ads.internal.util.client.zzb.zzb("Error constructing JSON for http response.", e);
            return jSONObject;
        }
    }

    public void zza(final zzll com_google_android_gms_internal_zzll, final Map<String, String> map) {
        zzkk.zza(new Runnable(this) {
            final /* synthetic */ zzeu zzbij;

            public void run() {
                com.google.android.gms.ads.internal.util.client.zzb.zzcw("Received Http request.");
                final JSONObject zzaw = this.zzbij.zzaw((String) map.get("http_request"));
                if (zzaw == null) {
                    com.google.android.gms.ads.internal.util.client.zzb.m9e("Response should not be null.");
                } else {
                    zzkl.zzclg.post(new Runnable(this) {
                        final /* synthetic */ C04131 zzbil;

                        public void run() {
                            com_google_android_gms_internal_zzll.zzb("fetchHttpRequestCompleted", zzaw);
                            com.google.android.gms.ads.internal.util.client.zzb.zzcw("Dispatched http response.");
                        }
                    });
                }
            }
        });
    }

    public org.json.JSONObject zzaw(java.lang.String r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r6 = this;
        r0 = 0;
        r1 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x0077 }
        r1.<init>(r7);	 Catch:{ JSONException -> 0x0077 }
        r7 = new org.json.JSONObject;
        r7.<init>();
        r2 = "";
        r3 = "http_request_id";	 Catch:{ Exception -> 0x0056 }
        r3 = r1.optString(r3);	 Catch:{ Exception -> 0x0056 }
        r1 = r6.zzc(r1);	 Catch:{ Exception -> 0x0054 }
        r1 = r6.zza(r1);	 Catch:{ Exception -> 0x0054 }
        r2 = r1.isSuccess();	 Catch:{ Exception -> 0x0054 }
        if (r2 == 0) goto L_0x0035;	 Catch:{ Exception -> 0x0054 }
    L_0x0021:
        r1 = r1.zzlk();	 Catch:{ Exception -> 0x0054 }
        r1 = r6.zza(r1);	 Catch:{ Exception -> 0x0054 }
        r2 = "response";	 Catch:{ Exception -> 0x0054 }
        r7.put(r2, r1);	 Catch:{ Exception -> 0x0054 }
        r1 = "success";	 Catch:{ Exception -> 0x0054 }
        r2 = 1;	 Catch:{ Exception -> 0x0054 }
        r7.put(r1, r2);	 Catch:{ Exception -> 0x0054 }
        return r7;	 Catch:{ Exception -> 0x0054 }
    L_0x0035:
        r2 = "response";	 Catch:{ Exception -> 0x0054 }
        r4 = new org.json.JSONObject;	 Catch:{ Exception -> 0x0054 }
        r4.<init>();	 Catch:{ Exception -> 0x0054 }
        r5 = "http_request_id";	 Catch:{ Exception -> 0x0054 }
        r4 = r4.put(r5, r3);	 Catch:{ Exception -> 0x0054 }
        r7.put(r2, r4);	 Catch:{ Exception -> 0x0054 }
        r2 = "success";	 Catch:{ Exception -> 0x0054 }
        r7.put(r2, r0);	 Catch:{ Exception -> 0x0054 }
        r2 = "reason";	 Catch:{ Exception -> 0x0054 }
        r1 = r1.getReason();	 Catch:{ Exception -> 0x0054 }
        r7.put(r2, r1);	 Catch:{ Exception -> 0x0054 }
        return r7;
    L_0x0054:
        r1 = move-exception;
        goto L_0x0058;
    L_0x0056:
        r1 = move-exception;
        r3 = r2;
    L_0x0058:
        r2 = "response";	 Catch:{ JSONException -> 0x0076 }
        r4 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x0076 }
        r4.<init>();	 Catch:{ JSONException -> 0x0076 }
        r5 = "http_request_id";	 Catch:{ JSONException -> 0x0076 }
        r3 = r4.put(r5, r3);	 Catch:{ JSONException -> 0x0076 }
        r7.put(r2, r3);	 Catch:{ JSONException -> 0x0076 }
        r2 = "success";	 Catch:{ JSONException -> 0x0076 }
        r7.put(r2, r0);	 Catch:{ JSONException -> 0x0076 }
        r0 = "reason";	 Catch:{ JSONException -> 0x0076 }
        r1 = r1.toString();	 Catch:{ JSONException -> 0x0076 }
        r7.put(r0, r1);	 Catch:{ JSONException -> 0x0076 }
    L_0x0076:
        return r7;
    L_0x0077:
        r7 = "The request is not a valid JSON.";
        com.google.android.gms.ads.internal.util.client.zzb.m9e(r7);
        r7 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x0088 }
        r7.<init>();	 Catch:{ JSONException -> 0x0088 }
        r1 = "success";	 Catch:{ JSONException -> 0x0088 }
        r7 = r7.put(r1, r0);	 Catch:{ JSONException -> 0x0088 }
        return r7;
    L_0x0088:
        r7 = new org.json.JSONObject;
        r7.<init>();
        return r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzeu.zzaw(java.lang.String):org.json.JSONObject");
    }

    protected zzb zzc(JSONObject jSONObject) {
        String optString = jSONObject.optString("http_request_id");
        String optString2 = jSONObject.optString("url");
        URL url = null;
        String optString3 = jSONObject.optString("post_body", null);
        try {
            url = new URL(optString2);
        } catch (Throwable e) {
            com.google.android.gms.ads.internal.util.client.zzb.zzb("Error constructing http request.", e);
        }
        ArrayList arrayList = new ArrayList();
        JSONArray optJSONArray = jSONObject.optJSONArray("headers");
        if (optJSONArray == null) {
            optJSONArray = new JSONArray();
        }
        for (int i = 0; i < optJSONArray.length(); i++) {
            JSONObject optJSONObject = optJSONArray.optJSONObject(i);
            if (optJSONObject != null) {
                arrayList.add(new zza(optJSONObject.optString("key"), optJSONObject.optString(Param.VALUE)));
            }
        }
        return new zzb(optString, url, arrayList, optString3);
    }
}
