package com.google.android.gms.internal;

public abstract class zzre<T> {
    private static zza vA = null;
    private static int vB = 0;
    private static String vC = "com.google.android.providers.gsf.permission.READ_GSERVICES";
    private static final Object zzamp = new Object();
    private T vD = null;
    protected final String zzaxn;
    protected final T zzaxo;

    private interface zza {
        Long getLong(String str, Long l);

        String getString(String str, String str2);

        Boolean zza(String str, Boolean bool);

        Float zzb(String str, Float f);

        Integer zzb(String str, Integer num);
    }

    class C09601 extends zzre<Boolean> {
        C09601(String str, Boolean bool) {
            super(str, bool);
        }

        protected /* synthetic */ Object zzgz(String str) {
            return zzha(str);
        }

        protected Boolean zzha(String str) {
            return null.zza(this.zzaxn, (Boolean) this.zzaxo);
        }
    }

    class C09612 extends zzre<Long> {
        C09612(String str, Long l) {
            super(str, l);
        }

        protected /* synthetic */ Object zzgz(String str) {
            return zzhb(str);
        }

        protected Long zzhb(String str) {
            return null.getLong(this.zzaxn, (Long) this.zzaxo);
        }
    }

    class C09623 extends zzre<Integer> {
        C09623(String str, Integer num) {
            super(str, num);
        }

        protected /* synthetic */ Object zzgz(String str) {
            return zzhc(str);
        }

        protected Integer zzhc(String str) {
            return null.zzb(this.zzaxn, (Integer) this.zzaxo);
        }
    }

    class C09634 extends zzre<Float> {
        C09634(String str, Float f) {
            super(str, f);
        }

        protected /* synthetic */ Object zzgz(String str) {
            return zzhd(str);
        }

        protected Float zzhd(String str) {
            return null.zzb(this.zzaxn, (Float) this.zzaxo);
        }
    }

    class C09645 extends zzre<String> {
        C09645(String str, String str2) {
            super(str, str2);
        }

        protected /* synthetic */ Object zzgz(String str) {
            return zzhe(str);
        }

        protected String zzhe(String str) {
            return null.getString(this.zzaxn, (String) this.zzaxo);
        }
    }

    protected zzre(String str, T t) {
        this.zzaxn = str;
        this.zzaxo = t;
    }

    public static zzre<Float> zza(String str, Float f) {
        return new C09634(str, f);
    }

    public static zzre<Integer> zza(String str, Integer num) {
        return new C09623(str, num);
    }

    public static zzre<Long> zza(String str, Long l) {
        return new C09612(str, l);
    }

    public static zzre<String> zzab(String str, String str2) {
        return new C09645(str, str2);
    }

    public static zzre<Boolean> zzm(String str, boolean z) {
        return new C09601(str, Boolean.valueOf(z));
    }

    public final T get() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r3.zzaxn;	 Catch:{ SecurityException -> 0x0007 }
        r0 = r3.zzgz(r0);	 Catch:{ SecurityException -> 0x0007 }
        return r0;
    L_0x0007:
        r0 = android.os.Binder.clearCallingIdentity();
        r2 = r3.zzaxn;	 Catch:{ all -> 0x0015 }
        r2 = r3.zzgz(r2);	 Catch:{ all -> 0x0015 }
        android.os.Binder.restoreCallingIdentity(r0);
        return r2;
    L_0x0015:
        r2 = move-exception;
        android.os.Binder.restoreCallingIdentity(r0);
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzre.get():T");
    }

    protected abstract T zzgz(String str);
}
