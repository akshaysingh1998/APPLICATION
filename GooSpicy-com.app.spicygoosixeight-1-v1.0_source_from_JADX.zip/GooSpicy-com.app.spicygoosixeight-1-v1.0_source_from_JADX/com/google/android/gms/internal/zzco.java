package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.graphics.Rect;
import android.os.PowerManager;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.common.util.zzs;

@TargetApi(14)
@zzir
public class zzco extends Thread {
    private boolean mStarted = false;
    private final Object zzail;
    private final int zzart;
    private final int zzarv;
    private boolean zzash = false;
    private final zzcn zzasi;
    private final zzcm zzasj;
    private final zziq zzask;
    private final int zzasl;
    private final int zzasm;
    private final int zzasn;
    private boolean zzbl = false;

    @zzir
    class zza {
        final /* synthetic */ zzco zzasp;
        final int zzasv;
        final int zzasw;

        zza(zzco com_google_android_gms_internal_zzco, int i, int i2) {
            this.zzasp = com_google_android_gms_internal_zzco;
            this.zzasv = i;
            this.zzasw = i2;
        }
    }

    public zzco(zzcn com_google_android_gms_internal_zzcn, zzcm com_google_android_gms_internal_zzcm, zziq com_google_android_gms_internal_zziq) {
        this.zzasi = com_google_android_gms_internal_zzcn;
        this.zzasj = com_google_android_gms_internal_zzcm;
        this.zzask = com_google_android_gms_internal_zziq;
        this.zzail = new Object();
        this.zzart = ((Integer) zzdc.zzazg.get()).intValue();
        this.zzasm = ((Integer) zzdc.zzazh.get()).intValue();
        this.zzarv = ((Integer) zzdc.zzazi.get()).intValue();
        this.zzasn = ((Integer) zzdc.zzazj.get()).intValue();
        this.zzasl = ((Integer) zzdc.zzazk.get()).intValue();
        setName("ContentFetchTask");
    }

    public void run() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
    L_0x0000:
        r0 = r3.zzia();	 Catch:{ Throwable -> 0x002a }
        if (r0 == 0) goto L_0x001b;	 Catch:{ Throwable -> 0x002a }
    L_0x0006:
        r0 = r3.zzasi;	 Catch:{ Throwable -> 0x002a }
        r0 = r0.getActivity();	 Catch:{ Throwable -> 0x002a }
        if (r0 != 0) goto L_0x0017;	 Catch:{ Throwable -> 0x002a }
    L_0x000e:
        r0 = "ContentFetchThread: no activity. Sleeping.";	 Catch:{ Throwable -> 0x002a }
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r0);	 Catch:{ Throwable -> 0x002a }
    L_0x0013:
        r3.zzic();	 Catch:{ Throwable -> 0x002a }
        goto L_0x0021;	 Catch:{ Throwable -> 0x002a }
    L_0x0017:
        r3.zza(r0);	 Catch:{ Throwable -> 0x002a }
        goto L_0x0021;	 Catch:{ Throwable -> 0x002a }
    L_0x001b:
        r0 = "ContentFetchTask: sleeping";	 Catch:{ Throwable -> 0x002a }
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r0);	 Catch:{ Throwable -> 0x002a }
        goto L_0x0013;	 Catch:{ Throwable -> 0x002a }
    L_0x0021:
        r0 = r3.zzasl;	 Catch:{ Throwable -> 0x002a }
        r0 = r0 * 1000;	 Catch:{ Throwable -> 0x002a }
        r0 = (long) r0;	 Catch:{ Throwable -> 0x002a }
        java.lang.Thread.sleep(r0);	 Catch:{ Throwable -> 0x002a }
        goto L_0x0036;
    L_0x002a:
        r0 = move-exception;
        r1 = "Error in ContentFetchTask";
        com.google.android.gms.ads.internal.util.client.zzb.zzb(r1, r0);
        r1 = r3.zzask;
        r2 = 1;
        r1.zza(r0, r2);
    L_0x0036:
        r0 = r3.zzail;
        monitor-enter(r0);
    L_0x0039:
        r1 = r3.zzash;	 Catch:{ all -> 0x004a }
        if (r1 == 0) goto L_0x0048;
    L_0x003d:
        r1 = "ContentFetchTask: waiting";	 Catch:{ InterruptedException -> 0x0039 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r1);	 Catch:{ InterruptedException -> 0x0039 }
        r1 = r3.zzail;	 Catch:{ InterruptedException -> 0x0039 }
        r1.wait();	 Catch:{ InterruptedException -> 0x0039 }
        goto L_0x0039;
    L_0x0048:
        monitor-exit(r0);	 Catch:{ all -> 0x004a }
        goto L_0x0000;	 Catch:{ all -> 0x004a }
    L_0x004a:
        r1 = move-exception;	 Catch:{ all -> 0x004a }
        monitor-exit(r0);	 Catch:{ all -> 0x004a }
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzco.run():void");
    }

    public void wakeup() {
        synchronized (this.zzail) {
            this.zzash = false;
            this.zzail.notifyAll();
            zzb.zzcw("ContentFetchThread: wakeup");
        }
    }

    zza zza(View view, zzcl com_google_android_gms_internal_zzcl) {
        int i = 0;
        if (view == null) {
            return new zza(this, 0, 0);
        }
        boolean globalVisibleRect = view.getGlobalVisibleRect(new Rect());
        if ((view instanceof TextView) && !(view instanceof EditText)) {
            CharSequence text = ((TextView) view).getText();
            if (TextUtils.isEmpty(text)) {
                return new zza(this, 0, 0);
            }
            com_google_android_gms_internal_zzcl.zze(text.toString(), globalVisibleRect);
            return new zza(this, 1, 0);
        } else if ((view instanceof WebView) && !(view instanceof zzll)) {
            com_google_android_gms_internal_zzcl.zzhv();
            return zza((WebView) view, com_google_android_gms_internal_zzcl, globalVisibleRect) ? new zza(this, 0, 1) : new zza(this, 0, 0);
        } else if (!(view instanceof ViewGroup)) {
            return new zza(this, 0, 0);
        } else {
            ViewGroup viewGroup = (ViewGroup) view;
            int i2 = 0;
            int i3 = i2;
            while (i < viewGroup.getChildCount()) {
                zza zza = zza(viewGroup.getChildAt(i), com_google_android_gms_internal_zzcl);
                i2 += zza.zzasv;
                i3 += zza.zzasw;
                i++;
            }
            return new zza(this, i2, i3);
        }
    }

    void zza(android.app.Activity r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        if (r3 != 0) goto L_0x0003;
    L_0x0002:
        return;
    L_0x0003:
        r0 = 0;
        r1 = r3.getWindow();	 Catch:{ Throwable -> 0x0025 }
        if (r1 == 0) goto L_0x002a;	 Catch:{ Throwable -> 0x0025 }
    L_0x000a:
        r1 = r3.getWindow();	 Catch:{ Throwable -> 0x0025 }
        r1 = r1.getDecorView();	 Catch:{ Throwable -> 0x0025 }
        if (r1 == 0) goto L_0x002a;	 Catch:{ Throwable -> 0x0025 }
    L_0x0014:
        r3 = r3.getWindow();	 Catch:{ Throwable -> 0x0025 }
        r3 = r3.getDecorView();	 Catch:{ Throwable -> 0x0025 }
        r1 = 16908290; // 0x1020002 float:2.3877235E-38 double:8.353805E-317;	 Catch:{ Throwable -> 0x0025 }
        r3 = r3.findViewById(r1);	 Catch:{ Throwable -> 0x0025 }
        r0 = r3;
        goto L_0x002a;
    L_0x0025:
        r3 = "Failed getting root view of activity. Content not extracted.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r3);
    L_0x002a:
        if (r0 != 0) goto L_0x002d;
    L_0x002c:
        return;
    L_0x002d:
        r2.zze(r0);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzco.zza(android.app.Activity):void");
    }

    void zza(com.google.android.gms.internal.zzcl r5, android.webkit.WebView r6, java.lang.String r7, boolean r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r5.zzhu();
        r0 = 1;
        r1 = android.text.TextUtils.isEmpty(r7);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        if (r1 != 0) goto L_0x0054;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
    L_0x000a:
        r1 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1.<init>(r7);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r7 = "text";	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r7 = r1.optString(r7);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1 = r6.getTitle();	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1 = android.text.TextUtils.isEmpty(r1);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        if (r1 != 0) goto L_0x0051;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
    L_0x001f:
        r6 = r6.getTitle();	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r6 = java.lang.String.valueOf(r6);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1 = new java.lang.StringBuilder;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r2 = java.lang.String.valueOf(r6);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r2 = r2.length();	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r2 = r2 + r0;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r3 = java.lang.String.valueOf(r7);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r3 = r3.length();	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r2 = r2 + r3;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1.<init>(r2);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1.append(r6);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r6 = "\n";	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1.append(r6);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r1.append(r7);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r6 = r1.toString();	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r5.zzd(r6, r8);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        goto L_0x0054;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
    L_0x0051:
        r5.zzd(r7, r8);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
    L_0x0054:
        r6 = r5.zzhq();	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        if (r6 == 0) goto L_0x0071;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
    L_0x005a:
        r6 = r4.zzasj;	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        r6.zzb(r5);	 Catch:{ JSONException -> 0x006c, Throwable -> 0x0060 }
        return;
    L_0x0060:
        r5 = move-exception;
        r6 = "Failed to get webview content.";
        com.google.android.gms.ads.internal.util.client.zzb.zza(r6, r5);
        r6 = r4.zzask;
        r6.zza(r5, r0);
        return;
    L_0x006c:
        r5 = "Json string may be malformed.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r5);
    L_0x0071:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzco.zza(com.google.android.gms.internal.zzcl, android.webkit.WebView, java.lang.String, boolean):void");
    }

    boolean zza(RunningAppProcessInfo runningAppProcessInfo) {
        return runningAppProcessInfo.importance == 100;
    }

    @TargetApi(19)
    boolean zza(final WebView webView, final zzcl com_google_android_gms_internal_zzcl, final boolean z) {
        if (!zzs.zzavq()) {
            return false;
        }
        com_google_android_gms_internal_zzcl.zzhv();
        webView.post(new Runnable(this) {
            final /* synthetic */ zzco zzasp;
            ValueCallback<String> zzasq = new C04051(this);

            class C04051 implements ValueCallback<String> {
                final /* synthetic */ C04062 zzasu;

                C04051(C04062 c04062) {
                    this.zzasu = c04062;
                }

                public /* synthetic */ void onReceiveValue(Object obj) {
                    zzz((String) obj);
                }

                public void zzz(String str) {
                    this.zzasu.zzasp.zza(com_google_android_gms_internal_zzcl, webView, str, z);
                }
            }

            public void run() {
                /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
                /*
                r3 = this;
                r0 = r2;
                r0 = r0.getSettings();
                r0 = r0.getJavaScriptEnabled();
                if (r0 == 0) goto L_0x001d;
            L_0x000c:
                r0 = r2;	 Catch:{ Throwable -> 0x0016 }
                r1 = "(function() { return  {text:document.body.innerText}})();";	 Catch:{ Throwable -> 0x0016 }
                r2 = r3.zzasq;	 Catch:{ Throwable -> 0x0016 }
                r0.evaluateJavascript(r1, r2);	 Catch:{ Throwable -> 0x0016 }
                return;
            L_0x0016:
                r0 = r3.zzasq;
                r1 = "";
                r0.onReceiveValue(r1);
            L_0x001d:
                return;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzco.2.run():void");
            }
        });
        return true;
    }

    boolean zze(final View view) {
        if (view == null) {
            return false;
        }
        view.post(new Runnable(this) {
            final /* synthetic */ zzco zzasp;

            public void run() {
                this.zzasp.zzf(view);
            }
        });
        return true;
    }

    void zzf(View view) {
        try {
            zzcl com_google_android_gms_internal_zzcl = new zzcl(this.zzart, this.zzasm, this.zzarv, this.zzasn);
            zza zza = zza(view, com_google_android_gms_internal_zzcl);
            com_google_android_gms_internal_zzcl.zzhw();
            if (zza.zzasv != 0 || zza.zzasw != 0) {
                if (zza.zzasw != 0 || com_google_android_gms_internal_zzcl.zzhx() != 0) {
                    if (zza.zzasw != 0 || !this.zzasj.zza(com_google_android_gms_internal_zzcl)) {
                        this.zzasj.zzc(com_google_android_gms_internal_zzcl);
                    }
                }
            }
        } catch (Throwable e) {
            zzb.zzb("Exception in fetchContentOnUIThread", e);
            this.zzask.zza(e, true);
        }
    }

    public void zzhz() {
        synchronized (this.zzail) {
            if (this.mStarted) {
                zzb.zzcw("Content hash thread already started, quiting...");
                return;
            }
            this.mStarted = true;
            start();
        }
    }

    boolean zzia() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r7 = this;
        r0 = 0;
        r1 = r7.zzasi;	 Catch:{ Throwable -> 0x0051 }
        r1 = r1.getContext();	 Catch:{ Throwable -> 0x0051 }
        if (r1 != 0) goto L_0x000a;	 Catch:{ Throwable -> 0x0051 }
    L_0x0009:
        return r0;	 Catch:{ Throwable -> 0x0051 }
    L_0x000a:
        r2 = "activity";	 Catch:{ Throwable -> 0x0051 }
        r2 = r1.getSystemService(r2);	 Catch:{ Throwable -> 0x0051 }
        r2 = (android.app.ActivityManager) r2;	 Catch:{ Throwable -> 0x0051 }
        r3 = "keyguard";	 Catch:{ Throwable -> 0x0051 }
        r3 = r1.getSystemService(r3);	 Catch:{ Throwable -> 0x0051 }
        r3 = (android.app.KeyguardManager) r3;	 Catch:{ Throwable -> 0x0051 }
        if (r2 == 0) goto L_0x0051;	 Catch:{ Throwable -> 0x0051 }
    L_0x001c:
        if (r3 != 0) goto L_0x001f;	 Catch:{ Throwable -> 0x0051 }
    L_0x001e:
        return r0;	 Catch:{ Throwable -> 0x0051 }
    L_0x001f:
        r2 = r2.getRunningAppProcesses();	 Catch:{ Throwable -> 0x0051 }
        if (r2 != 0) goto L_0x0026;	 Catch:{ Throwable -> 0x0051 }
    L_0x0025:
        return r0;	 Catch:{ Throwable -> 0x0051 }
    L_0x0026:
        r2 = r2.iterator();	 Catch:{ Throwable -> 0x0051 }
    L_0x002a:
        r4 = r2.hasNext();	 Catch:{ Throwable -> 0x0051 }
        if (r4 == 0) goto L_0x0051;	 Catch:{ Throwable -> 0x0051 }
    L_0x0030:
        r4 = r2.next();	 Catch:{ Throwable -> 0x0051 }
        r4 = (android.app.ActivityManager.RunningAppProcessInfo) r4;	 Catch:{ Throwable -> 0x0051 }
        r5 = android.os.Process.myPid();	 Catch:{ Throwable -> 0x0051 }
        r6 = r4.pid;	 Catch:{ Throwable -> 0x0051 }
        if (r5 != r6) goto L_0x002a;	 Catch:{ Throwable -> 0x0051 }
    L_0x003e:
        r2 = r7.zza(r4);	 Catch:{ Throwable -> 0x0051 }
        if (r2 == 0) goto L_0x0051;	 Catch:{ Throwable -> 0x0051 }
    L_0x0044:
        r2 = r3.inKeyguardRestrictedInputMode();	 Catch:{ Throwable -> 0x0051 }
        if (r2 != 0) goto L_0x0051;	 Catch:{ Throwable -> 0x0051 }
    L_0x004a:
        r1 = r7.zzj(r1);	 Catch:{ Throwable -> 0x0051 }
        if (r1 == 0) goto L_0x0051;
    L_0x0050:
        r0 = 1;
    L_0x0051:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzco.zzia():boolean");
    }

    public zzcl zzib() {
        return this.zzasj.zzhy();
    }

    public void zzic() {
        synchronized (this.zzail) {
            this.zzash = true;
            boolean z = this.zzash;
            StringBuilder stringBuilder = new StringBuilder(42);
            stringBuilder.append("ContentFetchThread: paused, mPause = ");
            stringBuilder.append(z);
            zzb.zzcw(stringBuilder.toString());
        }
    }

    public boolean zzid() {
        return this.zzash;
    }

    boolean zzj(Context context) {
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        return powerManager == null ? false : powerManager.isScreenOn();
    }
}
