package com.google.android.gms.internal;

@zzir
public class zzjq {
    private final zzgo zzbok;
    private final zzjn zzcif;

    public zzjq(zzgo com_google_android_gms_internal_zzgo, zzjm com_google_android_gms_internal_zzjm) {
        this.zzbok = com_google_android_gms_internal_zzgo;
        this.zzcif = new zzjn(com_google_android_gms_internal_zzjm);
    }

    public zzgo zzrv() {
        return this.zzbok;
    }

    public zzjn zzrw() {
        return this.zzcif;
    }
}
