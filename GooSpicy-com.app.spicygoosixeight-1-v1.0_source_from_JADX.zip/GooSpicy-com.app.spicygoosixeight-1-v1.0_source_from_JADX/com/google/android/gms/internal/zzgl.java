package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@zzir
public class zzgl implements zzgc {
    private final Context mContext;
    private final Object zzail = new Object();
    private final zzdk zzajn;
    private final zzgn zzajz;
    private final boolean zzarj;
    private final boolean zzawl;
    private final zzge zzboi;
    private final AdRequestInfoParcel zzbox;
    private final long zzboy;
    private final long zzboz;
    private boolean zzbpb = false;
    private List<zzgi> zzbpd = new ArrayList();
    private zzgh zzbph;

    public zzgl(Context context, AdRequestInfoParcel adRequestInfoParcel, zzgn com_google_android_gms_internal_zzgn, zzge com_google_android_gms_internal_zzge, boolean z, boolean z2, long j, long j2, zzdk com_google_android_gms_internal_zzdk) {
        this.mContext = context;
        this.zzbox = adRequestInfoParcel;
        this.zzajz = com_google_android_gms_internal_zzgn;
        this.zzboi = com_google_android_gms_internal_zzge;
        this.zzarj = z;
        this.zzawl = z2;
        this.zzboy = j;
        this.zzboz = j2;
        this.zzajn = com_google_android_gms_internal_zzdk;
    }

    public void cancel() {
        synchronized (this.zzail) {
            this.zzbpb = true;
            if (this.zzbph != null) {
                this.zzbph.cancel();
            }
        }
    }

    public zzgi zzd(List<zzgd> list) {
        zzgl com_google_android_gms_internal_zzgl;
        zzgl com_google_android_gms_internal_zzgl2;
        ArrayList arrayList;
        zzb.zzcw("Starting mediation.");
        ArrayList arrayList2 = new ArrayList();
        zzdi zzkg = this.zzajn.zzkg();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            zzgd com_google_android_gms_internal_zzgd = (zzgd) it.next();
            String str = "Trying mediation network: ";
            String valueOf = String.valueOf(com_google_android_gms_internal_zzgd.zzbmz);
            zzb.zzcx(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            Iterator it2 = com_google_android_gms_internal_zzgd.zzbna.iterator();
            while (it2.hasNext()) {
                zzgi com_google_android_gms_internal_zzgi;
                String str2 = (String) it2.next();
                zzdi zzkg2 = com_google_android_gms_internal_zzgl.zzajn.zzkg();
                Object obj = com_google_android_gms_internal_zzgl.zzail;
                synchronized (obj) {
                    try {
                        if (com_google_android_gms_internal_zzgl.zzbpb) {
                            com_google_android_gms_internal_zzgi = new zzgi(-1);
                        } else {
                            Context context = com_google_android_gms_internal_zzgl.mContext;
                            zzgn com_google_android_gms_internal_zzgn = com_google_android_gms_internal_zzgl.zzajz;
                            zzge com_google_android_gms_internal_zzge = com_google_android_gms_internal_zzgl.zzboi;
                            AdRequestParcel adRequestParcel = com_google_android_gms_internal_zzgl.zzbox.zzcav;
                            AdSizeParcel adSizeParcel = com_google_android_gms_internal_zzgl.zzbox.zzaoy;
                            Iterator it3 = it;
                            VersionInfoParcel versionInfoParcel = com_google_android_gms_internal_zzgl.zzbox.zzaou;
                            zzdi com_google_android_gms_internal_zzdi = zzkg;
                            boolean z = com_google_android_gms_internal_zzgl.zzarj;
                            ArrayList arrayList3 = arrayList2;
                            boolean z2 = com_google_android_gms_internal_zzgl.zzawl;
                            AdRequestParcel adRequestParcel2 = adRequestParcel;
                            List list2 = com_google_android_gms_internal_zzgl.zzbox.zzapq;
                            AdRequestParcel adRequestParcel3 = adRequestParcel2;
                            NativeAdOptionsParcel nativeAdOptionsParcel = com_google_android_gms_internal_zzgl.zzbox.zzapm;
                            zzgh com_google_android_gms_internal_zzgh = com_google_android_gms_internal_zzgh;
                            zzge com_google_android_gms_internal_zzge2 = com_google_android_gms_internal_zzge;
                            String str3 = str2;
                            Object obj2 = obj;
                            zzgd com_google_android_gms_internal_zzgd2 = com_google_android_gms_internal_zzgd;
                            zzgh com_google_android_gms_internal_zzgh2 = com_google_android_gms_internal_zzgh;
                            zzdi com_google_android_gms_internal_zzdi2 = zzkg2;
                            zzgd com_google_android_gms_internal_zzgd3 = com_google_android_gms_internal_zzgd;
                            String str4 = str2;
                            AdSizeParcel adSizeParcel2 = adSizeParcel;
                            Iterator it4 = it2;
                            try {
                                com_google_android_gms_internal_zzgh = new zzgh(context, str3, com_google_android_gms_internal_zzgn, com_google_android_gms_internal_zzge2, com_google_android_gms_internal_zzgd2, adRequestParcel3, adSizeParcel2, versionInfoParcel, z, z2, nativeAdOptionsParcel, list2);
                            } catch (Throwable th) {
                                Throwable th2 = th;
                                com_google_android_gms_internal_zzgl2 = this;
                            }
                            try {
                                this.zzbph = com_google_android_gms_internal_zzgh2;
                                final zzgi zza = com_google_android_gms_internal_zzgl2.zzbph.zza(com_google_android_gms_internal_zzgl2.zzboy, com_google_android_gms_internal_zzgl2.zzboz);
                                com_google_android_gms_internal_zzgl2.zzbpd.add(zza);
                                if (zza.zzboq == 0) {
                                    zzb.zzcw("Adapter succeeded.");
                                    com_google_android_gms_internal_zzgl2.zzajn.zzh("mediation_network_succeed", str4);
                                    arrayList = arrayList3;
                                    if (!arrayList.isEmpty()) {
                                        com_google_android_gms_internal_zzgl2.zzajn.zzh("mediation_networks_fail", TextUtils.join(",", arrayList));
                                    }
                                    com_google_android_gms_internal_zzgl2.zzajn.zza(com_google_android_gms_internal_zzdi2, "mls");
                                    com_google_android_gms_internal_zzgl2.zzajn.zza(com_google_android_gms_internal_zzdi, "ttm");
                                    return zza;
                                }
                                zzdi com_google_android_gms_internal_zzdi3 = com_google_android_gms_internal_zzdi;
                                arrayList = arrayList3;
                                arrayList.add(str4);
                                com_google_android_gms_internal_zzgl2.zzajn.zza(com_google_android_gms_internal_zzdi2, "mlf");
                                if (zza.zzbos != null) {
                                    zzkl.zzclg.post(new Runnable(com_google_android_gms_internal_zzgl2) {
                                        final /* synthetic */ zzgl zzbpj;

                                        public void run() {
                                            try {
                                                zza.zzbos.destroy();
                                            } catch (Throwable e) {
                                                zzb.zzd("Could not destroy mediation adapter.", e);
                                            }
                                        }
                                    });
                                }
                                com_google_android_gms_internal_zzgl = com_google_android_gms_internal_zzgl2;
                                arrayList2 = arrayList;
                                it2 = it4;
                                zzkg = com_google_android_gms_internal_zzdi3;
                                it = it3;
                                com_google_android_gms_internal_zzgd = com_google_android_gms_internal_zzgd3;
                            } catch (Throwable th3) {
                                th2 = th3;
                            }
                        }
                    } catch (Throwable th4) {
                        th2 = th4;
                        com_google_android_gms_internal_zzgl2 = com_google_android_gms_internal_zzgl;
                        obj2 = obj;
                    }
                }
                return com_google_android_gms_internal_zzgi;
            }
        }
        arrayList = arrayList2;
        com_google_android_gms_internal_zzgl2 = com_google_android_gms_internal_zzgl;
        if (!arrayList.isEmpty()) {
            com_google_android_gms_internal_zzgl2.zzajn.zzh("mediation_networks_fail", TextUtils.join(",", arrayList));
        }
        return new zzgi(1);
        Throwable th5 = th2;
        throw th5;
    }

    public List<zzgi> zzmi() {
        return this.zzbpd;
    }
}
