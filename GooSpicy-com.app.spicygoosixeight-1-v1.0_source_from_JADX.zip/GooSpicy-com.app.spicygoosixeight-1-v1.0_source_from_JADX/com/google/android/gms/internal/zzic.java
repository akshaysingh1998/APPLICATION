package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.internal.zzab;
import com.google.android.gms.internal.zzlm.zza;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

@zzir
public abstract class zzic implements zzkn<Void>, zza {
    protected final Context mContext;
    protected final zzll zzbgj;
    protected final zzig.zza zzbxu;
    protected final zzjy.zza zzbxv;
    protected AdResponseParcel zzbxw;
    private Runnable zzbxx;
    protected final Object zzbxy = new Object();
    private AtomicBoolean zzbxz = new AtomicBoolean(true);

    class C04541 implements Runnable {
        final /* synthetic */ zzic zzbya;

        C04541(zzic com_google_android_gms_internal_zzic) {
            this.zzbya = com_google_android_gms_internal_zzic;
        }

        public void run() {
            if (this.zzbya.zzbxz.get()) {
                zzb.m9e("Timed out waiting for WebView to finish loading.");
                this.zzbya.cancel();
            }
        }
    }

    protected zzic(Context context, zzjy.zza com_google_android_gms_internal_zzjy_zza, zzll com_google_android_gms_internal_zzll, zzig.zza com_google_android_gms_internal_zzig_zza) {
        this.mContext = context;
        this.zzbxv = com_google_android_gms_internal_zzjy_zza;
        this.zzbxw = this.zzbxv.zzciu;
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.zzbxu = com_google_android_gms_internal_zzig_zza;
    }

    private zzjy zzak(int i) {
        AdRequestInfoParcel adRequestInfoParcel = this.zzbxv.zzcit;
        AdRequestParcel adRequestParcel = adRequestInfoParcel.zzcav;
        zzll com_google_android_gms_internal_zzll = this.zzbgj;
        List list = this.zzbxw.zzbnq;
        List list2 = this.zzbxw.zzbnr;
        List list3 = this.zzbxw.zzcce;
        int i2 = this.zzbxw.orientation;
        long j = this.zzbxw.zzbnw;
        String str = adRequestInfoParcel.zzcay;
        boolean z = this.zzbxw.zzccc;
        long j2 = this.zzbxw.zzccd;
        AdSizeParcel adSizeParcel = this.zzbxv.zzaoy;
        long j3 = j2;
        long j4 = this.zzbxw.zzccb;
        long j5 = this.zzbxv.zzcio;
        j2 = this.zzbxw.zzccg;
        String str2 = this.zzbxw.zzcch;
        JSONObject jSONObject = this.zzbxv.zzcii;
        RewardItemParcel rewardItemParcel = this.zzbxw.zzccr;
        List list4 = this.zzbxw.zzccs;
        List list5 = this.zzbxw.zzcct;
        boolean z2 = this.zzbxw.zzccu;
        String str3 = str2;
        long j6 = j3;
        j3 = j2;
        return new zzjy(adRequestParcel, com_google_android_gms_internal_zzll, list, i, list2, list3, i2, j, str, z, null, null, null, null, null, j6, adSizeParcel, j4, j5, j3, str3, jSONObject, null, rewardItemParcel, list4, list5, z2, this.zzbxw.zzccv, null, this.zzbxw.zzbnt);
    }

    public void cancel() {
        if (this.zzbxz.getAndSet(false)) {
            this.zzbgj.stopLoading();
            zzu.zzfs().zzj(this.zzbgj);
            zzaj(-1);
            zzkl.zzclg.removeCallbacks(this.zzbxx);
        }
    }

    public void zza(zzll com_google_android_gms_internal_zzll, boolean z) {
        zzb.zzcw("WebView finished loading.");
        int i = 0;
        if (this.zzbxz.getAndSet(false)) {
            if (z) {
                i = zzpy();
            }
            zzaj(i);
            zzkl.zzclg.removeCallbacks(this.zzbxx);
        }
    }

    protected void zzaj(int i) {
        if (i != -2) {
            this.zzbxw = new AdResponseParcel(i, this.zzbxw.zzbnw);
        }
        this.zzbgj.zzue();
        this.zzbxu.zzb(zzak(i));
    }

    public final Void zzpw() {
        zzab.zzhj("Webview render task needs to be called on UI thread.");
        this.zzbxx = new C04541(this);
        zzkl.zzclg.postDelayed(this.zzbxx, ((Long) zzdc.zzbbf.get()).longValue());
        zzpx();
        return null;
    }

    protected abstract void zzpx();

    protected int zzpy() {
        return -2;
    }

    public /* synthetic */ Object zzpz() {
        return zzpw();
    }
}
