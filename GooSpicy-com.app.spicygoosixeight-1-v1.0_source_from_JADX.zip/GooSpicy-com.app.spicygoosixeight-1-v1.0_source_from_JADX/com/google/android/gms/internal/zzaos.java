package com.google.android.gms.internal;

import java.io.IOException;

public final class zzaos extends IOException {
    public zzaos(String str) {
        super(str);
    }
}
