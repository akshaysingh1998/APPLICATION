package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.mediation.AdUrlAdapter;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEventAdapter;
import com.google.android.gms.ads.mediation.customevent.CustomEventExtras;
import com.google.android.gms.internal.zzgn.zza;
import java.util.Map;

@zzir
public final class zzgm extends zza {
    private Map<Class<? extends NetworkExtras>, NetworkExtras> zzbpk;

    private <NETWORK_EXTRAS extends com.google.ads.mediation.NetworkExtras, SERVER_PARAMETERS extends com.google.ads.mediation.MediationServerParameters> com.google.android.gms.internal.zzgo zzbp(java.lang.String r4) throws android.os.RemoteException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = 0;
        r1 = com.google.android.gms.internal.zzgm.class;	 Catch:{ Throwable -> 0x0069 }
        r1 = r1.getClassLoader();	 Catch:{ Throwable -> 0x0069 }
        r0 = java.lang.Class.forName(r4, r0, r1);	 Catch:{ Throwable -> 0x0069 }
        r1 = com.google.ads.mediation.MediationAdapter.class;	 Catch:{ Throwable -> 0x0069 }
        r1 = r1.isAssignableFrom(r0);	 Catch:{ Throwable -> 0x0069 }
        if (r1 == 0) goto L_0x002b;	 Catch:{ Throwable -> 0x0069 }
    L_0x0013:
        r0 = r0.newInstance();	 Catch:{ Throwable -> 0x0069 }
        r0 = (com.google.ads.mediation.MediationAdapter) r0;	 Catch:{ Throwable -> 0x0069 }
        r1 = r3.zzbpk;	 Catch:{ Throwable -> 0x0069 }
        r2 = r0.getAdditionalParametersType();	 Catch:{ Throwable -> 0x0069 }
        r1 = r1.get(r2);	 Catch:{ Throwable -> 0x0069 }
        r1 = (com.google.ads.mediation.NetworkExtras) r1;	 Catch:{ Throwable -> 0x0069 }
        r2 = new com.google.android.gms.internal.zzgz;	 Catch:{ Throwable -> 0x0069 }
        r2.<init>(r0, r1);	 Catch:{ Throwable -> 0x0069 }
        return r2;	 Catch:{ Throwable -> 0x0069 }
    L_0x002b:
        r1 = com.google.android.gms.ads.mediation.MediationAdapter.class;	 Catch:{ Throwable -> 0x0069 }
        r1 = r1.isAssignableFrom(r0);	 Catch:{ Throwable -> 0x0069 }
        if (r1 == 0) goto L_0x003f;	 Catch:{ Throwable -> 0x0069 }
    L_0x0033:
        r0 = r0.newInstance();	 Catch:{ Throwable -> 0x0069 }
        r0 = (com.google.android.gms.ads.mediation.MediationAdapter) r0;	 Catch:{ Throwable -> 0x0069 }
        r1 = new com.google.android.gms.internal.zzgu;	 Catch:{ Throwable -> 0x0069 }
        r1.<init>(r0);	 Catch:{ Throwable -> 0x0069 }
        return r1;	 Catch:{ Throwable -> 0x0069 }
    L_0x003f:
        r0 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0069 }
        r1 = 64;	 Catch:{ Throwable -> 0x0069 }
        r2 = java.lang.String.valueOf(r4);	 Catch:{ Throwable -> 0x0069 }
        r2 = r2.length();	 Catch:{ Throwable -> 0x0069 }
        r1 = r1 + r2;	 Catch:{ Throwable -> 0x0069 }
        r0.<init>(r1);	 Catch:{ Throwable -> 0x0069 }
        r1 = "Could not instantiate mediation adapter: ";	 Catch:{ Throwable -> 0x0069 }
        r0.append(r1);	 Catch:{ Throwable -> 0x0069 }
        r0.append(r4);	 Catch:{ Throwable -> 0x0069 }
        r1 = " (not a valid adapter).";	 Catch:{ Throwable -> 0x0069 }
        r0.append(r1);	 Catch:{ Throwable -> 0x0069 }
        r0 = r0.toString();	 Catch:{ Throwable -> 0x0069 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r0);	 Catch:{ Throwable -> 0x0069 }
        r0 = new android.os.RemoteException;	 Catch:{ Throwable -> 0x0069 }
        r0.<init>();	 Catch:{ Throwable -> 0x0069 }
        throw r0;	 Catch:{ Throwable -> 0x0069 }
    L_0x0069:
        r4 = r3.zzbq(r4);
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgm.zzbp(java.lang.String):com.google.android.gms.internal.zzgo");
    }

    private zzgo zzbq(String str) throws RemoteException {
        try {
            zzb.zzcw("Reflection failed, retrying using direct instantiation");
            if ("com.google.ads.mediation.admob.AdMobAdapter".equals(str)) {
                return new zzgu(new AdMobAdapter());
            }
            if ("com.google.ads.mediation.AdUrlAdapter".equals(str)) {
                return new zzgu(new AdUrlAdapter());
            }
            if ("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
                return new zzgu(new CustomEventAdapter());
            }
            if ("com.google.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
                MediationAdapter customEventAdapter = new com.google.ads.mediation.customevent.CustomEventAdapter();
                return new zzgz(customEventAdapter, (CustomEventExtras) this.zzbpk.get(customEventAdapter.getAdditionalParametersType()));
            }
            throw new RemoteException();
        } catch (Throwable th) {
            StringBuilder stringBuilder = new StringBuilder(43 + String.valueOf(str).length());
            stringBuilder.append("Could not instantiate mediation adapter: ");
            stringBuilder.append(str);
            stringBuilder.append(". ");
            zzb.zzd(stringBuilder.toString(), th);
        }
    }

    public zzgo zzbn(String str) throws RemoteException {
        return zzbp(str);
    }

    public boolean zzbo(java.lang.String r5) throws android.os.RemoteException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = 0;
        r1 = com.google.android.gms.internal.zzgm.class;	 Catch:{ Throwable -> 0x0012 }
        r1 = r1.getClassLoader();	 Catch:{ Throwable -> 0x0012 }
        r1 = java.lang.Class.forName(r5, r0, r1);	 Catch:{ Throwable -> 0x0012 }
        r2 = com.google.android.gms.ads.mediation.customevent.CustomEvent.class;	 Catch:{ Throwable -> 0x0012 }
        r1 = r2.isAssignableFrom(r1);	 Catch:{ Throwable -> 0x0012 }
        return r1;
    L_0x0012:
        r1 = new java.lang.StringBuilder;
        r2 = 80;
        r3 = java.lang.String.valueOf(r5);
        r3 = r3.length();
        r2 = r2 + r3;
        r1.<init>(r2);
        r2 = "Could not load custom event implementation class: ";
        r1.append(r2);
        r1.append(r5);
        r5 = ", assuming old implementation.";
        r1.append(r5);
        r5 = r1.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r5);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgm.zzbo(java.lang.String):boolean");
    }

    public void zzh(Map<Class<? extends NetworkExtras>, NetworkExtras> map) {
        this.zzbpk = map;
    }
}
