package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.clearcut.LogEventParcelable;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.internal.zzg;
import com.google.android.gms.common.internal.zzk;
import com.google.android.gms.internal.zzpk.zza;

public class zzph extends zzk<zzpk> {
    public zzph(Context context, Looper looper, zzg com_google_android_gms_common_internal_zzg, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, 40, com_google_android_gms_common_internal_zzg, connectionCallbacks, onConnectionFailedListener);
    }

    public void zza(zzpj com_google_android_gms_internal_zzpj, LogEventParcelable logEventParcelable) throws RemoteException {
        ((zzpk) zzarw()).zza(com_google_android_gms_internal_zzpj, logEventParcelable);
    }

    protected /* synthetic */ IInterface zzbb(IBinder iBinder) {
        return zzdk(iBinder);
    }

    protected zzpk zzdk(IBinder iBinder) {
        return zza.zzdm(iBinder);
    }

    protected String zzra() {
        return "com.google.android.gms.clearcut.service.START";
    }

    protected String zzrb() {
        return "com.google.android.gms.clearcut.internal.IClearcutLoggerService";
    }
}
