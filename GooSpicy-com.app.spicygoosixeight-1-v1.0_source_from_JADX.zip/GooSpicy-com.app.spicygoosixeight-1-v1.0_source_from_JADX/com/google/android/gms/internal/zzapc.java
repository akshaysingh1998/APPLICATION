package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzapc {
    protected volatile int bik = -1;

    public static final <T extends zzapc> T zza(T t, byte[] bArr) throws zzapb {
        return zzb(t, bArr, 0, bArr.length);
    }

    public static final void zza(zzapc com_google_android_gms_internal_zzapc, byte[] bArr, int i, int i2) {
        try {
            zzaov zzc = zzaov.zzc(bArr, i, i2);
            com_google_android_gms_internal_zzapc.zza(zzc);
            zzc.ab();
        } catch (Throwable e) {
            throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", e);
        }
    }

    public static final <T extends com.google.android.gms.internal.zzapc> T zzb(T r0, byte[] r1, int r2, int r3) throws com.google.android.gms.internal.zzapb {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = com.google.android.gms.internal.zzaou.zzb(r1, r2, r3);	 Catch:{ zzapb -> 0x0014, IOException -> 0x000c }
        r0.zzb(r1);	 Catch:{ zzapb -> 0x0014, IOException -> 0x000c }
        r2 = 0;	 Catch:{ zzapb -> 0x0014, IOException -> 0x000c }
        r1.zzaef(r2);	 Catch:{ zzapb -> 0x0014, IOException -> 0x000c }
        return r0;
    L_0x000c:
        r0 = new java.lang.RuntimeException;
        r1 = "Reading from a byte array threw an IOException (should never happen).";
        r0.<init>(r1);
        throw r0;
    L_0x0014:
        r0 = move-exception;
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzapc.zzb(com.google.android.gms.internal.zzapc, byte[], int, int):T");
    }

    public static final byte[] zzf(zzapc com_google_android_gms_internal_zzapc) {
        byte[] bArr = new byte[com_google_android_gms_internal_zzapc.ao()];
        zza(com_google_android_gms_internal_zzapc, bArr, 0, bArr.length);
        return bArr;
    }

    public zzapc ad() throws CloneNotSupportedException {
        return (zzapc) super.clone();
    }

    public int an() {
        if (this.bik < 0) {
            ao();
        }
        return this.bik;
    }

    public int ao() {
        int zzy = zzy();
        this.bik = zzy;
        return zzy;
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return ad();
    }

    public String toString() {
        return zzapd.zzg(this);
    }

    public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
    }

    public abstract zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException;

    protected int zzy() {
        return 0;
    }
}
