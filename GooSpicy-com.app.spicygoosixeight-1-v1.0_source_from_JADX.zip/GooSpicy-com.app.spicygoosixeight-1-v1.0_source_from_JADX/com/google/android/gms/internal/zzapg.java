package com.google.android.gms.internal;

import android.support.v4.media.TransportMediator;
import java.io.IOException;
import java.util.Arrays;

public interface zzapg {

    public static final class zza extends zzaow<zza> implements Cloneable {
        public String[] biu;
        public String[] biv;
        public int[] biw;
        public long[] bix;
        public long[] biy;

        public zza() {
            ap();
        }

        public /* synthetic */ zzaow ac() throws CloneNotSupportedException {
            return (zza) clone();
        }

        public /* synthetic */ zzapc ad() throws CloneNotSupportedException {
            return (zza) clone();
        }

        public zza ap() {
            this.biu = zzapf.bir;
            this.biv = zzapf.bir;
            this.biw = zzapf.bim;
            this.bix = zzapf.bin;
            this.biy = zzapf.bin;
            this.bib = null;
            this.bik = -1;
            return this;
        }

        public zza aq() {
            try {
                zza com_google_android_gms_internal_zzapg_zza = (zza) super.ac();
                if (this.biu != null && this.biu.length > 0) {
                    com_google_android_gms_internal_zzapg_zza.biu = (String[]) this.biu.clone();
                }
                if (this.biv != null && this.biv.length > 0) {
                    com_google_android_gms_internal_zzapg_zza.biv = (String[]) this.biv.clone();
                }
                if (this.biw != null && this.biw.length > 0) {
                    com_google_android_gms_internal_zzapg_zza.biw = (int[]) this.biw.clone();
                }
                if (this.bix != null && this.bix.length > 0) {
                    com_google_android_gms_internal_zzapg_zza.bix = (long[]) this.bix.clone();
                }
                if (this.biy != null && this.biy.length > 0) {
                    com_google_android_gms_internal_zzapg_zza.biy = (long[]) this.biy.clone();
                }
                return com_google_android_gms_internal_zzapg_zza;
            } catch (CloneNotSupportedException e) {
                throw new AssertionError(e);
            }
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            return aq();
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zza)) {
                return false;
            }
            zza com_google_android_gms_internal_zzapg_zza = (zza) obj;
            if (!zzapa.equals(this.biu, com_google_android_gms_internal_zzapg_zza.biu) || !zzapa.equals(this.biv, com_google_android_gms_internal_zzapg_zza.biv) || !zzapa.equals(this.biw, com_google_android_gms_internal_zzapg_zza.biw) || !zzapa.equals(this.bix, com_google_android_gms_internal_zzapg_zza.bix) || !zzapa.equals(this.biy, com_google_android_gms_internal_zzapg_zza.biy)) {
                return false;
            }
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    return this.bib.equals(com_google_android_gms_internal_zzapg_zza.bib);
                }
            }
            if (com_google_android_gms_internal_zzapg_zza.bib != null) {
                if (com_google_android_gms_internal_zzapg_zza.bib.isEmpty()) {
                    return true;
                }
                z = false;
            }
            return z;
        }

        public int hashCode() {
            int hashCode;
            int hashCode2 = 31 * (((((((((((527 + getClass().getName().hashCode()) * 31) + zzapa.hashCode(this.biu)) * 31) + zzapa.hashCode(this.biv)) * 31) + zzapa.hashCode(this.biw)) * 31) + zzapa.hashCode(this.bix)) * 31) + zzapa.hashCode(this.biy));
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    hashCode = this.bib.hashCode();
                    return hashCode2 + hashCode;
                }
            }
            hashCode = 0;
            return hashCode2 + hashCode;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            int i = 0;
            if (this.biu != null && this.biu.length > 0) {
                for (String str : this.biu) {
                    if (str != null) {
                        com_google_android_gms_internal_zzaov.zzr(1, str);
                    }
                }
            }
            if (this.biv != null && this.biv.length > 0) {
                for (String str2 : this.biv) {
                    if (str2 != null) {
                        com_google_android_gms_internal_zzaov.zzr(2, str2);
                    }
                }
            }
            if (this.biw != null && this.biw.length > 0) {
                for (int zzae : this.biw) {
                    com_google_android_gms_internal_zzaov.zzae(3, zzae);
                }
            }
            if (this.bix != null && this.bix.length > 0) {
                for (long zzb : this.bix) {
                    com_google_android_gms_internal_zzaov.zzb(4, zzb);
                }
            }
            if (this.biy != null && this.biy.length > 0) {
                while (i < this.biy.length) {
                    com_google_android_gms_internal_zzaov.zzb(5, this.biy[i]);
                    i++;
                }
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzcg(com_google_android_gms_internal_zzaou);
        }

        public zza zzcg(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                int length;
                Object obj;
                if (J == 10) {
                    J = zzapf.zzc(com_google_android_gms_internal_zzaou, 10);
                    length = this.biu == null ? 0 : this.biu.length;
                    obj = new String[(J + length)];
                    if (length != 0) {
                        System.arraycopy(this.biu, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = com_google_android_gms_internal_zzaou.readString();
                        com_google_android_gms_internal_zzaou.m39J();
                        length++;
                    }
                    obj[length] = com_google_android_gms_internal_zzaou.readString();
                    this.biu = obj;
                } else if (J == 18) {
                    J = zzapf.zzc(com_google_android_gms_internal_zzaou, 18);
                    length = this.biv == null ? 0 : this.biv.length;
                    obj = new String[(J + length)];
                    if (length != 0) {
                        System.arraycopy(this.biv, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = com_google_android_gms_internal_zzaou.readString();
                        com_google_android_gms_internal_zzaou.m39J();
                        length++;
                    }
                    obj[length] = com_google_android_gms_internal_zzaou.readString();
                    this.biv = obj;
                } else if (J != 24) {
                    int i;
                    Object obj2;
                    if (J == 26) {
                        J = com_google_android_gms_internal_zzaou.zzaei(com_google_android_gms_internal_zzaou.m48S());
                        length = com_google_android_gms_internal_zzaou.getPosition();
                        i = 0;
                        while (com_google_android_gms_internal_zzaou.m52X() > 0) {
                            com_google_android_gms_internal_zzaou.m43N();
                            i++;
                        }
                        com_google_android_gms_internal_zzaou.zzaek(length);
                        length = this.biw == null ? 0 : this.biw.length;
                        obj2 = new int[(i + length)];
                        if (length != 0) {
                            System.arraycopy(this.biw, 0, obj2, 0, length);
                        }
                        while (length < obj2.length) {
                            obj2[length] = com_google_android_gms_internal_zzaou.m43N();
                            length++;
                        }
                        this.biw = obj2;
                    } else if (J == 32) {
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 32);
                        length = this.bix == null ? 0 : this.bix.length;
                        obj = new long[(J + length)];
                        if (length != 0) {
                            System.arraycopy(this.bix, 0, obj, 0, length);
                        }
                        while (length < obj.length - 1) {
                            obj[length] = com_google_android_gms_internal_zzaou.m42M();
                            com_google_android_gms_internal_zzaou.m39J();
                            length++;
                        }
                        obj[length] = com_google_android_gms_internal_zzaou.m42M();
                        this.bix = obj;
                    } else if (J == 34) {
                        J = com_google_android_gms_internal_zzaou.zzaei(com_google_android_gms_internal_zzaou.m48S());
                        length = com_google_android_gms_internal_zzaou.getPosition();
                        i = 0;
                        while (com_google_android_gms_internal_zzaou.m52X() > 0) {
                            com_google_android_gms_internal_zzaou.m42M();
                            i++;
                        }
                        com_google_android_gms_internal_zzaou.zzaek(length);
                        length = this.bix == null ? 0 : this.bix.length;
                        obj2 = new long[(i + length)];
                        if (length != 0) {
                            System.arraycopy(this.bix, 0, obj2, 0, length);
                        }
                        while (length < obj2.length) {
                            obj2[length] = com_google_android_gms_internal_zzaou.m42M();
                            length++;
                        }
                        this.bix = obj2;
                    } else if (J == 40) {
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 40);
                        length = this.biy == null ? 0 : this.biy.length;
                        obj = new long[(J + length)];
                        if (length != 0) {
                            System.arraycopy(this.biy, 0, obj, 0, length);
                        }
                        while (length < obj.length - 1) {
                            obj[length] = com_google_android_gms_internal_zzaou.m42M();
                            com_google_android_gms_internal_zzaou.m39J();
                            length++;
                        }
                        obj[length] = com_google_android_gms_internal_zzaou.m42M();
                        this.biy = obj;
                    } else if (J == 42) {
                        J = com_google_android_gms_internal_zzaou.zzaei(com_google_android_gms_internal_zzaou.m48S());
                        length = com_google_android_gms_internal_zzaou.getPosition();
                        i = 0;
                        while (com_google_android_gms_internal_zzaou.m52X() > 0) {
                            com_google_android_gms_internal_zzaou.m42M();
                            i++;
                        }
                        com_google_android_gms_internal_zzaou.zzaek(length);
                        length = this.biy == null ? 0 : this.biy.length;
                        obj2 = new long[(i + length)];
                        if (length != 0) {
                            System.arraycopy(this.biy, 0, obj2, 0, length);
                        }
                        while (length < obj2.length) {
                            obj2[length] = com_google_android_gms_internal_zzaou.m42M();
                            length++;
                        }
                        this.biy = obj2;
                    } else if (!super.zza(com_google_android_gms_internal_zzaou, J)) {
                        return this;
                    }
                    com_google_android_gms_internal_zzaou.zzaej(J);
                } else {
                    J = zzapf.zzc(com_google_android_gms_internal_zzaou, 24);
                    length = this.biw == null ? 0 : this.biw.length;
                    obj = new int[(J + length)];
                    if (length != 0) {
                        System.arraycopy(this.biw, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = com_google_android_gms_internal_zzaou.m43N();
                        com_google_android_gms_internal_zzaou.m39J();
                        length++;
                    }
                    obj[length] = com_google_android_gms_internal_zzaou.m43N();
                    this.biw = obj;
                }
            }
        }

        protected int zzy() {
            int i;
            int i2;
            int i3;
            String str;
            int zzy = super.zzy();
            int i4 = 0;
            if (this.biu != null && this.biu.length > 0) {
                i = 0;
                i2 = i;
                i3 = i2;
                while (i < this.biu.length) {
                    str = this.biu[i];
                    if (str != null) {
                        i3++;
                        i2 += zzaov.zztg(str);
                    }
                    i++;
                }
                zzy = (zzy + i2) + (i3 * 1);
            }
            if (this.biv != null && this.biv.length > 0) {
                i = 0;
                i2 = i;
                i3 = i2;
                while (i < this.biv.length) {
                    str = this.biv[i];
                    if (str != null) {
                        i3++;
                        i2 += zzaov.zztg(str);
                    }
                    i++;
                }
                zzy = (zzy + i2) + (i3 * 1);
            }
            if (this.biw != null && this.biw.length > 0) {
                i = 0;
                i2 = i;
                while (i < this.biw.length) {
                    i2 += zzaov.zzaeo(this.biw[i]);
                    i++;
                }
                zzy = (zzy + i2) + (this.biw.length * 1);
            }
            if (this.bix != null && this.bix.length > 0) {
                i = 0;
                i2 = i;
                while (i < this.bix.length) {
                    i2 += zzaov.zzcw(this.bix[i]);
                    i++;
                }
                zzy = (zzy + i2) + (this.bix.length * 1);
            }
            if (this.biy == null || this.biy.length <= 0) {
                return zzy;
            }
            i = 0;
            while (i4 < this.biy.length) {
                i += zzaov.zzcw(this.biy[i4]);
                i4++;
            }
            return (zzy + i) + (1 * this.biy.length);
        }
    }

    public static final class zzb extends zzaow<zzb> implements Cloneable {
        public String biA;
        public int biz;
        public String version;

        public zzb() {
            ar();
        }

        public /* synthetic */ zzaow ac() throws CloneNotSupportedException {
            return (zzb) clone();
        }

        public /* synthetic */ zzapc ad() throws CloneNotSupportedException {
            return (zzb) clone();
        }

        public zzb ar() {
            this.biz = 0;
            this.biA = "";
            this.version = "";
            this.bib = null;
            this.bik = -1;
            return this;
        }

        public zzb as() {
            try {
                return (zzb) super.ac();
            } catch (CloneNotSupportedException e) {
                throw new AssertionError(e);
            }
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            return as();
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzb)) {
                return false;
            }
            zzb com_google_android_gms_internal_zzapg_zzb = (zzb) obj;
            if (this.biz != com_google_android_gms_internal_zzapg_zzb.biz) {
                return false;
            }
            if (this.biA == null) {
                if (com_google_android_gms_internal_zzapg_zzb.biA != null) {
                    return false;
                }
            } else if (!this.biA.equals(com_google_android_gms_internal_zzapg_zzb.biA)) {
                return false;
            }
            if (this.version == null) {
                if (com_google_android_gms_internal_zzapg_zzb.version != null) {
                    return false;
                }
            } else if (!this.version.equals(com_google_android_gms_internal_zzapg_zzb.version)) {
                return false;
            }
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    return this.bib.equals(com_google_android_gms_internal_zzapg_zzb.bib);
                }
            }
            if (com_google_android_gms_internal_zzapg_zzb.bib != null) {
                if (com_google_android_gms_internal_zzapg_zzb.bib.isEmpty()) {
                    return true;
                }
                z = false;
            }
            return z;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((527 + getClass().getName().hashCode()) * 31) + this.biz) * 31) + (this.biA == null ? 0 : this.biA.hashCode())) * 31) + (this.version == null ? 0 : this.version.hashCode()));
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    i = this.bib.hashCode();
                }
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.biz != 0) {
                com_google_android_gms_internal_zzaov.zzae(1, this.biz);
            }
            if (!this.biA.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(2, this.biA);
            }
            if (!this.version.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(3, this.version);
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzch(com_google_android_gms_internal_zzaou);
        }

        public zzb zzch(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J == 8) {
                    this.biz = com_google_android_gms_internal_zzaou.m43N();
                } else if (J == 18) {
                    this.biA = com_google_android_gms_internal_zzaou.readString();
                } else if (J == 26) {
                    this.version = com_google_android_gms_internal_zzaou.readString();
                } else if (!super.zza(com_google_android_gms_internal_zzaou, J)) {
                    return this;
                }
            }
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (this.biz != 0) {
                zzy += zzaov.zzag(1, this.biz);
            }
            if (!this.biA.equals("")) {
                zzy += zzaov.zzs(2, this.biA);
            }
            return !this.version.equals("") ? zzy + zzaov.zzs(3, this.version) : zzy;
        }
    }

    public static final class zzc extends zzaow<zzc> implements Cloneable {
        public byte[] biB;
        public String biC;
        public byte[][] biD;
        public boolean biE;

        public zzc() {
            at();
        }

        public /* synthetic */ zzaow ac() throws CloneNotSupportedException {
            return (zzc) clone();
        }

        public /* synthetic */ zzapc ad() throws CloneNotSupportedException {
            return (zzc) clone();
        }

        public zzc at() {
            this.biB = zzapf.bit;
            this.biC = "";
            this.biD = zzapf.bis;
            this.biE = false;
            this.bib = null;
            this.bik = -1;
            return this;
        }

        public zzc au() {
            try {
                zzc com_google_android_gms_internal_zzapg_zzc = (zzc) super.ac();
                if (this.biD != null && this.biD.length > 0) {
                    com_google_android_gms_internal_zzapg_zzc.biD = (byte[][]) this.biD.clone();
                }
                return com_google_android_gms_internal_zzapg_zzc;
            } catch (CloneNotSupportedException e) {
                throw new AssertionError(e);
            }
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            return au();
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzc)) {
                return false;
            }
            zzc com_google_android_gms_internal_zzapg_zzc = (zzc) obj;
            if (!Arrays.equals(this.biB, com_google_android_gms_internal_zzapg_zzc.biB)) {
                return false;
            }
            if (this.biC == null) {
                if (com_google_android_gms_internal_zzapg_zzc.biC != null) {
                    return false;
                }
            } else if (!this.biC.equals(com_google_android_gms_internal_zzapg_zzc.biC)) {
                return false;
            }
            if (!zzapa.zza(this.biD, com_google_android_gms_internal_zzapg_zzc.biD) || this.biE != com_google_android_gms_internal_zzapg_zzc.biE) {
                return false;
            }
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    return this.bib.equals(com_google_android_gms_internal_zzapg_zzc.bib);
                }
            }
            if (com_google_android_gms_internal_zzapg_zzc.bib != null) {
                if (com_google_android_gms_internal_zzapg_zzc.bib.isEmpty()) {
                    return true;
                }
                z = false;
            }
            return z;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((((527 + getClass().getName().hashCode()) * 31) + Arrays.hashCode(this.biB)) * 31) + (this.biC == null ? 0 : this.biC.hashCode())) * 31) + zzapa.zzb(this.biD)) * 31) + (this.biE ? 1231 : 1237));
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    i = this.bib.hashCode();
                }
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (!Arrays.equals(this.biB, zzapf.bit)) {
                com_google_android_gms_internal_zzaov.zza(1, this.biB);
            }
            if (this.biD != null && this.biD.length > 0) {
                for (byte[] bArr : this.biD) {
                    if (bArr != null) {
                        com_google_android_gms_internal_zzaov.zza(2, bArr);
                    }
                }
            }
            if (this.biE) {
                com_google_android_gms_internal_zzaov.zzj(3, this.biE);
            }
            if (!this.biC.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(4, this.biC);
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzci(com_google_android_gms_internal_zzaou);
        }

        public zzc zzci(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J == 10) {
                    this.biB = com_google_android_gms_internal_zzaou.readBytes();
                } else if (J == 18) {
                    J = zzapf.zzc(com_google_android_gms_internal_zzaou, 18);
                    int length = this.biD == null ? 0 : this.biD.length;
                    Object obj = new byte[(J + length)][];
                    if (length != 0) {
                        System.arraycopy(this.biD, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = com_google_android_gms_internal_zzaou.readBytes();
                        com_google_android_gms_internal_zzaou.m39J();
                        length++;
                    }
                    obj[length] = com_google_android_gms_internal_zzaou.readBytes();
                    this.biD = obj;
                } else if (J == 24) {
                    this.biE = com_google_android_gms_internal_zzaou.m45P();
                } else if (J == 34) {
                    this.biC = com_google_android_gms_internal_zzaou.readString();
                } else if (!super.zza(com_google_android_gms_internal_zzaou, J)) {
                    return this;
                }
            }
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (!Arrays.equals(this.biB, zzapf.bit)) {
                zzy += zzaov.zzb(1, this.biB);
            }
            if (this.biD != null && this.biD.length > 0) {
                int i = 0;
                int i2 = 0;
                int i3 = i2;
                while (i < this.biD.length) {
                    byte[] bArr = this.biD[i];
                    if (bArr != null) {
                        i3++;
                        i2 += zzaov.zzbc(bArr);
                    }
                    i++;
                }
                zzy = (zzy + i2) + (1 * i3);
            }
            if (this.biE) {
                zzy += zzaov.zzk(3, this.biE);
            }
            return !this.biC.equals("") ? zzy + zzaov.zzs(4, this.biC) : zzy;
        }
    }

    public static final class zzd extends zzaow<zzd> implements Cloneable {
        public boolean aTD;
        public long biF;
        public long biG;
        public long biH;
        public int biI;
        public zze[] biJ;
        public byte[] biK;
        public zzb biL;
        public byte[] biM;
        public String biN;
        public String biO;
        public zza biP;
        public String biQ;
        public long biR;
        public zzc biS;
        public byte[] biT;
        public String biU;
        public int biV;
        public int[] biW;
        public long biX;
        public zzf biY;
        public String tag;
        public int zzahl;

        public zzd() {
            av();
        }

        public /* synthetic */ zzaow ac() throws CloneNotSupportedException {
            return (zzd) clone();
        }

        public /* synthetic */ zzapc ad() throws CloneNotSupportedException {
            return (zzd) clone();
        }

        public zzd av() {
            this.biF = 0;
            this.biG = 0;
            this.biH = 0;
            this.tag = "";
            this.biI = 0;
            this.zzahl = 0;
            this.aTD = false;
            this.biJ = zze.ax();
            this.biK = zzapf.bit;
            this.biL = null;
            this.biM = zzapf.bit;
            this.biN = "";
            this.biO = "";
            this.biP = null;
            this.biQ = "";
            this.biR = 180000;
            this.biS = null;
            this.biT = zzapf.bit;
            this.biU = "";
            this.biV = 0;
            this.biW = zzapf.bim;
            this.biX = 0;
            this.biY = null;
            this.bib = null;
            this.bik = -1;
            return this;
        }

        public zzd aw() {
            try {
                zzd com_google_android_gms_internal_zzapg_zzd = (zzd) super.ac();
                if (this.biJ != null && this.biJ.length > 0) {
                    com_google_android_gms_internal_zzapg_zzd.biJ = new zze[this.biJ.length];
                    for (int i = 0; i < this.biJ.length; i++) {
                        if (this.biJ[i] != null) {
                            com_google_android_gms_internal_zzapg_zzd.biJ[i] = (zze) this.biJ[i].clone();
                        }
                    }
                }
                if (this.biL != null) {
                    com_google_android_gms_internal_zzapg_zzd.biL = (zzb) this.biL.clone();
                }
                if (this.biP != null) {
                    com_google_android_gms_internal_zzapg_zzd.biP = (zza) this.biP.clone();
                }
                if (this.biS != null) {
                    com_google_android_gms_internal_zzapg_zzd.biS = (zzc) this.biS.clone();
                }
                if (this.biW != null && this.biW.length > 0) {
                    com_google_android_gms_internal_zzapg_zzd.biW = (int[]) this.biW.clone();
                }
                if (this.biY != null) {
                    com_google_android_gms_internal_zzapg_zzd.biY = (zzf) this.biY.clone();
                }
                return com_google_android_gms_internal_zzapg_zzd;
            } catch (CloneNotSupportedException e) {
                throw new AssertionError(e);
            }
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            return aw();
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzd)) {
                return false;
            }
            zzd com_google_android_gms_internal_zzapg_zzd = (zzd) obj;
            if (this.biF != com_google_android_gms_internal_zzapg_zzd.biF || this.biG != com_google_android_gms_internal_zzapg_zzd.biG || this.biH != com_google_android_gms_internal_zzapg_zzd.biH) {
                return false;
            }
            if (this.tag == null) {
                if (com_google_android_gms_internal_zzapg_zzd.tag != null) {
                    return false;
                }
            } else if (!this.tag.equals(com_google_android_gms_internal_zzapg_zzd.tag)) {
                return false;
            }
            if (this.biI != com_google_android_gms_internal_zzapg_zzd.biI || this.zzahl != com_google_android_gms_internal_zzapg_zzd.zzahl || this.aTD != com_google_android_gms_internal_zzapg_zzd.aTD || !zzapa.equals(this.biJ, com_google_android_gms_internal_zzapg_zzd.biJ) || !Arrays.equals(this.biK, com_google_android_gms_internal_zzapg_zzd.biK)) {
                return false;
            }
            if (this.biL == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biL != null) {
                    return false;
                }
            } else if (!this.biL.equals(com_google_android_gms_internal_zzapg_zzd.biL)) {
                return false;
            }
            if (!Arrays.equals(this.biM, com_google_android_gms_internal_zzapg_zzd.biM)) {
                return false;
            }
            if (this.biN == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biN != null) {
                    return false;
                }
            } else if (!this.biN.equals(com_google_android_gms_internal_zzapg_zzd.biN)) {
                return false;
            }
            if (this.biO == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biO != null) {
                    return false;
                }
            } else if (!this.biO.equals(com_google_android_gms_internal_zzapg_zzd.biO)) {
                return false;
            }
            if (this.biP == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biP != null) {
                    return false;
                }
            } else if (!this.biP.equals(com_google_android_gms_internal_zzapg_zzd.biP)) {
                return false;
            }
            if (this.biQ == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biQ != null) {
                    return false;
                }
            } else if (!this.biQ.equals(com_google_android_gms_internal_zzapg_zzd.biQ)) {
                return false;
            }
            if (this.biR != com_google_android_gms_internal_zzapg_zzd.biR) {
                return false;
            }
            if (this.biS == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biS != null) {
                    return false;
                }
            } else if (!this.biS.equals(com_google_android_gms_internal_zzapg_zzd.biS)) {
                return false;
            }
            if (!Arrays.equals(this.biT, com_google_android_gms_internal_zzapg_zzd.biT)) {
                return false;
            }
            if (this.biU == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biU != null) {
                    return false;
                }
            } else if (!this.biU.equals(com_google_android_gms_internal_zzapg_zzd.biU)) {
                return false;
            }
            if (this.biV != com_google_android_gms_internal_zzapg_zzd.biV || !zzapa.equals(this.biW, com_google_android_gms_internal_zzapg_zzd.biW) || this.biX != com_google_android_gms_internal_zzapg_zzd.biX) {
                return false;
            }
            if (this.biY == null) {
                if (com_google_android_gms_internal_zzapg_zzd.biY != null) {
                    return false;
                }
            } else if (!this.biY.equals(com_google_android_gms_internal_zzapg_zzd.biY)) {
                return false;
            }
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    return this.bib.equals(com_google_android_gms_internal_zzapg_zzd.bib);
                }
            }
            if (com_google_android_gms_internal_zzapg_zzd.bib != null) {
                if (com_google_android_gms_internal_zzapg_zzd.bib.isEmpty()) {
                    return true;
                }
                z = false;
            }
            return z;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((((((((((((((((((((((((((((((((((((((((((527 + getClass().getName().hashCode()) * 31) + ((int) (this.biF ^ (this.biF >>> 32)))) * 31) + ((int) (this.biG ^ (this.biG >>> 32)))) * 31) + ((int) (this.biH ^ (this.biH >>> 32)))) * 31) + (this.tag == null ? 0 : this.tag.hashCode())) * 31) + this.biI) * 31) + this.zzahl) * 31) + (this.aTD ? 1231 : 1237)) * 31) + zzapa.hashCode(this.biJ)) * 31) + Arrays.hashCode(this.biK)) * 31) + (this.biL == null ? 0 : this.biL.hashCode())) * 31) + Arrays.hashCode(this.biM)) * 31) + (this.biN == null ? 0 : this.biN.hashCode())) * 31) + (this.biO == null ? 0 : this.biO.hashCode())) * 31) + (this.biP == null ? 0 : this.biP.hashCode())) * 31) + (this.biQ == null ? 0 : this.biQ.hashCode())) * 31) + ((int) (this.biR ^ (this.biR >>> 32)))) * 31) + (this.biS == null ? 0 : this.biS.hashCode())) * 31) + Arrays.hashCode(this.biT)) * 31) + (this.biU == null ? 0 : this.biU.hashCode())) * 31) + this.biV) * 31) + zzapa.hashCode(this.biW)) * 31) + ((int) (this.biX ^ (this.biX >>> 32)))) * 31) + (this.biY == null ? 0 : this.biY.hashCode()));
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    i = this.bib.hashCode();
                }
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.biF != 0) {
                com_google_android_gms_internal_zzaov.zzb(1, this.biF);
            }
            if (!this.tag.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(2, this.tag);
            }
            int i = 0;
            if (this.biJ != null && this.biJ.length > 0) {
                for (zzapc com_google_android_gms_internal_zzapc : this.biJ) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        com_google_android_gms_internal_zzaov.zza(3, com_google_android_gms_internal_zzapc);
                    }
                }
            }
            if (!Arrays.equals(this.biK, zzapf.bit)) {
                com_google_android_gms_internal_zzaov.zza(4, this.biK);
            }
            if (!Arrays.equals(this.biM, zzapf.bit)) {
                com_google_android_gms_internal_zzaov.zza(6, this.biM);
            }
            if (this.biP != null) {
                com_google_android_gms_internal_zzaov.zza(7, this.biP);
            }
            if (!this.biN.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(8, this.biN);
            }
            if (this.biL != null) {
                com_google_android_gms_internal_zzaov.zza(9, this.biL);
            }
            if (this.aTD) {
                com_google_android_gms_internal_zzaov.zzj(10, this.aTD);
            }
            if (this.biI != 0) {
                com_google_android_gms_internal_zzaov.zzae(11, this.biI);
            }
            if (this.zzahl != 0) {
                com_google_android_gms_internal_zzaov.zzae(12, this.zzahl);
            }
            if (!this.biO.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(13, this.biO);
            }
            if (!this.biQ.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(14, this.biQ);
            }
            if (this.biR != 180000) {
                com_google_android_gms_internal_zzaov.zzd(15, this.biR);
            }
            if (this.biS != null) {
                com_google_android_gms_internal_zzaov.zza(16, this.biS);
            }
            if (this.biG != 0) {
                com_google_android_gms_internal_zzaov.zzb(17, this.biG);
            }
            if (!Arrays.equals(this.biT, zzapf.bit)) {
                com_google_android_gms_internal_zzaov.zza(18, this.biT);
            }
            if (this.biV != 0) {
                com_google_android_gms_internal_zzaov.zzae(19, this.biV);
            }
            if (this.biW != null && this.biW.length > 0) {
                while (i < this.biW.length) {
                    com_google_android_gms_internal_zzaov.zzae(20, this.biW[i]);
                    i++;
                }
            }
            if (this.biH != 0) {
                com_google_android_gms_internal_zzaov.zzb(21, this.biH);
            }
            if (this.biX != 0) {
                com_google_android_gms_internal_zzaov.zzb(22, this.biX);
            }
            if (this.biY != null) {
                com_google_android_gms_internal_zzaov.zza(23, this.biY);
            }
            if (!this.biU.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(24, this.biU);
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzcj(com_google_android_gms_internal_zzaou);
        }

        public zzd zzcj(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                zzapc com_google_android_gms_internal_zzapc;
                int J = com_google_android_gms_internal_zzaou.m39J();
                int length;
                Object obj;
                switch (J) {
                    case 0:
                        return this;
                    case 8:
                        this.biF = com_google_android_gms_internal_zzaou.m42M();
                        continue;
                    case 18:
                        this.tag = com_google_android_gms_internal_zzaou.readString();
                        continue;
                    case 26:
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 26);
                        length = this.biJ == null ? 0 : this.biJ.length;
                        obj = new zze[(J + length)];
                        if (length != 0) {
                            System.arraycopy(this.biJ, 0, obj, 0, length);
                        }
                        while (length < obj.length - 1) {
                            obj[length] = new zze();
                            com_google_android_gms_internal_zzaou.zza(obj[length]);
                            com_google_android_gms_internal_zzaou.m39J();
                            length++;
                        }
                        obj[length] = new zze();
                        com_google_android_gms_internal_zzaou.zza(obj[length]);
                        this.biJ = obj;
                        continue;
                    case 34:
                        this.biK = com_google_android_gms_internal_zzaou.readBytes();
                        continue;
                    case 50:
                        this.biM = com_google_android_gms_internal_zzaou.readBytes();
                        continue;
                    case 58:
                        if (this.biP == null) {
                            this.biP = new zza();
                        }
                        com_google_android_gms_internal_zzapc = this.biP;
                        break;
                    case 66:
                        this.biN = com_google_android_gms_internal_zzaou.readString();
                        continue;
                    case 74:
                        if (this.biL == null) {
                            this.biL = new zzb();
                        }
                        com_google_android_gms_internal_zzapc = this.biL;
                        break;
                    case 80:
                        this.aTD = com_google_android_gms_internal_zzaou.m45P();
                        continue;
                    case 88:
                        this.biI = com_google_android_gms_internal_zzaou.m43N();
                        continue;
                    case 96:
                        this.zzahl = com_google_android_gms_internal_zzaou.m43N();
                        continue;
                    case 106:
                        this.biO = com_google_android_gms_internal_zzaou.readString();
                        continue;
                    case 114:
                        this.biQ = com_google_android_gms_internal_zzaou.readString();
                        continue;
                    case 120:
                        this.biR = com_google_android_gms_internal_zzaou.m47R();
                        continue;
                    case TransportMediator.KEYCODE_MEDIA_RECORD /*130*/:
                        if (this.biS == null) {
                            this.biS = new zzc();
                        }
                        com_google_android_gms_internal_zzapc = this.biS;
                        break;
                    case 136:
                        this.biG = com_google_android_gms_internal_zzaou.m42M();
                        continue;
                    case 146:
                        this.biT = com_google_android_gms_internal_zzaou.readBytes();
                        continue;
                    case 152:
                        J = com_google_android_gms_internal_zzaou.m43N();
                        switch (J) {
                            case 0:
                            case 1:
                            case 2:
                                this.biV = J;
                                break;
                            default:
                                continue;
                        }
                    case 160:
                        J = zzapf.zzc(com_google_android_gms_internal_zzaou, 160);
                        length = this.biW == null ? 0 : this.biW.length;
                        obj = new int[(J + length)];
                        if (length != 0) {
                            System.arraycopy(this.biW, 0, obj, 0, length);
                        }
                        while (length < obj.length - 1) {
                            obj[length] = com_google_android_gms_internal_zzaou.m43N();
                            com_google_android_gms_internal_zzaou.m39J();
                            length++;
                        }
                        obj[length] = com_google_android_gms_internal_zzaou.m43N();
                        this.biW = obj;
                        continue;
                    case 162:
                        J = com_google_android_gms_internal_zzaou.zzaei(com_google_android_gms_internal_zzaou.m48S());
                        length = com_google_android_gms_internal_zzaou.getPosition();
                        int i = 0;
                        while (com_google_android_gms_internal_zzaou.m52X() > 0) {
                            com_google_android_gms_internal_zzaou.m43N();
                            i++;
                        }
                        com_google_android_gms_internal_zzaou.zzaek(length);
                        length = this.biW == null ? 0 : this.biW.length;
                        Object obj2 = new int[(i + length)];
                        if (length != 0) {
                            System.arraycopy(this.biW, 0, obj2, 0, length);
                        }
                        while (length < obj2.length) {
                            obj2[length] = com_google_android_gms_internal_zzaou.m43N();
                            length++;
                        }
                        this.biW = obj2;
                        com_google_android_gms_internal_zzaou.zzaej(J);
                        continue;
                    case 168:
                        this.biH = com_google_android_gms_internal_zzaou.m42M();
                        continue;
                    case 176:
                        this.biX = com_google_android_gms_internal_zzaou.m42M();
                        continue;
                    case 186:
                        if (this.biY == null) {
                            this.biY = new zzf();
                        }
                        com_google_android_gms_internal_zzapc = this.biY;
                        break;
                    case 194:
                        this.biU = com_google_android_gms_internal_zzaou.readString();
                        continue;
                    default:
                        if (!super.zza(com_google_android_gms_internal_zzaou, J)) {
                            return this;
                        }
                        continue;
                }
                com_google_android_gms_internal_zzaou.zza(com_google_android_gms_internal_zzapc);
            }
        }

        protected int zzy() {
            int i;
            int zzy = super.zzy();
            if (this.biF != 0) {
                zzy += zzaov.zze(1, this.biF);
            }
            if (!this.tag.equals("")) {
                zzy += zzaov.zzs(2, this.tag);
            }
            int i2 = 0;
            if (this.biJ != null && this.biJ.length > 0) {
                i = zzy;
                for (zzapc com_google_android_gms_internal_zzapc : this.biJ) {
                    if (com_google_android_gms_internal_zzapc != null) {
                        i += zzaov.zzc(3, com_google_android_gms_internal_zzapc);
                    }
                }
                zzy = i;
            }
            if (!Arrays.equals(this.biK, zzapf.bit)) {
                zzy += zzaov.zzb(4, this.biK);
            }
            if (!Arrays.equals(this.biM, zzapf.bit)) {
                zzy += zzaov.zzb(6, this.biM);
            }
            if (this.biP != null) {
                zzy += zzaov.zzc(7, this.biP);
            }
            if (!this.biN.equals("")) {
                zzy += zzaov.zzs(8, this.biN);
            }
            if (this.biL != null) {
                zzy += zzaov.zzc(9, this.biL);
            }
            if (this.aTD) {
                zzy += zzaov.zzk(10, this.aTD);
            }
            if (this.biI != 0) {
                zzy += zzaov.zzag(11, this.biI);
            }
            if (this.zzahl != 0) {
                zzy += zzaov.zzag(12, this.zzahl);
            }
            if (!this.biO.equals("")) {
                zzy += zzaov.zzs(13, this.biO);
            }
            if (!this.biQ.equals("")) {
                zzy += zzaov.zzs(14, this.biQ);
            }
            if (this.biR != 180000) {
                zzy += zzaov.zzg(15, this.biR);
            }
            if (this.biS != null) {
                zzy += zzaov.zzc(16, this.biS);
            }
            if (this.biG != 0) {
                zzy += zzaov.zze(17, this.biG);
            }
            if (!Arrays.equals(this.biT, zzapf.bit)) {
                zzy += zzaov.zzb(18, this.biT);
            }
            if (this.biV != 0) {
                zzy += zzaov.zzag(19, this.biV);
            }
            if (this.biW != null && this.biW.length > 0) {
                i = 0;
                while (i2 < this.biW.length) {
                    i += zzaov.zzaeo(this.biW[i2]);
                    i2++;
                }
                zzy = (zzy + i) + (2 * this.biW.length);
            }
            if (this.biH != 0) {
                zzy += zzaov.zze(21, this.biH);
            }
            if (this.biX != 0) {
                zzy += zzaov.zze(22, this.biX);
            }
            if (this.biY != null) {
                zzy += zzaov.zzc(23, this.biY);
            }
            return !this.biU.equals("") ? zzy + zzaov.zzs(24, this.biU) : zzy;
        }
    }

    public static final class zze extends zzaow<zze> implements Cloneable {
        private static volatile zze[] biZ;
        public String value;
        public String zzcb;

        public zze() {
            ay();
        }

        public static zze[] ax() {
            if (biZ == null) {
                synchronized (zzapa.bij) {
                    if (biZ == null) {
                        biZ = new zze[0];
                    }
                }
            }
            return biZ;
        }

        public /* synthetic */ zzaow ac() throws CloneNotSupportedException {
            return (zze) clone();
        }

        public /* synthetic */ zzapc ad() throws CloneNotSupportedException {
            return (zze) clone();
        }

        public zze ay() {
            this.zzcb = "";
            this.value = "";
            this.bib = null;
            this.bik = -1;
            return this;
        }

        public zze az() {
            try {
                return (zze) super.ac();
            } catch (CloneNotSupportedException e) {
                throw new AssertionError(e);
            }
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            return az();
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zze)) {
                return false;
            }
            zze com_google_android_gms_internal_zzapg_zze = (zze) obj;
            if (this.zzcb == null) {
                if (com_google_android_gms_internal_zzapg_zze.zzcb != null) {
                    return false;
                }
            } else if (!this.zzcb.equals(com_google_android_gms_internal_zzapg_zze.zzcb)) {
                return false;
            }
            if (this.value == null) {
                if (com_google_android_gms_internal_zzapg_zze.value != null) {
                    return false;
                }
            } else if (!this.value.equals(com_google_android_gms_internal_zzapg_zze.value)) {
                return false;
            }
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    return this.bib.equals(com_google_android_gms_internal_zzapg_zze.bib);
                }
            }
            if (com_google_android_gms_internal_zzapg_zze.bib != null) {
                if (com_google_android_gms_internal_zzapg_zze.bib.isEmpty()) {
                    return true;
                }
                z = false;
            }
            return z;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((527 + getClass().getName().hashCode()) * 31) + (this.zzcb == null ? 0 : this.zzcb.hashCode())) * 31) + (this.value == null ? 0 : this.value.hashCode()));
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    i = this.bib.hashCode();
                }
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (!this.zzcb.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(1, this.zzcb);
            }
            if (!this.value.equals("")) {
                com_google_android_gms_internal_zzaov.zzr(2, this.value);
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzck(com_google_android_gms_internal_zzaou);
        }

        public zze zzck(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J == 10) {
                    this.zzcb = com_google_android_gms_internal_zzaou.readString();
                } else if (J == 18) {
                    this.value = com_google_android_gms_internal_zzaou.readString();
                } else if (!super.zza(com_google_android_gms_internal_zzaou, J)) {
                    return this;
                }
            }
        }

        protected int zzy() {
            int zzy = super.zzy();
            if (!this.zzcb.equals("")) {
                zzy += zzaov.zzs(1, this.zzcb);
            }
            return !this.value.equals("") ? zzy + zzaov.zzs(2, this.value) : zzy;
        }
    }

    public static final class zzf extends zzaow<zzf> implements Cloneable {
        public int bja;

        public zzf() {
            aA();
        }

        public zzf aA() {
            this.bja = -1;
            this.bib = null;
            this.bik = -1;
            return this;
        }

        public zzf aB() {
            try {
                return (zzf) super.ac();
            } catch (CloneNotSupportedException e) {
                throw new AssertionError(e);
            }
        }

        public /* synthetic */ zzaow ac() throws CloneNotSupportedException {
            return (zzf) clone();
        }

        public /* synthetic */ zzapc ad() throws CloneNotSupportedException {
            return (zzf) clone();
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            return aB();
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzf)) {
                return false;
            }
            zzf com_google_android_gms_internal_zzapg_zzf = (zzf) obj;
            if (this.bja != com_google_android_gms_internal_zzapg_zzf.bja) {
                return false;
            }
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    return this.bib.equals(com_google_android_gms_internal_zzapg_zzf.bib);
                }
            }
            if (com_google_android_gms_internal_zzapg_zzf.bib != null) {
                if (com_google_android_gms_internal_zzapg_zzf.bib.isEmpty()) {
                    return true;
                }
                z = false;
            }
            return z;
        }

        public int hashCode() {
            int hashCode;
            int hashCode2 = 31 * (((527 + getClass().getName().hashCode()) * 31) + this.bja);
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    hashCode = this.bib.hashCode();
                    return hashCode2 + hashCode;
                }
            }
            hashCode = 0;
            return hashCode2 + hashCode;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            if (this.bja != -1) {
                com_google_android_gms_internal_zzaov.zzae(1, this.bja);
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzcl(com_google_android_gms_internal_zzaou);
        }

        public zzf zzcl(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J != 0) {
                    if (J == 8) {
                        J = com_google_android_gms_internal_zzaou.m43N();
                        switch (J) {
                            case -1:
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                            case 8:
                            case 9:
                            case 10:
                            case 11:
                            case 12:
                            case 13:
                            case 14:
                            case 15:
                            case 16:
                            case 17:
                                this.bja = J;
                                break;
                            default:
                                break;
                        }
                    } else if (!super.zza(com_google_android_gms_internal_zzaou, J)) {
                        return this;
                    }
                } else {
                    return this;
                }
            }
        }

        protected int zzy() {
            int zzy = super.zzy();
            return this.bja != -1 ? zzy + zzaov.zzag(1, this.bja) : zzy;
        }
    }
}
