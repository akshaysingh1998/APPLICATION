package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;

@zzir
public final class zzjw implements zzjx {
    public String zzf(AdRequestInfoParcel adRequestInfoParcel) {
        return adRequestInfoParcel.zzcax;
    }
}
