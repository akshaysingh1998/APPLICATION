package com.google.android.gms.internal;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.regex.Pattern;

public class zzaer {
    public static final Uri CONTENT_URI = Uri.parse("content://com.google.android.gsf.gservices");
    public static final Uri aLW = Uri.parse("content://com.google.android.gsf.gservices/prefix");
    public static final Pattern aLX = Pattern.compile("^(1|true|t|on|yes|y)$", 2);
    public static final Pattern aLY = Pattern.compile("^(0|false|f|off|no|n)$", 2);
    private static HashMap<String, String> aLZ;
    private static Object aMa;
    private static String[] aMb = new String[0];
    private static Context aMc;

    class C03901 extends Thread {
        final /* synthetic */ ContentResolver aMd;

        C03901(String str, ContentResolver contentResolver) {
            this.aMd = contentResolver;
            super(str);
        }

        public void run() {
            Looper.prepare();
            this.aMd.registerContentObserver(zzaer.CONTENT_URI, true, new ContentObserver(this, new Handler(Looper.myLooper())) {
                final /* synthetic */ C03901 aMe;

                public void onChange(boolean z) {
                    synchronized (zzaer.class) {
                        zzaer.aLZ.clear();
                        zzaer.aMa = new Object();
                        if (zzaer.aMb.length > 0) {
                            zzaer.zzb(this.aMe.aMd, zzaer.aMb);
                        }
                    }
                }
            });
            Looper.loop();
        }
    }

    public static long getLong(android.content.ContentResolver r0, java.lang.String r1, long r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = getString(r0, r1);
        if (r0 == 0) goto L_0x000b;
    L_0x0006:
        r0 = java.lang.Long.parseLong(r0);	 Catch:{ NumberFormatException -> 0x000b }
        r2 = r0;
    L_0x000b:
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaer.getLong(android.content.ContentResolver, java.lang.String, long):long");
    }

    public static String getString(ContentResolver contentResolver, String str) {
        return zza(contentResolver, str, null);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String zza(android.content.ContentResolver r11, java.lang.String r12, java.lang.String r13) {
        /*
        r0 = com.google.android.gms.internal.zzaer.class;
        monitor-enter(r0);
        zza(r11);	 Catch:{ all -> 0x007b }
        r1 = aMa;	 Catch:{ all -> 0x007b }
        r2 = aLZ;	 Catch:{ all -> 0x007b }
        r2 = r2.containsKey(r12);	 Catch:{ all -> 0x007b }
        if (r2 == 0) goto L_0x001e;
    L_0x0010:
        r11 = aLZ;	 Catch:{ all -> 0x007b }
        r11 = r11.get(r12);	 Catch:{ all -> 0x007b }
        r11 = (java.lang.String) r11;	 Catch:{ all -> 0x007b }
        if (r11 == 0) goto L_0x001b;
    L_0x001a:
        goto L_0x001c;
    L_0x001b:
        r11 = r13;
    L_0x001c:
        monitor-exit(r0);	 Catch:{ all -> 0x007b }
        return r11;
    L_0x001e:
        monitor-exit(r0);	 Catch:{ all -> 0x007b }
        r0 = aMb;
        r2 = 0;
        r3 = r0.length;
        r4 = r2;
    L_0x0024:
        if (r4 >= r3) goto L_0x0032;
    L_0x0026:
        r5 = r0[r4];
        r5 = r12.startsWith(r5);
        if (r5 == 0) goto L_0x002f;
    L_0x002e:
        return r13;
    L_0x002f:
        r4 = r4 + 1;
        goto L_0x0024;
    L_0x0032:
        r6 = CONTENT_URI;
        r7 = 0;
        r8 = 0;
        r0 = 1;
        r9 = new java.lang.String[r0];
        r9[r2] = r12;
        r10 = 0;
        r5 = r11;
        r11 = r5.query(r6, r7, r8, r9, r10);
        if (r11 == 0) goto L_0x0069;
    L_0x0043:
        r2 = r11.moveToFirst();	 Catch:{ all -> 0x0067 }
        if (r2 != 0) goto L_0x004a;
    L_0x0049:
        goto L_0x0069;
    L_0x004a:
        r0 = r11.getString(r0);	 Catch:{ all -> 0x0067 }
        r2 = com.google.android.gms.internal.zzaer.class;
        monitor-enter(r2);	 Catch:{ all -> 0x0067 }
        r3 = aMa;	 Catch:{ all -> 0x0064 }
        if (r1 != r3) goto L_0x005a;
    L_0x0055:
        r1 = aLZ;	 Catch:{ all -> 0x0064 }
        r1.put(r12, r0);	 Catch:{ all -> 0x0064 }
    L_0x005a:
        monitor-exit(r2);	 Catch:{ all -> 0x0064 }
        if (r0 == 0) goto L_0x005e;
    L_0x005d:
        r13 = r0;
    L_0x005e:
        if (r11 == 0) goto L_0x0063;
    L_0x0060:
        r11.close();
    L_0x0063:
        return r13;
    L_0x0064:
        r12 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x0064 }
        throw r12;	 Catch:{ all -> 0x0067 }
    L_0x0067:
        r12 = move-exception;
        goto L_0x0075;
    L_0x0069:
        r0 = aLZ;	 Catch:{ all -> 0x0067 }
        r1 = 0;
        r0.put(r12, r1);	 Catch:{ all -> 0x0067 }
        if (r11 == 0) goto L_0x0074;
    L_0x0071:
        r11.close();
    L_0x0074:
        return r13;
    L_0x0075:
        if (r11 == 0) goto L_0x007a;
    L_0x0077:
        r11.close();
    L_0x007a:
        throw r12;
    L_0x007b:
        r11 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x007b }
        throw r11;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaer.zza(android.content.ContentResolver, java.lang.String, java.lang.String):java.lang.String");
    }

    public static Map<String, String> zza(ContentResolver contentResolver, String... strArr) {
        Cursor query = contentResolver.query(aLW, null, null, strArr, null);
        Map<String, String> treeMap = new TreeMap();
        if (query == null) {
            return treeMap;
        }
        while (query.moveToNext()) {
            try {
                treeMap.put(query.getString(0), query.getString(1));
            } finally {
                query.close();
            }
        }
        return treeMap;
    }

    private static void zza(ContentResolver contentResolver) {
        if (aLZ == null) {
            aLZ = new HashMap();
            aMa = new Object();
            new C03901("Gservices", contentResolver).start();
        }
    }

    public static void zzb(ContentResolver contentResolver, String... strArr) {
        Map zza = zza(contentResolver, strArr);
        synchronized (zzaer.class) {
            zza(contentResolver);
            aMb = strArr;
            for (Entry entry : zza.entrySet()) {
                aLZ.put((String) entry.getKey(), (String) entry.getValue());
            }
        }
    }
}
