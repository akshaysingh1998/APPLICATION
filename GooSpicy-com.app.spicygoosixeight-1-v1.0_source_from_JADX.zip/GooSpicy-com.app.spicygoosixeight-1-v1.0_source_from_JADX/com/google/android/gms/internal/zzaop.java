package com.google.android.gms.internal;

import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;

public class zzaop implements Closeable {
    private static final char[] bhm = ")]}'\n".toCharArray();
    private int aYn = 0;
    private boolean bhn = false;
    private final char[] bho = new char[1024];
    private int bhp = 0;
    private int bhq = 0;
    private int bhr = 0;
    private long bhs;
    private int bht;
    private String bhu;
    private int[] bhv = new int[32];
    private int bhw = 0;
    private String[] bhx;
    private int[] bhy;
    private final Reader in;
    private int pos = 0;

    static class C08711 extends zzanu {
        C08711() {
        }

        public void zzi(com.google.android.gms.internal.zzaop r8) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:18:0x002c in {3, 6, 9, 11, 14, 17, 20} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r7 = this;
            r0 = r8 instanceof com.google.android.gms.internal.zzaof;
            if (r0 == 0) goto L_0x000a;
        L_0x0004:
            r8 = (com.google.android.gms.internal.zzaof) r8;
            r8.m75k();
            return;
        L_0x000a:
            r0 = r8.bhr;
            if (r0 != 0) goto L_0x0014;
        L_0x0010:
            r0 = r8.m20u();
        L_0x0014:
            r1 = 13;
            if (r0 != r1) goto L_0x001e;
        L_0x0018:
            r0 = 9;
        L_0x001a:
            r8.bhr = r0;
            return;
        L_0x001e:
            r1 = 12;
            if (r0 != r1) goto L_0x0025;
        L_0x0022:
            r0 = 8;
            goto L_0x001a;
        L_0x0025:
            r1 = 14;
            if (r0 != r1) goto L_0x002d;
        L_0x0029:
            r0 = 10;
            goto L_0x001a;
            return;
        L_0x002d:
            r0 = new java.lang.IllegalStateException;
            r1 = r8.mo2301h();
            r1 = java.lang.String.valueOf(r1);
            r2 = r8.getLineNumber();
            r3 = r8.getColumnNumber();
            r8 = r8.getPath();
            r4 = new java.lang.StringBuilder;
            r5 = 70;
            r6 = java.lang.String.valueOf(r1);
            r6 = r6.length();
            r5 = r5 + r6;
            r6 = java.lang.String.valueOf(r8);
            r6 = r6.length();
            r5 = r5 + r6;
            r4.<init>(r5);
            r5 = "Expected a name but was ";
            r4.append(r5);
            r4.append(r1);
            r1 = " ";
            r4.append(r1);
            r1 = " at line ";
            r4.append(r1);
            r4.append(r2);
            r1 = " column ";
            r4.append(r1);
            r4.append(r3);
            r1 = " path ";
            r4.append(r1);
            r4.append(r8);
            r8 = r4.toString();
            r0.<init>(r8);
            throw r0;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaop.1.zzi(com.google.android.gms.internal.zzaop):void");
        }
    }

    static {
        zzanu.bff = new C08711();
    }

    public zzaop(Reader reader) {
        int[] iArr = this.bhv;
        int i = this.bhw;
        this.bhw = i + 1;
        iArr[i] = 6;
        this.bhx = new String[32];
        this.bhy = new int[32];
        if (reader == null) {
            throw new NullPointerException("in == null");
        }
        this.in = reader;
    }

    private void m17A() throws IOException {
        char c;
        do {
            if (this.pos >= this.aYn && !zzaed(1)) {
                break;
            }
            char[] cArr = this.bho;
            int i = this.pos;
            this.pos = i + 1;
            c = cArr[i];
            if (c == '\n') {
                this.bhp++;
                this.bhq = this.pos;
                return;
            }
        } while (c != '\r');
    }

    private char m18B() throws IOException {
        if (this.pos != this.aYn || zzaed(1)) {
            char[] cArr = this.bho;
            int i = this.pos;
            this.pos = i + 1;
            char c = cArr[i];
            if (c == '\n') {
                this.bhp++;
                this.bhq = this.pos;
                return c;
            } else if (c == 'b') {
                return '\b';
            } else {
                if (c == 'f') {
                    return '\f';
                }
                if (c == 'n') {
                    return '\n';
                }
                if (c == 'r') {
                    return '\r';
                }
                switch (c) {
                    case 't':
                        return '\t';
                    case 'u':
                        if (this.pos + 4 <= this.aYn || zzaed(4)) {
                            c = '\u0000';
                            int i2 = this.pos;
                            int i3 = i2 + 4;
                            while (i2 < i3) {
                                int i4;
                                char c2 = this.bho[i2];
                                c = (char) (c << 4);
                                if (c2 < '0' || c2 > '9') {
                                    if (c2 >= 'a' && c2 <= 'f') {
                                        i4 = c2 - 97;
                                    } else if (c2 < 'A' || c2 > 'F') {
                                        String str = "\\u";
                                        String valueOf = String.valueOf(new String(this.bho, this.pos, 4));
                                        throw new NumberFormatException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                                    } else {
                                        i4 = c2 - 65;
                                    }
                                    i4 += 10;
                                } else {
                                    i4 = c2 - 48;
                                }
                                c = (char) (c + i4);
                                i2++;
                            }
                            this.pos += 4;
                            return c;
                        }
                        throw zztd("Unterminated escape sequence");
                    default:
                        return c;
                }
            }
        }
        throw zztd("Unterminated escape sequence");
    }

    private void m19C() throws IOException {
        zzda(true);
        this.pos--;
        if (this.pos + bhm.length <= this.aYn || zzaed(bhm.length)) {
            int i = 0;
            while (i < bhm.length) {
                if (this.bho[this.pos + i] == bhm[i]) {
                    i++;
                } else {
                    return;
                }
            }
            this.pos += bhm.length;
        }
    }

    private int getColumnNumber() {
        return (this.pos - this.bhq) + 1;
    }

    private int getLineNumber() {
        return this.bhp + 1;
    }

    private int m20u() throws IOException {
        int i = this.bhv[this.bhw - 1];
        int zzda;
        if (i == 1) {
            this.bhv[this.bhw - 1] = 2;
            zzda = zzda(true);
            if (zzda != 34) {
                if (this.bhw == 1) {
                    m25z();
                }
                i = 9;
            } else if (zzda == 39) {
                if (!(zzda == 44 || zzda == 59)) {
                    if (zzda != 91) {
                        this.bhr = 3;
                        return 3;
                    } else if (zzda == 93) {
                        if (zzda == 123) {
                            this.pos--;
                            if (this.bhw == 1) {
                                m25z();
                            }
                            i = m21v();
                            if (i != 0) {
                                return i;
                            }
                            i = m22w();
                            if (i != 0) {
                                return i;
                            }
                            if (zze(this.bho[this.pos])) {
                                throw zztd("Expected value");
                            }
                            m25z();
                            i = 10;
                        } else {
                            this.bhr = 1;
                            return 1;
                        }
                    } else if (i == 1) {
                        this.bhr = 4;
                        return 4;
                    }
                }
                if (i != 1) {
                    if (i == 2) {
                        throw zztd("Unexpected value");
                    }
                }
                m25z();
                this.pos--;
                this.bhr = 7;
                return 7;
            } else {
                m25z();
                this.bhr = 8;
                return 8;
            }
        }
        if (i == 2) {
            zzda = zzda(true);
            if (zzda != 44) {
                if (zzda == 59) {
                    m25z();
                } else if (zzda != 93) {
                    throw zztd("Unterminated array");
                } else {
                    this.bhr = 4;
                    return 4;
                }
            }
        }
        int zzda2;
        if (i != 3) {
            if (i != 5) {
                if (i == 4) {
                    this.bhv[this.bhw - 1] = 5;
                    zzda = zzda(true);
                    if (zzda != 58) {
                        if (zzda != 61) {
                            throw zztd("Expected ':'");
                        }
                        m25z();
                        if ((this.pos < this.aYn || zzaed(1)) && this.bho[this.pos] == '>') {
                            zzda = this.pos + 1;
                        }
                    }
                } else if (i == 6) {
                    if (this.bhn) {
                        m19C();
                    }
                    this.bhv[this.bhw - 1] = 7;
                } else if (i == 7) {
                    if (zzda(false) == -1) {
                        i = 17;
                    } else {
                        m25z();
                        zzda = this.pos - 1;
                    }
                } else if (i == 8) {
                    throw new IllegalStateException("JsonReader is closed");
                }
                this.pos = zzda;
            }
        }
        this.bhv[this.bhw - 1] = 4;
        if (i == 5) {
            zzda2 = zzda(true);
            if (zzda2 != 44) {
                if (zzda2 == 59) {
                    m25z();
                } else if (zzda2 != 125) {
                    throw zztd("Unterminated object");
                } else {
                    this.bhr = 2;
                    return 2;
                }
            }
        }
        zzda2 = zzda(true);
        if (zzda2 == 34) {
            i = 13;
        } else if (zzda2 == 39) {
            m25z();
            i = 12;
        } else if (zzda2 != 125) {
            m25z();
            this.pos--;
            if (zze((char) zzda2)) {
                i = 14;
            } else {
                throw zztd("Expected name");
            }
        } else if (i != 5) {
            this.bhr = 2;
            return 2;
        } else {
            throw zztd("Expected name");
        }
        zzda = zzda(true);
        if (zzda != 34) {
            if (this.bhw == 1) {
                m25z();
            }
            i = 9;
        } else if (zzda == 39) {
            m25z();
            this.bhr = 8;
            return 8;
        } else if (zzda != 91) {
            this.bhr = 3;
            return 3;
        } else if (zzda == 93) {
            if (i == 1) {
                this.bhr = 4;
                return 4;
            }
            if (i != 1) {
                if (i == 2) {
                    throw zztd("Unexpected value");
                }
            }
            m25z();
            this.pos--;
            this.bhr = 7;
            return 7;
        } else if (zzda == 123) {
            this.bhr = 1;
            return 1;
        } else {
            this.pos--;
            if (this.bhw == 1) {
                m25z();
            }
            i = m21v();
            if (i != 0) {
                return i;
            }
            i = m22w();
            if (i != 0) {
                return i;
            }
            if (zze(this.bho[this.pos])) {
                m25z();
                i = 10;
            } else {
                throw zztd("Expected value");
            }
        }
        this.bhr = i;
        return i;
    }

    private int m21v() throws IOException {
        String str;
        String str2;
        int i;
        int length;
        int i2;
        char c;
        char c2 = this.bho[this.pos];
        if (c2 != 't') {
            if (c2 != 'T') {
                if (c2 != 'f') {
                    if (c2 != 'F') {
                        if (c2 != 'n') {
                            if (c2 != 'N') {
                                return 0;
                            }
                        }
                        str = "null";
                        str2 = "NULL";
                        i = 7;
                        length = str.length();
                        i2 = 1;
                        while (i2 < length) {
                            if (this.pos + i2 < this.aYn && !zzaed(i2 + 1)) {
                                return 0;
                            }
                            c = this.bho[this.pos + i2];
                            if (c != str.charAt(i2) && c != r2.charAt(i2)) {
                                return 0;
                            }
                            i2++;
                        }
                        if ((this.pos + length >= this.aYn || zzaed(length + 1)) && zze(this.bho[this.pos + length])) {
                            return 0;
                        }
                        this.pos += length;
                        this.bhr = i;
                        return i;
                    }
                }
                str = "false";
                str2 = "FALSE";
                i = 6;
                length = str.length();
                i2 = 1;
                while (i2 < length) {
                    if (this.pos + i2 < this.aYn) {
                    }
                    c = this.bho[this.pos + i2];
                    if (c != str.charAt(i2)) {
                    }
                    i2++;
                }
                if (this.pos + length >= this.aYn) {
                }
                return 0;
            }
        }
        str = "true";
        str2 = "TRUE";
        i = 5;
        length = str.length();
        i2 = 1;
        while (i2 < length) {
            if (this.pos + i2 < this.aYn) {
            }
            c = this.bho[this.pos + i2];
            if (c != str.charAt(i2)) {
            }
            i2++;
        }
        if (this.pos + length >= this.aYn) {
        }
        return 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int m22w() throws java.io.IOException {
        /*
        r21 = this;
        r0 = r21;
        r1 = r0.bho;
        r2 = r0.pos;
        r3 = r0.aYn;
        r6 = 1;
        r7 = 0;
        r8 = r3;
        r10 = r6;
        r3 = r7;
        r9 = r3;
        r13 = r9;
        r11 = 0;
    L_0x0011:
        r14 = r2 + r3;
        r15 = 2;
        if (r14 != r8) goto L_0x0028;
    L_0x0016:
        r2 = r1.length;
        if (r3 != r2) goto L_0x001a;
    L_0x0019:
        return r7;
    L_0x001a:
        r2 = r3 + 1;
        r2 = r0.zzaed(r2);
        if (r2 != 0) goto L_0x0024;
    L_0x0022:
        goto L_0x0099;
    L_0x0024:
        r2 = r0.pos;
        r8 = r0.aYn;
    L_0x0028:
        r14 = r2 + r3;
        r14 = r1[r14];
        r7 = 43;
        r4 = 3;
        r5 = 5;
        if (r14 == r7) goto L_0x00e7;
    L_0x0032:
        r7 = 69;
        if (r14 == r7) goto L_0x00db;
    L_0x0036:
        r7 = 101; // 0x65 float:1.42E-43 double:5.0E-322;
        if (r14 == r7) goto L_0x00db;
    L_0x003a:
        switch(r14) {
            case 45: goto L_0x00ce;
            case 46: goto L_0x00c7;
            default: goto L_0x003d;
        };
    L_0x003d:
        r7 = 48;
        if (r14 < r7) goto L_0x0093;
    L_0x0041:
        r7 = 57;
        if (r14 <= r7) goto L_0x0046;
    L_0x0045:
        goto L_0x0093;
    L_0x0046:
        if (r9 == r6) goto L_0x0088;
    L_0x0048:
        if (r9 != 0) goto L_0x004b;
    L_0x004a:
        goto L_0x0088;
    L_0x004b:
        if (r9 != r15) goto L_0x0077;
    L_0x004d:
        r18 = 0;
        r4 = (r11 > r18 ? 1 : (r11 == r18 ? 0 : -1));
        if (r4 != 0) goto L_0x0055;
    L_0x0053:
        r4 = 0;
        return r4;
    L_0x0055:
        r4 = 10;
        r4 = r4 * r11;
        r14 = r14 + -48;
        r14 = (long) r14;
        r16 = r4 - r14;
        r4 = -922337203685477580; // 0xf333333333333334 float:4.1723254E-8 double:-8.390303882365713E246;
        r7 = (r11 > r4 ? 1 : (r11 == r4 ? 0 : -1));
        if (r7 > 0) goto L_0x0071;
    L_0x0066:
        r7 = (r11 > r4 ? 1 : (r11 == r4 ? 0 : -1));
        if (r7 != 0) goto L_0x006f;
    L_0x006a:
        r4 = (r16 > r11 ? 1 : (r16 == r11 ? 0 : -1));
        if (r4 >= 0) goto L_0x006f;
    L_0x006e:
        goto L_0x0071;
    L_0x006f:
        r4 = 0;
        goto L_0x0072;
    L_0x0071:
        r4 = r6;
    L_0x0072:
        r4 = r4 & r10;
        r10 = r4;
        r11 = r16;
        goto L_0x0090;
    L_0x0077:
        r18 = 0;
        if (r9 != r4) goto L_0x007f;
    L_0x007b:
        r7 = 0;
        r9 = 4;
        goto L_0x00ee;
    L_0x007f:
        if (r9 == r5) goto L_0x0084;
    L_0x0081:
        r4 = 6;
        if (r9 != r4) goto L_0x0090;
    L_0x0084:
        r7 = 0;
        r9 = 7;
        goto L_0x00ee;
    L_0x0088:
        r18 = 0;
        r14 = r14 + -48;
        r4 = -r14;
        r4 = (long) r4;
        r11 = r4;
        r9 = r15;
    L_0x0090:
        r7 = 0;
        goto L_0x00ee;
    L_0x0093:
        r1 = r0.zze(r14);
        if (r1 != 0) goto L_0x00c5;
    L_0x0099:
        if (r9 != r15) goto L_0x00b5;
    L_0x009b:
        if (r10 == 0) goto L_0x00b5;
    L_0x009d:
        r1 = -9223372036854775808;
        r4 = (r11 > r1 ? 1 : (r11 == r1 ? 0 : -1));
        if (r4 != 0) goto L_0x00a5;
    L_0x00a3:
        if (r13 == 0) goto L_0x00b5;
    L_0x00a5:
        if (r13 == 0) goto L_0x00a8;
    L_0x00a7:
        goto L_0x00a9;
    L_0x00a8:
        r11 = -r11;
    L_0x00a9:
        r0.bhs = r11;
        r1 = r0.pos;
        r1 = r1 + r3;
        r0.pos = r1;
        r1 = 15;
    L_0x00b2:
        r0.bhr = r1;
        return r1;
    L_0x00b5:
        if (r9 == r15) goto L_0x00c0;
    L_0x00b7:
        r1 = 4;
        if (r9 == r1) goto L_0x00c0;
    L_0x00ba:
        r1 = 7;
        if (r9 != r1) goto L_0x00be;
    L_0x00bd:
        goto L_0x00c0;
    L_0x00be:
        r7 = 0;
        return r7;
    L_0x00c0:
        r0.bht = r3;
        r1 = 16;
        goto L_0x00b2;
    L_0x00c5:
        r7 = 0;
        return r7;
    L_0x00c7:
        r7 = 0;
        r18 = 0;
        if (r9 != r15) goto L_0x00cd;
    L_0x00cc:
        goto L_0x00ed;
    L_0x00cd:
        return r7;
    L_0x00ce:
        r4 = 6;
        r7 = 0;
        r18 = 0;
        if (r9 != 0) goto L_0x00d7;
    L_0x00d4:
        r9 = r6;
        r13 = r9;
        goto L_0x00ee;
    L_0x00d7:
        if (r9 != r5) goto L_0x00da;
    L_0x00d9:
        goto L_0x00ed;
    L_0x00da:
        return r7;
    L_0x00db:
        r7 = 0;
        r18 = 0;
        if (r9 == r15) goto L_0x00e5;
    L_0x00e0:
        r4 = 4;
        if (r9 != r4) goto L_0x00e4;
    L_0x00e3:
        goto L_0x00e5;
    L_0x00e4:
        return r7;
    L_0x00e5:
        r9 = r5;
        goto L_0x00ee;
    L_0x00e7:
        r4 = 6;
        r7 = 0;
        r18 = 0;
        if (r9 != r5) goto L_0x00f2;
    L_0x00ed:
        r9 = r4;
    L_0x00ee:
        r3 = r3 + 1;
        goto L_0x0011;
    L_0x00f2:
        return r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaop.w():int");
    }

    private String m23x() throws IOException {
        String str;
        int i = 0;
        StringBuilder stringBuilder = null;
        do {
            int i2 = 0;
            while (true) {
                if (this.pos + i2 < this.aYn) {
                    switch (this.bho[this.pos + i2]) {
                        case '\t':
                        case '\n':
                        case '\f':
                        case '\r':
                        case ' ':
                        case ',':
                        case ':':
                        case '[':
                        case ']':
                        case '{':
                        case '}':
                            break;
                        case '#':
                        case '/':
                        case ';':
                        case '=':
                        case '\\':
                            m25z();
                            break;
                        default:
                            i2++;
                            break;
                    }
                } else if (i2 >= this.bho.length) {
                    if (stringBuilder == null) {
                        stringBuilder = new StringBuilder();
                    }
                    stringBuilder.append(this.bho, this.pos, i2);
                    this.pos += i2;
                } else if (zzaed(i2 + 1)) {
                }
                i = i2;
                if (stringBuilder != null) {
                    str = new String(this.bho, this.pos, i);
                } else {
                    stringBuilder.append(this.bho, this.pos, i);
                    str = stringBuilder.toString();
                }
                this.pos += i;
                return str;
            }
        } while (zzaed(1));
        if (stringBuilder != null) {
            stringBuilder.append(this.bho, this.pos, i);
            str = stringBuilder.toString();
        } else {
            str = new String(this.bho, this.pos, i);
        }
        this.pos += i;
        return str;
    }

    private void m24y() throws IOException {
        do {
            int i = 0;
            while (this.pos + i < this.aYn) {
                switch (this.bho[this.pos + i]) {
                    case '\t':
                    case '\n':
                    case '\f':
                    case '\r':
                    case ' ':
                    case ',':
                    case ':':
                    case '[':
                    case ']':
                    case '{':
                    case '}':
                        break;
                    case '#':
                    case '/':
                    case ';':
                    case '=':
                    case '\\':
                        m25z();
                        break;
                    default:
                        i++;
                }
                this.pos += i;
                return;
            }
            this.pos += i;
        } while (zzaed(1));
    }

    private void m25z() throws IOException {
        if (!this.bhn) {
            throw zztd("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    private void zzaec(int i) {
        if (this.bhw == this.bhv.length) {
            Object obj = new int[(this.bhw * 2)];
            Object obj2 = new int[(this.bhw * 2)];
            Object obj3 = new String[(this.bhw * 2)];
            System.arraycopy(this.bhv, 0, obj, 0, this.bhw);
            System.arraycopy(this.bhy, 0, obj2, 0, this.bhw);
            System.arraycopy(this.bhx, 0, obj3, 0, this.bhw);
            this.bhv = obj;
            this.bhy = obj2;
            this.bhx = obj3;
        }
        int[] iArr = this.bhv;
        int i2 = this.bhw;
        this.bhw = i2 + 1;
        iArr[i2] = i;
    }

    private boolean zzaed(int i) throws IOException {
        Object obj = this.bho;
        this.bhq -= this.pos;
        if (this.aYn != this.pos) {
            this.aYn -= this.pos;
            System.arraycopy(obj, this.pos, obj, 0, this.aYn);
        } else {
            this.aYn = 0;
        }
        this.pos = 0;
        do {
            int read = this.in.read(obj, this.aYn, obj.length - this.aYn);
            if (read == -1) {
                return false;
            }
            this.aYn += read;
            if (this.bhp == 0 && this.bhq == 0 && this.aYn > 0 && obj[0] == '﻿') {
                this.pos++;
                this.bhq++;
                i++;
            }
        } while (this.aYn < i);
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int zzda(boolean r8) throws java.io.IOException {
        /*
        r7 = this;
        r0 = r7.bho;
    L_0x0002:
        r1 = r7.pos;
    L_0x0004:
        r2 = r7.aYn;
    L_0x0006:
        r3 = 1;
        if (r1 != r2) goto L_0x004f;
    L_0x0009:
        r7.pos = r1;
        r1 = r7.zzaed(r3);
        if (r1 != 0) goto L_0x004b;
    L_0x0011:
        if (r8 == 0) goto L_0x0049;
    L_0x0013:
        r8 = new java.io.EOFException;
        r0 = "End of input at line ";
        r0 = java.lang.String.valueOf(r0);
        r1 = r7.getLineNumber();
        r2 = r7.getColumnNumber();
        r3 = new java.lang.StringBuilder;
        r4 = 30;
        r5 = java.lang.String.valueOf(r0);
        r5 = r5.length();
        r4 = r4 + r5;
        r3.<init>(r4);
        r3.append(r0);
        r3.append(r1);
        r0 = " column ";
        r3.append(r0);
        r3.append(r2);
        r0 = r3.toString();
        r8.<init>(r0);
        throw r8;
    L_0x0049:
        r8 = -1;
        return r8;
    L_0x004b:
        r1 = r7.pos;
        r2 = r7.aYn;
    L_0x004f:
        r4 = r1 + 1;
        r1 = r0[r1];
        r5 = 10;
        if (r1 != r5) goto L_0x005f;
    L_0x0057:
        r1 = r7.bhp;
        r1 = r1 + r3;
        r7.bhp = r1;
        r7.bhq = r4;
        goto L_0x00c4;
    L_0x005f:
        r5 = 32;
        if (r1 == r5) goto L_0x00c4;
    L_0x0063:
        r5 = 13;
        if (r1 == r5) goto L_0x00c4;
    L_0x0067:
        r5 = 9;
        if (r1 != r5) goto L_0x006c;
    L_0x006b:
        goto L_0x00c4;
    L_0x006c:
        r5 = 47;
        if (r1 != r5) goto L_0x00b7;
    L_0x0070:
        r7.pos = r4;
        r6 = 2;
        if (r4 != r2) goto L_0x0086;
    L_0x0075:
        r2 = r7.pos;
        r2 = r2 - r3;
        r7.pos = r2;
        r2 = r7.zzaed(r6);
        r4 = r7.pos;
        r4 = r4 + r3;
        r7.pos = r4;
        if (r2 != 0) goto L_0x0086;
    L_0x0085:
        return r1;
    L_0x0086:
        r7.m25z();
        r2 = r7.pos;
        r2 = r0[r2];
        r4 = 42;
        if (r2 == r4) goto L_0x009e;
    L_0x0091:
        if (r2 == r5) goto L_0x0094;
    L_0x0093:
        return r1;
    L_0x0094:
        r1 = r7.pos;
        r1 = r1 + r3;
        r7.pos = r1;
    L_0x0099:
        r7.m17A();
        goto L_0x0002;
    L_0x009e:
        r1 = r7.pos;
        r1 = r1 + r3;
        r7.pos = r1;
        r1 = "*/";
        r1 = r7.zztc(r1);
        if (r1 != 0) goto L_0x00b2;
    L_0x00ab:
        r8 = "Unterminated comment";
        r8 = r7.zztd(r8);
        throw r8;
    L_0x00b2:
        r1 = r7.pos;
        r1 = r1 + r6;
        goto L_0x0004;
    L_0x00b7:
        r2 = 35;
        if (r1 != r2) goto L_0x00c1;
    L_0x00bb:
        r7.pos = r4;
        r7.m25z();
        goto L_0x0099;
    L_0x00c1:
        r7.pos = r4;
        return r1;
    L_0x00c4:
        r1 = r4;
        goto L_0x0006;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaop.zzda(boolean):int");
    }

    private boolean zze(char c) throws IOException {
        switch (c) {
            case '\t':
            case '\n':
            case '\f':
            case '\r':
            case ' ':
            case ',':
            case ':':
            case '[':
            case ']':
            case '{':
            case '}':
                break;
            case '#':
            case '/':
            case ';':
            case '=':
            case '\\':
                m25z();
                break;
            default:
                return true;
        }
        return false;
    }

    private String zzf(char c) throws IOException {
        char[] cArr = this.bho;
        StringBuilder stringBuilder = new StringBuilder();
        while (true) {
            int i = this.pos;
            int i2 = this.aYn;
            int i3 = i;
            while (i < i2) {
                int i4 = i + 1;
                char c2 = cArr[i];
                if (c2 == c) {
                    this.pos = i4;
                    stringBuilder.append(cArr, i3, (i4 - i3) - 1);
                    return stringBuilder.toString();
                } else if (c2 == '\\') {
                    this.pos = i4;
                    stringBuilder.append(cArr, i3, (i4 - i3) - 1);
                    stringBuilder.append(m18B());
                    break;
                } else {
                    if (c2 == '\n') {
                        this.bhp++;
                        this.bhq = i4;
                    }
                    i = i4;
                }
            }
            stringBuilder.append(cArr, i3, i - i3);
            this.pos = i;
            if (!zzaed(1)) {
                throw zztd("Unterminated string");
            }
        }
    }

    private void zzg(char c) throws IOException {
        char[] cArr = this.bho;
        while (true) {
            int i = this.pos;
            int i2 = this.aYn;
            while (i < i2) {
                int i3 = i + 1;
                char c2 = cArr[i];
                if (c2 == c) {
                    this.pos = i3;
                    return;
                } else if (c2 == '\\') {
                    this.pos = i3;
                    m18B();
                    break;
                } else {
                    if (c2 == '\n') {
                        this.bhp++;
                        this.bhq = i3;
                    }
                    i = i3;
                }
            }
            this.pos = i;
            if (!zzaed(1)) {
                throw zztd("Unterminated string");
            }
        }
    }

    private boolean zztc(String str) throws IOException {
        while (true) {
            int i = 0;
            if (this.pos + str.length() > this.aYn) {
                if (!zzaed(str.length())) {
                    return false;
                }
            }
            if (this.bho[this.pos] == '\n') {
                this.bhp++;
                this.bhq = this.pos + 1;
            } else {
                while (i < str.length()) {
                    if (this.bho[this.pos + i] == str.charAt(i)) {
                        i++;
                    }
                }
                return true;
            }
            this.pos++;
        }
    }

    private IOException zztd(String str) throws IOException {
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        StringBuilder stringBuilder = new StringBuilder((45 + String.valueOf(str).length()) + String.valueOf(path).length());
        stringBuilder.append(str);
        stringBuilder.append(" at line ");
        stringBuilder.append(lineNumber);
        stringBuilder.append(" column ");
        stringBuilder.append(columnNumber);
        stringBuilder.append(" path ");
        stringBuilder.append(path);
        throw new zzaos(stringBuilder.toString());
    }

    public void beginArray() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 3) {
            zzaec(1);
            this.bhy[this.bhw - 1] = 0;
            this.bhr = 0;
            return;
        }
        String valueOf = String.valueOf(mo2301h());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        StringBuilder stringBuilder = new StringBuilder((74 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
        stringBuilder.append("Expected BEGIN_ARRAY but was ");
        stringBuilder.append(valueOf);
        stringBuilder.append(" at line ");
        stringBuilder.append(lineNumber);
        stringBuilder.append(" column ");
        stringBuilder.append(columnNumber);
        stringBuilder.append(" path ");
        stringBuilder.append(path);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public void beginObject() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 1) {
            zzaec(3);
            this.bhr = 0;
            return;
        }
        String valueOf = String.valueOf(mo2301h());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        StringBuilder stringBuilder = new StringBuilder((75 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
        stringBuilder.append("Expected BEGIN_OBJECT but was ");
        stringBuilder.append(valueOf);
        stringBuilder.append(" at line ");
        stringBuilder.append(lineNumber);
        stringBuilder.append(" column ");
        stringBuilder.append(columnNumber);
        stringBuilder.append(" path ");
        stringBuilder.append(path);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public void close() throws IOException {
        this.bhr = 0;
        this.bhv[0] = 8;
        this.bhw = 1;
        this.in.close();
    }

    public void endArray() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 4) {
            this.bhw--;
            int[] iArr = this.bhy;
            int i2 = this.bhw - 1;
            iArr[i2] = iArr[i2] + 1;
            this.bhr = 0;
            return;
        }
        String valueOf = String.valueOf(mo2301h());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        StringBuilder stringBuilder = new StringBuilder((72 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
        stringBuilder.append("Expected END_ARRAY but was ");
        stringBuilder.append(valueOf);
        stringBuilder.append(" at line ");
        stringBuilder.append(lineNumber);
        stringBuilder.append(" column ");
        stringBuilder.append(columnNumber);
        stringBuilder.append(" path ");
        stringBuilder.append(path);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public void endObject() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 2) {
            this.bhw--;
            this.bhx[this.bhw] = null;
            int[] iArr = this.bhy;
            int i2 = this.bhw - 1;
            iArr[i2] = iArr[i2] + 1;
            this.bhr = 0;
            return;
        }
        String valueOf = String.valueOf(mo2301h());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        StringBuilder stringBuilder = new StringBuilder((73 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
        stringBuilder.append("Expected END_OBJECT but was ");
        stringBuilder.append(valueOf);
        stringBuilder.append(" at line ");
        stringBuilder.append(lineNumber);
        stringBuilder.append(" column ");
        stringBuilder.append(columnNumber);
        stringBuilder.append(" path ");
        stringBuilder.append(path);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public String getPath() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('$');
        int i = this.bhw;
        for (int i2 = 0; i2 < i; i2++) {
            switch (this.bhv[i2]) {
                case 1:
                case 2:
                    stringBuilder.append('[');
                    stringBuilder.append(this.bhy[i2]);
                    stringBuilder.append(']');
                    break;
                case 3:
                case 4:
                case 5:
                    stringBuilder.append('.');
                    if (this.bhx[i2] == null) {
                        break;
                    }
                    stringBuilder.append(this.bhx[i2]);
                    break;
                default:
                    break;
            }
        }
        return stringBuilder.toString();
    }

    public zzaoq mo2301h() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        switch (i) {
            case 1:
                return zzaoq.BEGIN_OBJECT;
            case 2:
                return zzaoq.END_OBJECT;
            case 3:
                return zzaoq.BEGIN_ARRAY;
            case 4:
                return zzaoq.END_ARRAY;
            case 5:
            case 6:
                return zzaoq.BOOLEAN;
            case 7:
                return zzaoq.NULL;
            case 8:
            case 9:
            case 10:
            case 11:
                return zzaoq.STRING;
            case 12:
            case 13:
            case 14:
                return zzaoq.NAME;
            case 15:
            case 16:
                return zzaoq.NUMBER;
            case 17:
                return zzaoq.END_DOCUMENT;
            default:
                throw new AssertionError();
        }
    }

    public boolean hasNext() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        return (i == 2 || i == 4) ? false : true;
    }

    public final boolean isLenient() {
        return this.bhn;
    }

    public boolean nextBoolean() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        int[] iArr;
        int i2;
        if (i == 5) {
            this.bhr = 0;
            iArr = this.bhy;
            i2 = this.bhw - 1;
            iArr[i2] = iArr[i2] + 1;
            return true;
        } else if (i == 6) {
            this.bhr = 0;
            iArr = this.bhy;
            i2 = this.bhw - 1;
            iArr[i2] = iArr[i2] + 1;
            return false;
        } else {
            String valueOf = String.valueOf(mo2301h());
            int lineNumber = getLineNumber();
            int columnNumber = getColumnNumber();
            String path = getPath();
            StringBuilder stringBuilder = new StringBuilder((72 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
            stringBuilder.append("Expected a boolean but was ");
            stringBuilder.append(valueOf);
            stringBuilder.append(" at line ");
            stringBuilder.append(lineNumber);
            stringBuilder.append(" column ");
            stringBuilder.append(columnNumber);
            stringBuilder.append(" path ");
            stringBuilder.append(path);
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    public double nextDouble() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 15) {
            this.bhr = 0;
            int[] iArr = this.bhy;
            int i2 = this.bhw - 1;
            iArr[i2] = iArr[i2] + 1;
            return (double) this.bhs;
        }
        if (i == 16) {
            this.bhu = new String(this.bho, this.pos, this.bht);
            this.pos += this.bht;
        } else {
            String x;
            if (i != 8) {
                if (i != 9) {
                    if (i == 10) {
                        x = m23x();
                        this.bhu = x;
                    } else if (i != 11) {
                        String valueOf = String.valueOf(mo2301h());
                        int lineNumber = getLineNumber();
                        int columnNumber = getColumnNumber();
                        String path = getPath();
                        StringBuilder stringBuilder = new StringBuilder((71 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
                        stringBuilder.append("Expected a double but was ");
                        stringBuilder.append(valueOf);
                        stringBuilder.append(" at line ");
                        stringBuilder.append(lineNumber);
                        stringBuilder.append(" column ");
                        stringBuilder.append(columnNumber);
                        stringBuilder.append(" path ");
                        stringBuilder.append(path);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                }
            }
            x = zzf(i == 8 ? '\'' : '\"');
            this.bhu = x;
        }
        this.bhr = 11;
        double parseDouble = Double.parseDouble(this.bhu);
        if (this.bhn || !(Double.isNaN(parseDouble) || Double.isInfinite(parseDouble))) {
            this.bhu = null;
            this.bhr = 0;
            int[] iArr2 = this.bhy;
            columnNumber = this.bhw - 1;
            iArr2[columnNumber] = iArr2[columnNumber] + 1;
            return parseDouble;
        }
        columnNumber = getLineNumber();
        int columnNumber2 = getColumnNumber();
        String path2 = getPath();
        StringBuilder stringBuilder2 = new StringBuilder(102 + String.valueOf(path2).length());
        stringBuilder2.append("JSON forbids NaN and infinities: ");
        stringBuilder2.append(parseDouble);
        stringBuilder2.append(" at line ");
        stringBuilder2.append(columnNumber);
        stringBuilder2.append(" column ");
        stringBuilder2.append(columnNumber2);
        stringBuilder2.append(" path ");
        stringBuilder2.append(path2);
        throw new zzaos(stringBuilder2.toString());
    }

    public int nextInt() throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r9 = this;
        r0 = r9.bhr;
        if (r0 != 0) goto L_0x0008;
    L_0x0004:
        r0 = r9.m20u();
    L_0x0008:
        r1 = 15;
        r2 = 0;
        if (r0 != r1) goto L_0x006e;
    L_0x000d:
        r0 = r9.bhs;
        r0 = (int) r0;
        r3 = r9.bhs;
        r5 = (long) r0;
        r1 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1));
        if (r1 == 0) goto L_0x005f;
    L_0x0017:
        r0 = new java.lang.NumberFormatException;
        r1 = r9.bhs;
        r3 = r9.getLineNumber();
        r4 = r9.getColumnNumber();
        r5 = r9.getPath();
        r6 = new java.lang.StringBuilder;
        r7 = 89;
        r8 = java.lang.String.valueOf(r5);
        r8 = r8.length();
        r7 = r7 + r8;
        r6.<init>(r7);
        r7 = "Expected an int but was ";
        r6.append(r7);
        r6.append(r1);
        r1 = " at line ";
        r6.append(r1);
        r6.append(r3);
        r1 = " column ";
        r6.append(r1);
        r6.append(r4);
        r1 = " path ";
        r6.append(r1);
        r6.append(r5);
        r1 = r6.toString();
        r0.<init>(r1);
        throw r0;
    L_0x005f:
        r9.bhr = r2;
        r1 = r9.bhy;
        r2 = r9.bhw;
        r2 = r2 + -1;
        r3 = r1[r2];
        r3 = r3 + 1;
        r1[r2] = r3;
        return r0;
    L_0x006e:
        r1 = 16;
        r3 = 69;
        if (r0 != r1) goto L_0x008a;
    L_0x0074:
        r0 = new java.lang.String;
        r1 = r9.bho;
        r4 = r9.pos;
        r5 = r9.bht;
        r0.<init>(r1, r4, r5);
        r9.bhu = r0;
        r0 = r9.pos;
        r1 = r9.bht;
        r0 = r0 + r1;
        r9.pos = r0;
        goto L_0x010a;
    L_0x008a:
        r1 = 8;
        if (r0 == r1) goto L_0x00e8;
    L_0x008e:
        r4 = 9;
        if (r0 != r4) goto L_0x0093;
    L_0x0092:
        goto L_0x00e8;
    L_0x0093:
        r0 = new java.lang.IllegalStateException;
        r1 = r9.mo2301h();
        r1 = java.lang.String.valueOf(r1);
        r2 = r9.getLineNumber();
        r4 = r9.getColumnNumber();
        r5 = r9.getPath();
        r6 = new java.lang.StringBuilder;
        r7 = java.lang.String.valueOf(r1);
        r7 = r7.length();
        r3 = r3 + r7;
        r7 = java.lang.String.valueOf(r5);
        r7 = r7.length();
        r3 = r3 + r7;
        r6.<init>(r3);
        r3 = "Expected an int but was ";
        r6.append(r3);
        r6.append(r1);
        r1 = " at line ";
        r6.append(r1);
        r6.append(r2);
        r1 = " column ";
        r6.append(r1);
        r6.append(r4);
        r1 = " path ";
        r6.append(r1);
        r6.append(r5);
        r1 = r6.toString();
        r0.<init>(r1);
        throw r0;
    L_0x00e8:
        if (r0 != r1) goto L_0x00ed;
    L_0x00ea:
        r0 = 39;
        goto L_0x00ef;
    L_0x00ed:
        r0 = 34;
    L_0x00ef:
        r0 = r9.zzf(r0);
        r9.bhu = r0;
        r0 = r9.bhu;	 Catch:{ NumberFormatException -> 0x010a }
        r0 = java.lang.Integer.parseInt(r0);	 Catch:{ NumberFormatException -> 0x010a }
        r9.bhr = r2;	 Catch:{ NumberFormatException -> 0x010a }
        r1 = r9.bhy;	 Catch:{ NumberFormatException -> 0x010a }
        r4 = r9.bhw;	 Catch:{ NumberFormatException -> 0x010a }
        r4 = r4 + -1;	 Catch:{ NumberFormatException -> 0x010a }
        r5 = r1[r4];	 Catch:{ NumberFormatException -> 0x010a }
        r5 = r5 + 1;	 Catch:{ NumberFormatException -> 0x010a }
        r1[r4] = r5;	 Catch:{ NumberFormatException -> 0x010a }
        return r0;
    L_0x010a:
        r0 = 11;
        r9.bhr = r0;
        r0 = r9.bhu;
        r0 = java.lang.Double.parseDouble(r0);
        r4 = (int) r0;
        r5 = (double) r4;
        r7 = (r5 > r0 ? 1 : (r5 == r0 ? 0 : -1));
        if (r7 == 0) goto L_0x0169;
    L_0x011a:
        r0 = new java.lang.NumberFormatException;
        r1 = r9.bhu;
        r2 = r9.getLineNumber();
        r4 = r9.getColumnNumber();
        r5 = r9.getPath();
        r6 = new java.lang.StringBuilder;
        r7 = java.lang.String.valueOf(r1);
        r7 = r7.length();
        r3 = r3 + r7;
        r7 = java.lang.String.valueOf(r5);
        r7 = r7.length();
        r3 = r3 + r7;
        r6.<init>(r3);
        r3 = "Expected an int but was ";
        r6.append(r3);
        r6.append(r1);
        r1 = " at line ";
        r6.append(r1);
        r6.append(r2);
        r1 = " column ";
        r6.append(r1);
        r6.append(r4);
        r1 = " path ";
        r6.append(r1);
        r6.append(r5);
        r1 = r6.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0169:
        r0 = 0;
        r9.bhu = r0;
        r9.bhr = r2;
        r0 = r9.bhy;
        r1 = r9.bhw;
        r1 = r1 + -1;
        r2 = r0[r1];
        r2 = r2 + 1;
        r0[r1] = r2;
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaop.nextInt():int");
    }

    public long nextLong() throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r9 = this;
        r0 = r9.bhr;
        if (r0 != 0) goto L_0x0008;
    L_0x0004:
        r0 = r9.m20u();
    L_0x0008:
        r1 = 15;
        r2 = 0;
        if (r0 != r1) goto L_0x001e;
    L_0x000d:
        r9.bhr = r2;
        r0 = r9.bhy;
        r1 = r9.bhw;
        r1 = r1 + -1;
        r2 = r0[r1];
        r2 = r2 + 1;
        r0[r1] = r2;
        r0 = r9.bhs;
        return r0;
    L_0x001e:
        r1 = 16;
        r3 = 69;
        if (r0 != r1) goto L_0x003a;
    L_0x0024:
        r0 = new java.lang.String;
        r1 = r9.bho;
        r4 = r9.pos;
        r5 = r9.bht;
        r0.<init>(r1, r4, r5);
        r9.bhu = r0;
        r0 = r9.pos;
        r1 = r9.bht;
        r0 = r0 + r1;
        r9.pos = r0;
        goto L_0x00ba;
    L_0x003a:
        r1 = 8;
        if (r0 == r1) goto L_0x0098;
    L_0x003e:
        r4 = 9;
        if (r0 != r4) goto L_0x0043;
    L_0x0042:
        goto L_0x0098;
    L_0x0043:
        r0 = new java.lang.IllegalStateException;
        r1 = r9.mo2301h();
        r1 = java.lang.String.valueOf(r1);
        r2 = r9.getLineNumber();
        r4 = r9.getColumnNumber();
        r5 = r9.getPath();
        r6 = new java.lang.StringBuilder;
        r7 = java.lang.String.valueOf(r1);
        r7 = r7.length();
        r3 = r3 + r7;
        r7 = java.lang.String.valueOf(r5);
        r7 = r7.length();
        r3 = r3 + r7;
        r6.<init>(r3);
        r3 = "Expected a long but was ";
        r6.append(r3);
        r6.append(r1);
        r1 = " at line ";
        r6.append(r1);
        r6.append(r2);
        r1 = " column ";
        r6.append(r1);
        r6.append(r4);
        r1 = " path ";
        r6.append(r1);
        r6.append(r5);
        r1 = r6.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0098:
        if (r0 != r1) goto L_0x009d;
    L_0x009a:
        r0 = 39;
        goto L_0x009f;
    L_0x009d:
        r0 = 34;
    L_0x009f:
        r0 = r9.zzf(r0);
        r9.bhu = r0;
        r0 = r9.bhu;	 Catch:{ NumberFormatException -> 0x00ba }
        r0 = java.lang.Long.parseLong(r0);	 Catch:{ NumberFormatException -> 0x00ba }
        r9.bhr = r2;	 Catch:{ NumberFormatException -> 0x00ba }
        r4 = r9.bhy;	 Catch:{ NumberFormatException -> 0x00ba }
        r5 = r9.bhw;	 Catch:{ NumberFormatException -> 0x00ba }
        r5 = r5 + -1;	 Catch:{ NumberFormatException -> 0x00ba }
        r6 = r4[r5];	 Catch:{ NumberFormatException -> 0x00ba }
        r6 = r6 + 1;	 Catch:{ NumberFormatException -> 0x00ba }
        r4[r5] = r6;	 Catch:{ NumberFormatException -> 0x00ba }
        return r0;
    L_0x00ba:
        r0 = 11;
        r9.bhr = r0;
        r0 = r9.bhu;
        r0 = java.lang.Double.parseDouble(r0);
        r4 = (long) r0;
        r6 = (double) r4;
        r8 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1));
        if (r8 == 0) goto L_0x0119;
    L_0x00ca:
        r0 = new java.lang.NumberFormatException;
        r1 = r9.bhu;
        r2 = r9.getLineNumber();
        r4 = r9.getColumnNumber();
        r5 = r9.getPath();
        r6 = new java.lang.StringBuilder;
        r7 = java.lang.String.valueOf(r1);
        r7 = r7.length();
        r3 = r3 + r7;
        r7 = java.lang.String.valueOf(r5);
        r7 = r7.length();
        r3 = r3 + r7;
        r6.<init>(r3);
        r3 = "Expected a long but was ";
        r6.append(r3);
        r6.append(r1);
        r1 = " at line ";
        r6.append(r1);
        r6.append(r2);
        r1 = " column ";
        r6.append(r1);
        r6.append(r4);
        r1 = " path ";
        r6.append(r1);
        r6.append(r5);
        r1 = r6.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0119:
        r0 = 0;
        r9.bhu = r0;
        r9.bhr = r2;
        r0 = r9.bhy;
        r1 = r9.bhw;
        r1 = r1 + -1;
        r2 = r0[r1];
        r2 = r2 + 1;
        r0[r1] = r2;
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaop.nextLong():long");
    }

    public String nextName() throws IOException {
        String x;
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 14) {
            x = m23x();
        } else {
            char c;
            if (i == 12) {
                c = '\'';
            } else if (i == 13) {
                c = '\"';
            } else {
                String valueOf = String.valueOf(mo2301h());
                int lineNumber = getLineNumber();
                int columnNumber = getColumnNumber();
                String path = getPath();
                StringBuilder stringBuilder = new StringBuilder((69 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
                stringBuilder.append("Expected a name but was ");
                stringBuilder.append(valueOf);
                stringBuilder.append(" at line ");
                stringBuilder.append(lineNumber);
                stringBuilder.append(" column ");
                stringBuilder.append(columnNumber);
                stringBuilder.append(" path ");
                stringBuilder.append(path);
                throw new IllegalStateException(stringBuilder.toString());
            }
            x = zzf(c);
        }
        this.bhr = 0;
        this.bhx[this.bhw - 1] = x;
        return x;
    }

    public void nextNull() throws IOException {
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 7) {
            this.bhr = 0;
            int[] iArr = this.bhy;
            int i2 = this.bhw - 1;
            iArr[i2] = iArr[i2] + 1;
            return;
        }
        String valueOf = String.valueOf(mo2301h());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        StringBuilder stringBuilder = new StringBuilder((67 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
        stringBuilder.append("Expected null but was ");
        stringBuilder.append(valueOf);
        stringBuilder.append(" at line ");
        stringBuilder.append(lineNumber);
        stringBuilder.append(" column ");
        stringBuilder.append(columnNumber);
        stringBuilder.append(" path ");
        stringBuilder.append(path);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public String nextString() throws IOException {
        String x;
        int lineNumber;
        int i = this.bhr;
        if (i == 0) {
            i = m20u();
        }
        if (i == 10) {
            x = m23x();
        } else {
            char c;
            if (i == 8) {
                c = '\'';
            } else if (i == 9) {
                c = '\"';
            } else if (i == 11) {
                x = this.bhu;
                this.bhu = null;
            } else if (i == 15) {
                x = Long.toString(this.bhs);
            } else if (i == 16) {
                x = new String(this.bho, this.pos, this.bht);
                this.pos += this.bht;
            } else {
                String valueOf = String.valueOf(mo2301h());
                lineNumber = getLineNumber();
                int columnNumber = getColumnNumber();
                String path = getPath();
                StringBuilder stringBuilder = new StringBuilder((71 + String.valueOf(valueOf).length()) + String.valueOf(path).length());
                stringBuilder.append("Expected a string but was ");
                stringBuilder.append(valueOf);
                stringBuilder.append(" at line ");
                stringBuilder.append(lineNumber);
                stringBuilder.append(" column ");
                stringBuilder.append(columnNumber);
                stringBuilder.append(" path ");
                stringBuilder.append(path);
                throw new IllegalStateException(stringBuilder.toString());
            }
            x = zzf(c);
        }
        this.bhr = 0;
        int[] iArr = this.bhy;
        lineNumber = this.bhw - 1;
        iArr[lineNumber] = iArr[lineNumber] + 1;
        return x;
    }

    public final void setLenient(boolean z) {
        this.bhn = z;
    }

    public void skipValue() throws IOException {
        int i = 0;
        do {
            int i2 = this.bhr;
            if (i2 == 0) {
                i2 = m20u();
            }
            if (i2 == 3) {
                zzaec(1);
            } else if (i2 == 1) {
                zzaec(3);
            } else {
                if (i2 != 4) {
                    if (i2 != 2) {
                        if (i2 != 14) {
                            if (i2 != 10) {
                                char c;
                                if (i2 != 8) {
                                    if (i2 != 12) {
                                        if (i2 != 9) {
                                            if (i2 != 13) {
                                                if (i2 == 16) {
                                                    this.pos += this.bht;
                                                }
                                                this.bhr = 0;
                                            }
                                        }
                                        c = '\"';
                                        zzg(c);
                                        this.bhr = 0;
                                    }
                                }
                                c = '\'';
                                zzg(c);
                                this.bhr = 0;
                            }
                        }
                        m24y();
                        this.bhr = 0;
                    }
                }
                this.bhw--;
                i--;
                this.bhr = 0;
            }
            i++;
            this.bhr = 0;
        } while (i != 0);
        int[] iArr = this.bhy;
        i = this.bhw - 1;
        iArr[i] = iArr[i] + 1;
        this.bhx[this.bhw - 1] = "null";
    }

    public String toString() {
        String valueOf = String.valueOf(getClass().getSimpleName());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        StringBuilder stringBuilder = new StringBuilder(39 + String.valueOf(valueOf).length());
        stringBuilder.append(valueOf);
        stringBuilder.append(" at line ");
        stringBuilder.append(lineNumber);
        stringBuilder.append(" column ");
        stringBuilder.append(columnNumber);
        return stringBuilder.toString();
    }
}
