package com.google.android.gms.internal;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.util.zzf;
import java.util.Map;
import java.util.Set;

@zzir
public class zzhe extends zzhj {
    static final Set<String> zzbqi = zzf.zzc("top-left", "top-right", "top-center", "center", "bottom-left", "bottom-right", "bottom-center");
    private int zzaie = -1;
    private int zzaif = -1;
    private final Object zzail = new Object();
    private AdSizeParcel zzang;
    private final zzll zzbgj;
    private final Activity zzbpy;
    private String zzbqj = "top-right";
    private boolean zzbqk = true;
    private int zzbql = 0;
    private int zzbqm = 0;
    private int zzbqn = 0;
    private int zzbqo = 0;
    private ImageView zzbqp;
    private LinearLayout zzbqq;
    private zzhk zzbqr;
    private PopupWindow zzbqs;
    private RelativeLayout zzbqt;
    private ViewGroup zzbqu;

    class C04481 implements OnClickListener {
        final /* synthetic */ zzhe zzbqv;

        C04481(zzhe com_google_android_gms_internal_zzhe) {
            this.zzbqv = com_google_android_gms_internal_zzhe;
        }

        public void onClick(View view) {
            this.zzbqv.zzs(true);
        }
    }

    public zzhe(zzll com_google_android_gms_internal_zzll, zzhk com_google_android_gms_internal_zzhk) {
        super(com_google_android_gms_internal_zzll, "resize");
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.zzbpy = com_google_android_gms_internal_zzll.zzuf();
        this.zzbqr = com_google_android_gms_internal_zzhk;
    }

    private void zzi(Map<String, String> map) {
        if (!TextUtils.isEmpty((CharSequence) map.get("width"))) {
            this.zzaie = zzu.zzfq().zzcq((String) map.get("width"));
        }
        if (!TextUtils.isEmpty((CharSequence) map.get("height"))) {
            this.zzaif = zzu.zzfq().zzcq((String) map.get("height"));
        }
        if (!TextUtils.isEmpty((CharSequence) map.get("offsetX"))) {
            this.zzbqn = zzu.zzfq().zzcq((String) map.get("offsetX"));
        }
        if (!TextUtils.isEmpty((CharSequence) map.get("offsetY"))) {
            this.zzbqo = zzu.zzfq().zzcq((String) map.get("offsetY"));
        }
        if (!TextUtils.isEmpty((CharSequence) map.get("allowOffscreen"))) {
            this.zzbqk = Boolean.parseBoolean((String) map.get("allowOffscreen"));
        }
        String str = (String) map.get("customClosePosition");
        if (!TextUtils.isEmpty(str)) {
            this.zzbqj = str;
        }
    }

    private int[] zzmx() {
        if (!zzmz()) {
            return null;
        }
        if (this.zzbqk) {
            return new int[]{this.zzbql + this.zzbqn, this.zzbqm + this.zzbqo};
        }
        int[] zzi = zzu.zzfq().zzi(this.zzbpy);
        int[] zzk = zzu.zzfq().zzk(this.zzbpy);
        int i = zzi[0];
        int i2 = this.zzbql + this.zzbqn;
        int i3 = this.zzbqm + this.zzbqo;
        i = i2 < 0 ? 0 : this.zzaie + i2 > i ? i - this.zzaie : i2;
        if (i3 < zzk[0]) {
            i3 = zzk[0];
        } else if (this.zzaif + i3 > zzk[1]) {
            i3 = zzk[1] - this.zzaif;
        }
        return new int[]{i, i3};
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void execute(java.util.Map<java.lang.String, java.lang.String> r12) {
        /*
        r11 = this;
        r0 = r11.zzail;
        monitor-enter(r0);
        r1 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        if (r1 != 0) goto L_0x000e;
    L_0x0007:
        r12 = "Not an activity context. Cannot resize.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x000e:
        r1 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r1 = r1.zzdo();	 Catch:{ all -> 0x0273 }
        if (r1 != 0) goto L_0x001d;
    L_0x0016:
        r12 = "Webview is not yet available, size is not set.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x001d:
        r1 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r1 = r1.zzdo();	 Catch:{ all -> 0x0273 }
        r1 = r1.zzauq;	 Catch:{ all -> 0x0273 }
        if (r1 == 0) goto L_0x002e;
    L_0x0027:
        r12 = "Is interstitial. Cannot resize an interstitial.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x002e:
        r1 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r1 = r1.zzuo();	 Catch:{ all -> 0x0273 }
        if (r1 == 0) goto L_0x003d;
    L_0x0036:
        r12 = "Cannot resize an expanded banner.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x003d:
        r11.zzi(r12);	 Catch:{ all -> 0x0273 }
        r12 = r11.zzmw();	 Catch:{ all -> 0x0273 }
        if (r12 != 0) goto L_0x004d;
    L_0x0046:
        r12 = "Invalid width and height options. Cannot resize.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x004d:
        r12 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r12 = r12.getWindow();	 Catch:{ all -> 0x0273 }
        if (r12 == 0) goto L_0x026c;
    L_0x0055:
        r1 = r12.getDecorView();	 Catch:{ all -> 0x0273 }
        if (r1 != 0) goto L_0x005d;
    L_0x005b:
        goto L_0x026c;
    L_0x005d:
        r1 = r11.zzmx();	 Catch:{ all -> 0x0273 }
        if (r1 != 0) goto L_0x006a;
    L_0x0063:
        r12 = "Resize location out of screen or close button is not visible.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x006a:
        r2 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ all -> 0x0273 }
        r3 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r4 = r11.zzaie;	 Catch:{ all -> 0x0273 }
        r2 = r2.zza(r3, r4);	 Catch:{ all -> 0x0273 }
        r3 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r5 = r11.zzaif;	 Catch:{ all -> 0x0273 }
        r3 = r3.zza(r4, r5);	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r4 = r4.getView();	 Catch:{ all -> 0x0273 }
        r4 = r4.getParent();	 Catch:{ all -> 0x0273 }
        if (r4 == 0) goto L_0x0265;
    L_0x008e:
        r5 = r4 instanceof android.view.ViewGroup;	 Catch:{ all -> 0x0273 }
        if (r5 == 0) goto L_0x0265;
    L_0x0092:
        r5 = r4;
        r5 = (android.view.ViewGroup) r5;	 Catch:{ all -> 0x0273 }
        r6 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r6 = r6.getView();	 Catch:{ all -> 0x0273 }
        r5.removeView(r6);	 Catch:{ all -> 0x0273 }
        r5 = r11.zzbqs;	 Catch:{ all -> 0x0273 }
        if (r5 != 0) goto L_0x00d2;
    L_0x00a2:
        r4 = (android.view.ViewGroup) r4;	 Catch:{ all -> 0x0273 }
        r11.zzbqu = r4;	 Catch:{ all -> 0x0273 }
        r4 = com.google.android.gms.ads.internal.zzu.zzfq();	 Catch:{ all -> 0x0273 }
        r5 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r5 = r5.getView();	 Catch:{ all -> 0x0273 }
        r4 = r4.zzk(r5);	 Catch:{ all -> 0x0273 }
        r5 = new android.widget.ImageView;	 Catch:{ all -> 0x0273 }
        r6 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r5.<init>(r6);	 Catch:{ all -> 0x0273 }
        r11.zzbqp = r5;	 Catch:{ all -> 0x0273 }
        r5 = r11.zzbqp;	 Catch:{ all -> 0x0273 }
        r5.setImageBitmap(r4);	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r4 = r4.zzdo();	 Catch:{ all -> 0x0273 }
        r11.zzang = r4;	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbqu;	 Catch:{ all -> 0x0273 }
        r5 = r11.zzbqp;	 Catch:{ all -> 0x0273 }
        r4.addView(r5);	 Catch:{ all -> 0x0273 }
        goto L_0x00d7;
    L_0x00d2:
        r4 = r11.zzbqs;	 Catch:{ all -> 0x0273 }
        r4.dismiss();	 Catch:{ all -> 0x0273 }
    L_0x00d7:
        r4 = new android.widget.RelativeLayout;	 Catch:{ all -> 0x0273 }
        r5 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r4.<init>(r5);	 Catch:{ all -> 0x0273 }
        r11.zzbqt = r4;	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbqt;	 Catch:{ all -> 0x0273 }
        r5 = 0;
        r4.setBackgroundColor(r5);	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbqt;	 Catch:{ all -> 0x0273 }
        r6 = new android.view.ViewGroup$LayoutParams;	 Catch:{ all -> 0x0273 }
        r6.<init>(r2, r3);	 Catch:{ all -> 0x0273 }
        r4.setLayoutParams(r6);	 Catch:{ all -> 0x0273 }
        r4 = com.google.android.gms.ads.internal.zzu.zzfq();	 Catch:{ all -> 0x0273 }
        r6 = r11.zzbqt;	 Catch:{ all -> 0x0273 }
        r2 = r4.zza(r6, r2, r3, r5);	 Catch:{ all -> 0x0273 }
        r11.zzbqs = r2;	 Catch:{ all -> 0x0273 }
        r2 = r11.zzbqs;	 Catch:{ all -> 0x0273 }
        r3 = 1;
        r2.setOutsideTouchable(r3);	 Catch:{ all -> 0x0273 }
        r2 = r11.zzbqs;	 Catch:{ all -> 0x0273 }
        r2.setTouchable(r3);	 Catch:{ all -> 0x0273 }
        r2 = r11.zzbqs;	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbqk;	 Catch:{ all -> 0x0273 }
        r4 = r4 ^ r3;
        r2.setClippingEnabled(r4);	 Catch:{ all -> 0x0273 }
        r2 = r11.zzbqt;	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r4 = r4.getView();	 Catch:{ all -> 0x0273 }
        r6 = -1;
        r2.addView(r4, r6, r6);	 Catch:{ all -> 0x0273 }
        r2 = new android.widget.LinearLayout;	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r2.<init>(r4);	 Catch:{ all -> 0x0273 }
        r11.zzbqq = r2;	 Catch:{ all -> 0x0273 }
        r2 = new android.widget.RelativeLayout$LayoutParams;	 Catch:{ all -> 0x0273 }
        r4 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ all -> 0x0273 }
        r7 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r8 = 50;
        r4 = r4.zza(r7, r8);	 Catch:{ all -> 0x0273 }
        r7 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ all -> 0x0273 }
        r9 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r7 = r7.zza(r9, r8);	 Catch:{ all -> 0x0273 }
        r2.<init>(r4, r7);	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbqj;	 Catch:{ all -> 0x0273 }
        r7 = r4.hashCode();	 Catch:{ all -> 0x0273 }
        switch(r7) {
            case -1364013995: goto L_0x017b;
            case -1012429441: goto L_0x0171;
            case -655373719: goto L_0x0167;
            case 1163912186: goto L_0x015d;
            case 1288627767: goto L_0x0153;
            case 1755462605: goto L_0x0149;
            default: goto L_0x0148;
        };	 Catch:{ all -> 0x0273 }
    L_0x0148:
        goto L_0x0185;
    L_0x0149:
        r7 = "top-center";
        r4 = r4.equals(r7);	 Catch:{ all -> 0x0273 }
        if (r4 == 0) goto L_0x0185;
    L_0x0151:
        r4 = r3;
        goto L_0x0186;
    L_0x0153:
        r7 = "bottom-center";
        r4 = r4.equals(r7);	 Catch:{ all -> 0x0273 }
        if (r4 == 0) goto L_0x0185;
    L_0x015b:
        r4 = 4;
        goto L_0x0186;
    L_0x015d:
        r7 = "bottom-right";
        r4 = r4.equals(r7);	 Catch:{ all -> 0x0273 }
        if (r4 == 0) goto L_0x0185;
    L_0x0165:
        r4 = 5;
        goto L_0x0186;
    L_0x0167:
        r7 = "bottom-left";
        r4 = r4.equals(r7);	 Catch:{ all -> 0x0273 }
        if (r4 == 0) goto L_0x0185;
    L_0x016f:
        r4 = 3;
        goto L_0x0186;
    L_0x0171:
        r7 = "top-left";
        r4 = r4.equals(r7);	 Catch:{ all -> 0x0273 }
        if (r4 == 0) goto L_0x0185;
    L_0x0179:
        r4 = r5;
        goto L_0x0186;
    L_0x017b:
        r7 = "center";
        r4 = r4.equals(r7);	 Catch:{ all -> 0x0273 }
        if (r4 == 0) goto L_0x0185;
    L_0x0183:
        r4 = 2;
        goto L_0x0186;
    L_0x0185:
        r4 = r6;
    L_0x0186:
        r6 = 9;
        r7 = 14;
        r8 = 11;
        r9 = 12;
        r10 = 10;
        switch(r4) {
            case 0: goto L_0x01b6;
            case 1: goto L_0x01b2;
            case 2: goto L_0x01ac;
            case 3: goto L_0x01a5;
            case 4: goto L_0x019e;
            case 5: goto L_0x0197;
            default: goto L_0x0193;
        };	 Catch:{ all -> 0x0273 }
    L_0x0193:
        r2.addRule(r10);	 Catch:{ all -> 0x0273 }
        goto L_0x019a;
    L_0x0197:
        r2.addRule(r9);	 Catch:{ all -> 0x0273 }
    L_0x019a:
        r2.addRule(r8);	 Catch:{ all -> 0x0273 }
        goto L_0x01ba;
    L_0x019e:
        r2.addRule(r9);	 Catch:{ all -> 0x0273 }
    L_0x01a1:
        r2.addRule(r7);	 Catch:{ all -> 0x0273 }
        goto L_0x01ba;
    L_0x01a5:
        r2.addRule(r9);	 Catch:{ all -> 0x0273 }
    L_0x01a8:
        r2.addRule(r6);	 Catch:{ all -> 0x0273 }
        goto L_0x01ba;
    L_0x01ac:
        r4 = 13;
        r2.addRule(r4);	 Catch:{ all -> 0x0273 }
        goto L_0x01ba;
    L_0x01b2:
        r2.addRule(r10);	 Catch:{ all -> 0x0273 }
        goto L_0x01a1;
    L_0x01b6:
        r2.addRule(r10);	 Catch:{ all -> 0x0273 }
        goto L_0x01a8;
    L_0x01ba:
        r4 = r11.zzbqq;	 Catch:{ all -> 0x0273 }
        r6 = new com.google.android.gms.internal.zzhe$1;	 Catch:{ all -> 0x0273 }
        r6.<init>(r11);	 Catch:{ all -> 0x0273 }
        r4.setOnClickListener(r6);	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbqq;	 Catch:{ all -> 0x0273 }
        r6 = "Close button";
        r4.setContentDescription(r6);	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbqt;	 Catch:{ all -> 0x0273 }
        r6 = r11.zzbqq;	 Catch:{ all -> 0x0273 }
        r4.addView(r6, r2);	 Catch:{ all -> 0x0273 }
        r2 = r11.zzbqs;	 Catch:{ RuntimeException -> 0x021d }
        r12 = r12.getDecorView();	 Catch:{ RuntimeException -> 0x021d }
        r4 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ RuntimeException -> 0x021d }
        r6 = r11.zzbpy;	 Catch:{ RuntimeException -> 0x021d }
        r7 = r1[r5];	 Catch:{ RuntimeException -> 0x021d }
        r4 = r4.zza(r6, r7);	 Catch:{ RuntimeException -> 0x021d }
        r6 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ RuntimeException -> 0x021d }
        r7 = r11.zzbpy;	 Catch:{ RuntimeException -> 0x021d }
        r8 = r1[r3];	 Catch:{ RuntimeException -> 0x021d }
        r6 = r6.zza(r7, r8);	 Catch:{ RuntimeException -> 0x021d }
        r2.showAtLocation(r12, r5, r4, r6);	 Catch:{ RuntimeException -> 0x021d }
        r12 = r1[r5];	 Catch:{ all -> 0x0273 }
        r2 = r1[r3];	 Catch:{ all -> 0x0273 }
        r11.zzb(r12, r2);	 Catch:{ all -> 0x0273 }
        r12 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r2 = new com.google.android.gms.ads.internal.client.AdSizeParcel;	 Catch:{ all -> 0x0273 }
        r4 = r11.zzbpy;	 Catch:{ all -> 0x0273 }
        r6 = new com.google.android.gms.ads.AdSize;	 Catch:{ all -> 0x0273 }
        r7 = r11.zzaie;	 Catch:{ all -> 0x0273 }
        r8 = r11.zzaif;	 Catch:{ all -> 0x0273 }
        r6.<init>(r7, r8);	 Catch:{ all -> 0x0273 }
        r2.<init>(r4, r6);	 Catch:{ all -> 0x0273 }
        r12.zza(r2);	 Catch:{ all -> 0x0273 }
        r12 = r1[r5];	 Catch:{ all -> 0x0273 }
        r1 = r1[r3];	 Catch:{ all -> 0x0273 }
        r11.zzc(r12, r1);	 Catch:{ all -> 0x0273 }
        r12 = "resized";
        r11.zzbw(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x021d:
        r12 = move-exception;
        r1 = "Cannot show popup window: ";
        r12 = r12.getMessage();	 Catch:{ all -> 0x0273 }
        r12 = java.lang.String.valueOf(r12);	 Catch:{ all -> 0x0273 }
        r2 = r12.length();	 Catch:{ all -> 0x0273 }
        if (r2 == 0) goto L_0x0233;
    L_0x022e:
        r12 = r1.concat(r12);	 Catch:{ all -> 0x0273 }
        goto L_0x0238;
    L_0x0233:
        r12 = new java.lang.String;	 Catch:{ all -> 0x0273 }
        r12.<init>(r1);	 Catch:{ all -> 0x0273 }
    L_0x0238:
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        r12 = r11.zzbqt;	 Catch:{ all -> 0x0273 }
        r1 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r1 = r1.getView();	 Catch:{ all -> 0x0273 }
        r12.removeView(r1);	 Catch:{ all -> 0x0273 }
        r12 = r11.zzbqu;	 Catch:{ all -> 0x0273 }
        if (r12 == 0) goto L_0x0263;
    L_0x024a:
        r12 = r11.zzbqu;	 Catch:{ all -> 0x0273 }
        r1 = r11.zzbqp;	 Catch:{ all -> 0x0273 }
        r12.removeView(r1);	 Catch:{ all -> 0x0273 }
        r12 = r11.zzbqu;	 Catch:{ all -> 0x0273 }
        r1 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r1 = r1.getView();	 Catch:{ all -> 0x0273 }
        r12.addView(r1);	 Catch:{ all -> 0x0273 }
        r12 = r11.zzbgj;	 Catch:{ all -> 0x0273 }
        r1 = r11.zzang;	 Catch:{ all -> 0x0273 }
        r12.zza(r1);	 Catch:{ all -> 0x0273 }
    L_0x0263:
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x0265:
        r12 = "Webview is detached, probably in the middle of a resize or expand.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x026c:
        r12 = "Activity context is not ready, cannot get window or decor view.";
        r11.zzbu(r12);	 Catch:{ all -> 0x0273 }
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        return;
    L_0x0273:
        r12 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x0273 }
        throw r12;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhe.execute(java.util.Map):void");
    }

    public void zza(int i, int i2, boolean z) {
        synchronized (this.zzail) {
            this.zzbql = i;
            this.zzbqm = i2;
            if (this.zzbqs != null && z) {
                int[] zzmx = zzmx();
                if (zzmx != null) {
                    this.zzbqs.update(zzm.zziw().zza(this.zzbpy, zzmx[0]), zzm.zziw().zza(this.zzbpy, zzmx[1]), this.zzbqs.getWidth(), this.zzbqs.getHeight());
                    zzc(zzmx[0], zzmx[1]);
                } else {
                    zzs(true);
                }
            }
        }
    }

    void zzb(int i, int i2) {
        if (this.zzbqr != null) {
            this.zzbqr.zza(i, i2, this.zzaie, this.zzaif);
        }
    }

    void zzc(int i, int i2) {
        zzb(i, i2 - zzu.zzfq().zzk(this.zzbpy)[0], this.zzaie, this.zzaif);
    }

    public void zzd(int i, int i2) {
        this.zzbql = i;
        this.zzbqm = i2;
    }

    boolean zzmw() {
        return this.zzaie > -1 && this.zzaif > -1;
    }

    public boolean zzmy() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzbqs != null;
        }
        return z;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    boolean zzmz() {
        /*
        r9 = this;
        r0 = com.google.android.gms.ads.internal.zzu.zzfq();
        r1 = r9.zzbpy;
        r0 = r0.zzi(r1);
        r1 = com.google.android.gms.ads.internal.zzu.zzfq();
        r2 = r9.zzbpy;
        r1 = r1.zzk(r2);
        r2 = 0;
        r3 = r0[r2];
        r4 = 1;
        r0 = r0[r4];
        r5 = r9.zzaie;
        r6 = 50;
        if (r5 < r6) goto L_0x00ff;
    L_0x0020:
        r5 = r9.zzaie;
        if (r5 <= r3) goto L_0x0026;
    L_0x0024:
        goto L_0x00ff;
    L_0x0026:
        r5 = r9.zzaif;
        if (r5 < r6) goto L_0x00fb;
    L_0x002a:
        r5 = r9.zzaif;
        if (r5 <= r0) goto L_0x0030;
    L_0x002e:
        goto L_0x00fb;
    L_0x0030:
        r5 = r9.zzaif;
        if (r5 != r0) goto L_0x003e;
    L_0x0034:
        r0 = r9.zzaie;
        if (r0 != r3) goto L_0x003e;
    L_0x0038:
        r0 = "Cannot resize to a full-screen ad.";
    L_0x003a:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r0);
        return r2;
    L_0x003e:
        r0 = r9.zzbqk;
        if (r0 == 0) goto L_0x00fa;
    L_0x0042:
        r0 = r9.zzbqj;
        r5 = -1;
        r7 = r0.hashCode();
        r8 = 2;
        switch(r7) {
            case -1364013995: goto L_0x0080;
            case -1012429441: goto L_0x0076;
            case -655373719: goto L_0x006c;
            case 1163912186: goto L_0x0062;
            case 1288627767: goto L_0x0058;
            case 1755462605: goto L_0x004e;
            default: goto L_0x004d;
        };
    L_0x004d:
        goto L_0x008a;
    L_0x004e:
        r7 = "top-center";
        r0 = r0.equals(r7);
        if (r0 == 0) goto L_0x008a;
    L_0x0056:
        r0 = r4;
        goto L_0x008b;
    L_0x0058:
        r7 = "bottom-center";
        r0 = r0.equals(r7);
        if (r0 == 0) goto L_0x008a;
    L_0x0060:
        r0 = 4;
        goto L_0x008b;
    L_0x0062:
        r7 = "bottom-right";
        r0 = r0.equals(r7);
        if (r0 == 0) goto L_0x008a;
    L_0x006a:
        r0 = 5;
        goto L_0x008b;
    L_0x006c:
        r7 = "bottom-left";
        r0 = r0.equals(r7);
        if (r0 == 0) goto L_0x008a;
    L_0x0074:
        r0 = 3;
        goto L_0x008b;
    L_0x0076:
        r7 = "top-left";
        r0 = r0.equals(r7);
        if (r0 == 0) goto L_0x008a;
    L_0x007e:
        r0 = r2;
        goto L_0x008b;
    L_0x0080:
        r7 = "center";
        r0 = r0.equals(r7);
        if (r0 == 0) goto L_0x008a;
    L_0x0088:
        r0 = r8;
        goto L_0x008b;
    L_0x008a:
        r0 = r5;
    L_0x008b:
        switch(r0) {
            case 0: goto L_0x00e5;
            case 1: goto L_0x00d9;
            case 2: goto L_0x00c2;
            case 3: goto L_0x00b3;
            case 4: goto L_0x00a7;
            case 5: goto L_0x009d;
            default: goto L_0x008e;
        };
    L_0x008e:
        r0 = r9.zzbql;
        r5 = r9.zzbqn;
        r0 = r0 + r5;
        r5 = r9.zzaie;
        r0 = r0 + r5;
        r0 = r0 - r6;
    L_0x0097:
        r5 = r9.zzbqm;
        r7 = r9.zzbqo;
        r5 = r5 + r7;
        goto L_0x00eb;
    L_0x009d:
        r0 = r9.zzbql;
        r5 = r9.zzbqn;
        r0 = r0 + r5;
        r5 = r9.zzaie;
        r0 = r0 + r5;
        r0 = r0 - r6;
        goto L_0x00b8;
    L_0x00a7:
        r0 = r9.zzbql;
        r5 = r9.zzbqn;
        r0 = r0 + r5;
        r5 = r9.zzaie;
        r5 = r5 / r8;
        r0 = r0 + r5;
        r0 = r0 + -25;
        goto L_0x00b8;
    L_0x00b3:
        r0 = r9.zzbql;
        r5 = r9.zzbqn;
        r0 = r0 + r5;
    L_0x00b8:
        r5 = r9.zzbqm;
        r7 = r9.zzbqo;
        r5 = r5 + r7;
        r7 = r9.zzaif;
        r5 = r5 + r7;
        r5 = r5 - r6;
        goto L_0x00eb;
    L_0x00c2:
        r0 = r9.zzbql;
        r5 = r9.zzbqn;
        r0 = r0 + r5;
        r5 = r9.zzaie;
        r5 = r5 / r8;
        r0 = r0 + r5;
        r0 = r0 + -25;
        r5 = r9.zzbqm;
        r7 = r9.zzbqo;
        r5 = r5 + r7;
        r7 = r9.zzaif;
        r7 = r7 / r8;
        r5 = r5 + r7;
        r5 = r5 + -25;
        goto L_0x00eb;
    L_0x00d9:
        r0 = r9.zzbql;
        r5 = r9.zzbqn;
        r0 = r0 + r5;
        r5 = r9.zzaie;
        r5 = r5 / r8;
        r0 = r0 + r5;
        r0 = r0 + -25;
        goto L_0x0097;
    L_0x00e5:
        r0 = r9.zzbql;
        r5 = r9.zzbqn;
        r0 = r0 + r5;
        goto L_0x0097;
    L_0x00eb:
        if (r0 < 0) goto L_0x00f9;
    L_0x00ed:
        r0 = r0 + r6;
        if (r0 > r3) goto L_0x00f9;
    L_0x00f0:
        r0 = r1[r2];
        if (r5 < r0) goto L_0x00f9;
    L_0x00f4:
        r5 = r5 + r6;
        r0 = r1[r4];
        if (r5 <= r0) goto L_0x00fa;
    L_0x00f9:
        return r2;
    L_0x00fa:
        return r4;
    L_0x00fb:
        r0 = "Height is too small or too large.";
        goto L_0x003a;
    L_0x00ff:
        r0 = "Width is too small or too large.";
        goto L_0x003a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhe.zzmz():boolean");
    }

    public void zzs(boolean z) {
        synchronized (this.zzail) {
            if (this.zzbqs != null) {
                this.zzbqs.dismiss();
                this.zzbqt.removeView(this.zzbgj.getView());
                if (this.zzbqu != null) {
                    this.zzbqu.removeView(this.zzbqp);
                    this.zzbqu.addView(this.zzbgj.getView());
                    this.zzbgj.zza(this.zzang);
                }
                if (z) {
                    zzbw("default");
                    if (this.zzbqr != null) {
                        this.zzbqr.zzek();
                    }
                }
                this.zzbqs = null;
                this.zzbqt = null;
                this.zzbqu = null;
                this.zzbqq = null;
            }
        }
    }
}
