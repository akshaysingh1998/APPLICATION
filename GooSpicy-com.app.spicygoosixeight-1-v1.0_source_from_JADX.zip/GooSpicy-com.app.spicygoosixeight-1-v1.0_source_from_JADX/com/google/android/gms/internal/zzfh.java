package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.util.client.zza;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.api.Releasable;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

@zzir
public abstract class zzfh implements Releasable {
    protected Context mContext;
    protected String zzbjj;
    protected WeakReference<zzll> zzbjk;

    public zzfh(zzll com_google_android_gms_internal_zzll) {
        this.mContext = com_google_android_gms_internal_zzll.getContext();
        this.zzbjj = zzu.zzfq().zzh(this.mContext, com_google_android_gms_internal_zzll.zzun().zzcs);
        this.zzbjk = new WeakReference(com_google_android_gms_internal_zzll);
    }

    private void zza(String str, Map<String, String> map) {
        zzll com_google_android_gms_internal_zzll = (zzll) this.zzbjk.get();
        if (com_google_android_gms_internal_zzll != null) {
            com_google_android_gms_internal_zzll.zza(str, (Map) map);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.lang.String zzbc(java.lang.String r3) {
        /*
        r2 = this;
        r0 = "internal";
        r1 = r3.hashCode();
        switch(r1) {
            case -1396664534: goto L_0x0067;
            case -1347010958: goto L_0x005d;
            case -918817863: goto L_0x0053;
            case -659376217: goto L_0x0049;
            case -642208130: goto L_0x003f;
            case -354048396: goto L_0x0034;
            case -32082395: goto L_0x0029;
            case 96784904: goto L_0x001f;
            case 580119100: goto L_0x0015;
            case 725497484: goto L_0x000b;
            default: goto L_0x0009;
        };
    L_0x0009:
        goto L_0x0071;
    L_0x000b:
        r1 = "noCacheDir";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x0013:
        r3 = 4;
        goto L_0x0072;
    L_0x0015:
        r1 = "expireFailed";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x001d:
        r3 = 5;
        goto L_0x0072;
    L_0x001f:
        r1 = "error";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x0027:
        r3 = 0;
        goto L_0x0072;
    L_0x0029:
        r1 = "externalAbort";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x0031:
        r3 = 9;
        goto L_0x0072;
    L_0x0034:
        r1 = "sizeExceeded";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x003c:
        r3 = 8;
        goto L_0x0072;
    L_0x003f:
        r1 = "playerFailed";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x0047:
        r3 = 1;
        goto L_0x0072;
    L_0x0049:
        r1 = "contentLengthMissing";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x0051:
        r3 = 3;
        goto L_0x0072;
    L_0x0053:
        r1 = "downloadTimeout";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x005b:
        r3 = 7;
        goto L_0x0072;
    L_0x005d:
        r1 = "inProgress";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x0065:
        r3 = 2;
        goto L_0x0072;
    L_0x0067:
        r1 = "badUrl";
        r3 = r3.equals(r1);
        if (r3 == 0) goto L_0x0071;
    L_0x006f:
        r3 = 6;
        goto L_0x0072;
    L_0x0071:
        r3 = -1;
    L_0x0072:
        switch(r3) {
            case 0: goto L_0x007f;
            case 1: goto L_0x007f;
            case 2: goto L_0x007f;
            case 3: goto L_0x007f;
            case 4: goto L_0x007c;
            case 5: goto L_0x007c;
            case 6: goto L_0x0079;
            case 7: goto L_0x0079;
            case 8: goto L_0x0076;
            case 9: goto L_0x0076;
            default: goto L_0x0075;
        };
    L_0x0075:
        return r0;
    L_0x0076:
        r0 = "policy";
        return r0;
    L_0x0079:
        r0 = "network";
        return r0;
    L_0x007c:
        r0 = "io";
        return r0;
    L_0x007f:
        r0 = "internal";
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfh.zzbc(java.lang.String):java.lang.String");
    }

    public abstract void abort();

    public void release() {
    }

    protected void zza(final String str, final String str2, final int i) {
        zza.zzcnf.post(new Runnable(this) {
            final /* synthetic */ zzfh zzbjq;

            public void run() {
                Map hashMap = new HashMap();
                hashMap.put("event", "precacheComplete");
                hashMap.put("src", str);
                hashMap.put("cachedSrc", str2);
                hashMap.put("totalBytes", Integer.toString(i));
                this.zzbjq.zza("onPrecacheEvent", hashMap);
            }
        });
    }

    protected void zza(String str, String str2, int i, int i2, boolean z) {
        final String str3 = str;
        final String str4 = str2;
        final int i3 = i;
        final int i4 = i2;
        final boolean z2 = z;
        zza.zzcnf.post(new Runnable(this) {
            final /* synthetic */ zzfh zzbjq;

            public void run() {
                Map hashMap = new HashMap();
                hashMap.put("event", "precacheProgress");
                hashMap.put("src", str3);
                hashMap.put("cachedSrc", str4);
                hashMap.put("bytesLoaded", Integer.toString(i3));
                hashMap.put("totalBytes", Integer.toString(i4));
                hashMap.put("cacheReady", z2 ? "1" : "0");
                this.zzbjq.zza("onPrecacheEvent", hashMap);
            }
        });
    }

    protected void zza(String str, String str2, String str3, String str4) {
        final String str5 = str;
        final String str6 = str2;
        final String str7 = str3;
        final String str8 = str4;
        zza.zzcnf.post(new Runnable(this) {
            final /* synthetic */ zzfh zzbjq;

            public void run() {
                Map hashMap = new HashMap();
                hashMap.put("event", "precacheCanceled");
                hashMap.put("src", str5);
                if (!TextUtils.isEmpty(str6)) {
                    hashMap.put("cachedSrc", str6);
                }
                hashMap.put("type", this.zzbjq.zzbc(str7));
                hashMap.put("reason", str7);
                if (!TextUtils.isEmpty(str8)) {
                    hashMap.put("message", str8);
                }
                this.zzbjq.zza("onPrecacheEvent", hashMap);
            }
        });
    }

    public abstract boolean zzba(String str);

    protected String zzbb(String str) {
        return zzm.zziw().zzcv(str);
    }
}
