package com.google.android.gms.internal;

import java.lang.Character.UnicodeBlock;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

@zzir
public class zzcr {
    private static boolean zza(UnicodeBlock unicodeBlock) {
        if (!(unicodeBlock == UnicodeBlock.BOPOMOFO || unicodeBlock == UnicodeBlock.BOPOMOFO_EXTENDED || unicodeBlock == UnicodeBlock.CJK_COMPATIBILITY || unicodeBlock == UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS || unicodeBlock == UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT || unicodeBlock == UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS || unicodeBlock == UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A || unicodeBlock == UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B || unicodeBlock == UnicodeBlock.ENCLOSED_CJK_LETTERS_AND_MONTHS || unicodeBlock == UnicodeBlock.HANGUL_JAMO || unicodeBlock == UnicodeBlock.HANGUL_SYLLABLES || unicodeBlock == UnicodeBlock.HIRAGANA || unicodeBlock == UnicodeBlock.KATAKANA)) {
            if (unicodeBlock != UnicodeBlock.KATAKANA_PHONETIC_EXTENSIONS) {
                return false;
            }
        }
        return true;
    }

    public static int zzac(java.lang.String r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = "UTF-8";	 Catch:{ UnsupportedEncodingException -> 0x0007 }
        r0 = r2.getBytes(r0);	 Catch:{ UnsupportedEncodingException -> 0x0007 }
        goto L_0x000b;
    L_0x0007:
        r0 = r2.getBytes();
    L_0x000b:
        r2 = 0;
        r1 = r0.length;
        r2 = com.google.android.gms.common.util.zzr.zza(r0, r2, r1, r2);
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzcr.zzac(java.lang.String):int");
    }

    public static String[] zzad(String str) {
        if (str == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        char[] toCharArray = str.toCharArray();
        int length = str.length();
        int i = 0;
        int i2 = i;
        int i3 = i2;
        while (i < length) {
            Object str2;
            int codePointAt = Character.codePointAt(toCharArray, i);
            int charCount = Character.charCount(codePointAt);
            if (zzm(codePointAt)) {
                if (i2 != 0) {
                    arrayList.add(new String(toCharArray, i3, i - i3));
                }
                str2 = new String(toCharArray, i, charCount);
            } else {
                if (!(Character.isLetterOrDigit(codePointAt) || Character.getType(codePointAt) == 6)) {
                    if (Character.getType(codePointAt) != 8) {
                        if (i2 != 0) {
                            str2 = new String(toCharArray, i3, i - i3);
                        } else {
                            i += charCount;
                        }
                    }
                }
                if (i2 == 0) {
                    i3 = i;
                }
                i2 = 1;
                i += charCount;
            }
            arrayList.add(str2);
            i2 = 0;
            i += charCount;
        }
        if (i2 != 0) {
            arrayList.add(new String(toCharArray, i3, i - i3));
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    static boolean zzm(int i) {
        return Character.isLetter(i) && (zza(UnicodeBlock.of(i)) || zzo(i));
    }

    public static byte[] zzn(int i) {
        ByteBuffer allocate = ByteBuffer.allocate(4);
        allocate.order(ByteOrder.LITTLE_ENDIAN);
        allocate.putInt(i);
        return allocate.array();
    }

    private static boolean zzo(int i) {
        return (i >= 65382 && i <= 65437) || (i >= 65441 && i <= 65500);
    }
}
