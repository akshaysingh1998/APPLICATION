package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;

public interface zzan {
    void zza(int i, int i2, int i3);

    void zza(MotionEvent motionEvent);

    String zzb(Context context);

    String zzb(Context context, String str);
}
