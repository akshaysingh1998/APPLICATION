package com.google.android.gms.internal;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;

public final class zzanr {
    static final Type[] beG = new Type[0];

    private static final class zza implements Serializable, GenericArrayType {
        private final Type beH;

        public zza(Type type) {
            this.beH = zzanr.zze(type);
        }

        public boolean equals(Object obj) {
            return (obj instanceof GenericArrayType) && zzanr.zza((Type) this, (GenericArrayType) obj);
        }

        public Type getGenericComponentType() {
            return this.beH;
        }

        public int hashCode() {
            return this.beH.hashCode();
        }

        public String toString() {
            return String.valueOf(zzanr.zzg(this.beH)).concat("[]");
        }
    }

    private static final class zzb implements Serializable, ParameterizedType {
        private final Type beI;
        private final Type beJ;
        private final Type[] beK;

        public zzb(Type type, Type type2, Type... typeArr) {
            int i = 0;
            if (type2 instanceof Class) {
                int i2;
                Class cls = (Class) type2;
                boolean z = true;
                if (!Modifier.isStatic(cls.getModifiers())) {
                    if (cls.getEnclosingClass() != null) {
                        i2 = 0;
                        if (type == null) {
                            if (i2 != 0) {
                                z = false;
                            }
                        }
                        zzanq.zzbn(z);
                    }
                }
                i2 = true;
                if (type == null) {
                    if (i2 != 0) {
                        z = false;
                    }
                }
                zzanq.zzbn(z);
            }
            this.beI = type == null ? null : zzanr.zze(type);
            this.beJ = zzanr.zze(type2);
            this.beK = (Type[]) typeArr.clone();
            while (i < this.beK.length) {
                zzanq.zzaa(this.beK[i]);
                zzanr.zzi(this.beK[i]);
                this.beK[i] = zzanr.zze(this.beK[i]);
                i++;
            }
        }

        public boolean equals(Object obj) {
            return (obj instanceof ParameterizedType) && zzanr.zza((Type) this, (ParameterizedType) obj);
        }

        public Type[] getActualTypeArguments() {
            return (Type[]) this.beK.clone();
        }

        public Type getOwnerType() {
            return this.beI;
        }

        public Type getRawType() {
            return this.beJ;
        }

        public int hashCode() {
            return (Arrays.hashCode(this.beK) ^ this.beJ.hashCode()) ^ zzanr.zzcm(this.beI);
        }

        public String toString() {
            int i = 1;
            StringBuilder stringBuilder = new StringBuilder(30 * (this.beK.length + 1));
            stringBuilder.append(zzanr.zzg(this.beJ));
            if (this.beK.length == 0) {
                return stringBuilder.toString();
            }
            stringBuilder.append("<");
            stringBuilder.append(zzanr.zzg(this.beK[0]));
            while (i < this.beK.length) {
                stringBuilder.append(", ");
                stringBuilder.append(zzanr.zzg(this.beK[i]));
                i++;
            }
            stringBuilder.append(">");
            return stringBuilder.toString();
        }
    }

    private static final class zzc implements Serializable, WildcardType {
        private final Type beL;
        private final Type beM;

        public zzc(Type[] typeArr, Type[] typeArr2) {
            Type type;
            boolean z = true;
            zzanq.zzbn(typeArr2.length <= 1);
            zzanq.zzbn(typeArr.length == 1);
            if (typeArr2.length == 1) {
                zzanq.zzaa(typeArr2[0]);
                zzanr.zzi(typeArr2[0]);
                if (typeArr[0] != Object.class) {
                    z = false;
                }
                zzanq.zzbn(z);
                this.beM = zzanr.zze(typeArr2[0]);
                type = Object.class;
            } else {
                zzanq.zzaa(typeArr[0]);
                zzanr.zzi(typeArr[0]);
                this.beM = null;
                type = zzanr.zze(typeArr[0]);
            }
            this.beL = type;
        }

        public boolean equals(Object obj) {
            return (obj instanceof WildcardType) && zzanr.zza((Type) this, (WildcardType) obj);
        }

        public Type[] getLowerBounds() {
            if (this.beM == null) {
                return zzanr.beG;
            }
            return new Type[]{this.beM};
        }

        public Type[] getUpperBounds() {
            return new Type[]{this.beL};
        }

        public int hashCode() {
            return (this.beM != null ? this.beM.hashCode() + 31 : 1) ^ (31 + this.beL.hashCode());
        }

        public String toString() {
            String str;
            String valueOf;
            if (this.beM != null) {
                str = "? super ";
                valueOf = String.valueOf(zzanr.zzg(this.beM));
                return valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
            } else if (this.beL == Object.class) {
                return "?";
            } else {
                str = "? extends ";
                valueOf = String.valueOf(zzanr.zzg(this.beL));
                return valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
            }
        }
    }

    static boolean equal(Object obj, Object obj2) {
        if (obj != obj2) {
            if (obj == null || !obj.equals(obj2)) {
                return false;
            }
        }
        return true;
    }

    private static int zza(Object[] objArr, Object obj) {
        for (int i = 0; i < objArr.length; i++) {
            if (obj.equals(objArr[i])) {
                return i;
            }
        }
        throw new NoSuchElementException();
    }

    private static Class<?> zza(TypeVariable<?> typeVariable) {
        GenericDeclaration genericDeclaration = typeVariable.getGenericDeclaration();
        return genericDeclaration instanceof Class ? (Class) genericDeclaration : null;
    }

    public static ParameterizedType zza(Type type, Type type2, Type... typeArr) {
        return new zzb(type, type2, typeArr);
    }

    public static Type zza(Type type, Class<?> cls) {
        type = zzb(type, cls, Collection.class);
        if (type instanceof WildcardType) {
            type = ((WildcardType) type).getUpperBounds()[0];
        }
        return type instanceof ParameterizedType ? ((ParameterizedType) type).getActualTypeArguments()[0] : Object.class;
    }

    static Type zza(Type type, Class<?> cls, Class<?> cls2) {
        if (cls2 == cls) {
            return type;
        }
        if (cls2.isInterface()) {
            Class[] interfaces = cls.getInterfaces();
            int length = interfaces.length;
            for (int i = 0; i < length; i++) {
                if (interfaces[i] == cls2) {
                    return cls.getGenericInterfaces()[i];
                }
                if (cls2.isAssignableFrom(interfaces[i])) {
                    return zza(cls.getGenericInterfaces()[i], interfaces[i], (Class) cls2);
                }
            }
        }
        if (!cls.isInterface()) {
            Class cls3;
            while (cls3 != Object.class) {
                Class superclass = cls3.getSuperclass();
                if (superclass == cls2) {
                    return cls3.getGenericSuperclass();
                }
                if (cls2.isAssignableFrom(superclass)) {
                    return zza(cls3.getGenericSuperclass(), superclass, (Class) cls2);
                }
                cls3 = superclass;
            }
        }
        return cls2;
    }

    public static Type zza(Type type, Class<?> cls, Type type2) {
        while (type2 instanceof TypeVariable) {
            type2 = (TypeVariable) type2;
            Type zza = zza(type, (Class) cls, (TypeVariable) type2);
            if (zza == type2) {
                return zza;
            }
            type2 = zza;
        }
        if (type2 instanceof Class) {
            Class cls2 = (Class) type2;
            if (cls2.isArray()) {
                type2 = cls2.getComponentType();
                type = zza(type, (Class) cls, type2);
                return type2 == type ? cls2 : zzb(type);
            }
        }
        if (type2 instanceof GenericArrayType) {
            GenericArrayType genericArrayType = (GenericArrayType) type2;
            zza = genericArrayType.getGenericComponentType();
            type = zza(type, (Class) cls, zza);
            return zza == type ? genericArrayType : zzb(type);
        } else {
            int i = 0;
            if (type2 instanceof ParameterizedType) {
                type2 = (ParameterizedType) type2;
                zza = type2.getOwnerType();
                Type zza2 = zza(type, (Class) cls, zza);
                int i2 = zza2 != zza ? 1 : 0;
                Type[] actualTypeArguments = type2.getActualTypeArguments();
                int length = actualTypeArguments.length;
                while (i < length) {
                    Type zza3 = zza(type, (Class) cls, actualTypeArguments[i]);
                    if (zza3 != actualTypeArguments[i]) {
                        if (i2 == 0) {
                            actualTypeArguments = (Type[]) actualTypeArguments.clone();
                            i2 = 1;
                        }
                        actualTypeArguments[i] = zza3;
                    }
                    i++;
                }
                if (i2 != 0) {
                    type2 = zza(zza2, type2.getRawType(), actualTypeArguments);
                }
                return type2;
            }
            if (type2 instanceof WildcardType) {
                type2 = (WildcardType) type2;
                Type[] lowerBounds = type2.getLowerBounds();
                Type[] upperBounds = type2.getUpperBounds();
                if (lowerBounds.length == 1) {
                    type = zza(type, (Class) cls, lowerBounds[0]);
                    if (type != lowerBounds[0]) {
                        return zzd(type);
                    }
                } else if (upperBounds.length == 1) {
                    type = zza(type, (Class) cls, upperBounds[0]);
                    if (type != upperBounds[0]) {
                        return zzc(type);
                    }
                }
            }
            return type2;
        }
    }

    static Type zza(Type type, Class<?> cls, TypeVariable<?> typeVariable) {
        Class zza = zza(typeVariable);
        if (zza == null) {
            return typeVariable;
        }
        type = zza(type, (Class) cls, zza);
        if (!(type instanceof ParameterizedType)) {
            return typeVariable;
        }
        return ((ParameterizedType) type).getActualTypeArguments()[zza(zza.getTypeParameters(), (Object) typeVariable)];
    }

    public static boolean zza(Type type, Type type2) {
        if (type == type2) {
            return true;
        }
        if (type instanceof Class) {
            return type.equals(type2);
        }
        if (type instanceof ParameterizedType) {
            if (!(type2 instanceof ParameterizedType)) {
                return false;
            }
            ParameterizedType parameterizedType = (ParameterizedType) type;
            ParameterizedType parameterizedType2 = (ParameterizedType) type2;
            return equal(parameterizedType.getOwnerType(), parameterizedType2.getOwnerType()) && parameterizedType.getRawType().equals(parameterizedType2.getRawType()) && Arrays.equals(parameterizedType.getActualTypeArguments(), parameterizedType2.getActualTypeArguments());
        } else if (type instanceof GenericArrayType) {
            if (!(type2 instanceof GenericArrayType)) {
                return false;
            }
            return zza(((GenericArrayType) type).getGenericComponentType(), ((GenericArrayType) type2).getGenericComponentType());
        } else if (type instanceof WildcardType) {
            if (!(type2 instanceof WildcardType)) {
                return false;
            }
            WildcardType wildcardType = (WildcardType) type;
            WildcardType wildcardType2 = (WildcardType) type2;
            return Arrays.equals(wildcardType.getUpperBounds(), wildcardType2.getUpperBounds()) && Arrays.equals(wildcardType.getLowerBounds(), wildcardType2.getLowerBounds());
        } else if (!(type instanceof TypeVariable) || !(type2 instanceof TypeVariable)) {
            return false;
        } else {
            TypeVariable typeVariable = (TypeVariable) type;
            TypeVariable typeVariable2 = (TypeVariable) type2;
            return typeVariable.getGenericDeclaration() == typeVariable2.getGenericDeclaration() && typeVariable.getName().equals(typeVariable2.getName());
        }
    }

    public static GenericArrayType zzb(Type type) {
        return new zza(type);
    }

    static Type zzb(Type type, Class<?> cls, Class<?> cls2) {
        zzanq.zzbn(cls2.isAssignableFrom(cls));
        return zza(type, (Class) cls, zza(type, (Class) cls, (Class) cls2));
    }

    public static Type[] zzb(Type type, Class<?> cls) {
        if (type == Properties.class) {
            return new Type[]{String.class, String.class};
        }
        type = zzb(type, cls, Map.class);
        if (type instanceof ParameterizedType) {
            return ((ParameterizedType) type).getActualTypeArguments();
        }
        return new Type[]{Object.class, Object.class};
    }

    public static WildcardType zzc(Type type) {
        return new zzc(new Type[]{type}, beG);
    }

    private static int zzcm(Object obj) {
        return obj != null ? obj.hashCode() : 0;
    }

    public static WildcardType zzd(Type type) {
        return new zzc(new Type[]{Object.class}, new Type[]{type});
    }

    public static Type zze(Type type) {
        if (type instanceof Class) {
            Class cls = (Class) type;
            if (cls.isArray()) {
                cls = new zza(zze(cls.getComponentType()));
            }
            return cls;
        } else if (type instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) type;
            return new zzb(parameterizedType.getOwnerType(), parameterizedType.getRawType(), parameterizedType.getActualTypeArguments());
        } else if (type instanceof GenericArrayType) {
            return new zza(((GenericArrayType) type).getGenericComponentType());
        } else {
            if (!(type instanceof WildcardType)) {
                return type;
            }
            WildcardType wildcardType = (WildcardType) type;
            return new zzc(wildcardType.getUpperBounds(), wildcardType.getLowerBounds());
        }
    }

    public static Class<?> zzf(Type type) {
        if (type instanceof Class) {
            return (Class) type;
        }
        if (type instanceof ParameterizedType) {
            type = ((ParameterizedType) type).getRawType();
            zzanq.zzbn(type instanceof Class);
            return (Class) type;
        } else if (type instanceof GenericArrayType) {
            return Array.newInstance(zzf(((GenericArrayType) type).getGenericComponentType()), 0).getClass();
        } else {
            if (type instanceof TypeVariable) {
                return Object.class;
            }
            if (type instanceof WildcardType) {
                return zzf(((WildcardType) type).getUpperBounds()[0]);
            }
            String name = type == null ? "null" : type.getClass().getName();
            String valueOf = String.valueOf("Expected a Class, ParameterizedType, or GenericArrayType, but <");
            String valueOf2 = String.valueOf(type);
            StringBuilder stringBuilder = new StringBuilder(((13 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length()) + String.valueOf(name).length());
            stringBuilder.append(valueOf);
            stringBuilder.append(valueOf2);
            stringBuilder.append("> is of type ");
            stringBuilder.append(name);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
    }

    public static String zzg(Type type) {
        return type instanceof Class ? ((Class) type).getName() : type.toString();
    }

    public static Type zzh(Type type) {
        return type instanceof GenericArrayType ? ((GenericArrayType) type).getGenericComponentType() : ((Class) type).getComponentType();
    }

    private static void zzi(Type type) {
        boolean z;
        if (type instanceof Class) {
            if (((Class) type).isPrimitive()) {
                z = false;
                zzanq.zzbn(z);
            }
        }
        z = true;
        zzanq.zzbn(z);
    }
}
