package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.zzl;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.internal.zzab;
import java.util.Iterator;
import java.util.LinkedList;

@zzir
class zzfq {
    private final String zzall;
    private final LinkedList<zza> zzbkv = new LinkedList();
    private AdRequestParcel zzbkw;
    private final int zzbkx;
    private boolean zzbky;

    class zza {
        zzl zzbkz;
        AdRequestParcel zzbla;
        zzfm zzblb;
        long zzblc;
        boolean zzbld;
        boolean zzble;
        final /* synthetic */ zzfq zzblf;

        zza(zzfq com_google_android_gms_internal_zzfq, zzfl com_google_android_gms_internal_zzfl) {
            this.zzblf = com_google_android_gms_internal_zzfq;
            this.zzbkz = com_google_android_gms_internal_zzfl.zzbe(com_google_android_gms_internal_zzfq.zzall);
            this.zzblb = new zzfm();
            this.zzblb.zzc(this.zzbkz);
        }

        zza(zzfq com_google_android_gms_internal_zzfq, zzfl com_google_android_gms_internal_zzfl, AdRequestParcel adRequestParcel) {
            this(com_google_android_gms_internal_zzfq, com_google_android_gms_internal_zzfl);
            this.zzbla = adRequestParcel;
        }

        void zzlx() {
            if (!this.zzbld) {
                this.zzble = this.zzbkz.zzb(zzfo.zzj(this.zzbla != null ? this.zzbla : this.zzblf.zzbkw));
                this.zzbld = true;
                this.zzblc = zzu.zzfu().currentTimeMillis();
            }
        }
    }

    zzfq(AdRequestParcel adRequestParcel, String str, int i) {
        zzab.zzaa(adRequestParcel);
        zzab.zzaa(str);
        this.zzbkw = adRequestParcel;
        this.zzall = str;
        this.zzbkx = i;
    }

    String getAdUnitId() {
        return this.zzall;
    }

    int getNetworkType() {
        return this.zzbkx;
    }

    int size() {
        return this.zzbkv.size();
    }

    void zza(zzfl com_google_android_gms_internal_zzfl, AdRequestParcel adRequestParcel) {
        this.zzbkv.add(new zza(this, com_google_android_gms_internal_zzfl, adRequestParcel));
    }

    void zzb(zzfl com_google_android_gms_internal_zzfl) {
        zza com_google_android_gms_internal_zzfq_zza = new zza(this, com_google_android_gms_internal_zzfl);
        this.zzbkv.add(com_google_android_gms_internal_zzfq_zza);
        com_google_android_gms_internal_zzfq_zza.zzlx();
    }

    AdRequestParcel zzls() {
        return this.zzbkw;
    }

    int zzlt() {
        Iterator it = this.zzbkv.iterator();
        int i = 0;
        while (it.hasNext()) {
            if (((zza) it.next()).zzbld) {
                i++;
            }
        }
        return i;
    }

    void zzlu() {
        Iterator it = this.zzbkv.iterator();
        while (it.hasNext()) {
            ((zza) it.next()).zzlx();
        }
    }

    void zzlv() {
        this.zzbky = true;
    }

    boolean zzlw() {
        return this.zzbky;
    }

    zza zzm(AdRequestParcel adRequestParcel) {
        if (adRequestParcel != null) {
            this.zzbkw = adRequestParcel;
        }
        return (zza) this.zzbkv.remove();
    }
}
