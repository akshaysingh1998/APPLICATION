package com.google.android.gms.internal;

import com.bumptech.glide.load.Key;
import com.google.android.gms.internal.zzau.zza;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public class zzbo {
    protected static final String TAG = "zzbo";
    private final String className;
    private final zzax zzaey;
    private final String zzahf;
    private final int zzahg = 2;
    private volatile Method zzahh = null;
    private List<Class> zzahi;
    private CountDownLatch zzahj = new CountDownLatch(1);

    class C04011 implements Runnable {
        final /* synthetic */ zzbo zzahk;

        C04011(zzbo com_google_android_gms_internal_zzbo) {
            this.zzahk = com_google_android_gms_internal_zzbo;
        }

        public void run() {
            this.zzahk.zzcz();
        }
    }

    public zzbo(zzax com_google_android_gms_internal_zzax, String str, String str2, List<Class> list) {
        this.zzaey = com_google_android_gms_internal_zzax;
        this.className = str;
        this.zzahf = str2;
        this.zzahi = new ArrayList(list);
        this.zzaey.zzce().submit(new C04011(this));
    }

    private void zzcz() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = r4.zzaey;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r0 = r0.zzcf();	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r1 = r4.zzaey;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r1 = r1.zzch();	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r2 = r4.className;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r1 = r4.zzd(r1, r2);	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r0 = r0.loadClass(r1);	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        if (r0 != 0) goto L_0x001e;
    L_0x0018:
        r0 = r4.zzahj;
        r0.countDown();
        return;
    L_0x001e:
        r1 = r4.zzaey;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r1 = r1.zzch();	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r2 = r4.zzahf;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r1 = r4.zzd(r1, r2);	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r2 = r4.zzahi;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r3 = r4.zzahi;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r3 = r3.size();	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r3 = new java.lang.Class[r3];	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r2 = r2.toArray(r3);	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r2 = (java.lang.Class[]) r2;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r0 = r0.getMethod(r1, r2);	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r4.zzahh = r0;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        r0 = r4.zzahh;	 Catch:{ zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, zza -> 0x004c, all -> 0x0045 }
        if (r0 != 0) goto L_0x004c;
    L_0x0044:
        goto L_0x0018;
    L_0x0045:
        r0 = move-exception;
        r1 = r4.zzahj;
        r1.countDown();
        throw r0;
    L_0x004c:
        r0 = r4.zzahj;
        r0.countDown();
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzbo.zzcz():void");
    }

    private String zzd(byte[] bArr, String str) throws zza, UnsupportedEncodingException {
        return new String(this.zzaey.zzcg().zzc(bArr, str), Key.STRING_CHARSET_NAME);
    }

    public java.lang.reflect.Method zzda() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r5 = this;
        r0 = r5.zzahh;
        if (r0 == 0) goto L_0x0007;
    L_0x0004:
        r0 = r5.zzahh;
        return r0;
    L_0x0007:
        r0 = 0;
        r1 = r5.zzahj;	 Catch:{ InterruptedException -> 0x0018 }
        r2 = 2;	 Catch:{ InterruptedException -> 0x0018 }
        r4 = java.util.concurrent.TimeUnit.SECONDS;	 Catch:{ InterruptedException -> 0x0018 }
        r1 = r1.await(r2, r4);	 Catch:{ InterruptedException -> 0x0018 }
        if (r1 != 0) goto L_0x0015;	 Catch:{ InterruptedException -> 0x0018 }
    L_0x0014:
        return r0;	 Catch:{ InterruptedException -> 0x0018 }
    L_0x0015:
        r1 = r5.zzahh;	 Catch:{ InterruptedException -> 0x0018 }
        return r1;
    L_0x0018:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzbo.zzda():java.lang.reflect.Method");
    }
}
