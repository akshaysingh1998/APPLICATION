package com.google.android.gms.internal;

public final class zzanh extends zzanc {
    public zzanh(String str) {
        super(str);
    }

    public zzanh(String str, Throwable th) {
        super(str, th);
    }

    public zzanh(Throwable th) {
        super(th);
    }
}
