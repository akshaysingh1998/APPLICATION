package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.zzjd.zza;

@zzir
public final class zzjg implements zzjd {
    public zza zzz(Context context) {
        return null;
    }
}
