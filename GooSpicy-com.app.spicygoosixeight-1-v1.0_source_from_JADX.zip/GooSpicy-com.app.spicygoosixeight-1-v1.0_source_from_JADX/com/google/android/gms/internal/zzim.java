package com.google.android.gms.internal;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.zzc;
import com.google.android.gms.ads.internal.formats.zzf;
import com.google.android.gms.ads.internal.formats.zzi;
import com.google.android.gms.ads.internal.zzq;
import com.google.android.gms.common.internal.zzab;
import com.google.android.gms.dynamic.zze;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public class zzim implements Callable<zzjy> {
    private static final long zzbyx = TimeUnit.SECONDS.toMillis(60);
    private final Context mContext;
    private final Object zzail = new Object();
    private final zzil zzbgf;
    private final zzas zzbgh;
    private final com.google.android.gms.internal.zzjy.zza zzbxv;
    private int zzbym;
    private final zzkr zzbzg;
    private final zzq zzbzh;
    private boolean zzbzi;
    private List<String> zzbzj;
    private JSONObject zzbzk;

    public interface zza<T extends com.google.android.gms.ads.internal.formats.zzh.zza> {
        T zza(zzim com_google_android_gms_internal_zzim, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException;
    }

    class zzb {
        final /* synthetic */ zzim zzbzo;
        public zzet zzcad;

        zzb(zzim com_google_android_gms_internal_zzim) {
            this.zzbzo = com_google_android_gms_internal_zzim;
        }
    }

    public zzim(Context context, zzq com_google_android_gms_ads_internal_zzq, zzkr com_google_android_gms_internal_zzkr, zzas com_google_android_gms_internal_zzas, com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza) {
        this.mContext = context;
        this.zzbzh = com_google_android_gms_ads_internal_zzq;
        this.zzbzg = com_google_android_gms_internal_zzkr;
        this.zzbxv = com_google_android_gms_internal_zzjy_zza;
        this.zzbgh = com_google_android_gms_internal_zzas;
        this.zzbgf = zza(context, com_google_android_gms_internal_zzjy_zza, com_google_android_gms_ads_internal_zzq, com_google_android_gms_internal_zzas);
        this.zzbgf.zzqh();
        this.zzbzi = false;
        this.zzbym = -2;
        this.zzbzj = null;
    }

    private com.google.android.gms.ads.internal.formats.zzh.zza zza(zza com_google_android_gms_internal_zzim_zza, JSONObject jSONObject, String str) throws ExecutionException, InterruptedException, JSONException {
        if (zzqt()) {
            return null;
        }
        JSONObject jSONObject2 = jSONObject.getJSONObject("tracking_urls_and_actions");
        String[] zzc = zzc(jSONObject2, "impression_tracking_urls");
        this.zzbzj = zzc == null ? null : Arrays.asList(zzc);
        this.zzbzk = jSONObject2.optJSONObject("active_view");
        com.google.android.gms.ads.internal.formats.zzh.zza zza = com_google_android_gms_internal_zzim_zza.zza(this, jSONObject);
        if (zza == null) {
            com.google.android.gms.ads.internal.util.client.zzb.m9e("Failed to retrieve ad assets.");
            return null;
        }
        zza.zzb(new zzi(this.mContext, this.zzbzh, this.zzbgf, this.zzbgh, jSONObject, zza, this.zzbxv.zzcit.zzaou, str));
        return zza;
    }

    private zzlc<zzc> zza(JSONObject jSONObject, boolean z, boolean z2) throws JSONException {
        String string = z ? jSONObject.getString("url") : jSONObject.optString("url");
        final double optDouble = jSONObject.optDouble("scale", 1.0d);
        if (TextUtils.isEmpty(string)) {
            zza(0, z);
            return new zzla(null);
        } else if (z2) {
            return new zzla(new zzc(null, Uri.parse(string), optDouble));
        } else {
            final boolean z3 = z;
            final String str = string;
            return this.zzbzg.zza(string, new com.google.android.gms.internal.zzkr.zza<zzc>(this) {
                final /* synthetic */ zzim zzbzo;

                public com.google.android.gms.ads.internal.formats.zzc zzg(java.io.InputStream r5) {
                    /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
                    /*
                    r4 = this;
                    r0 = 0;
                    r5 = com.google.android.gms.common.util.zzo.zzk(r5);	 Catch:{ IOException -> 0x0006 }
                    goto L_0x0007;
                L_0x0006:
                    r5 = r0;
                L_0x0007:
                    r1 = 2;
                    if (r5 != 0) goto L_0x0012;
                L_0x000a:
                    r5 = r4.zzbzo;
                    r2 = r3;
                    r5.zza(r1, r2);
                    return r0;
                L_0x0012:
                    r2 = 0;
                    r3 = r5.length;
                    r5 = android.graphics.BitmapFactory.decodeByteArray(r5, r2, r3);
                    if (r5 != 0) goto L_0x0022;
                L_0x001a:
                    r5 = r4.zzbzo;
                    r2 = r3;
                    r5.zza(r1, r2);
                    return r0;
                L_0x0022:
                    r0 = 4639833516098453504; // 0x4064000000000000 float:0.0 double:160.0;
                    r2 = r4;
                    r0 = r0 * r2;
                    r0 = (int) r0;
                    r5.setDensity(r0);
                    r0 = new com.google.android.gms.ads.internal.formats.zzc;
                    r1 = new android.graphics.drawable.BitmapDrawable;
                    r2 = android.content.res.Resources.getSystem();
                    r1.<init>(r2, r5);
                    r5 = r6;
                    r5 = android.net.Uri.parse(r5);
                    r2 = r4;
                    r0.<init>(r1, r5, r2);
                    return r0;
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzim.6.zzg(java.io.InputStream):com.google.android.gms.ads.internal.formats.zzc");
                }

                public /* synthetic */ Object zzh(InputStream inputStream) {
                    return zzg(inputStream);
                }

                public zzc zzqu() {
                    this.zzbzo.zza(2, z3);
                    return null;
                }

                public /* synthetic */ Object zzqv() {
                    return zzqu();
                }
            });
        }
    }

    private void zza(com.google.android.gms.ads.internal.formats.zzh.zza com_google_android_gms_ads_internal_formats_zzh_zza) {
        if (com_google_android_gms_ads_internal_formats_zzh_zza instanceof zzf) {
            final zzf com_google_android_gms_ads_internal_formats_zzf = (zzf) com_google_android_gms_ads_internal_formats_zzh_zza;
            zzb com_google_android_gms_internal_zzim_zzb = new zzb(this);
            final zzet c09333 = new zzet(this) {
                final /* synthetic */ zzim zzbzo;

                public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
                    this.zzbzo.zzb(com_google_android_gms_ads_internal_formats_zzf, (String) map.get("asset"));
                }
            };
            com_google_android_gms_internal_zzim_zzb.zzcad = c09333;
            this.zzbgf.zza(new com.google.android.gms.internal.zzil.zza(this) {
                final /* synthetic */ zzim zzbzo;

                public void zze(zzfx com_google_android_gms_internal_zzfx) {
                    com_google_android_gms_internal_zzfx.zza("/nativeAdCustomClick", c09333);
                }
            });
        }
    }

    private zzjy zzb(com.google.android.gms.ads.internal.formats.zzh.zza com_google_android_gms_ads_internal_formats_zzh_zza) {
        int i;
        synchronized (this.zzail) {
            try {
                int i2 = r1.zzbym;
                if (com_google_android_gms_ads_internal_formats_zzh_zza == null && r1.zzbym == -2) {
                    i2 = 0;
                }
                i = i2;
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                }
            }
        }
        com.google.android.gms.ads.internal.formats.zzh.zza com_google_android_gms_ads_internal_formats_zzh_zza2 = i != -2 ? null : com_google_android_gms_ads_internal_formats_zzh_zza;
        AdRequestParcel adRequestParcel = r1.zzbxv.zzcit.zzcav;
        List list = r1.zzbxv.zzciu.zzbnq;
        List list2 = r1.zzbxv.zzciu.zzbnr;
        List list3 = r1.zzbzj;
        int i3 = r1.zzbxv.zzciu.orientation;
        long j = r1.zzbxv.zzciu.zzbnw;
        String str = r1.zzbxv.zzcit.zzcay;
        AdSizeParcel adSizeParcel = r1.zzbxv.zzaoy;
        long j2 = r1.zzbxv.zzciu.zzccb;
        return new zzjy(adRequestParcel, null, list, i, list2, list3, i3, j, str, false, null, null, null, null, null, 0, adSizeParcel, j2, r1.zzbxv.zzcio, r1.zzbxv.zzcip, r1.zzbxv.zzciu.zzcch, r1.zzbzk, com_google_android_gms_ads_internal_formats_zzh_zza2, null, null, null, r1.zzbxv.zzciu.zzccu, r1.zzbxv.zzciu.zzccv, null, r1.zzbxv.zzciu.zzbnt);
    }

    private java.lang.Integer zzb(org.json.JSONObject r3, java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r3 = r3.getJSONObject(r4);	 Catch:{ JSONException -> 0x001f }
        r4 = "r";	 Catch:{ JSONException -> 0x001f }
        r4 = r3.getInt(r4);	 Catch:{ JSONException -> 0x001f }
        r0 = "g";	 Catch:{ JSONException -> 0x001f }
        r0 = r3.getInt(r0);	 Catch:{ JSONException -> 0x001f }
        r1 = "b";	 Catch:{ JSONException -> 0x001f }
        r3 = r3.getInt(r1);	 Catch:{ JSONException -> 0x001f }
        r3 = android.graphics.Color.rgb(r4, r0, r3);	 Catch:{ JSONException -> 0x001f }
        r3 = java.lang.Integer.valueOf(r3);	 Catch:{ JSONException -> 0x001f }
        return r3;
    L_0x001f:
        r3 = 0;
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzim.zzb(org.json.JSONObject, java.lang.String):java.lang.Integer");
    }

    private void zzb(zzec com_google_android_gms_internal_zzec, String str) {
        try {
            zzeg zzv = this.zzbzh.zzv(com_google_android_gms_internal_zzec.getCustomTemplateId());
            if (zzv != null) {
                zzv.zza(com_google_android_gms_internal_zzec, str);
            }
        } catch (Throwable e) {
            StringBuilder stringBuilder = new StringBuilder(40 + String.valueOf(str).length());
            stringBuilder.append("Failed to call onCustomClick for asset ");
            stringBuilder.append(str);
            stringBuilder.append(".");
            com.google.android.gms.ads.internal.util.client.zzb.zzd(stringBuilder.toString(), e);
        }
    }

    private String[] zzc(JSONObject jSONObject, String str) throws JSONException {
        JSONArray optJSONArray = jSONObject.optJSONArray(str);
        if (optJSONArray == null) {
            return null;
        }
        String[] strArr = new String[optJSONArray.length()];
        for (int i = 0; i < optJSONArray.length(); i++) {
            strArr[i] = optJSONArray.getString(i);
        }
        return strArr;
    }

    private JSONObject zzcc(final String str) throws ExecutionException, InterruptedException, TimeoutException, JSONException {
        if (zzqt()) {
            return null;
        }
        final zzkz com_google_android_gms_internal_zzkz = new zzkz();
        final zzb com_google_android_gms_internal_zzim_zzb = new zzb(this);
        this.zzbgf.zza(new com.google.android.gms.internal.zzil.zza(this) {
            final /* synthetic */ zzim zzbzo;

            public void zze(final zzfx com_google_android_gms_internal_zzfx) {
                zzet c09311 = new zzet(this) {
                    final /* synthetic */ C09321 zzbzp;

                    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
                        com_google_android_gms_internal_zzfx.zzb("/nativeAdPreProcess", com_google_android_gms_internal_zzim_zzb.zzcad);
                        try {
                            String str = (String) map.get("success");
                            if (!TextUtils.isEmpty(str)) {
                                com_google_android_gms_internal_zzkz.zzi(new JSONObject(str).getJSONArray("ads").getJSONObject(0));
                                return;
                            }
                        } catch (Throwable e) {
                            com.google.android.gms.ads.internal.util.client.zzb.zzb("Malformed native JSON response.", e);
                        }
                        this.zzbzp.zzbzo.zzan(0);
                        zzab.zza(this.zzbzp.zzbzo.zzqt(), (Object) "Unable to set the ad state error!");
                        com_google_android_gms_internal_zzkz.zzi(null);
                    }
                };
                com_google_android_gms_internal_zzim_zzb.zzcad = c09311;
                com_google_android_gms_internal_zzfx.zza("/nativeAdPreProcess", c09311);
                try {
                    JSONObject jSONObject = new JSONObject(this.zzbzo.zzbxv.zzciu.body);
                    jSONObject.put("ads_id", str);
                    com_google_android_gms_internal_zzfx.zza("google.afma.nativeAds.preProcessJsonGmsg", jSONObject);
                } catch (Throwable e) {
                    com.google.android.gms.ads.internal.util.client.zzb.zzd("Exception occurred while invoking javascript", e);
                    com_google_android_gms_internal_zzkz.zzi(null);
                }
            }

            public void zzqr() {
                com_google_android_gms_internal_zzkz.zzi(null);
            }
        });
        return (JSONObject) com_google_android_gms_internal_zzkz.get(zzbyx, TimeUnit.MILLISECONDS);
    }

    private static List<Drawable> zzh(List<zzc> list) throws RemoteException {
        List<Drawable> arrayList = new ArrayList();
        for (zzc zzkv : list) {
            arrayList.add((Drawable) zze.zzad(zzkv.zzkv()));
        }
        return arrayList;
    }

    public /* synthetic */ Object call() throws Exception {
        return zzqs();
    }

    zzil zza(Context context, com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza, zzq com_google_android_gms_ads_internal_zzq, zzas com_google_android_gms_internal_zzas) {
        return new zzil(context, com_google_android_gms_internal_zzjy_zza, com_google_android_gms_ads_internal_zzq, com_google_android_gms_internal_zzas);
    }

    public zzlc<zzc> zza(JSONObject jSONObject, String str, boolean z, boolean z2) throws JSONException {
        jSONObject = z ? jSONObject.getJSONObject(str) : jSONObject.optJSONObject(str);
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        return zza(jSONObject, z, z2);
    }

    public List<zzlc<zzc>> zza(JSONObject jSONObject, String str, boolean z, boolean z2, boolean z3) throws JSONException {
        JSONArray jSONArray = z ? jSONObject.getJSONArray(str) : jSONObject.optJSONArray(str);
        List<zzlc<zzc>> arrayList = new ArrayList();
        int i = 0;
        if (jSONArray != null) {
            if (jSONArray.length() != 0) {
                int length = z3 ? jSONArray.length() : 1;
                while (i < length) {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                    if (jSONObject2 == null) {
                        jSONObject2 = new JSONObject();
                    }
                    arrayList.add(zza(jSONObject2, z, z2));
                    i++;
                }
                return arrayList;
            }
        }
        zza(0, z);
        return arrayList;
    }

    public Future<zzc> zza(JSONObject jSONObject, String str, boolean z) throws JSONException {
        jSONObject = jSONObject.getJSONObject(str);
        boolean optBoolean = jSONObject.optBoolean("require", true);
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        return zza(jSONObject, optBoolean, z);
    }

    public void zza(int i, boolean z) {
        if (z) {
            zzan(i);
        }
    }

    public void zzan(int i) {
        synchronized (this.zzail) {
            this.zzbzi = true;
            this.zzbym = i;
        }
    }

    protected zza zzf(JSONObject jSONObject) throws ExecutionException, InterruptedException, JSONException, TimeoutException {
        if (zzqt()) {
            return null;
        }
        String string = jSONObject.getString("template_id");
        boolean z = this.zzbxv.zzcit.zzapm != null ? this.zzbxv.zzcit.zzapm.zzbgt : false;
        boolean z2 = this.zzbxv.zzcit.zzapm != null ? this.zzbxv.zzcit.zzapm.zzbgv : false;
        if ("2".equals(string)) {
            return new zzin(z, z2);
        }
        if ("1".equals(string)) {
            return new zzio(z, z2);
        }
        if ("3".equals(string)) {
            string = jSONObject.getString("custom_template_id");
            final zzkz com_google_android_gms_internal_zzkz = new zzkz();
            zzkl.zzclg.post(new Runnable(this) {
                final /* synthetic */ zzim zzbzo;

                public void run() {
                    com_google_android_gms_internal_zzkz.zzi((zzeh) this.zzbzo.zzbzh.zzfb().get(string));
                }
            });
            if (com_google_android_gms_internal_zzkz.get(zzbyx, TimeUnit.MILLISECONDS) != null) {
                return new zzip(z);
            }
            string = "No handler for custom template: ";
            String valueOf = String.valueOf(jSONObject.getString("custom_template_id"));
            com.google.android.gms.ads.internal.util.client.zzb.m9e(valueOf.length() != 0 ? string.concat(valueOf) : new String(string));
            return null;
        }
        zzan(0);
        return null;
    }

    public zzlc<com.google.android.gms.ads.internal.formats.zza> zzg(JSONObject jSONObject) throws JSONException {
        JSONObject optJSONObject = jSONObject.optJSONObject("attribution");
        if (optJSONObject == null) {
            return new zzla(null);
        }
        String optString = optJSONObject.optString("text");
        final int optInt = optJSONObject.optInt("text_size", -1);
        final Integer zzb = zzb(optJSONObject, "text_color");
        Integer zzb2 = zzb(optJSONObject, "bg_color");
        final int optInt2 = optJSONObject.optInt("animation_ms", 1000);
        final int optInt3 = optJSONObject.optInt("presentation_ms", 4000);
        int i = (this.zzbxv.zzcit.zzapm == null || this.zzbxv.zzcit.zzapm.versionCode < 2) ? 1 : this.zzbxv.zzcit.zzapm.zzbgw;
        final int i2 = i;
        List arrayList = new ArrayList();
        if (optJSONObject.optJSONArray("images") != null) {
            arrayList = zza(optJSONObject, "images", false, false, true);
        } else {
            arrayList.add(zza(optJSONObject, "image", false, false));
        }
        final String str = optString;
        final Integer num = zzb2;
        return zzlb.zza(zzlb.zzn(arrayList), new com.google.android.gms.internal.zzlb.zza<List<zzc>, com.google.android.gms.ads.internal.formats.zza>(this) {
            final /* synthetic */ zzim zzbzo;

            public /* synthetic */ Object zzh(Object obj) {
                return zzj((List) obj);
            }

            public com.google.android.gms.ads.internal.formats.zza zzj(List<zzc> list) {
                if (list != null) {
                    try {
                        if (list.isEmpty()) {
                            return null;
                        }
                        return new com.google.android.gms.ads.internal.formats.zza(str, zzim.zzh(list), num, zzb, optInt > 0 ? Integer.valueOf(optInt) : null, optInt3 + optInt2, i2);
                    } catch (Throwable e) {
                        com.google.android.gms.ads.internal.util.client.zzb.zzb("Could not get attribution icon", e);
                    }
                }
                return null;
            }
        });
    }

    public com.google.android.gms.internal.zzjy zzqs() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r3.zzbgf;	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r0.zzqi();	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r0 = java.util.UUID.randomUUID();	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r0 = r0.toString();	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r1 = r3.zzcc(r0);	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r2 = r3.zzf(r1);	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r0 = r3.zza(r2, r1, r0);	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r3.zza(r0);	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        r0 = r3.zzb(r0);	 Catch:{ CancellationException -> 0x002b, CancellationException -> 0x002b, CancellationException -> 0x002b, JSONException -> 0x0025, TimeoutException -> 0x0021 }
        return r0;
    L_0x0021:
        r0 = move-exception;
        r1 = "Timeout when loading native ad.";
        goto L_0x0028;
    L_0x0025:
        r0 = move-exception;
        r1 = "Malformed native JSON response.";
    L_0x0028:
        com.google.android.gms.ads.internal.util.client.zzb.zzd(r1, r0);
    L_0x002b:
        r0 = r3.zzbzi;
        if (r0 != 0) goto L_0x0033;
    L_0x002f:
        r0 = 0;
        r3.zzan(r0);
    L_0x0033:
        r0 = 0;
        r0 = r3.zzb(r0);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzim.zzqs():com.google.android.gms.internal.zzjy");
    }

    public boolean zzqt() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzbzi;
        }
        return z;
    }
}
