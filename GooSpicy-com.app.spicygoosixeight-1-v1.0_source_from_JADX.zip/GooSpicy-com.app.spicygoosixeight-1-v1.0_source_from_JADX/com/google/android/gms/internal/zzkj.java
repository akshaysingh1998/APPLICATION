package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import java.util.concurrent.Future;

@zzir
public final class zzkj {

    public interface zzb {
        void zzg(Bundle bundle);
    }

    private static abstract class zza extends zzkg {
        private zza() {
        }

        public void onStop() {
        }
    }

    class AnonymousClass10 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzb zzcks;

        AnonymousClass10(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
            this.zzaky = context;
            this.zzcks = com_google_android_gms_internal_zzkj_zzb;
            super();
        }

        public void zzew() {
            SharedPreferences zzn = zzkj.zzn(this.zzaky);
            Bundle bundle = new Bundle();
            bundle.putString("content_url_hashes", zzn.getString("content_url_hashes", ""));
            if (this.zzcks != null) {
                this.zzcks.zzg(bundle);
            }
        }
    }

    class AnonymousClass11 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ boolean zzckx;

        AnonymousClass11(Context context, boolean z) {
            this.zzaky = context;
            this.zzckx = z;
            super();
        }

        public void zzew() {
            Editor edit = zzkj.zzn(this.zzaky).edit();
            edit.putBoolean("auto_collect_location", this.zzckx);
            edit.apply();
        }
    }

    class C11211 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ boolean zzckr;

        C11211(Context context, boolean z) {
            this.zzaky = context;
            this.zzckr = z;
            super();
        }

        public void zzew() {
            Editor edit = zzkj.zzn(this.zzaky).edit();
            edit.putBoolean("use_https", this.zzckr);
            edit.apply();
        }
    }

    class C11222 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzb zzcks;

        C11222(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
            this.zzaky = context;
            this.zzcks = com_google_android_gms_internal_zzkj_zzb;
            super();
        }

        public void zzew() {
            SharedPreferences zzn = zzkj.zzn(this.zzaky);
            Bundle bundle = new Bundle();
            bundle.putBoolean("auto_collect_location", zzn.getBoolean("auto_collect_location", false));
            if (this.zzcks != null) {
                this.zzcks.zzg(bundle);
            }
        }
    }

    class C11233 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ String zzckt;
        final /* synthetic */ long zzcku;

        C11233(Context context, String str, long j) {
            this.zzaky = context;
            this.zzckt = str;
            this.zzcku = j;
            super();
        }

        public void zzew() {
            Editor edit = zzkj.zzn(this.zzaky).edit();
            edit.putString("app_settings_json", this.zzckt);
            edit.putLong("app_settings_last_update_ms", this.zzcku);
            edit.apply();
        }
    }

    class C11244 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzb zzcks;

        C11244(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
            this.zzaky = context;
            this.zzcks = com_google_android_gms_internal_zzkj_zzb;
            super();
        }

        public void zzew() {
            SharedPreferences zzn = zzkj.zzn(this.zzaky);
            Bundle bundle = new Bundle();
            bundle.putString("app_settings_json", zzn.getString("app_settings_json", ""));
            bundle.putLong("app_settings_last_update_ms", zzn.getLong("app_settings_last_update_ms", 0));
            if (this.zzcks != null) {
                this.zzcks.zzg(bundle);
            }
        }
    }

    class C11255 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzb zzcks;

        C11255(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
            this.zzaky = context;
            this.zzcks = com_google_android_gms_internal_zzkj_zzb;
            super();
        }

        public void zzew() {
            SharedPreferences zzn = zzkj.zzn(this.zzaky);
            Bundle bundle = new Bundle();
            bundle.putBoolean("use_https", zzn.getBoolean("use_https", true));
            if (this.zzcks != null) {
                this.zzcks.zzg(bundle);
            }
        }
    }

    class C11266 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzb zzcks;

        C11266(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
            this.zzaky = context;
            this.zzcks = com_google_android_gms_internal_zzkj_zzb;
            super();
        }

        public void zzew() {
            SharedPreferences zzn = zzkj.zzn(this.zzaky);
            Bundle bundle = new Bundle();
            bundle.putInt("webview_cache_version", zzn.getInt("webview_cache_version", 0));
            if (this.zzcks != null) {
                this.zzcks.zzg(bundle);
            }
        }
    }

    class C11277 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ boolean zzckv;

        C11277(Context context, boolean z) {
            this.zzaky = context;
            this.zzckv = z;
            super();
        }

        public void zzew() {
            Editor edit = zzkj.zzn(this.zzaky).edit();
            edit.putBoolean("content_url_opted_out", this.zzckv);
            edit.apply();
        }
    }

    class C11288 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzb zzcks;

        C11288(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
            this.zzaky = context;
            this.zzcks = com_google_android_gms_internal_zzkj_zzb;
            super();
        }

        public void zzew() {
            SharedPreferences zzn = zzkj.zzn(this.zzaky);
            Bundle bundle = new Bundle();
            bundle.putBoolean("content_url_opted_out", zzn.getBoolean("content_url_opted_out", true));
            if (this.zzcks != null) {
                this.zzcks.zzg(bundle);
            }
        }
    }

    class C11299 extends zza {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ String zzckw;

        C11299(Context context, String str) {
            this.zzaky = context;
            this.zzckw = str;
            super();
        }

        public void zzew() {
            Editor edit = zzkj.zzn(this.zzaky).edit();
            edit.putString("content_url_hashes", this.zzckw);
            edit.apply();
        }
    }

    public static Future zza(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
        return (Future) new C11255(context, com_google_android_gms_internal_zzkj_zzb).zzpz();
    }

    public static Future zza(Context context, String str, long j) {
        return (Future) new C11233(context, str, j).zzpz();
    }

    public static Future zzb(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
        return (Future) new C11266(context, com_google_android_gms_internal_zzkj_zzb).zzpz();
    }

    public static Future zzc(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
        return (Future) new C11288(context, com_google_android_gms_internal_zzkj_zzb).zzpz();
    }

    public static Future zzc(Context context, boolean z) {
        return (Future) new C11211(context, z).zzpz();
    }

    public static Future zzd(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
        return (Future) new AnonymousClass10(context, com_google_android_gms_internal_zzkj_zzb).zzpz();
    }

    public static Future zze(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
        return (Future) new C11222(context, com_google_android_gms_internal_zzkj_zzb).zzpz();
    }

    public static Future zze(Context context, boolean z) {
        return (Future) new C11277(context, z).zzpz();
    }

    public static Future zzf(Context context, zzb com_google_android_gms_internal_zzkj_zzb) {
        return (Future) new C11244(context, com_google_android_gms_internal_zzkj_zzb).zzpz();
    }

    public static Future zzf(Context context, boolean z) {
        return (Future) new AnonymousClass11(context, z).zzpz();
    }

    public static Future zzg(Context context, String str) {
        return (Future) new C11299(context, str).zzpz();
    }

    public static SharedPreferences zzn(Context context) {
        return context.getSharedPreferences("admob", 0);
    }
}
