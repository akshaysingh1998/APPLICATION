package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.internal.zzab;
import com.google.android.gms.common.zzc;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;

public final class zzsj {
    private static zzsk Me;
    private static final zza Mf = new C09651();
    public static final zzb Mg = new C09662();
    public static final zzb Mh = new C09673();
    public static final zzb Mi = new C09684();
    public static final zzb Mj = new C09695();
    public static final zzb Mk = new C09706();
    private final Context Ml;

    public static class zza extends Exception {
        private zza(String str) {
            super(str);
        }

        private zza(String str, Throwable th) {
            super(str, th);
        }
    }

    public interface zzb {

        public interface zza {
            int zzd(Context context, String str, boolean z);

            int zzt(Context context, String str);
        }

        public static class zzb {
            public int Mn = 0;
            public int Mo = 0;
            public int Mp = 0;
        }

        zzb zza(Context context, String str, zza com_google_android_gms_internal_zzsj_zzb_zza);
    }

    class C09651 implements zza {
        C09651() {
        }

        public int zzd(Context context, String str, boolean z) {
            return zzsj.zzd(context, str, z);
        }

        public int zzt(Context context, String str) {
            return zzsj.zzt(context, str);
        }
    }

    class C09662 implements zzb {
        C09662() {
        }

        public zzb zza(Context context, String str, zza com_google_android_gms_internal_zzsj_zzb_zza) {
            zzb com_google_android_gms_internal_zzsj_zzb_zzb = new zzb();
            com_google_android_gms_internal_zzsj_zzb_zzb.Mo = com_google_android_gms_internal_zzsj_zzb_zza.zzd(context, str, true);
            if (com_google_android_gms_internal_zzsj_zzb_zzb.Mo != 0) {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = 1;
                return com_google_android_gms_internal_zzsj_zzb_zzb;
            }
            com_google_android_gms_internal_zzsj_zzb_zzb.Mn = com_google_android_gms_internal_zzsj_zzb_zza.zzt(context, str);
            if (com_google_android_gms_internal_zzsj_zzb_zzb.Mn != 0) {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = -1;
            }
            return com_google_android_gms_internal_zzsj_zzb_zzb;
        }
    }

    class C09673 implements zzb {
        C09673() {
        }

        public zzb zza(Context context, String str, zza com_google_android_gms_internal_zzsj_zzb_zza) {
            zzb com_google_android_gms_internal_zzsj_zzb_zzb = new zzb();
            com_google_android_gms_internal_zzsj_zzb_zzb.Mn = com_google_android_gms_internal_zzsj_zzb_zza.zzt(context, str);
            if (com_google_android_gms_internal_zzsj_zzb_zzb.Mn != 0) {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = -1;
                return com_google_android_gms_internal_zzsj_zzb_zzb;
            }
            com_google_android_gms_internal_zzsj_zzb_zzb.Mo = com_google_android_gms_internal_zzsj_zzb_zza.zzd(context, str, true);
            if (com_google_android_gms_internal_zzsj_zzb_zzb.Mo != 0) {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = 1;
            }
            return com_google_android_gms_internal_zzsj_zzb_zzb;
        }
    }

    class C09684 implements zzb {
        C09684() {
        }

        public zzb zza(Context context, String str, zza com_google_android_gms_internal_zzsj_zzb_zza) {
            int i;
            zzb com_google_android_gms_internal_zzsj_zzb_zzb = new zzb();
            com_google_android_gms_internal_zzsj_zzb_zzb.Mn = com_google_android_gms_internal_zzsj_zzb_zza.zzt(context, str);
            com_google_android_gms_internal_zzsj_zzb_zzb.Mo = com_google_android_gms_internal_zzsj_zzb_zza.zzd(context, str, true);
            if (com_google_android_gms_internal_zzsj_zzb_zzb.Mn == 0 && com_google_android_gms_internal_zzsj_zzb_zzb.Mo == 0) {
                i = 0;
            } else if (com_google_android_gms_internal_zzsj_zzb_zzb.Mn >= com_google_android_gms_internal_zzsj_zzb_zzb.Mo) {
                i = -1;
            } else {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = 1;
                return com_google_android_gms_internal_zzsj_zzb_zzb;
            }
            com_google_android_gms_internal_zzsj_zzb_zzb.Mp = i;
            return com_google_android_gms_internal_zzsj_zzb_zzb;
        }
    }

    class C09695 implements zzb {
        C09695() {
        }

        public com.google.android.gms.internal.zzsj.zzb.zzb zza(android.content.Context r3, java.lang.String r4, com.google.android.gms.internal.zzsj.zzb.zza r5) {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:12:0x0029 in {4, 6, 10, 11} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r2 = this;
            r0 = new com.google.android.gms.internal.zzsj$zzb$zzb;
            r0.<init>();
            r1 = r5.zzt(r3, r4);
            r0.Mn = r1;
            r1 = 1;
            r3 = r5.zzd(r3, r4, r1);
            r0.Mo = r3;
            r3 = r0.Mn;
            if (r3 != 0) goto L_0x001e;
        L_0x0016:
            r3 = r0.Mo;
            if (r3 != 0) goto L_0x001e;
        L_0x001a:
            r3 = 0;
        L_0x001b:
            r0.Mp = r3;
            return r0;
        L_0x001e:
            r3 = r0.Mo;
            r4 = r0.Mn;
            if (r3 < r4) goto L_0x0027;
        L_0x0024:
            r0.Mp = r1;
            return r0;
        L_0x0027:
            r3 = -1;
            goto L_0x001b;
            return r0;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzsj.5.zza(android.content.Context, java.lang.String, com.google.android.gms.internal.zzsj$zzb$zza):com.google.android.gms.internal.zzsj$zzb$zzb");
        }
    }

    class C09706 implements zzb {
        C09706() {
        }

        public zzb zza(Context context, String str, zza com_google_android_gms_internal_zzsj_zzb_zza) {
            zzb com_google_android_gms_internal_zzsj_zzb_zzb = new zzb();
            com_google_android_gms_internal_zzsj_zzb_zzb.Mn = com_google_android_gms_internal_zzsj_zzb_zza.zzt(context, str);
            com_google_android_gms_internal_zzsj_zzb_zzb.Mo = com_google_android_gms_internal_zzsj_zzb_zzb.Mn != 0 ? com_google_android_gms_internal_zzsj_zzb_zza.zzd(context, str, false) : com_google_android_gms_internal_zzsj_zzb_zza.zzd(context, str, true);
            if (com_google_android_gms_internal_zzsj_zzb_zzb.Mn == 0 && com_google_android_gms_internal_zzsj_zzb_zzb.Mo == 0) {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = 0;
                return com_google_android_gms_internal_zzsj_zzb_zzb;
            } else if (com_google_android_gms_internal_zzsj_zzb_zzb.Mo >= com_google_android_gms_internal_zzsj_zzb_zzb.Mn) {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = 1;
                return com_google_android_gms_internal_zzsj_zzb_zzb;
            } else {
                com_google_android_gms_internal_zzsj_zzb_zzb.Mp = -1;
                return com_google_android_gms_internal_zzsj_zzb_zzb;
            }
        }
    }

    class C09717 implements zza {
        final /* synthetic */ int Mm;

        C09717(int i) {
            this.Mm = i;
        }

        public int zzd(Context context, String str, boolean z) {
            return 0;
        }

        public int zzt(Context context, String str) {
            return this.Mm;
        }
    }

    private zzsj(Context context) {
        this.Ml = (Context) zzab.zzaa(context);
    }

    public static zzsj zza(Context context, zzb com_google_android_gms_internal_zzsj_zzb, String str) throws zza {
        int i;
        zzb zza = com_google_android_gms_internal_zzsj_zzb.zza(context, str, Mf);
        int i2 = zza.Mn;
        int i3 = zza.Mo;
        StringBuilder stringBuilder = new StringBuilder((68 + String.valueOf(str).length()) + String.valueOf(str).length());
        stringBuilder.append("Considering local module ");
        stringBuilder.append(str);
        stringBuilder.append(":");
        stringBuilder.append(i2);
        stringBuilder.append(" and remote module ");
        stringBuilder.append(str);
        stringBuilder.append(":");
        stringBuilder.append(i3);
        Log.i("DynamiteModule", stringBuilder.toString());
        if (!(zza.Mp == 0 || (zza.Mp == -1 && zza.Mn == 0))) {
            if (zza.Mp != 1 || zza.Mo != 0) {
                if (zza.Mp == -1) {
                    return zzv(context, str);
                }
                if (zza.Mp == 1) {
                    try {
                        return zza(context, str, zza.Mo);
                    } catch (Throwable e) {
                        String str2 = "DynamiteModule";
                        String str3 = "Failed to load remote module: ";
                        String valueOf = String.valueOf(e.getMessage());
                        Log.w(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
                        if (zza.Mn != 0 && com_google_android_gms_internal_zzsj_zzb.zza(context, str, new C09717(zza.Mn)).Mp == -1) {
                            return zzv(context, str);
                        }
                        throw new zza("Remote load failed. No local fallback found.", e);
                    }
                }
                i = zza.Mp;
                StringBuilder stringBuilder2 = new StringBuilder(47);
                stringBuilder2.append("VersionPolicy returned invalid code:");
                stringBuilder2.append(i);
                throw new zza(stringBuilder2.toString());
            }
        }
        i = zza.Mn;
        int i4 = zza.Mo;
        StringBuilder stringBuilder3 = new StringBuilder(91);
        stringBuilder3.append("No acceptable module found. Local version is ");
        stringBuilder3.append(i);
        stringBuilder3.append(" and remote version is ");
        stringBuilder3.append(i4);
        stringBuilder3.append(".");
        throw new zza(stringBuilder3.toString());
    }

    private static zzsj zza(Context context, String str, int i) throws zza {
        StringBuilder stringBuilder = new StringBuilder(51 + String.valueOf(str).length());
        stringBuilder.append("Selected remote version of ");
        stringBuilder.append(str);
        stringBuilder.append(", version >= ");
        stringBuilder.append(i);
        Log.i("DynamiteModule", stringBuilder.toString());
        zzsk zzcs = zzcs(context);
        if (zzcs == null) {
            throw new zza("Failed to create IDynamiteLoader.");
        }
        try {
            zzd zza = zzcs.zza(zze.zzae(context), str, i);
            if (zze.zzad(zza) != null) {
                return new zzsj((Context) zze.zzad(zza));
            }
            throw new zza("Failed to load remote module.");
        } catch (Throwable e) {
            throw new zza("Failed to load remote module.", e);
        }
    }

    private static zzsk zzcs(Context context) {
        synchronized (zzsj.class) {
            zzsk com_google_android_gms_internal_zzsk;
            if (Me != null) {
                com_google_android_gms_internal_zzsk = Me;
                return com_google_android_gms_internal_zzsk;
            } else if (zzc.zzand().isGooglePlayServicesAvailable(context) != 0) {
                return null;
            } else {
                try {
                    com_google_android_gms_internal_zzsk = com.google.android.gms.internal.zzsk.zza.zzfd((IBinder) context.createPackageContext("com.google.android.gms", 3).getClassLoader().loadClass("com.google.android.gms.chimera.container.DynamiteLoaderImpl").newInstance());
                    if (com_google_android_gms_internal_zzsk != null) {
                        Me = com_google_android_gms_internal_zzsk;
                        return com_google_android_gms_internal_zzsk;
                    }
                } catch (Exception e) {
                    String str = "DynamiteModule";
                    String str2 = "Failed to load IDynamiteLoader from GmsCore: ";
                    String valueOf = String.valueOf(e.getMessage());
                    Log.e(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
                }
            }
        }
        return null;
    }

    public static int zzd(Context context, String str, boolean z) {
        zzsk zzcs = zzcs(context);
        if (zzcs == null) {
            return 0;
        }
        try {
            return zzcs.zza(zze.zzae(context), str, z);
        } catch (RemoteException e) {
            str = "DynamiteModule";
            String str2 = "Failed to retrieve remote module version: ";
            String valueOf = String.valueOf(e.getMessage());
            Log.w(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            return 0;
        }
    }

    public static int zzt(android.content.Context r6, java.lang.String r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = 0;
        r6 = r6.getApplicationContext();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r6 = r6.getClassLoader();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = "com.google.android.gms.dynamite.descriptors.";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = java.lang.String.valueOf(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2 = "ModuleDescriptor";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2 = java.lang.String.valueOf(r2);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3 = new java.lang.StringBuilder;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = 1;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r5 = java.lang.String.valueOf(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r5 = r5.length();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = r4 + r5;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r5 = java.lang.String.valueOf(r7);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r5 = r5.length();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = r4 + r5;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r5 = java.lang.String.valueOf(r2);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r5 = r5.length();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = r4 + r5;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3.<init>(r4);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3.append(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3.append(r7);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = ".";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3.append(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3.append(r2);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = r3.toString();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r6 = r6.loadClass(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = "MODULE_ID";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = r6.getDeclaredField(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2 = "MODULE_VERSION";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r6 = r6.getDeclaredField(r2);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2 = 0;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3 = r1.get(r2);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3 = r3.equals(r7);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        if (r3 != 0) goto L_0x00a3;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
    L_0x0063:
        r6 = "DynamiteModule";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = r1.get(r2);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = java.lang.String.valueOf(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2 = new java.lang.StringBuilder;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3 = 51;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = java.lang.String.valueOf(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = r4.length();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3 = r3 + r4;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = java.lang.String.valueOf(r7);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r4 = r4.length();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3 = r3 + r4;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2.<init>(r3);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r3 = "Module descriptor id '";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2.append(r3);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2.append(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = "' didn't match expected id '";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2.append(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2.append(r7);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = "'";	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r2.append(r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        r1 = r2.toString();	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        android.util.Log.e(r6, r1);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        return r0;	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
    L_0x00a3:
        r6 = r6.getInt(r2);	 Catch:{ ClassNotFoundException -> 0x00c9, Exception -> 0x00a8 }
        return r6;
    L_0x00a8:
        r6 = move-exception;
        r7 = "DynamiteModule";
        r1 = "Failed to load module descriptor class: ";
        r6 = r6.getMessage();
        r6 = java.lang.String.valueOf(r6);
        r2 = r6.length();
        if (r2 == 0) goto L_0x00c0;
    L_0x00bb:
        r6 = r1.concat(r6);
        goto L_0x00c5;
    L_0x00c0:
        r6 = new java.lang.String;
        r6.<init>(r1);
    L_0x00c5:
        android.util.Log.e(r7, r6);
        return r0;
    L_0x00c9:
        r6 = "DynamiteModule";
        r1 = new java.lang.StringBuilder;
        r2 = 45;
        r3 = java.lang.String.valueOf(r7);
        r3 = r3.length();
        r2 = r2 + r3;
        r1.<init>(r2);
        r2 = "Local module descriptor class for ";
        r1.append(r2);
        r1.append(r7);
        r7 = " not found.";
        r1.append(r7);
        r7 = r1.toString();
        android.util.Log.w(r6, r7);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzsj.zzt(android.content.Context, java.lang.String):int");
    }

    public static int zzu(Context context, String str) {
        return zzd(context, str, false);
    }

    private static zzsj zzv(Context context, String str) {
        String str2 = "DynamiteModule";
        String str3 = "Selected local version of ";
        str = String.valueOf(str);
        Log.i(str2, str.length() != 0 ? str3.concat(str) : new String(str3));
        return new zzsj(context.getApplicationContext());
    }

    public Context zzbcw() {
        return this.Ml;
    }

    public IBinder zziv(String str) throws zza {
        try {
            return (IBinder) this.Ml.getClassLoader().loadClass(str).newInstance();
        } catch (Throwable e) {
            String str2 = "Failed to instantiate module class: ";
            str = String.valueOf(str);
            throw new zza(str.length() != 0 ? str2.concat(str) : new String(str2), e);
        }
    }
}
