package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public final class zzaoj implements zzanl {
    private final zzans beb;
    private final zzant bek;
    private final zzamr bem;

    static abstract class zzb {
        final boolean bgc;
        final boolean bgd;
        final String name;

        protected zzb(String str, boolean z, boolean z2) {
            this.name = str;
            this.bgc = z;
            this.bgd = z2;
        }

        abstract void zza(zzaop com_google_android_gms_internal_zzaop, Object obj) throws IOException, IllegalAccessException;

        abstract void zza(zzaor com_google_android_gms_internal_zzaor, Object obj) throws IOException, IllegalAccessException;

        abstract boolean zzcq(Object obj) throws IOException, IllegalAccessException;
    }

    public static final class zza<T> extends zzank<T> {
        private final zzanx<T> bfI;
        private final Map<String, zzb> bgb;

        private zza(zzanx<T> com_google_android_gms_internal_zzanx_T, Map<String, zzb> map) {
            this.bfI = com_google_android_gms_internal_zzanx_T;
            this.bgb = map;
        }

        public void zza(com.google.android.gms.internal.zzaor r4, T r5) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            if (r5 != 0) goto L_0x0006;
        L_0x0002:
            r4.mo2318r();
            return;
        L_0x0006:
            r4.mo2316p();
            r0 = r3.bgb;	 Catch:{ IllegalAccessException -> 0x0032 }
            r0 = r0.values();	 Catch:{ IllegalAccessException -> 0x0032 }
            r0 = r0.iterator();	 Catch:{ IllegalAccessException -> 0x0032 }
        L_0x0013:
            r1 = r0.hasNext();	 Catch:{ IllegalAccessException -> 0x0032 }
            if (r1 == 0) goto L_0x002e;	 Catch:{ IllegalAccessException -> 0x0032 }
        L_0x0019:
            r1 = r0.next();	 Catch:{ IllegalAccessException -> 0x0032 }
            r1 = (com.google.android.gms.internal.zzaoj.zzb) r1;	 Catch:{ IllegalAccessException -> 0x0032 }
            r2 = r1.zzcq(r5);	 Catch:{ IllegalAccessException -> 0x0032 }
            if (r2 == 0) goto L_0x0013;	 Catch:{ IllegalAccessException -> 0x0032 }
        L_0x0025:
            r2 = r1.name;	 Catch:{ IllegalAccessException -> 0x0032 }
            r4.zzta(r2);	 Catch:{ IllegalAccessException -> 0x0032 }
            r1.zza(r4, r5);	 Catch:{ IllegalAccessException -> 0x0032 }
            goto L_0x0013;
        L_0x002e:
            r4.mo2317q();
            return;
        L_0x0032:
            r4 = new java.lang.AssertionError;
            r4.<init>();
            throw r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaoj.zza.zza(com.google.android.gms.internal.zzaor, java.lang.Object):void");
        }

        public T zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            Object a = this.bfI.mo2294a();
            try {
                com_google_android_gms_internal_zzaop.beginObject();
                while (com_google_android_gms_internal_zzaop.hasNext()) {
                    zzb com_google_android_gms_internal_zzaoj_zzb = (zzb) this.bgb.get(com_google_android_gms_internal_zzaop.nextName());
                    if (com_google_android_gms_internal_zzaoj_zzb != null) {
                        if (com_google_android_gms_internal_zzaoj_zzb.bgd) {
                            com_google_android_gms_internal_zzaoj_zzb.zza(com_google_android_gms_internal_zzaop, a);
                        }
                    }
                    com_google_android_gms_internal_zzaop.skipValue();
                }
                com_google_android_gms_internal_zzaop.endObject();
                return a;
            } catch (Throwable e) {
                throw new zzanh(e);
            } catch (IllegalAccessException e2) {
                throw new AssertionError(e2);
            }
        }
    }

    public zzaoj(zzans com_google_android_gms_internal_zzans, zzamr com_google_android_gms_internal_zzamr, zzant com_google_android_gms_internal_zzant) {
        this.beb = com_google_android_gms_internal_zzans;
        this.bem = com_google_android_gms_internal_zzamr;
        this.bek = com_google_android_gms_internal_zzant;
    }

    private zzank<?> zza(zzams com_google_android_gms_internal_zzams, Field field, zzaoo<?> com_google_android_gms_internal_zzaoo_) {
        zzanm com_google_android_gms_internal_zzanm = (zzanm) field.getAnnotation(zzanm.class);
        if (com_google_android_gms_internal_zzanm != null) {
            zzank<?> zza = zzaoe.zza(this.beb, com_google_android_gms_internal_zzams, com_google_android_gms_internal_zzaoo_, com_google_android_gms_internal_zzanm);
            if (zza != null) {
                return zza;
            }
        }
        return com_google_android_gms_internal_zzams.zza((zzaoo) com_google_android_gms_internal_zzaoo_);
    }

    private zzb zza(zzams com_google_android_gms_internal_zzams, Field field, String str, zzaoo<?> com_google_android_gms_internal_zzaoo_, boolean z, boolean z2) {
        final boolean zzk = zzany.zzk(com_google_android_gms_internal_zzaoo_.m15s());
        final zzams com_google_android_gms_internal_zzams2 = com_google_android_gms_internal_zzams;
        final Field field2 = field;
        final zzaoo<?> com_google_android_gms_internal_zzaoo_2 = com_google_android_gms_internal_zzaoo_;
        return new zzb(this, str, z, z2) {
            final zzank<?> bfV = this.bga.zza(com_google_android_gms_internal_zzams2, field2, com_google_android_gms_internal_zzaoo_2);
            final /* synthetic */ zzaoj bga;

            void zza(zzaop com_google_android_gms_internal_zzaop, Object obj) throws IOException, IllegalAccessException {
                Object zzb = this.bfV.zzb(com_google_android_gms_internal_zzaop);
                if (zzb != null || !zzk) {
                    field2.set(obj, zzb);
                }
            }

            void zza(zzaor com_google_android_gms_internal_zzaor, Object obj) throws IOException, IllegalAccessException {
                new zzaom(com_google_android_gms_internal_zzams2, this.bfV, com_google_android_gms_internal_zzaoo_2.m16t()).zza(com_google_android_gms_internal_zzaor, field2.get(obj));
            }

            public boolean zzcq(Object obj) throws IOException, IllegalAccessException {
                boolean z = false;
                if (!this.bgc) {
                    return false;
                }
                if (field2.get(obj) != obj) {
                    z = true;
                }
                return z;
            }
        };
    }

    static List<String> zza(zzamr com_google_android_gms_internal_zzamr, Field field) {
        zzann com_google_android_gms_internal_zzann = (zzann) field.getAnnotation(zzann.class);
        List<String> linkedList = new LinkedList();
        if (com_google_android_gms_internal_zzann == null) {
            linkedList.add(com_google_android_gms_internal_zzamr.zzc(field));
            return linkedList;
        }
        linkedList.add(com_google_android_gms_internal_zzann.value());
        for (Object add : com_google_android_gms_internal_zzann.zzczy()) {
            linkedList.add(add);
        }
        return linkedList;
    }

    private Map<String, zzb> zza(zzams com_google_android_gms_internal_zzams, zzaoo<?> com_google_android_gms_internal_zzaoo_, Class<?> cls) {
        zzaoj com_google_android_gms_internal_zzaoj = this;
        Map<String, zzb> linkedHashMap = new LinkedHashMap();
        if (cls.isInterface()) {
            return linkedHashMap;
        }
        Type t = com_google_android_gms_internal_zzaoo_.m16t();
        zzaoo com_google_android_gms_internal_zzaoo = com_google_android_gms_internal_zzaoo_;
        Class cls2 = cls;
        while (cls2 != Object.class) {
            Field[] declaredFields = cls2.getDeclaredFields();
            boolean z = false;
            int length = declaredFields.length;
            int i = 0;
            while (i < length) {
                Field field = declaredFields[i];
                boolean zza = zza(field, true);
                boolean zza2 = zza(field, z);
                if (zza || zza2) {
                    zzb com_google_android_gms_internal_zzaoj_zzb;
                    field.setAccessible(true);
                    Type zza3 = zzanr.zza(com_google_android_gms_internal_zzaoo.m16t(), cls2, field.getGenericType());
                    List zzd = zzd(field);
                    zzb com_google_android_gms_internal_zzaoj_zzb2 = null;
                    int i2 = z;
                    while (i2 < zzd.size()) {
                        String str = (String) zzd.get(i2);
                        boolean z2 = i2 != 0 ? z : zza;
                        String str2 = str;
                        com_google_android_gms_internal_zzaoj_zzb = com_google_android_gms_internal_zzaoj_zzb2;
                        int i3 = i2;
                        List list = zzd;
                        Type type = zza3;
                        Field field2 = field;
                        com_google_android_gms_internal_zzaoj_zzb2 = com_google_android_gms_internal_zzaoj_zzb == null ? (zzb) linkedHashMap.put(str2, zza(com_google_android_gms_internal_zzams, field, str2, zzaoo.zzl(zza3), z2, zza2)) : com_google_android_gms_internal_zzaoj_zzb;
                        i2 = i3 + 1;
                        zza = z2;
                        zza3 = type;
                        zzd = list;
                        field = field2;
                        z = false;
                    }
                    com_google_android_gms_internal_zzaoj_zzb = com_google_android_gms_internal_zzaoj_zzb2;
                    if (com_google_android_gms_internal_zzaoj_zzb != null) {
                        String valueOf = String.valueOf(t);
                        String str3 = com_google_android_gms_internal_zzaoj_zzb.name;
                        StringBuilder stringBuilder = new StringBuilder((37 + String.valueOf(valueOf).length()) + String.valueOf(str3).length());
                        stringBuilder.append(valueOf);
                        stringBuilder.append(" declares multiple JSON fields named ");
                        stringBuilder.append(str3);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                }
                i++;
                z = false;
            }
            com_google_android_gms_internal_zzaoo = zzaoo.zzl(zzanr.zza(com_google_android_gms_internal_zzaoo.m16t(), cls2, cls2.getGenericSuperclass()));
            cls2 = com_google_android_gms_internal_zzaoo.m15s();
        }
        return linkedHashMap;
    }

    static boolean zza(Field field, boolean z, zzant com_google_android_gms_internal_zzant) {
        return (com_google_android_gms_internal_zzant.zza(field.getType(), z) || com_google_android_gms_internal_zzant.zza(field, z)) ? false : true;
    }

    private List<String> zzd(Field field) {
        return zza(this.bem, field);
    }

    public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
        Class s = com_google_android_gms_internal_zzaoo_T.m15s();
        return !Object.class.isAssignableFrom(s) ? null : new zza(this.beb.zzb(com_google_android_gms_internal_zzaoo_T), zza(com_google_android_gms_internal_zzams, (zzaoo) com_google_android_gms_internal_zzaoo_T, s));
    }

    public boolean zza(Field field, boolean z) {
        return zza(field, z, this.bek);
    }
}
