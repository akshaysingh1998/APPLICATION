package com.google.android.gms.internal;

public final class zzanq {
    public static <T> T zzaa(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }

    public static void zzbn(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }
}
