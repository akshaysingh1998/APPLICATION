package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

@zzir
public class zzde {
    final Context mContext;
    final String zzarh;
    String zzbdn;
    BlockingQueue<zzdk> zzbdp;
    ExecutorService zzbdq;
    LinkedHashMap<String, String> zzbdr = new LinkedHashMap();
    Map<String, zzdh> zzbds = new HashMap();
    private AtomicBoolean zzbdt;
    private File zzbdu;

    class C04101 implements Runnable {
        final /* synthetic */ zzde zzbdv;

        C04101(zzde com_google_android_gms_internal_zzde) {
            this.zzbdv = com_google_android_gms_internal_zzde;
        }

        public void run() {
            this.zzbdv.zzkc();
        }
    }

    public zzde(Context context, String str, String str2, Map<String, String> map) {
        this.mContext = context;
        this.zzarh = str;
        this.zzbdn = str2;
        this.zzbdt = new AtomicBoolean(false);
        this.zzbdt.set(((Boolean) zzdc.zzaze.get()).booleanValue());
        if (this.zzbdt.get()) {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            if (externalStorageDirectory != null) {
                this.zzbdu = new File(externalStorageDirectory, "sdk_csi_data.txt");
            }
        }
        for (Entry entry : map.entrySet()) {
            this.zzbdr.put((String) entry.getKey(), (String) entry.getValue());
        }
        this.zzbdp = new ArrayBlockingQueue(30);
        this.zzbdq = Executors.newSingleThreadExecutor();
        this.zzbdq.execute(new C04101(this));
        this.zzbds.put("action", zzdh.zzbdx);
        this.zzbds.put("ad_format", zzdh.zzbdx);
        this.zzbds.put("e", zzdh.zzbdy);
    }

    private void zzc(File file, String str) {
        Throwable e;
        if (file != null) {
            FileOutputStream fileOutputStream = null;
            try {
                FileOutputStream fileOutputStream2 = new FileOutputStream(file, true);
                try {
                    fileOutputStream2.write(str.getBytes());
                    fileOutputStream2.write(10);
                    if (fileOutputStream2 != null) {
                        try {
                            fileOutputStream2.close();
                            return;
                        } catch (Throwable e2) {
                            zzb.zzd("CsiReporter: Cannot close file: sdk_csi_data.txt.", e2);
                            return;
                        }
                    }
                } catch (IOException e3) {
                    e2 = e3;
                    fileOutputStream = fileOutputStream2;
                    try {
                        zzb.zzd("CsiReporter: Cannot write to file: sdk_csi_data.txt.", e2);
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                            return;
                        }
                    } catch (Throwable th) {
                        e2 = th;
                        if (fileOutputStream != null) {
                            try {
                                fileOutputStream.close();
                            } catch (Throwable e4) {
                                zzb.zzd("CsiReporter: Cannot close file: sdk_csi_data.txt.", e4);
                            }
                        }
                        throw e2;
                    }
                } catch (Throwable th2) {
                    e2 = th2;
                    fileOutputStream = fileOutputStream2;
                    if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }
                    throw e2;
                }
            } catch (IOException e5) {
                e2 = e5;
                zzb.zzd("CsiReporter: Cannot write to file: sdk_csi_data.txt.", e2);
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                    return;
                }
            }
        }
        zzb.zzcy("CsiReporter: File doesn't exists. Cannot write CSI data to file.");
    }

    private void zzc(Map<String, String> map, String str) {
        String zza = zza(this.zzbdn, map, str);
        if (this.zzbdt.get()) {
            zzc(this.zzbdu, zza);
        } else {
            zzu.zzfq().zzc(this.mContext, this.zzarh, zza);
        }
    }

    private void zzkc() {
        while (true) {
            try {
                zzdk com_google_android_gms_internal_zzdk = (zzdk) this.zzbdp.take();
                String zzki = com_google_android_gms_internal_zzdk.zzki();
                if (!TextUtils.isEmpty(zzki)) {
                    zzc(zza(this.zzbdr, com_google_android_gms_internal_zzdk.zzm()), zzki);
                }
            } catch (Throwable e) {
                zzb.zzd("CsiReporter:reporter interrupted", e);
                return;
            }
        }
    }

    String zza(String str, Map<String, String> map, @NonNull String str2) {
        Builder buildUpon = Uri.parse(str).buildUpon();
        for (Entry entry : map.entrySet()) {
            buildUpon.appendQueryParameter((String) entry.getKey(), (String) entry.getValue());
        }
        StringBuilder stringBuilder = new StringBuilder(buildUpon.build().toString());
        stringBuilder.append("&");
        stringBuilder.append("it");
        stringBuilder.append("=");
        stringBuilder.append(str2);
        return stringBuilder.toString();
    }

    Map<String, String> zza(Map<String, String> map, @Nullable Map<String, String> map2) {
        Map<String, String> linkedHashMap = new LinkedHashMap(map);
        if (map2 == null) {
            return linkedHashMap;
        }
        for (Entry entry : map2.entrySet()) {
            String str = (String) entry.getKey();
            String str2 = (String) linkedHashMap.get(str);
            linkedHashMap.put(str, zzaq(str).zzg(str2, (String) entry.getValue()));
        }
        return linkedHashMap;
    }

    public boolean zza(zzdk com_google_android_gms_internal_zzdk) {
        return this.zzbdp.offer(com_google_android_gms_internal_zzdk);
    }

    public zzdh zzaq(String str) {
        zzdh com_google_android_gms_internal_zzdh = (zzdh) this.zzbds.get(str);
        return com_google_android_gms_internal_zzdh != null ? com_google_android_gms_internal_zzdh : zzdh.zzbdw;
    }

    public void zzc(List<String> list) {
        if (list != null && !list.isEmpty()) {
            this.zzbdr.put("e", TextUtils.join(",", list));
        }
    }
}
