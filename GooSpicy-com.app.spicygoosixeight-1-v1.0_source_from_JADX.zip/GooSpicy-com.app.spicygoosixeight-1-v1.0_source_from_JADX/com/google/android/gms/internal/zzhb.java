package com.google.android.gms.internal;

import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.AdRequest.Gender;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.zza;
import java.util.Date;
import java.util.HashSet;

@zzir
public final class zzhb {

    static /* synthetic */ class C04441 {
        static final /* synthetic */ int[] zzbpw = new int[Gender.values().length];

        static {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r0 = com.google.ads.AdRequest.ErrorCode.values();
            r0 = r0.length;
            r0 = new int[r0];
            zzbpx = r0;
            r0 = 1;
            r1 = zzbpx;	 Catch:{ NoSuchFieldError -> 0x0014 }
            r2 = com.google.ads.AdRequest.ErrorCode.INTERNAL_ERROR;	 Catch:{ NoSuchFieldError -> 0x0014 }
            r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0014 }
            r1[r2] = r0;	 Catch:{ NoSuchFieldError -> 0x0014 }
        L_0x0014:
            r1 = 2;
            r2 = zzbpx;	 Catch:{ NoSuchFieldError -> 0x001f }
            r3 = com.google.ads.AdRequest.ErrorCode.INVALID_REQUEST;	 Catch:{ NoSuchFieldError -> 0x001f }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x001f }
            r2[r3] = r1;	 Catch:{ NoSuchFieldError -> 0x001f }
        L_0x001f:
            r2 = 3;
            r3 = zzbpx;	 Catch:{ NoSuchFieldError -> 0x002a }
            r4 = com.google.ads.AdRequest.ErrorCode.NETWORK_ERROR;	 Catch:{ NoSuchFieldError -> 0x002a }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x002a }
            r3[r4] = r2;	 Catch:{ NoSuchFieldError -> 0x002a }
        L_0x002a:
            r3 = zzbpx;	 Catch:{ NoSuchFieldError -> 0x0035 }
            r4 = com.google.ads.AdRequest.ErrorCode.NO_FILL;	 Catch:{ NoSuchFieldError -> 0x0035 }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x0035 }
            r5 = 4;	 Catch:{ NoSuchFieldError -> 0x0035 }
            r3[r4] = r5;	 Catch:{ NoSuchFieldError -> 0x0035 }
        L_0x0035:
            r3 = com.google.ads.AdRequest.Gender.values();
            r3 = r3.length;
            r3 = new int[r3];
            zzbpw = r3;
            r3 = zzbpw;	 Catch:{ NoSuchFieldError -> 0x0048 }
            r4 = com.google.ads.AdRequest.Gender.FEMALE;	 Catch:{ NoSuchFieldError -> 0x0048 }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x0048 }
            r3[r4] = r0;	 Catch:{ NoSuchFieldError -> 0x0048 }
        L_0x0048:
            r0 = zzbpw;	 Catch:{ NoSuchFieldError -> 0x0052 }
            r3 = com.google.ads.AdRequest.Gender.MALE;	 Catch:{ NoSuchFieldError -> 0x0052 }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x0052 }
            r0[r3] = r1;	 Catch:{ NoSuchFieldError -> 0x0052 }
        L_0x0052:
            r0 = zzbpw;	 Catch:{ NoSuchFieldError -> 0x005c }
            r1 = com.google.ads.AdRequest.Gender.UNKNOWN;	 Catch:{ NoSuchFieldError -> 0x005c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x005c }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x005c }
        L_0x005c:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhb.1.<clinit>():void");
        }
    }

    public static int zza(ErrorCode errorCode) {
        switch (errorCode) {
            case INVALID_REQUEST:
                return 1;
            case NETWORK_ERROR:
                return 2;
            case NO_FILL:
                return 3;
            default:
                return 0;
        }
    }

    public static Gender zzab(int i) {
        switch (i) {
            case 1:
                return Gender.MALE;
            case 2:
                return Gender.FEMALE;
            default:
                return Gender.UNKNOWN;
        }
    }

    public static AdSize zzc(AdSizeParcel adSizeParcel) {
        r1 = new AdSize[6];
        int i = 0;
        r1[0] = AdSize.SMART_BANNER;
        r1[1] = AdSize.BANNER;
        r1[2] = AdSize.IAB_MRECT;
        r1[3] = AdSize.IAB_BANNER;
        r1[4] = AdSize.IAB_LEADERBOARD;
        r1[5] = AdSize.IAB_WIDE_SKYSCRAPER;
        while (i < 6) {
            if (r1[i].getWidth() == adSizeParcel.width && r1[i].getHeight() == adSizeParcel.height) {
                return r1[i];
            }
            i++;
        }
        return new AdSize(zza.zza(adSizeParcel.width, adSizeParcel.height, adSizeParcel.zzaup));
    }

    public static MediationAdRequest zzp(AdRequestParcel adRequestParcel) {
        return new MediationAdRequest(new Date(adRequestParcel.zzatk), zzab(adRequestParcel.zzatl), adRequestParcel.zzatm != null ? new HashSet(adRequestParcel.zzatm) : null, adRequestParcel.zzatn, adRequestParcel.zzats);
    }
}
