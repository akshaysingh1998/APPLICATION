package com.google.android.gms.internal;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Debug;
import android.os.Debug.MemoryInfo;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.PowerManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.PopupWindow;
import com.google.android.gms.ads.AdActivity;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzo;
import com.google.android.gms.ads.internal.zzu;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Future;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public class zzkl {
    public static final Handler zzclg = new zzki(Looper.getMainLooper());
    private final Object zzail = new Object();
    private String zzbjj;
    private zzfw zzcee;
    private boolean zzclh = true;
    private boolean zzcli = false;

    private final class zza extends BroadcastReceiver {
        final /* synthetic */ zzkl zzcll;

        private zza(zzkl com_google_android_gms_internal_zzkl) {
            this.zzcll = com_google_android_gms_internal_zzkl;
        }

        public void onReceive(Context context, Intent intent) {
            zzkl com_google_android_gms_internal_zzkl;
            boolean z;
            if ("android.intent.action.USER_PRESENT".equals(intent.getAction())) {
                com_google_android_gms_internal_zzkl = this.zzcll;
                z = true;
            } else if ("android.intent.action.SCREEN_OFF".equals(intent.getAction())) {
                com_google_android_gms_internal_zzkl = this.zzcll;
                z = false;
            } else {
                return;
            }
            com_google_android_gms_internal_zzkl.zzclh = z;
        }
    }

    private JSONArray zza(Collection<?> collection) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        for (Object zza : collection) {
            zza(jSONArray, zza);
        }
        return jSONArray;
    }

    private void zza(org.json.JSONArray r2, java.lang.Object r3) throws org.json.JSONException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:14:0x002f in {2, 4, 7, 10, 13} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = r3 instanceof android.os.Bundle;
        if (r0 == 0) goto L_0x000e;
    L_0x0004:
        r3 = (android.os.Bundle) r3;
        r3 = r1.zzh(r3);
    L_0x000a:
        r2.put(r3);
        return;
    L_0x000e:
        r0 = r3 instanceof java.util.Map;
        if (r0 == 0) goto L_0x0019;
    L_0x0012:
        r3 = (java.util.Map) r3;
        r3 = r1.zzam(r3);
        goto L_0x000a;
    L_0x0019:
        r0 = r3 instanceof java.util.Collection;
        if (r0 == 0) goto L_0x0024;
    L_0x001d:
        r3 = (java.util.Collection) r3;
        r3 = r1.zza(r3);
        goto L_0x000a;
    L_0x0024:
        r0 = r3 instanceof java.lang.Object[];
        if (r0 == 0) goto L_0x000a;
    L_0x0028:
        r3 = (java.lang.Object[]) r3;
        r3 = r1.zza(r3);
        goto L_0x000a;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zza(org.json.JSONArray, java.lang.Object):void");
    }

    private void zza(org.json.JSONObject r2, java.lang.String r3, java.lang.Object r4) throws org.json.JSONException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:18:0x0034 in {2, 4, 7, 11, 12, 13, 16, 17} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = r4 instanceof android.os.Bundle;
        if (r0 == 0) goto L_0x000e;
    L_0x0004:
        r4 = (android.os.Bundle) r4;
        r4 = r1.zzh(r4);
    L_0x000a:
        r2.put(r3, r4);
        return;
    L_0x000e:
        r0 = r4 instanceof java.util.Map;
        if (r0 == 0) goto L_0x0019;
    L_0x0012:
        r4 = (java.util.Map) r4;
        r4 = r1.zzam(r4);
        goto L_0x000a;
    L_0x0019:
        r0 = r4 instanceof java.util.Collection;
        if (r0 == 0) goto L_0x0025;
    L_0x001d:
        if (r3 == 0) goto L_0x0020;
    L_0x001f:
        goto L_0x0022;
    L_0x0020:
        r3 = "null";
    L_0x0022:
        r4 = (java.util.Collection) r4;
        goto L_0x002f;
    L_0x0025:
        r0 = r4 instanceof java.lang.Object[];
        if (r0 == 0) goto L_0x000a;
    L_0x0029:
        r4 = (java.lang.Object[]) r4;
        r4 = java.util.Arrays.asList(r4);
    L_0x002f:
        r4 = r1.zza(r4);
        goto L_0x000a;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zza(org.json.JSONObject, java.lang.String, java.lang.Object):void");
    }

    private boolean zza(KeyguardManager keyguardManager) {
        return keyguardManager == null ? false : keyguardManager.inKeyguardRestrictedInputMode();
    }

    private boolean zza(PowerManager powerManager) {
        if (powerManager != null) {
            if (!powerManager.isScreenOn()) {
                return false;
            }
        }
        return true;
    }

    private JSONObject zzh(Bundle bundle) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        for (String str : bundle.keySet()) {
            zza(jSONObject, str, bundle.get(str));
        }
        return jSONObject;
    }

    private boolean zzj(Context context) {
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        return powerManager == null ? false : powerManager.isScreenOn();
    }

    private Bitmap zzl(@NonNull View view) {
        try {
            int width = view.getWidth();
            int height = view.getHeight();
            if (width != 0) {
                if (height != 0) {
                    Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Config.RGB_565);
                    Canvas canvas = new Canvas(createBitmap);
                    view.layout(0, 0, width, height);
                    view.draw(canvas);
                    return createBitmap;
                }
            }
            zzb.zzcy("Width or height of view is zero");
            return null;
        } catch (Throwable e) {
            zzb.zzb("Fail to capture the webview", e);
            return null;
        }
    }

    private Bitmap zzm(@NonNull View view) {
        Bitmap bitmap = null;
        try {
            boolean isDrawingCacheEnabled = view.isDrawingCacheEnabled();
            view.setDrawingCacheEnabled(true);
            Bitmap drawingCache = view.getDrawingCache();
            if (drawingCache != null) {
                bitmap = Bitmap.createBitmap(drawingCache);
            }
            view.setDrawingCacheEnabled(isDrawingCacheEnabled);
            return bitmap;
        } catch (Throwable e) {
            zzb.zzb("Fail to capture the web view", e);
            return null;
        }
    }

    public void runOnUiThread(Runnable runnable) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            runnable.run();
        } else {
            zzclg.post(runnable);
        }
    }

    public DisplayMetrics zza(WindowManager windowManager) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics;
    }

    public PopupWindow zza(View view, int i, int i2, boolean z) {
        return new PopupWindow(view, i, i2, z);
    }

    public String zza(Context context, View view, AdSizeParcel adSizeParcel) {
        if (!((Boolean) zzdc.zzazv.get()).booleanValue()) {
            return null;
        }
        try {
            JSONObject jSONObject = new JSONObject();
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("width", adSizeParcel.width);
            jSONObject2.put("height", adSizeParcel.height);
            jSONObject.put("size", jSONObject2);
            jSONObject.put("activity", zzah(context));
            if (!adSizeParcel.zzauq) {
                JSONArray jSONArray = new JSONArray();
                while (view != null) {
                    ViewParent parent = view.getParent();
                    if (parent != null) {
                        int i = -1;
                        if (parent instanceof ViewGroup) {
                            i = ((ViewGroup) parent).indexOfChild(view);
                        }
                        JSONObject jSONObject3 = new JSONObject();
                        jSONObject3.put("type", parent.getClass().getName());
                        jSONObject3.put("index_of_child", i);
                        jSONArray.put(jSONObject3);
                    }
                    view = (parent == null || !(parent instanceof View)) ? null : (View) parent;
                }
                if (jSONArray.length() > 0) {
                    jSONObject.put("parents", jSONArray);
                }
            }
            return jSONObject.toString();
        } catch (Throwable e) {
            zzb.zzd("Fail to get view hierarchy json", e);
            return null;
        }
    }

    public java.lang.String zza(android.content.Context r3, com.google.android.gms.internal.zzas r4, java.lang.String r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        if (r4 != 0) goto L_0x0003;
    L_0x0002:
        return r5;
    L_0x0003:
        r0 = android.net.Uri.parse(r5);	 Catch:{ Exception -> 0x0016 }
        r1 = r4.zzd(r0);	 Catch:{ Exception -> 0x0016 }
        if (r1 == 0) goto L_0x0011;	 Catch:{ Exception -> 0x0016 }
    L_0x000d:
        r0 = r4.zzb(r0, r3);	 Catch:{ Exception -> 0x0016 }
    L_0x0011:
        r3 = r0.toString();	 Catch:{ Exception -> 0x0016 }
        return r3;
    L_0x0016:
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zza(android.content.Context, com.google.android.gms.internal.zzas, java.lang.String):java.lang.String");
    }

    public String zza(zzll com_google_android_gms_internal_zzll, String str) {
        return zza(com_google_android_gms_internal_zzll.getContext(), com_google_android_gms_internal_zzll.zzum(), str);
    }

    public String zza(InputStreamReader inputStreamReader) throws IOException {
        StringBuilder stringBuilder = new StringBuilder(8192);
        char[] cArr = new char[2048];
        while (true) {
            int read = inputStreamReader.read(cArr);
            if (read == -1) {
                return stringBuilder.toString();
            }
            stringBuilder.append(cArr, 0, read);
        }
    }

    JSONArray zza(Object[] objArr) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        for (Object zza : objArr) {
            zza(jSONArray, zza);
        }
        return jSONArray;
    }

    public void zza(Activity activity, OnGlobalLayoutListener onGlobalLayoutListener) {
        Window window = activity.getWindow();
        if (window != null && window.getDecorView() != null && window.getDecorView().getViewTreeObserver() != null) {
            window.getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(onGlobalLayoutListener);
        }
    }

    public void zza(Activity activity, OnScrollChangedListener onScrollChangedListener) {
        Window window = activity.getWindow();
        if (window != null && window.getDecorView() != null && window.getDecorView().getViewTreeObserver() != null) {
            window.getDecorView().getViewTreeObserver().addOnScrollChangedListener(onScrollChangedListener);
        }
    }

    public void zza(Context context, String str, WebSettings webSettings) {
        webSettings.setUserAgentString(zzh(context, str));
    }

    public void zza(final Context context, @Nullable final String str, String str2, Bundle bundle, boolean z) {
        if (z) {
            bundle.putString("device", zzu.zzfq().zzth());
            bundle.putString("eids", TextUtils.join(",", zzdc.zzjx()));
        }
        zzm.zziw().zza(context, str, str2, bundle, z, new com.google.android.gms.ads.internal.util.client.zza.zza(this) {
            final /* synthetic */ zzkl zzcll;

            public void zzcs(String str) {
                zzu.zzfq().zzc(context, str, str);
            }
        });
    }

    public void zza(Context context, String str, List<String> list) {
        for (String com_google_android_gms_internal_zzku : list) {
            Future future = (Future) new zzku(context, str, com_google_android_gms_internal_zzku).zzpz();
        }
    }

    public void zza(Context context, String str, boolean z, HttpURLConnection httpURLConnection) {
        zza(context, str, z, httpURLConnection, false);
    }

    public void zza(Context context, String str, boolean z, HttpURLConnection httpURLConnection, boolean z2) {
        httpURLConnection.setConnectTimeout(60000);
        httpURLConnection.setInstanceFollowRedirects(z);
        httpURLConnection.setReadTimeout(60000);
        httpURLConnection.setRequestProperty("User-Agent", zzh(context, str));
        httpURLConnection.setUseCaches(z2);
    }

    public void zza(final Context context, final List<String> list) {
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            if (!TextUtils.isEmpty(zzaph.zzeu(activity))) {
                if (list == null) {
                    zzkh.m83v("Cannot ping urls: empty list.");
                } else if (zzdq.zzo(context)) {
                    final zzdq com_google_android_gms_internal_zzdq = new zzdq();
                    com_google_android_gms_internal_zzdq.zza(new com.google.android.gms.internal.zzdq.zza(this) {
                        final /* synthetic */ zzkl zzcll;

                        public void zzkn() {
                            for (String str : list) {
                                String str2 = "Pinging url: ";
                                String valueOf = String.valueOf(str);
                                zzb.zzcx(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
                                com_google_android_gms_internal_zzdq.mayLaunchUrl(Uri.parse(str), null, null);
                            }
                            com_google_android_gms_internal_zzdq.zzd((Activity) context);
                        }

                        public void zzko() {
                        }
                    });
                    com_google_android_gms_internal_zzdq.zze(activity);
                } else {
                    zzkh.m83v("Cannot ping url because custom tabs is not supported");
                }
            }
        }
    }

    public void zza(List<String> list, String str) {
        for (String com_google_android_gms_internal_zzku : list) {
            Future future = (Future) new zzku(com_google_android_gms_internal_zzku, str).zzpz();
        }
    }

    public boolean zza(PackageManager packageManager, String str, String str2) {
        return packageManager.checkPermission(str2, str) == 0;
    }

    public boolean zza(View view, Context context) {
        Context applicationContext = context.getApplicationContext();
        KeyguardManager keyguardManager = null;
        PowerManager powerManager = applicationContext != null ? (PowerManager) applicationContext.getSystemService("power") : null;
        Object systemService = context.getSystemService("keyguard");
        if (systemService != null && (systemService instanceof KeyguardManager)) {
            keyguardManager = (KeyguardManager) systemService;
        }
        return zza(view, powerManager, keyguardManager);
    }

    public boolean zza(View view, PowerManager powerManager, KeyguardManager keyguardManager) {
        boolean z;
        boolean z2 = true;
        if (!zzu.zzfq().zztd()) {
            if (zza(keyguardManager)) {
                z = false;
                if (view.getVisibility() == 0 && view.isShown() && zza(powerManager) && r6) {
                    if (((Boolean) zzdc.zzbao.get()).booleanValue() && !view.getLocalVisibleRect(new Rect())) {
                        if (view.getGlobalVisibleRect(new Rect())) {
                            return true;
                        }
                    }
                    return z2;
                }
                z2 = false;
                return z2;
            }
        }
        z = true;
        if (view.getGlobalVisibleRect(new Rect())) {
            return true;
        }
        z2 = false;
        return z2;
    }

    public boolean zza(java.lang.ClassLoader r2, java.lang.Class<?> r3, java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = 0;
        r2 = java.lang.Class.forName(r4, r0, r2);	 Catch:{ Throwable -> 0x000a }
        r2 = r3.isAssignableFrom(r2);	 Catch:{ Throwable -> 0x000a }
        return r2;
    L_0x000a:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zza(java.lang.ClassLoader, java.lang.Class, java.lang.String):boolean");
    }

    public boolean zzac(Context context) {
        String format;
        Intent intent = new Intent();
        intent.setClassName(context, AdActivity.CLASS_NAME);
        ResolveInfo resolveActivity = context.getPackageManager().resolveActivity(intent, 65536);
        if (resolveActivity != null) {
            if (resolveActivity.activityInfo != null) {
                boolean z;
                String str = "com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".";
                if ((resolveActivity.activityInfo.configChanges & 16) == 0) {
                    zzb.zzcy(String.format(str, new Object[]{"keyboard"}));
                    z = false;
                } else {
                    z = true;
                }
                if ((resolveActivity.activityInfo.configChanges & 32) == 0) {
                    zzb.zzcy(String.format(str, new Object[]{"keyboardHidden"}));
                    z = false;
                }
                if ((resolveActivity.activityInfo.configChanges & 128) == 0) {
                    zzb.zzcy(String.format(str, new Object[]{"orientation"}));
                    z = false;
                }
                if ((resolveActivity.activityInfo.configChanges & 256) == 0) {
                    zzb.zzcy(String.format(str, new Object[]{"screenLayout"}));
                    z = false;
                }
                if ((resolveActivity.activityInfo.configChanges & 512) == 0) {
                    zzb.zzcy(String.format(str, new Object[]{"uiMode"}));
                    z = false;
                }
                if ((resolveActivity.activityInfo.configChanges & 1024) == 0) {
                    zzb.zzcy(String.format(str, new Object[]{"screenSize"}));
                    z = false;
                }
                if ((resolveActivity.activityInfo.configChanges & 2048) != 0) {
                    return z;
                }
                format = String.format(str, new Object[]{"smallestScreenSize"});
                zzb.zzcy(format);
                return false;
            }
        }
        format = "Could not find com.google.android.gms.ads.AdActivity, please make sure it is declared in AndroidManifest.xml.";
        zzb.zzcy(format);
        return false;
    }

    public boolean zzad(Context context) {
        if (this.zzcli) {
            return false;
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.USER_PRESENT");
        intentFilter.addAction("android.intent.action.SCREEN_OFF");
        context.getApplicationContext().registerReceiver(new zza(), intentFilter);
        this.zzcli = true;
        return true;
    }

    protected String zzae(Context context) {
        return new WebView(context).getSettings().getUserAgentString();
    }

    public Builder zzaf(Context context) {
        return new Builder(context);
    }

    public zzcu zzag(Context context) {
        return new zzcu(context);
    }

    public java.lang.String zzah(android.content.Context r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r0 = 0;
        r1 = "activity";	 Catch:{ Exception -> 0x002d }
        r3 = r3.getSystemService(r1);	 Catch:{ Exception -> 0x002d }
        r3 = (android.app.ActivityManager) r3;	 Catch:{ Exception -> 0x002d }
        if (r3 != 0) goto L_0x000c;	 Catch:{ Exception -> 0x002d }
    L_0x000b:
        return r0;	 Catch:{ Exception -> 0x002d }
    L_0x000c:
        r1 = 1;	 Catch:{ Exception -> 0x002d }
        r3 = r3.getRunningTasks(r1);	 Catch:{ Exception -> 0x002d }
        if (r3 == 0) goto L_0x002d;	 Catch:{ Exception -> 0x002d }
    L_0x0013:
        r1 = r3.isEmpty();	 Catch:{ Exception -> 0x002d }
        if (r1 != 0) goto L_0x002d;	 Catch:{ Exception -> 0x002d }
    L_0x0019:
        r1 = 0;	 Catch:{ Exception -> 0x002d }
        r3 = r3.get(r1);	 Catch:{ Exception -> 0x002d }
        r3 = (android.app.ActivityManager.RunningTaskInfo) r3;	 Catch:{ Exception -> 0x002d }
        if (r3 == 0) goto L_0x002d;	 Catch:{ Exception -> 0x002d }
    L_0x0022:
        r1 = r3.topActivity;	 Catch:{ Exception -> 0x002d }
        if (r1 == 0) goto L_0x002d;	 Catch:{ Exception -> 0x002d }
    L_0x0026:
        r3 = r3.topActivity;	 Catch:{ Exception -> 0x002d }
        r3 = r3.getClassName();	 Catch:{ Exception -> 0x002d }
        return r3;
    L_0x002d:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zzah(android.content.Context):java.lang.String");
    }

    public boolean zzai(android.content.Context r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r6 = this;
        r0 = 0;
        r1 = "activity";	 Catch:{ Throwable -> 0x0049 }
        r1 = r7.getSystemService(r1);	 Catch:{ Throwable -> 0x0049 }
        r1 = (android.app.ActivityManager) r1;	 Catch:{ Throwable -> 0x0049 }
        r2 = "keyguard";	 Catch:{ Throwable -> 0x0049 }
        r2 = r7.getSystemService(r2);	 Catch:{ Throwable -> 0x0049 }
        r2 = (android.app.KeyguardManager) r2;	 Catch:{ Throwable -> 0x0049 }
        if (r1 == 0) goto L_0x0049;	 Catch:{ Throwable -> 0x0049 }
    L_0x0013:
        if (r2 != 0) goto L_0x0016;	 Catch:{ Throwable -> 0x0049 }
    L_0x0015:
        return r0;	 Catch:{ Throwable -> 0x0049 }
    L_0x0016:
        r1 = r1.getRunningAppProcesses();	 Catch:{ Throwable -> 0x0049 }
        if (r1 != 0) goto L_0x001d;	 Catch:{ Throwable -> 0x0049 }
    L_0x001c:
        return r0;	 Catch:{ Throwable -> 0x0049 }
    L_0x001d:
        r1 = r1.iterator();	 Catch:{ Throwable -> 0x0049 }
    L_0x0021:
        r3 = r1.hasNext();	 Catch:{ Throwable -> 0x0049 }
        if (r3 == 0) goto L_0x0049;	 Catch:{ Throwable -> 0x0049 }
    L_0x0027:
        r3 = r1.next();	 Catch:{ Throwable -> 0x0049 }
        r3 = (android.app.ActivityManager.RunningAppProcessInfo) r3;	 Catch:{ Throwable -> 0x0049 }
        r4 = android.os.Process.myPid();	 Catch:{ Throwable -> 0x0049 }
        r5 = r3.pid;	 Catch:{ Throwable -> 0x0049 }
        if (r4 != r5) goto L_0x0021;	 Catch:{ Throwable -> 0x0049 }
    L_0x0035:
        r1 = r3.importance;	 Catch:{ Throwable -> 0x0049 }
        r3 = 100;	 Catch:{ Throwable -> 0x0049 }
        if (r1 != r3) goto L_0x0049;	 Catch:{ Throwable -> 0x0049 }
    L_0x003b:
        r1 = r2.inKeyguardRestrictedInputMode();	 Catch:{ Throwable -> 0x0049 }
        if (r1 != 0) goto L_0x0049;	 Catch:{ Throwable -> 0x0049 }
    L_0x0041:
        r7 = r6.zzj(r7);	 Catch:{ Throwable -> 0x0049 }
        if (r7 == 0) goto L_0x0049;
    L_0x0047:
        r7 = 1;
        return r7;
    L_0x0049:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zzai(android.content.Context):boolean");
    }

    public Bitmap zzaj(Context context) {
        if (!(context instanceof Activity)) {
            return null;
        }
        try {
            Bitmap zzm;
            if (((Boolean) zzdc.zzbbz.get()).booleanValue()) {
                Window window = ((Activity) context).getWindow();
                zzm = window != null ? zzm(window.getDecorView().getRootView()) : null;
            } else {
                zzm = zzl(((Activity) context).getWindow().getDecorView());
            }
            return zzm;
        } catch (Throwable e) {
            zzb.zzb("Fail to capture screen shot", e);
            return null;
        }
    }

    public AudioManager zzak(Context context) {
        return (AudioManager) context.getSystemService("audio");
    }

    public float zzal(Context context) {
        AudioManager zzak = zzak(context);
        if (zzak == null) {
            return 0.0f;
        }
        int streamMaxVolume = zzak.getStreamMaxVolume(3);
        return streamMaxVolume == 0 ? 0.0f : ((float) zzak.getStreamVolume(3)) / ((float) streamMaxVolume);
    }

    public int zzam(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        return applicationInfo == null ? 0 : applicationInfo.targetSdkVersion;
    }

    public JSONObject zzam(Map<String, ?> map) throws JSONException {
        try {
            JSONObject jSONObject = new JSONObject();
            for (String str : map.keySet()) {
                zza(jSONObject, str, map.get(str));
            }
            return jSONObject;
        } catch (ClassCastException e) {
            String str2 = "Could not convert map to JSON: ";
            String valueOf = String.valueOf(e.getMessage());
            throw new JSONException(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        }
    }

    public boolean zzan(android.content.Context r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r2 = r2.getClassLoader();	 Catch:{ ClassNotFoundException -> 0x000f }
        r0 = com.google.android.gms.ads.internal.ClientApi.class;	 Catch:{ ClassNotFoundException -> 0x000f }
        r0 = r0.getName();	 Catch:{ ClassNotFoundException -> 0x000f }
        r2.loadClass(r0);	 Catch:{ ClassNotFoundException -> 0x000f }
        r2 = 0;
        return r2;
    L_0x000f:
        r2 = 1;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zzan(android.content.Context):boolean");
    }

    public void zzb(Activity activity, OnScrollChangedListener onScrollChangedListener) {
        Window window = activity.getWindow();
        if (window != null && window.getDecorView() != null && window.getDecorView().getViewTreeObserver() != null) {
            window.getDecorView().getViewTreeObserver().removeOnScrollChangedListener(onScrollChangedListener);
        }
    }

    public void zzb(android.content.Context r2, android.content.Intent r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r2.startActivity(r3);	 Catch:{ Throwable -> 0x0004 }
        return;
    L_0x0004:
        r0 = 268435456; // 0x10000000 float:2.5243549E-29 double:1.32624737E-315;
        r3.addFlags(r0);
        r2.startActivity(r3);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zzb(android.content.Context, android.content.Intent):void");
    }

    public void zzb(Context context, String str, String str2, Bundle bundle, boolean z) {
        if (((Boolean) zzdc.zzbas.get()).booleanValue()) {
            zza(context, str, str2, bundle, z);
        }
    }

    public zzfw zzc(Context context, VersionInfoParcel versionInfoParcel) {
        zzfw com_google_android_gms_internal_zzfw;
        synchronized (this.zzail) {
            if (this.zzcee == null) {
                if (context.getApplicationContext() != null) {
                    context = context.getApplicationContext();
                }
                this.zzcee = new zzfw(context, versionInfoParcel, (String) zzdc.zzaxw.get());
            }
            com_google_android_gms_internal_zzfw = this.zzcee;
        }
        return com_google_android_gms_internal_zzfw;
    }

    public void zzc(Context context, String str, String str2) {
        List arrayList = new ArrayList();
        arrayList.add(str2);
        zza(context, str, arrayList);
    }

    public String zzcp(String str) {
        return Uri.parse(str).buildUpon().query(null).build().toString();
    }

    public int zzcq(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            str = String.valueOf(e);
            StringBuilder stringBuilder = new StringBuilder(22 + String.valueOf(str).length());
            stringBuilder.append("Could not parse value:");
            stringBuilder.append(str);
            zzb.zzcy(stringBuilder.toString());
            return 0;
        }
    }

    public boolean zzcr(String str) {
        return TextUtils.isEmpty(str) ? false : str.matches("([^\\s]+(\\.(?i)(jpg|png|gif|bmp|webp))$)");
    }

    public float zzey() {
        zzo zzex = zzu.zzgg().zzex();
        return (zzex == null || !zzex.zzez()) ? 1.0f : zzex.zzey();
    }

    public Map<String, String> zzf(Uri uri) {
        if (uri == null) {
            return null;
        }
        Map hashMap = new HashMap();
        for (String str : zzu.zzfs().zzg(uri)) {
            hashMap.put(str, uri.getQueryParameter(str));
        }
        return hashMap;
    }

    public boolean zzfa() {
        zzo zzex = zzu.zzgg().zzex();
        return zzex != null ? zzex.zzfa() : false;
    }

    public java.lang.String zzh(final android.content.Context r5, java.lang.String r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = r4.zzail;
        monitor-enter(r0);
        r1 = r4.zzbjj;	 Catch:{ all -> 0x00a7 }
        if (r1 == 0) goto L_0x000b;	 Catch:{ all -> 0x00a7 }
    L_0x0007:
        r5 = r4.zzbjj;	 Catch:{ all -> 0x00a7 }
        monitor-exit(r0);	 Catch:{ all -> 0x00a7 }
        return r5;
    L_0x000b:
        r1 = com.google.android.gms.ads.internal.zzu.zzfs();	 Catch:{ Exception -> 0x0015 }
        r1 = r1.getDefaultUserAgent(r5);	 Catch:{ Exception -> 0x0015 }
        r4.zzbjj = r1;	 Catch:{ Exception -> 0x0015 }
    L_0x0015:
        r1 = r4.zzbjj;	 Catch:{ all -> 0x00a7 }
        r1 = android.text.TextUtils.isEmpty(r1);	 Catch:{ all -> 0x00a7 }
        if (r1 == 0) goto L_0x006e;	 Catch:{ all -> 0x00a7 }
    L_0x001d:
        r1 = com.google.android.gms.ads.internal.client.zzm.zziw();	 Catch:{ all -> 0x00a7 }
        r1 = r1.zzty();	 Catch:{ all -> 0x00a7 }
        if (r1 != 0) goto L_0x0061;	 Catch:{ all -> 0x00a7 }
    L_0x0027:
        r1 = 0;	 Catch:{ all -> 0x00a7 }
        r4.zzbjj = r1;	 Catch:{ all -> 0x00a7 }
        r1 = zzclg;	 Catch:{ all -> 0x00a7 }
        r2 = new com.google.android.gms.internal.zzkl$2;	 Catch:{ all -> 0x00a7 }
        r2.<init>(r4, r5);	 Catch:{ all -> 0x00a7 }
        r1.post(r2);	 Catch:{ all -> 0x00a7 }
    L_0x0034:
        r5 = r4.zzbjj;	 Catch:{ all -> 0x00a7 }
        if (r5 != 0) goto L_0x006e;
    L_0x0038:
        r5 = r4.zzail;	 Catch:{ InterruptedException -> 0x003e }
        r5.wait();	 Catch:{ InterruptedException -> 0x003e }
        goto L_0x0034;
    L_0x003e:
        r5 = r4.zzte();	 Catch:{ all -> 0x00a7 }
        r4.zzbjj = r5;	 Catch:{ all -> 0x00a7 }
        r5 = "Interrupted, use default user agent: ";	 Catch:{ all -> 0x00a7 }
        r1 = r4.zzbjj;	 Catch:{ all -> 0x00a7 }
        r1 = java.lang.String.valueOf(r1);	 Catch:{ all -> 0x00a7 }
        r2 = r1.length();	 Catch:{ all -> 0x00a7 }
        if (r2 == 0) goto L_0x0057;	 Catch:{ all -> 0x00a7 }
    L_0x0052:
        r5 = r5.concat(r1);	 Catch:{ all -> 0x00a7 }
        goto L_0x005d;	 Catch:{ all -> 0x00a7 }
    L_0x0057:
        r1 = new java.lang.String;	 Catch:{ all -> 0x00a7 }
        r1.<init>(r5);	 Catch:{ all -> 0x00a7 }
        r5 = r1;	 Catch:{ all -> 0x00a7 }
    L_0x005d:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r5);	 Catch:{ all -> 0x00a7 }
        goto L_0x0034;
    L_0x0061:
        r5 = r4.zzae(r5);	 Catch:{ Exception -> 0x0068 }
        r4.zzbjj = r5;	 Catch:{ Exception -> 0x0068 }
        goto L_0x006e;
    L_0x0068:
        r5 = r4.zzte();	 Catch:{ all -> 0x00a7 }
        r4.zzbjj = r5;	 Catch:{ all -> 0x00a7 }
    L_0x006e:
        r5 = r4.zzbjj;	 Catch:{ all -> 0x00a7 }
        r5 = java.lang.String.valueOf(r5);	 Catch:{ all -> 0x00a7 }
        r1 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00a7 }
        r2 = 11;	 Catch:{ all -> 0x00a7 }
        r3 = java.lang.String.valueOf(r5);	 Catch:{ all -> 0x00a7 }
        r3 = r3.length();	 Catch:{ all -> 0x00a7 }
        r2 = r2 + r3;	 Catch:{ all -> 0x00a7 }
        r3 = java.lang.String.valueOf(r6);	 Catch:{ all -> 0x00a7 }
        r3 = r3.length();	 Catch:{ all -> 0x00a7 }
        r2 = r2 + r3;	 Catch:{ all -> 0x00a7 }
        r1.<init>(r2);	 Catch:{ all -> 0x00a7 }
        r1.append(r5);	 Catch:{ all -> 0x00a7 }
        r5 = " (Mobile; ";	 Catch:{ all -> 0x00a7 }
        r1.append(r5);	 Catch:{ all -> 0x00a7 }
        r1.append(r6);	 Catch:{ all -> 0x00a7 }
        r5 = ")";	 Catch:{ all -> 0x00a7 }
        r1.append(r5);	 Catch:{ all -> 0x00a7 }
        r5 = r1.toString();	 Catch:{ all -> 0x00a7 }
        r4.zzbjj = r5;	 Catch:{ all -> 0x00a7 }
        r5 = r4.zzbjj;	 Catch:{ all -> 0x00a7 }
        monitor-exit(r0);	 Catch:{ all -> 0x00a7 }
        return r5;	 Catch:{ all -> 0x00a7 }
    L_0x00a7:
        r5 = move-exception;	 Catch:{ all -> 0x00a7 }
        monitor-exit(r0);	 Catch:{ all -> 0x00a7 }
        throw r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zzh(android.content.Context, java.lang.String):java.lang.String");
    }

    public int[] zzh(Activity activity) {
        Window window = activity.getWindow();
        if (window == null || window.findViewById(16908290) == null) {
            return zzti();
        }
        return new int[]{window.findViewById(16908290).getWidth(), window.findViewById(16908290).getHeight()};
    }

    public int[] zzi(Activity activity) {
        int[] zzh = zzh(activity);
        return new int[]{zzm.zziw().zzb((Context) activity, zzh[0]), zzm.zziw().zzb((Context) activity, zzh[1])};
    }

    public int[] zzj(Activity activity) {
        Window window = activity.getWindow();
        if (window == null || window.findViewById(16908290) == null) {
            return zzti();
        }
        return new int[]{window.findViewById(16908290).getTop(), window.findViewById(16908290).getBottom()};
    }

    public Bitmap zzk(View view) {
        view.setDrawingCacheEnabled(true);
        Bitmap createBitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        return createBitmap;
    }

    public int[] zzk(Activity activity) {
        int[] zzj = zzj(activity);
        return new int[]{zzm.zziw().zzb((Context) activity, zzj[0]), zzm.zziw().zzb((Context) activity, zzj[1])};
    }

    public int zzn(@Nullable View view) {
        if (view == null) {
            return -1;
        }
        ViewParent parent = view.getParent();
        while (parent != null && !(parent instanceof AdapterView)) {
            parent = parent.getParent();
        }
        return parent == null ? -1 : ((AdapterView) parent).getPositionForView(view);
    }

    public boolean zztd() {
        return this.zzclh;
    }

    String zzte() {
        StringBuffer stringBuffer = new StringBuffer(256);
        stringBuffer.append("Mozilla/5.0 (Linux; U; Android");
        if (VERSION.RELEASE != null) {
            stringBuffer.append(" ");
            stringBuffer.append(VERSION.RELEASE);
        }
        stringBuffer.append("; ");
        stringBuffer.append(Locale.getDefault());
        if (Build.DEVICE != null) {
            stringBuffer.append("; ");
            stringBuffer.append(Build.DEVICE);
            if (Build.DISPLAY != null) {
                stringBuffer.append(" Build/");
                stringBuffer.append(Build.DISPLAY);
            }
        }
        stringBuffer.append(") AppleWebKit/533 Version/4.0 Safari/533");
        return stringBuffer.toString();
    }

    public String zztf() {
        return UUID.randomUUID().toString();
    }

    public java.lang.String zztg() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r9 = this;
        r0 = java.util.UUID.randomUUID();
        r1 = r0.getLeastSignificantBits();
        r1 = java.math.BigInteger.valueOf(r1);
        r1 = r1.toByteArray();
        r2 = r0.getMostSignificantBits();
        r0 = java.math.BigInteger.valueOf(r2);
        r0 = r0.toByteArray();
        r2 = new java.math.BigInteger;
        r3 = 1;
        r2.<init>(r3, r1);
        r2 = r2.toString();
        r4 = 0;
        r5 = r2;
        r2 = r4;
    L_0x0029:
        r6 = 2;
        if (r2 >= r6) goto L_0x0050;
    L_0x002c:
        r6 = "MD5";	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r6 = java.security.MessageDigest.getInstance(r6);	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r6.update(r1);	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r6.update(r0);	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r7 = 8;	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r8 = new byte[r7];	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r6 = r6.digest();	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        java.lang.System.arraycopy(r6, r4, r8, r4, r7);	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r6 = new java.math.BigInteger;	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r6.<init>(r3, r8);	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r6 = r6.toString();	 Catch:{ NoSuchAlgorithmException -> 0x004d }
        r5 = r6;
    L_0x004d:
        r2 = r2 + 1;
        goto L_0x0029;
    L_0x0050:
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkl.zztg():java.lang.String");
    }

    public String zzth() {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        if (str2.startsWith(str)) {
            return str2;
        }
        StringBuilder stringBuilder = new StringBuilder((1 + String.valueOf(str).length()) + String.valueOf(str2).length());
        stringBuilder.append(str);
        stringBuilder.append(" ");
        stringBuilder.append(str2);
        return stringBuilder.toString();
    }

    protected int[] zzti() {
        return new int[]{0, 0};
    }

    public Bundle zztj() {
        Bundle bundle = new Bundle();
        try {
            Parcelable memoryInfo = new MemoryInfo();
            Debug.getMemoryInfo(memoryInfo);
            bundle.putParcelable("debug_memory_info", memoryInfo);
            Runtime runtime = Runtime.getRuntime();
            bundle.putLong("runtime_free_memory", runtime.freeMemory());
            bundle.putLong("runtime_max_memory", runtime.maxMemory());
            bundle.putLong("runtime_total_memory", runtime.totalMemory());
            return bundle;
        } catch (Throwable e) {
            zzb.zzd("Unable to gather memory stats", e);
            return bundle;
        }
    }
}
