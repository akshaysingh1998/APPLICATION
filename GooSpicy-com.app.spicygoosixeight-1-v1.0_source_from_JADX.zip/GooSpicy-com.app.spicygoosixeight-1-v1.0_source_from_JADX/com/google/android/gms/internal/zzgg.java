package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import com.google.android.gms.internal.zzgp.zza;

@zzir
public final class zzgg extends zza {
    private final Object zzail = new Object();
    private zzgi.zza zzboe;
    private zzgf zzbof;

    public void onAdClicked() {
        synchronized (this.zzail) {
            if (this.zzbof != null) {
                this.zzbof.zzea();
            }
        }
    }

    public void onAdClosed() {
        synchronized (this.zzail) {
            if (this.zzbof != null) {
                this.zzbof.zzeb();
            }
        }
    }

    public void onAdFailedToLoad(int i) {
        synchronized (this.zzail) {
            if (this.zzboe != null) {
                this.zzboe.zzy(i == 3 ? 1 : 2);
                this.zzboe = null;
            }
        }
    }

    public void onAdImpression() {
        synchronized (this.zzail) {
            if (this.zzbof != null) {
                this.zzbof.zzef();
            }
        }
    }

    public void onAdLeftApplication() {
        synchronized (this.zzail) {
            if (this.zzbof != null) {
                this.zzbof.zzec();
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onAdLoaded() {
        /*
        r3 = this;
        r0 = r3.zzail;
        monitor-enter(r0);
        r1 = r3.zzboe;	 Catch:{ all -> 0x001d }
        if (r1 == 0) goto L_0x0012;
    L_0x0007:
        r1 = r3.zzboe;	 Catch:{ all -> 0x001d }
        r2 = 0;
        r1.zzy(r2);	 Catch:{ all -> 0x001d }
        r1 = 0;
        r3.zzboe = r1;	 Catch:{ all -> 0x001d }
        monitor-exit(r0);	 Catch:{ all -> 0x001d }
        return;
    L_0x0012:
        r1 = r3.zzbof;	 Catch:{ all -> 0x001d }
        if (r1 == 0) goto L_0x001b;
    L_0x0016:
        r1 = r3.zzbof;	 Catch:{ all -> 0x001d }
        r1.zzee();	 Catch:{ all -> 0x001d }
    L_0x001b:
        monitor-exit(r0);	 Catch:{ all -> 0x001d }
        return;
    L_0x001d:
        r1 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x001d }
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgg.onAdLoaded():void");
    }

    public void onAdOpened() {
        synchronized (this.zzail) {
            if (this.zzbof != null) {
                this.zzbof.zzed();
            }
        }
    }

    public void zza(@Nullable zzgf com_google_android_gms_internal_zzgf) {
        synchronized (this.zzail) {
            this.zzbof = com_google_android_gms_internal_zzgf;
        }
    }

    public void zza(zzgi.zza com_google_android_gms_internal_zzgi_zza) {
        synchronized (this.zzail) {
            this.zzboe = com_google_android_gms_internal_zzgi_zza;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void zza(com.google.android.gms.internal.zzgq r4) {
        /*
        r3 = this;
        r0 = r3.zzail;
        monitor-enter(r0);
        r1 = r3.zzboe;	 Catch:{ all -> 0x001d }
        if (r1 == 0) goto L_0x0012;
    L_0x0007:
        r1 = r3.zzboe;	 Catch:{ all -> 0x001d }
        r2 = 0;
        r1.zza(r2, r4);	 Catch:{ all -> 0x001d }
        r4 = 0;
        r3.zzboe = r4;	 Catch:{ all -> 0x001d }
        monitor-exit(r0);	 Catch:{ all -> 0x001d }
        return;
    L_0x0012:
        r4 = r3.zzbof;	 Catch:{ all -> 0x001d }
        if (r4 == 0) goto L_0x001b;
    L_0x0016:
        r4 = r3.zzbof;	 Catch:{ all -> 0x001d }
        r4.zzee();	 Catch:{ all -> 0x001d }
    L_0x001b:
        monitor-exit(r0);	 Catch:{ all -> 0x001d }
        return;
    L_0x001d:
        r4 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x001d }
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgg.zza(com.google.android.gms.internal.zzgq):void");
    }
}
