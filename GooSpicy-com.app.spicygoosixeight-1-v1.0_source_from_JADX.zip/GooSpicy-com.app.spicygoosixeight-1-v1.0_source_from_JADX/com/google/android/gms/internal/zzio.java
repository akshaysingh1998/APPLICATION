package com.google.android.gms.internal;

import android.os.Bundle;
import com.google.android.gms.ads.internal.formats.zzc;
import com.google.android.gms.ads.internal.formats.zze;
import com.google.android.gms.ads.internal.formats.zzh;
import com.google.android.gms.internal.zzim.zza;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public class zzio implements zza<zze> {
    private final boolean zzcae;
    private final boolean zzcaf;

    public zzio(boolean z, boolean z2) {
        this.zzcae = z;
        this.zzcaf = z2;
    }

    public /* synthetic */ zzh.zza zza(zzim com_google_android_gms_internal_zzim, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        return zzc(com_google_android_gms_internal_zzim, jSONObject);
    }

    public zze zzc(zzim com_google_android_gms_internal_zzim, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        List<zzlc> zza = com_google_android_gms_internal_zzim.zza(jSONObject, "images", true, this.zzcae, this.zzcaf);
        Future zza2 = com_google_android_gms_internal_zzim.zza(jSONObject, "secondary_image", false, this.zzcae);
        Future zzg = com_google_android_gms_internal_zzim.zzg(jSONObject);
        List arrayList = new ArrayList();
        for (zzlc com_google_android_gms_internal_zzlc : zza) {
            arrayList.add((zzc) com_google_android_gms_internal_zzlc.get());
        }
        return new zze(jSONObject.getString("headline"), arrayList, jSONObject.getString("body"), (zzdu) zza2.get(), jSONObject.getString("call_to_action"), jSONObject.getString("advertiser"), (com.google.android.gms.ads.internal.formats.zza) zzg.get(), new Bundle());
    }
}
