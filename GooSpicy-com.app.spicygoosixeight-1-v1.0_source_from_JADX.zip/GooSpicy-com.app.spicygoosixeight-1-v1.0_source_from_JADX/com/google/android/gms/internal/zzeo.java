package com.google.android.gms.internal;

import android.support.annotation.Nullable;

public interface zzeo {
    void onAppEvent(String str, @Nullable String str2);
}
