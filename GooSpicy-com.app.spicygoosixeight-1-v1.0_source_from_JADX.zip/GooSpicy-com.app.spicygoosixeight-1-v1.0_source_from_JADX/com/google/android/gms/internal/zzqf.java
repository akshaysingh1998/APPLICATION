package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.zzc;
import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.internal.zzg;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class zzqf implements zzqm {
    private final Context mContext;
    final com.google.android.gms.common.api.Api.zza<? extends zzvx, zzvy> rY;
    final zzqd sX;
    final zzg tD;
    final Map<Api<?>, Integer> tE;
    final Map<zzc<?>, zze> tY;
    private final Lock th;
    private final com.google.android.gms.common.zzc tp;
    private final Condition ul;
    private final zzb um;
    final Map<zzc<?>, ConnectionResult> un = new HashMap();
    private volatile zzqe uo;
    private ConnectionResult up = null;
    int uq;
    final com.google.android.gms.internal.zzqm.zza ur;

    static abstract class zza {
        private final zzqe us;

        protected zza(zzqe com_google_android_gms_internal_zzqe) {
            this.us = com_google_android_gms_internal_zzqe;
        }

        protected abstract void zzapi();

        public final void zzd(zzqf com_google_android_gms_internal_zzqf) {
            com_google_android_gms_internal_zzqf.th.lock();
            try {
                if (com_google_android_gms_internal_zzqf.uo == this.us) {
                    zzapi();
                    com_google_android_gms_internal_zzqf.th.unlock();
                }
            } finally {
                com_google_android_gms_internal_zzqf.th.unlock();
            }
        }
    }

    final class zzb extends Handler {
        final /* synthetic */ zzqf ut;

        zzb(zzqf com_google_android_gms_internal_zzqf, Looper looper) {
            this.ut = com_google_android_gms_internal_zzqf;
            super(looper);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    ((zza) message.obj).zzd(this.ut);
                    return;
                case 2:
                    throw ((RuntimeException) message.obj);
                default:
                    int i = message.what;
                    StringBuilder stringBuilder = new StringBuilder(31);
                    stringBuilder.append("Unknown message id: ");
                    stringBuilder.append(i);
                    Log.w("GACStateManager", stringBuilder.toString());
                    return;
            }
        }
    }

    public zzqf(Context context, zzqd com_google_android_gms_internal_zzqd, Lock lock, Looper looper, com.google.android.gms.common.zzc com_google_android_gms_common_zzc, Map<zzc<?>, zze> map, zzg com_google_android_gms_common_internal_zzg, Map<Api<?>, Integer> map2, com.google.android.gms.common.api.Api.zza<? extends zzvx, zzvy> com_google_android_gms_common_api_Api_zza__extends_com_google_android_gms_internal_zzvx__com_google_android_gms_internal_zzvy, ArrayList<zzpu> arrayList, com.google.android.gms.internal.zzqm.zza com_google_android_gms_internal_zzqm_zza) {
        this.mContext = context;
        this.th = lock;
        this.tp = com_google_android_gms_common_zzc;
        this.tY = map;
        this.tD = com_google_android_gms_common_internal_zzg;
        this.tE = map2;
        this.rY = com_google_android_gms_common_api_Api_zza__extends_com_google_android_gms_internal_zzvx__com_google_android_gms_internal_zzvy;
        this.sX = com_google_android_gms_internal_zzqd;
        this.ur = com_google_android_gms_internal_zzqm_zza;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((zzpu) it.next()).zza(this);
        }
        this.um = new zzb(this, looper);
        this.ul = lock.newCondition();
        this.uo = new zzqc(this);
    }

    public com.google.android.gms.common.ConnectionResult blockingConnect() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r3.connect();
    L_0x0003:
        r0 = r3.isConnecting();
        r1 = 0;
        if (r0 == 0) goto L_0x001f;
    L_0x000a:
        r0 = r3.ul;	 Catch:{ InterruptedException -> 0x0010 }
        r0.await();	 Catch:{ InterruptedException -> 0x0010 }
        goto L_0x0003;
    L_0x0010:
        r0 = java.lang.Thread.currentThread();
        r0.interrupt();
        r0 = new com.google.android.gms.common.ConnectionResult;
        r2 = 15;
        r0.<init>(r2, r1);
        return r0;
    L_0x001f:
        r0 = r3.isConnected();
        if (r0 == 0) goto L_0x0028;
    L_0x0025:
        r0 = com.google.android.gms.common.ConnectionResult.qR;
        return r0;
    L_0x0028:
        r0 = r3.up;
        if (r0 == 0) goto L_0x002f;
    L_0x002c:
        r0 = r3.up;
        return r0;
    L_0x002f:
        r0 = new com.google.android.gms.common.ConnectionResult;
        r2 = 13;
        r0.<init>(r2, r1);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzqf.blockingConnect():com.google.android.gms.common.ConnectionResult");
    }

    public com.google.android.gms.common.ConnectionResult blockingConnect(long r4, java.util.concurrent.TimeUnit r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r3.connect();
        r4 = r6.toNanos(r4);
    L_0x0007:
        r6 = r3.isConnecting();
        r0 = 0;
        if (r6 == 0) goto L_0x0035;
    L_0x000e:
        r1 = 0;
        r6 = (r4 > r1 ? 1 : (r4 == r1 ? 0 : -1));
        if (r6 > 0) goto L_0x001f;
    L_0x0014:
        r3.disconnect();	 Catch:{ InterruptedException -> 0x0026 }
        r4 = new com.google.android.gms.common.ConnectionResult;	 Catch:{ InterruptedException -> 0x0026 }
        r5 = 14;	 Catch:{ InterruptedException -> 0x0026 }
        r4.<init>(r5, r0);	 Catch:{ InterruptedException -> 0x0026 }
        return r4;	 Catch:{ InterruptedException -> 0x0026 }
    L_0x001f:
        r6 = r3.ul;	 Catch:{ InterruptedException -> 0x0026 }
        r4 = r6.awaitNanos(r4);	 Catch:{ InterruptedException -> 0x0026 }
        goto L_0x0007;
    L_0x0026:
        r4 = java.lang.Thread.currentThread();
        r4.interrupt();
        r4 = new com.google.android.gms.common.ConnectionResult;
        r5 = 15;
        r4.<init>(r5, r0);
        return r4;
    L_0x0035:
        r4 = r3.isConnected();
        if (r4 == 0) goto L_0x003e;
    L_0x003b:
        r4 = com.google.android.gms.common.ConnectionResult.qR;
        return r4;
    L_0x003e:
        r4 = r3.up;
        if (r4 == 0) goto L_0x0045;
    L_0x0042:
        r4 = r3.up;
        return r4;
    L_0x0045:
        r4 = new com.google.android.gms.common.ConnectionResult;
        r5 = 13;
        r4.<init>(r5, r0);
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzqf.blockingConnect(long, java.util.concurrent.TimeUnit):com.google.android.gms.common.ConnectionResult");
    }

    public void connect() {
        this.uo.connect();
    }

    public void disconnect() {
        if (this.uo.disconnect()) {
            this.un.clear();
        }
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String concat = String.valueOf(str).concat("  ");
        printWriter.append(str).append("mState=").println(this.uo);
        for (Api api : this.tE.keySet()) {
            printWriter.append(str).append(api.getName()).println(":");
            ((zze) this.tY.get(api.zzanp())).dump(concat, fileDescriptor, printWriter, strArr);
        }
    }

    @Nullable
    public ConnectionResult getConnectionResult(@NonNull Api<?> api) {
        zzc zzanp = api.zzanp();
        if (this.tY.containsKey(zzanp)) {
            if (((zze) this.tY.get(zzanp)).isConnected()) {
                return ConnectionResult.qR;
            }
            if (this.un.containsKey(zzanp)) {
                return (ConnectionResult) this.un.get(zzanp);
            }
        }
        return null;
    }

    public boolean isConnected() {
        return this.uo instanceof zzqa;
    }

    public boolean isConnecting() {
        return this.uo instanceof zzqb;
    }

    public void onConnected(@Nullable Bundle bundle) {
        this.th.lock();
        try {
            this.uo.onConnected(bundle);
        } finally {
            this.th.unlock();
        }
    }

    public void onConnectionSuspended(int i) {
        this.th.lock();
        try {
            this.uo.onConnectionSuspended(i);
        } finally {
            this.th.unlock();
        }
    }

    public void zza(@NonNull ConnectionResult connectionResult, @NonNull Api<?> api, int i) {
        this.th.lock();
        try {
            this.uo.zza(connectionResult, api, i);
        } finally {
            this.th.unlock();
        }
    }

    void zza(zza com_google_android_gms_internal_zzqf_zza) {
        this.um.sendMessage(this.um.obtainMessage(1, com_google_android_gms_internal_zzqf_zza));
    }

    void zza(RuntimeException runtimeException) {
        this.um.sendMessage(this.um.obtainMessage(2, runtimeException));
    }

    public boolean zza(zzqy com_google_android_gms_internal_zzqy) {
        return false;
    }

    public void zzaoc() {
    }

    public void zzaoy() {
        if (isConnected()) {
            ((zzqa) this.uo).zzaph();
        }
    }

    void zzapw() {
        this.th.lock();
        try {
            this.uo = new zzqb(this, this.tD, this.tE, this.tp, this.rY, this.th, this.mContext);
            this.uo.begin();
            this.ul.signalAll();
        } finally {
            this.th.unlock();
        }
    }

    void zzapx() {
        this.th.lock();
        try {
            this.sX.zzapt();
            this.uo = new zzqa(this);
            this.uo.begin();
            this.ul.signalAll();
        } finally {
            this.th.unlock();
        }
    }

    void zzapy() {
        for (zze disconnect : this.tY.values()) {
            disconnect.disconnect();
        }
    }

    public <A extends com.google.android.gms.common.api.Api.zzb, R extends Result, T extends com.google.android.gms.internal.zzpr.zza<R, A>> T zzc(@NonNull T t) {
        t.zzaot();
        return this.uo.zzc(t);
    }

    public <A extends com.google.android.gms.common.api.Api.zzb, T extends com.google.android.gms.internal.zzpr.zza<? extends Result, A>> T zzd(@NonNull T t) {
        t.zzaot();
        return this.uo.zzd(t);
    }

    void zzi(ConnectionResult connectionResult) {
        this.th.lock();
        try {
            this.up = connectionResult;
            this.uo = new zzqc(this);
            this.uo.begin();
            this.ul.signalAll();
        } finally {
            this.th.unlock();
        }
    }
}
