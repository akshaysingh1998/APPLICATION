package com.google.android.gms.internal;

import android.util.Log;
import com.google.ads.AdRequest;
import com.google.android.gms.ads.internal.util.client.zzb;

@zzir
public final class zzkh extends zzb {
    public static void m83v(String str) {
        if (zztc()) {
            Log.v(AdRequest.LOGTAG, str);
        }
    }

    public static boolean zztb() {
        return ((Boolean) zzdc.zzban.get()).booleanValue();
    }

    private static boolean zztc() {
        return zzb.zzaz(2) && zztb();
    }
}
