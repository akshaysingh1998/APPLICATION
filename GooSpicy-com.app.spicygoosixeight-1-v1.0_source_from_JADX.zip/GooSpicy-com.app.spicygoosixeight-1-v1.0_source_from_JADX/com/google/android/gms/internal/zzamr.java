package com.google.android.gms.internal;

import java.lang.reflect.Field;

public interface zzamr {
    String zzc(Field field);
}
