package com.google.android.gms.internal;

import android.content.Context;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.internal.zzjy.zza;

@zzir
public class zzie extends zzic {
    private zzid zzbyk;

    zzie(Context context, zza com_google_android_gms_internal_zzjy_zza, zzll com_google_android_gms_internal_zzll, zzig.zza com_google_android_gms_internal_zzig_zza) {
        super(context, com_google_android_gms_internal_zzjy_zza, com_google_android_gms_internal_zzll, com_google_android_gms_internal_zzig_zza);
    }

    protected void zzpx() {
        int i;
        int i2;
        AdSizeParcel zzdo = this.zzbgj.zzdo();
        if (zzdo.zzauq) {
            DisplayMetrics displayMetrics = this.mContext.getResources().getDisplayMetrics();
            i = displayMetrics.widthPixels;
            i2 = displayMetrics.heightPixels;
        } else {
            i = zzdo.widthPixels;
            i2 = zzdo.heightPixels;
        }
        this.zzbyk = new zzid(this, this.zzbgj, i, i2);
        this.zzbgj.zzuk().zza((zzlm.zza) this);
        this.zzbyk.zza(this.zzbxw);
    }

    protected int zzpy() {
        if (!this.zzbyk.zzqc()) {
            return !this.zzbyk.zzqd() ? 2 : -2;
        } else {
            zzb.zzcw("Ad-Network indicated no fill with passback URL.");
            return 3;
        }
    }
}
