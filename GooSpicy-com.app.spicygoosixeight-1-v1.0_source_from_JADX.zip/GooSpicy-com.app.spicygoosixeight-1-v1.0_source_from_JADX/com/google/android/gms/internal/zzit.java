package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.zzk.zza;
import com.google.android.gms.ads.internal.request.zzl;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzfw.zzc;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

@zzir
public final class zzit extends zza {
    private static final Object zzamp = new Object();
    private static zzit zzceb;
    private final Context mContext;
    private final zzis zzcec;
    private final zzcv zzced;
    private final zzfw zzcee;

    class C04601 implements Callable<Void> {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzis zzcef;
        final /* synthetic */ AdRequestInfoParcel zzceg;
        final /* synthetic */ Bundle zzceh;

        C04601(zzis com_google_android_gms_internal_zzis, Context context, AdRequestInfoParcel adRequestInfoParcel, Bundle bundle) {
            this.zzcef = com_google_android_gms_internal_zzis;
            this.zzaky = context;
            this.zzceg = adRequestInfoParcel;
            this.zzceh = bundle;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzcy();
        }

        public Void zzcy() throws Exception {
            this.zzcef.zzcea.zza(this.zzaky, this.zzceg.zzcaw.packageName, this.zzceh);
            return null;
        }
    }

    class C04612 implements Runnable {
        final /* synthetic */ zzdk zzakg;
        final /* synthetic */ zzfw zzaku;
        final /* synthetic */ zziv zzcei;
        final /* synthetic */ zzdi zzcej;
        final /* synthetic */ String zzcek;

        class C09382 implements zzle.zza {
            final /* synthetic */ C04612 zzcem;

            C09382(C04612 c04612) {
                this.zzcem = c04612;
            }

            public void run() {
            }
        }

        C04612(zzfw com_google_android_gms_internal_zzfw, zziv com_google_android_gms_internal_zziv, zzdk com_google_android_gms_internal_zzdk, zzdi com_google_android_gms_internal_zzdi, String str) {
            this.zzaku = com_google_android_gms_internal_zzfw;
            this.zzcei = com_google_android_gms_internal_zziv;
            this.zzakg = com_google_android_gms_internal_zzdk;
            this.zzcej = com_google_android_gms_internal_zzdi;
            this.zzcek = str;
        }

        public void run() {
            zzc zzmc = this.zzaku.zzmc();
            this.zzcei.zzb(zzmc);
            this.zzakg.zza(this.zzcej, "rwc");
            final zzdi zzkg = this.zzakg.zzkg();
            zzmc.zza(new zzle.zzc<zzfx>(this) {
                final /* synthetic */ C04612 zzcem;

                public void zzb(zzfx com_google_android_gms_internal_zzfx) {
                    this.zzcem.zzakg.zza(zzkg, "jsf");
                    this.zzcem.zzakg.zzkh();
                    com_google_android_gms_internal_zzfx.zza("/invalidRequest", this.zzcem.zzcei.zzcet);
                    com_google_android_gms_internal_zzfx.zza("/loadAdURL", this.zzcem.zzcei.zzceu);
                    com_google_android_gms_internal_zzfx.zza("/loadAd", this.zzcem.zzcei.zzcev);
                    try {
                        com_google_android_gms_internal_zzfx.zzj("AFMA_getAd", this.zzcem.zzcek);
                    } catch (Throwable e) {
                        zzb.zzb("Error requesting an ad url", e);
                    }
                }

                public /* synthetic */ void zzd(Object obj) {
                    zzb((zzfx) obj);
                }
            }, new C09382(this));
        }
    }

    class C04623 implements Runnable {
        final /* synthetic */ Context zzaky;
        final /* synthetic */ zzis zzcef;
        final /* synthetic */ AdRequestInfoParcel zzceg;
        final /* synthetic */ zziv zzcei;

        C04623(zzis com_google_android_gms_internal_zzis, Context context, zziv com_google_android_gms_internal_zziv, AdRequestInfoParcel adRequestInfoParcel) {
            this.zzcef = com_google_android_gms_internal_zzis;
            this.zzaky = context;
            this.zzcei = com_google_android_gms_internal_zziv;
            this.zzceg = adRequestInfoParcel;
        }

        public void run() {
            this.zzcef.zzcdv.zza(this.zzaky, this.zzcei, this.zzceg.zzaou);
        }
    }

    class C09394 implements zzkp<zzft> {
        final /* synthetic */ zzit zzcen;

        C09394(zzit com_google_android_gms_internal_zzit) {
            this.zzcen = com_google_android_gms_internal_zzit;
        }

        public void zza(zzft com_google_android_gms_internal_zzft) {
            com_google_android_gms_internal_zzft.zza("/log", zzer.zzbhz);
        }

        public /* synthetic */ void zzd(Object obj) {
            zza((zzft) obj);
        }
    }

    zzit(Context context, zzcv com_google_android_gms_internal_zzcv, zzis com_google_android_gms_internal_zzis) {
        this.mContext = context;
        this.zzcec = com_google_android_gms_internal_zzis;
        this.zzced = com_google_android_gms_internal_zzcv;
        if (context.getApplicationContext() != null) {
            context = context.getApplicationContext();
        }
        this.zzcee = new zzfw(context, new VersionInfoParcel(9256208, 9256208, true), com_google_android_gms_internal_zzcv.zzjv(), new C09394(this), new zzfw.zzb());
    }

    private static com.google.android.gms.ads.internal.request.AdResponseParcel zza(android.content.Context r23, com.google.android.gms.internal.zzfw r24, com.google.android.gms.internal.zzcv r25, com.google.android.gms.internal.zzis r26, com.google.android.gms.ads.internal.request.AdRequestInfoParcel r27) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r11 = r23;
        r12 = r26;
        r13 = r27;
        r1 = "Starting ad request from service using: AFMA_getAd";
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r1);
        com.google.android.gms.internal.zzdc.initialize(r23);
        r14 = new com.google.android.gms.internal.zzdk;
        r1 = com.google.android.gms.internal.zzdc.zzazc;
        r1 = r1.get();
        r1 = (java.lang.Boolean) r1;
        r1 = r1.booleanValue();
        r2 = "load_ad";
        r3 = r13.zzaoy;
        r3 = r3.zzaup;
        r14.<init>(r1, r2, r3);
        r1 = r13.versionCode;
        r15 = 1;
        r10 = 0;
        r2 = 10;
        if (r1 <= r2) goto L_0x0044;
    L_0x002d:
        r1 = r13.zzcbn;
        r3 = -1;
        r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1));
        if (r5 == 0) goto L_0x0044;
    L_0x0035:
        r1 = r13.zzcbn;
        r1 = r14.zzc(r1);
        r2 = new java.lang.String[r15];
        r3 = "cts";
        r2[r10] = r3;
        r14.zza(r1, r2);
    L_0x0044:
        r9 = r14.zzkg();
        r1 = r13.versionCode;
        r2 = 4;
        r8 = 0;
        if (r1 < r2) goto L_0x0055;
    L_0x004e:
        r1 = r13.zzcbc;
        if (r1 == 0) goto L_0x0055;
    L_0x0052:
        r1 = r13.zzcbc;
        goto L_0x0056;
    L_0x0055:
        r1 = r8;
    L_0x0056:
        r2 = com.google.android.gms.internal.zzdc.zzazl;
        r2 = r2.get();
        r2 = (java.lang.Boolean) r2;
        r2 = r2.booleanValue();
        if (r2 == 0) goto L_0x0090;
    L_0x0064:
        r2 = r12.zzcea;
        if (r2 == 0) goto L_0x0090;
    L_0x0068:
        if (r1 != 0) goto L_0x0082;
    L_0x006a:
        r2 = com.google.android.gms.internal.zzdc.zzazm;
        r2 = r2.get();
        r2 = (java.lang.Boolean) r2;
        r2 = r2.booleanValue();
        if (r2 == 0) goto L_0x0082;
    L_0x0078:
        r1 = "contentInfo is not present, but we'll still launch the app index task";
        com.google.android.gms.internal.zzkh.m83v(r1);
        r1 = new android.os.Bundle;
        r1.<init>();
    L_0x0082:
        if (r1 == 0) goto L_0x0090;
    L_0x0084:
        r2 = new com.google.android.gms.internal.zzit$1;
        r2.<init>(r12, r11, r13, r1);
        r2 = com.google.android.gms.internal.zzkk.zza(r2);
        r16 = r1;
        goto L_0x0093;
    L_0x0090:
        r16 = r1;
        r2 = r8;
    L_0x0093:
        r1 = new com.google.android.gms.internal.zzla;
        r1.<init>(r8);
        r3 = r13.zzcav;
        r3 = r3.extras;
        if (r3 == 0) goto L_0x00a8;
    L_0x009e:
        r4 = "_ad";
        r3 = r3.getString(r4);
        if (r3 == 0) goto L_0x00a8;
    L_0x00a6:
        r3 = r15;
        goto L_0x00a9;
    L_0x00a8:
        r3 = r10;
    L_0x00a9:
        r4 = r13.zzcbu;
        if (r4 == 0) goto L_0x00b7;
    L_0x00ad:
        if (r3 != 0) goto L_0x00b7;
    L_0x00af:
        r1 = r12.zzcdw;
        r3 = r13.applicationInfo;
        r1 = r1.zza(r3);
    L_0x00b7:
        r3 = com.google.android.gms.ads.internal.zzu.zzfw();
        r3 = r3.zzy(r11);
        r4 = r3.zzcgt;
        r5 = -1;
        if (r4 != r5) goto L_0x00d0;
    L_0x00c4:
        r1 = "Device is offline.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r1);
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;
        r2 = 2;
        r1.<init>(r2);
        return r1;
    L_0x00d0:
        r4 = r13.versionCode;
        r7 = 7;
        if (r4 < r7) goto L_0x00d9;
    L_0x00d5:
        r4 = r13.zzcbk;
    L_0x00d7:
        r6 = r4;
        goto L_0x00e2;
    L_0x00d9:
        r4 = java.util.UUID.randomUUID();
        r4 = r4.toString();
        goto L_0x00d7;
    L_0x00e2:
        r5 = new com.google.android.gms.internal.zziv;
        r4 = r13.applicationInfo;
        r4 = r4.packageName;
        r5.<init>(r6, r4);
        r4 = r13.zzcav;
        r4 = r4.extras;
        if (r4 == 0) goto L_0x0102;
    L_0x00f1:
        r4 = r13.zzcav;
        r4 = r4.extras;
        r7 = "_ad";
        r4 = r4.getString(r7);
        if (r4 == 0) goto L_0x0102;
    L_0x00fd:
        r1 = com.google.android.gms.internal.zziu.zza(r11, r13, r4);
        return r1;
    L_0x0102:
        r4 = r12.zzcdu;
        r18 = r4.zza(r13);
        r4 = r12.zzcdx;
        r7 = r4.zzf(r13);
        r4 = r12.zzcdy;
        r4 = r4.zzz(r11);
        if (r2 == 0) goto L_0x013f;
    L_0x0116:
        r8 = "Waiting for app index fetching task.";	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        com.google.android.gms.internal.zzkh.m83v(r8);	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        r8 = com.google.android.gms.internal.zzdc.zzazn;	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        r8 = r8.get();	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        r8 = (java.lang.Long) r8;	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        r10 = r8.longValue();	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        r8 = java.util.concurrent.TimeUnit.MILLISECONDS;	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        r2.get(r10, r8);	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        r2 = "App index fetching task completed.";	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        com.google.android.gms.internal.zzkh.m83v(r2);	 Catch:{ ExecutionException -> 0x0138, ExecutionException -> 0x0138, TimeoutException -> 0x0132 }
        goto L_0x013f;
    L_0x0132:
        r2 = "Timed out waiting for app index fetching task";
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r2);
        goto L_0x013f;
    L_0x0138:
        r0 = move-exception;
        r2 = r0;
        r8 = "Failed to fetch app index signal";
        com.google.android.gms.ads.internal.util.client.zzb.zzd(r8, r2);
    L_0x013f:
        r2 = r12.zzcdt;
        r8 = r13.zzcaw;
        r8 = r8.packageName;
        r11 = r2.zzcl(r8);
        r8 = zzb(r1);
        r10 = r23;
        r1 = r10;
        r2 = r13;
        r19 = r5;
        r5 = r8;
        r8 = r6;
        r6 = r25;
        r15 = 7;
        r20 = r8;
        r17 = 0;
        r8 = r18;
        r21 = r9;
        r9 = r16;
        r15 = 0;
        r10 = r11;
        r1 = com.google.android.gms.internal.zziu.zza(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10);
        if (r1 != 0) goto L_0x0170;
    L_0x016a:
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;
        r1.<init>(r15);
        return r1;
    L_0x0170:
        r2 = r13.versionCode;
        r3 = 7;
        if (r2 >= r3) goto L_0x017c;
    L_0x0175:
        r2 = "request_id";	 Catch:{ JSONException -> 0x017c }
        r4 = r20;	 Catch:{ JSONException -> 0x017c }
        r1.put(r2, r4);	 Catch:{ JSONException -> 0x017c }
    L_0x017c:
        r2 = "prefetch_mode";	 Catch:{ JSONException -> 0x0184 }
        r3 = "url";	 Catch:{ JSONException -> 0x0184 }
        r1.put(r2, r3);	 Catch:{ JSONException -> 0x0184 }
        goto L_0x018b;
    L_0x0184:
        r0 = move-exception;
        r2 = r0;
        r3 = "Failed putting prefetch parameters to ad request.";
        com.google.android.gms.ads.internal.util.client.zzb.zzd(r3, r2);
    L_0x018b:
        r7 = r1.toString();
        r1 = 1;
        r2 = new java.lang.String[r1];
        r1 = "arc";
        r2[r15] = r1;
        r9 = r21;
        r14.zza(r9, r2);
        r6 = r14.zzkg();
        r1 = com.google.android.gms.internal.zzkl.zzclg;
        r8 = new com.google.android.gms.internal.zzit$2;
        r2 = r8;
        r3 = r24;
        r4 = r19;
        r5 = r14;
        r2.<init>(r3, r4, r5, r6, r7);
        r1.post(r8);
        r10 = r19;
        r1 = r10.zzri();	 Catch:{ Exception -> 0x0271, all -> 0x026c }
        r2 = 10;	 Catch:{ Exception -> 0x0271, all -> 0x026c }
        r4 = java.util.concurrent.TimeUnit.SECONDS;	 Catch:{ Exception -> 0x0271, all -> 0x026c }
        r1 = r1.get(r2, r4);	 Catch:{ Exception -> 0x0271, all -> 0x026c }
        r6 = r1;	 Catch:{ Exception -> 0x0271, all -> 0x026c }
        r6 = (com.google.android.gms.internal.zziy) r6;	 Catch:{ Exception -> 0x0271, all -> 0x026c }
        if (r6 != 0) goto L_0x01da;
    L_0x01c2:
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x01d4 }
        r1.<init>(r15);	 Catch:{ all -> 0x01d4 }
        r2 = com.google.android.gms.internal.zzkl.zzclg;
        r3 = new com.google.android.gms.internal.zzit$3;
        r8 = r23;
        r3.<init>(r12, r8, r10, r13);
        r2.post(r3);
        return r1;
    L_0x01d4:
        r0 = move-exception;
        r1 = r0;
        r11 = r23;
        goto L_0x0285;
    L_0x01da:
        r8 = r23;
        r1 = r6.getErrorCode();	 Catch:{ all -> 0x0269 }
        r2 = -2;
        if (r1 == r2) goto L_0x01fc;
    L_0x01e3:
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x01f7 }
        r2 = r6.getErrorCode();	 Catch:{ all -> 0x01f7 }
        r1.<init>(r2);	 Catch:{ all -> 0x01f7 }
        r2 = com.google.android.gms.internal.zzkl.zzclg;
        r3 = new com.google.android.gms.internal.zzit$3;
        r3.<init>(r12, r8, r10, r13);
        r2.post(r3);
        return r1;
    L_0x01f7:
        r0 = move-exception;
        r1 = r0;
        r11 = r8;
        goto L_0x0285;
    L_0x01fc:
        r1 = r14.zzkj();	 Catch:{ all -> 0x0269 }
        if (r1 == 0) goto L_0x0210;
    L_0x0202:
        r1 = r14.zzkj();	 Catch:{ all -> 0x01f7 }
        r2 = 1;	 Catch:{ all -> 0x01f7 }
        r3 = new java.lang.String[r2];	 Catch:{ all -> 0x01f7 }
        r2 = "rur";	 Catch:{ all -> 0x01f7 }
        r3[r15] = r2;	 Catch:{ all -> 0x01f7 }
        r14.zza(r1, r3);	 Catch:{ all -> 0x01f7 }
    L_0x0210:
        r1 = r6.zzrn();	 Catch:{ all -> 0x0269 }
        r1 = android.text.TextUtils.isEmpty(r1);	 Catch:{ all -> 0x0269 }
        if (r1 != 0) goto L_0x0224;
    L_0x021a:
        r1 = r6.zzrn();	 Catch:{ all -> 0x01f7 }
        r1 = com.google.android.gms.internal.zziu.zza(r8, r13, r1);	 Catch:{ all -> 0x01f7 }
        r17 = r1;
    L_0x0224:
        if (r17 != 0) goto L_0x0243;
    L_0x0226:
        r1 = r6.getUrl();	 Catch:{ all -> 0x0269 }
        r1 = android.text.TextUtils.isEmpty(r1);	 Catch:{ all -> 0x0269 }
        if (r1 != 0) goto L_0x0243;	 Catch:{ all -> 0x0269 }
    L_0x0230:
        r1 = r13.zzaou;	 Catch:{ all -> 0x0269 }
        r3 = r1.zzcs;	 Catch:{ all -> 0x0269 }
        r4 = r6.getUrl();	 Catch:{ all -> 0x0269 }
        r1 = r13;
        r2 = r8;
        r5 = r11;
        r7 = r14;
        r11 = r8;
        r8 = r12;
        r17 = zza(r1, r2, r3, r4, r5, r6, r7, r8);	 Catch:{ all -> 0x0283 }
        goto L_0x0244;	 Catch:{ all -> 0x0283 }
    L_0x0243:
        r11 = r8;	 Catch:{ all -> 0x0283 }
    L_0x0244:
        if (r17 != 0) goto L_0x024c;	 Catch:{ all -> 0x0283 }
    L_0x0246:
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x0283 }
        r1.<init>(r15);	 Catch:{ all -> 0x0283 }
        goto L_0x024e;	 Catch:{ all -> 0x0283 }
    L_0x024c:
        r1 = r17;	 Catch:{ all -> 0x0283 }
    L_0x024e:
        r2 = 1;	 Catch:{ all -> 0x0283 }
        r2 = new java.lang.String[r2];	 Catch:{ all -> 0x0283 }
        r3 = "tts";	 Catch:{ all -> 0x0283 }
        r2[r15] = r3;	 Catch:{ all -> 0x0283 }
        r14.zza(r9, r2);	 Catch:{ all -> 0x0283 }
        r2 = r14.zzki();	 Catch:{ all -> 0x0283 }
        r1.zzccp = r2;	 Catch:{ all -> 0x0283 }
        r2 = com.google.android.gms.internal.zzkl.zzclg;
        r3 = new com.google.android.gms.internal.zzit$3;
        r3.<init>(r12, r11, r10, r13);
        r2.post(r3);
        return r1;
    L_0x0269:
        r0 = move-exception;
        r11 = r8;
        goto L_0x026f;
    L_0x026c:
        r0 = move-exception;
        r11 = r23;
    L_0x026f:
        r1 = r0;
        goto L_0x0285;
    L_0x0271:
        r11 = r23;
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x0283 }
        r1.<init>(r15);	 Catch:{ all -> 0x0283 }
        r2 = com.google.android.gms.internal.zzkl.zzclg;
        r3 = new com.google.android.gms.internal.zzit$3;
        r3.<init>(r12, r11, r10, r13);
        r2.post(r3);
        return r1;
    L_0x0283:
        r0 = move-exception;
        goto L_0x026f;
    L_0x0285:
        r2 = com.google.android.gms.internal.zzkl.zzclg;
        r3 = new com.google.android.gms.internal.zzit$3;
        r3.<init>(r12, r11, r10, r13);
        r2.post(r3);
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzit.zza(android.content.Context, com.google.android.gms.internal.zzfw, com.google.android.gms.internal.zzcv, com.google.android.gms.internal.zzis, com.google.android.gms.ads.internal.request.AdRequestInfoParcel):com.google.android.gms.ads.internal.request.AdResponseParcel");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.ads.internal.request.AdResponseParcel zza(com.google.android.gms.ads.internal.request.AdRequestInfoParcel r18, android.content.Context r19, java.lang.String r20, java.lang.String r21, java.lang.String r22, com.google.android.gms.internal.zziy r23, com.google.android.gms.internal.zzdk r24, com.google.android.gms.internal.zzis r25) {
        /*
        r1 = r18;
        r2 = r24;
        r3 = r25;
        if (r2 == 0) goto L_0x000d;
    L_0x0008:
        r5 = r24.zzkg();
        goto L_0x000e;
    L_0x000d:
        r5 = 0;
    L_0x000e:
        r6 = new com.google.android.gms.internal.zziw;	 Catch:{ IOException -> 0x019f }
        r6.<init>(r1);	 Catch:{ IOException -> 0x019f }
        r7 = "AdRequestServiceImpl: Sending request: ";
        r8 = java.lang.String.valueOf(r21);	 Catch:{ IOException -> 0x019f }
        r9 = r8.length();	 Catch:{ IOException -> 0x019f }
        if (r9 == 0) goto L_0x0024;
    L_0x001f:
        r7 = r7.concat(r8);	 Catch:{ IOException -> 0x019f }
        goto L_0x002a;
    L_0x0024:
        r8 = new java.lang.String;	 Catch:{ IOException -> 0x019f }
        r8.<init>(r7);	 Catch:{ IOException -> 0x019f }
        r7 = r8;
    L_0x002a:
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r7);	 Catch:{ IOException -> 0x019f }
        r7 = new java.net.URL;	 Catch:{ IOException -> 0x019f }
        r8 = r21;
        r7.<init>(r8);	 Catch:{ IOException -> 0x019f }
        r8 = com.google.android.gms.ads.internal.zzu.zzfu();	 Catch:{ IOException -> 0x019f }
        r8 = r8.elapsedRealtime();	 Catch:{ IOException -> 0x019f }
        r10 = 0;
        r11 = r10;
    L_0x003e:
        if (r3 == 0) goto L_0x0045;
    L_0x0040:
        r12 = r3.zzcdz;	 Catch:{ IOException -> 0x019f }
        r12.zzrp();	 Catch:{ IOException -> 0x019f }
    L_0x0045:
        r12 = r7.openConnection();	 Catch:{ IOException -> 0x019f }
        r12 = (java.net.HttpURLConnection) r12;	 Catch:{ IOException -> 0x019f }
        r13 = com.google.android.gms.ads.internal.zzu.zzfq();	 Catch:{ all -> 0x0192 }
        r14 = r19;
        r15 = r20;
        r13.zza(r14, r15, r10, r12);	 Catch:{ all -> 0x0192 }
        r13 = android.text.TextUtils.isEmpty(r22);	 Catch:{ all -> 0x0192 }
        if (r13 != 0) goto L_0x006a;
    L_0x005c:
        r13 = r23.zzrm();	 Catch:{ all -> 0x0192 }
        if (r13 == 0) goto L_0x006a;
    L_0x0062:
        r13 = "x-afma-drt-cookie";
        r4 = r22;
        r12.addRequestProperty(r13, r4);	 Catch:{ all -> 0x0192 }
        goto L_0x006c;
    L_0x006a:
        r4 = r22;
    L_0x006c:
        r13 = r1.zzcbv;	 Catch:{ all -> 0x0192 }
        r16 = android.text.TextUtils.isEmpty(r13);	 Catch:{ all -> 0x0192 }
        if (r16 != 0) goto L_0x007e;
    L_0x0074:
        r10 = "Sending webview cookie in ad request header.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r10);	 Catch:{ all -> 0x0192 }
        r10 = "Cookie";
        r12.addRequestProperty(r10, r13);	 Catch:{ all -> 0x0192 }
    L_0x007e:
        if (r23 == 0) goto L_0x00b5;
    L_0x0080:
        r10 = r23.zzrl();	 Catch:{ all -> 0x0192 }
        r10 = android.text.TextUtils.isEmpty(r10);	 Catch:{ all -> 0x0192 }
        if (r10 != 0) goto L_0x00b5;
    L_0x008a:
        r10 = 1;
        r12.setDoOutput(r10);	 Catch:{ all -> 0x0192 }
        r10 = r23.zzrl();	 Catch:{ all -> 0x0192 }
        r10 = r10.getBytes();	 Catch:{ all -> 0x0192 }
        r1 = r10.length;	 Catch:{ all -> 0x0192 }
        r12.setFixedLengthStreamingMode(r1);	 Catch:{ all -> 0x0192 }
        r1 = new java.io.BufferedOutputStream;	 Catch:{ all -> 0x00ae }
        r4 = r12.getOutputStream();	 Catch:{ all -> 0x00ae }
        r1.<init>(r4);	 Catch:{ all -> 0x00ae }
        r1.write(r10);	 Catch:{ all -> 0x00aa }
        com.google.android.gms.common.util.zzo.zzb(r1);	 Catch:{ all -> 0x0192 }
        goto L_0x00b5;
    L_0x00aa:
        r0 = move-exception;
        r2 = r1;
        r1 = r0;
        goto L_0x00b1;
    L_0x00ae:
        r0 = move-exception;
        r1 = r0;
        r2 = 0;
    L_0x00b1:
        com.google.android.gms.common.util.zzo.zzb(r2);	 Catch:{ all -> 0x0192 }
        throw r1;	 Catch:{ all -> 0x0192 }
    L_0x00b5:
        r1 = r12.getResponseCode();	 Catch:{ all -> 0x0192 }
        r4 = r12.getHeaderFields();	 Catch:{ all -> 0x0192 }
        r10 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;
        r13 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
        if (r1 < r10) goto L_0x0109;
    L_0x00c3:
        if (r1 >= r13) goto L_0x0109;
    L_0x00c5:
        r7 = r7.toString();	 Catch:{ all -> 0x0192 }
        r10 = new java.io.InputStreamReader;	 Catch:{ all -> 0x0102 }
        r11 = r12.getInputStream();	 Catch:{ all -> 0x0102 }
        r10.<init>(r11);	 Catch:{ all -> 0x0102 }
        r11 = com.google.android.gms.ads.internal.zzu.zzfq();	 Catch:{ all -> 0x00ff }
        r11 = r11.zza(r10);	 Catch:{ all -> 0x00ff }
        com.google.android.gms.common.util.zzo.zzb(r10);	 Catch:{ all -> 0x0192 }
        zza(r7, r4, r11, r1);	 Catch:{ all -> 0x0192 }
        r6.zzb(r7, r4, r11);	 Catch:{ all -> 0x0192 }
        if (r2 == 0) goto L_0x00f0;
    L_0x00e5:
        r1 = 1;
        r1 = new java.lang.String[r1];	 Catch:{ all -> 0x0192 }
        r4 = "ufe";
        r7 = 0;
        r1[r7] = r4;	 Catch:{ all -> 0x0192 }
        r2.zza(r5, r1);	 Catch:{ all -> 0x0192 }
    L_0x00f0:
        r1 = r6.zzj(r8);	 Catch:{ all -> 0x0192 }
        r12.disconnect();	 Catch:{ IOException -> 0x019f }
        if (r3 == 0) goto L_0x00fe;
    L_0x00f9:
        r2 = r3.zzcdz;	 Catch:{ IOException -> 0x019f }
        r2.zzrq();	 Catch:{ IOException -> 0x019f }
    L_0x00fe:
        return r1;
    L_0x00ff:
        r0 = move-exception;
        r1 = r0;
        goto L_0x0105;
    L_0x0102:
        r0 = move-exception;
        r1 = r0;
        r10 = 0;
    L_0x0105:
        com.google.android.gms.common.util.zzo.zzb(r10);	 Catch:{ all -> 0x0192 }
        throw r1;	 Catch:{ all -> 0x0192 }
    L_0x0109:
        r7 = r7.toString();	 Catch:{ all -> 0x0192 }
        r10 = 0;
        zza(r7, r4, r10, r1);	 Catch:{ all -> 0x0192 }
        if (r1 < r13) goto L_0x016b;
    L_0x0113:
        r7 = 400; // 0x190 float:5.6E-43 double:1.976E-321;
        if (r1 >= r7) goto L_0x016b;
    L_0x0117:
        r1 = "Location";
        r1 = r12.getHeaderField(r1);	 Catch:{ all -> 0x0192 }
        r7 = android.text.TextUtils.isEmpty(r1);	 Catch:{ all -> 0x0192 }
        if (r7 == 0) goto L_0x0139;
    L_0x0123:
        r1 = "No location header to follow redirect.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);	 Catch:{ all -> 0x0192 }
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x0192 }
        r2 = 0;
        r1.<init>(r2);	 Catch:{ all -> 0x0192 }
        r12.disconnect();	 Catch:{ IOException -> 0x019f }
        if (r3 == 0) goto L_0x0138;
    L_0x0133:
        r2 = r3.zzcdz;	 Catch:{ IOException -> 0x019f }
        r2.zzrq();	 Catch:{ IOException -> 0x019f }
    L_0x0138:
        return r1;
    L_0x0139:
        r7 = new java.net.URL;	 Catch:{ all -> 0x0192 }
        r7.<init>(r1);	 Catch:{ all -> 0x0192 }
        r1 = 1;
        r11 = r11 + r1;
        r1 = 5;
        if (r11 <= r1) goto L_0x0159;
    L_0x0143:
        r1 = "Too many redirects.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);	 Catch:{ all -> 0x0192 }
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x0192 }
        r2 = 0;
        r1.<init>(r2);	 Catch:{ all -> 0x0192 }
        r12.disconnect();	 Catch:{ IOException -> 0x019f }
        if (r3 == 0) goto L_0x0158;
    L_0x0153:
        r2 = r3.zzcdz;	 Catch:{ IOException -> 0x019f }
        r2.zzrq();	 Catch:{ IOException -> 0x019f }
    L_0x0158:
        return r1;
    L_0x0159:
        r6.zzj(r4);	 Catch:{ all -> 0x0192 }
        r12.disconnect();	 Catch:{ IOException -> 0x019f }
        if (r3 == 0) goto L_0x0166;
    L_0x0161:
        r1 = r3.zzcdz;	 Catch:{ IOException -> 0x019f }
        r1.zzrq();	 Catch:{ IOException -> 0x019f }
    L_0x0166:
        r1 = r18;
        r10 = 0;
        goto L_0x003e;
    L_0x016b:
        r2 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0192 }
        r4 = 46;
        r2.<init>(r4);	 Catch:{ all -> 0x0192 }
        r4 = "Received error HTTP response code: ";
        r2.append(r4);	 Catch:{ all -> 0x0192 }
        r2.append(r1);	 Catch:{ all -> 0x0192 }
        r1 = r2.toString();	 Catch:{ all -> 0x0192 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);	 Catch:{ all -> 0x0192 }
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x0192 }
        r2 = 0;
        r1.<init>(r2);	 Catch:{ all -> 0x0192 }
        r12.disconnect();	 Catch:{ IOException -> 0x019f }
        if (r3 == 0) goto L_0x0191;
    L_0x018c:
        r2 = r3.zzcdz;	 Catch:{ IOException -> 0x019f }
        r2.zzrq();	 Catch:{ IOException -> 0x019f }
    L_0x0191:
        return r1;
    L_0x0192:
        r0 = move-exception;
        r1 = r0;
        r12.disconnect();	 Catch:{ IOException -> 0x019f }
        if (r3 == 0) goto L_0x019e;
    L_0x0199:
        r2 = r3.zzcdz;	 Catch:{ IOException -> 0x019f }
        r2.zzrq();	 Catch:{ IOException -> 0x019f }
    L_0x019e:
        throw r1;	 Catch:{ IOException -> 0x019f }
    L_0x019f:
        r0 = move-exception;
        r1 = r0;
        r2 = "Error while connecting to ad server: ";
        r1 = r1.getMessage();
        r1 = java.lang.String.valueOf(r1);
        r3 = r1.length();
        if (r3 == 0) goto L_0x01b6;
    L_0x01b1:
        r1 = r2.concat(r1);
        goto L_0x01bb;
    L_0x01b6:
        r1 = new java.lang.String;
        r1.<init>(r2);
    L_0x01bb:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);
        r1 = new com.google.android.gms.ads.internal.request.AdResponseParcel;
        r2 = 2;
        r1.<init>(r2);
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzit.zza(com.google.android.gms.ads.internal.request.AdRequestInfoParcel, android.content.Context, java.lang.String, java.lang.String, java.lang.String, com.google.android.gms.internal.zziy, com.google.android.gms.internal.zzdk, com.google.android.gms.internal.zzis):com.google.android.gms.ads.internal.request.AdResponseParcel");
    }

    public static zzit zza(Context context, zzcv com_google_android_gms_internal_zzcv, zzis com_google_android_gms_internal_zzis) {
        zzit com_google_android_gms_internal_zzit;
        synchronized (zzamp) {
            if (zzceb == null) {
                if (context.getApplicationContext() != null) {
                    context = context.getApplicationContext();
                }
                zzceb = new zzit(context, com_google_android_gms_internal_zzcv, com_google_android_gms_internal_zzis);
            }
            com_google_android_gms_internal_zzit = zzceb;
        }
        return com_google_android_gms_internal_zzit;
    }

    private static void zza(String str, Map<String, List<String>> map, String str2, int i) {
        if (zzb.zzaz(2)) {
            StringBuilder stringBuilder = new StringBuilder(39 + String.valueOf(str).length());
            stringBuilder.append("Http Response: {\n  URL:\n    ");
            stringBuilder.append(str);
            stringBuilder.append("\n  Headers:");
            zzkh.m83v(stringBuilder.toString());
            if (map != null) {
                for (String str3 : map.keySet()) {
                    StringBuilder stringBuilder2 = new StringBuilder(5 + String.valueOf(str3).length());
                    stringBuilder2.append("    ");
                    stringBuilder2.append(str3);
                    stringBuilder2.append(":");
                    zzkh.m83v(stringBuilder2.toString());
                    for (String valueOf : (List) map.get(str3)) {
                        String str4 = "      ";
                        String valueOf2 = String.valueOf(valueOf2);
                        zzkh.m83v(valueOf2.length() != 0 ? str4.concat(valueOf2) : new String(str4));
                    }
                }
            }
            zzkh.m83v("  Body:");
            if (str2 != null) {
                int i2 = 0;
                while (i2 < Math.min(str2.length(), 100000)) {
                    int i3 = i2 + 1000;
                    zzkh.m83v(str2.substring(i2, Math.min(str2.length(), i3)));
                    i2 = i3;
                }
            } else {
                zzkh.m83v("    null");
            }
            StringBuilder stringBuilder3 = new StringBuilder(34);
            stringBuilder3.append("  Response Code:\n    ");
            stringBuilder3.append(i);
            stringBuilder3.append("\n}");
            zzkh.m83v(stringBuilder3.toString());
        }
    }

    private static Location zzb(zzlc<Location> com_google_android_gms_internal_zzlc_android_location_Location) {
        try {
            return (Location) com_google_android_gms_internal_zzlc_android_location_Location.get(((Long) zzdc.zzbcn.get()).longValue(), TimeUnit.MILLISECONDS);
        } catch (Throwable e) {
            zzb.zzd("Exception caught while getting location", e);
            return null;
        }
    }

    public void zza(final AdRequestInfoParcel adRequestInfoParcel, final zzl com_google_android_gms_ads_internal_request_zzl) {
        zzu.zzft().zzb(this.mContext, adRequestInfoParcel.zzaou);
        zzkk.zza(new Runnable(this) {
            final /* synthetic */ zzit zzcen;

            public void run() {
                AdResponseParcel zzd;
                try {
                    zzd = this.zzcen.zzd(adRequestInfoParcel);
                } catch (Throwable e) {
                    zzu.zzft().zzb(e, true);
                    zzb.zzd("Could not fetch ad response due to an Exception.", e);
                    zzd = null;
                }
                if (zzd == null) {
                    zzd = new AdResponseParcel(0);
                }
                try {
                    com_google_android_gms_ads_internal_request_zzl.zzb(zzd);
                } catch (Throwable e2) {
                    zzb.zzd("Fail to forward ad response.", e2);
                }
            }
        });
    }

    public AdResponseParcel zzd(AdRequestInfoParcel adRequestInfoParcel) {
        return zza(this.mContext, this.zzcee, this.zzced, this.zzcec, adRequestInfoParcel);
    }
}
