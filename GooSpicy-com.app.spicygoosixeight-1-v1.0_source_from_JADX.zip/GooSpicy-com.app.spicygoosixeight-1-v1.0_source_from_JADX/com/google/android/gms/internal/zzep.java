package com.google.android.gms.internal;

@zzir
public class zzep implements zzfj {
    public zzfh zza(zzll com_google_android_gms_internal_zzll, int i, String str) {
        return new zzfk(com_google_android_gms_internal_zzll);
    }
}
