package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.view.MotionEvent;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzca.zza;

public final class zzby extends zza {
    private final zzar zzaiq;
    private final zzas zzair;
    private final zzap zzais;
    private boolean zzait = false;

    public zzby(String str, Context context, boolean z) {
        this.zzaiq = zzar.zza(str, context, z);
        this.zzair = new zzas(this.zzaiq);
        this.zzais = z ? null : zzap.zze(context);
    }

    private com.google.android.gms.dynamic.zzd zza(com.google.android.gms.dynamic.zzd r1, com.google.android.gms.dynamic.zzd r2, boolean r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = this;
        r1 = com.google.android.gms.dynamic.zze.zzad(r1);	 Catch:{ zzat -> 0x0020 }
        r1 = (android.net.Uri) r1;	 Catch:{ zzat -> 0x0020 }
        r2 = com.google.android.gms.dynamic.zze.zzad(r2);	 Catch:{ zzat -> 0x0020 }
        r2 = (android.content.Context) r2;	 Catch:{ zzat -> 0x0020 }
        if (r3 == 0) goto L_0x0015;	 Catch:{ zzat -> 0x0020 }
    L_0x000e:
        r3 = r0.zzair;	 Catch:{ zzat -> 0x0020 }
        r1 = r3.zza(r1, r2);	 Catch:{ zzat -> 0x0020 }
        goto L_0x001b;	 Catch:{ zzat -> 0x0020 }
    L_0x0015:
        r3 = r0.zzair;	 Catch:{ zzat -> 0x0020 }
        r1 = r3.zzb(r1, r2);	 Catch:{ zzat -> 0x0020 }
    L_0x001b:
        r1 = com.google.android.gms.dynamic.zze.zzae(r1);	 Catch:{ zzat -> 0x0020 }
        return r1;
    L_0x0020:
        r1 = 0;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzby.zza(com.google.android.gms.dynamic.zzd, com.google.android.gms.dynamic.zzd, boolean):com.google.android.gms.dynamic.zzd");
    }

    public zzd zza(zzd com_google_android_gms_dynamic_zzd, zzd com_google_android_gms_dynamic_zzd2) {
        return zza(com_google_android_gms_dynamic_zzd, com_google_android_gms_dynamic_zzd2, true);
    }

    public String zza(zzd com_google_android_gms_dynamic_zzd, String str) {
        return this.zzaiq.zzb((Context) zze.zzad(com_google_android_gms_dynamic_zzd), str);
    }

    public boolean zza(zzd com_google_android_gms_dynamic_zzd) {
        return this.zzair.zza((Uri) zze.zzad(com_google_android_gms_dynamic_zzd));
    }

    public zzd zzb(zzd com_google_android_gms_dynamic_zzd, zzd com_google_android_gms_dynamic_zzd2) {
        return zza(com_google_android_gms_dynamic_zzd, com_google_android_gms_dynamic_zzd2, false);
    }

    public void zzb(String str, String str2) {
        this.zzair.zzb(str, str2);
    }

    public boolean zzb(zzd com_google_android_gms_dynamic_zzd) {
        return this.zzair.zzc((Uri) zze.zzad(com_google_android_gms_dynamic_zzd));
    }

    public boolean zzb(String str, boolean z) {
        if (this.zzais == null) {
            return false;
        }
        this.zzais.zza(new Info(str, z));
        this.zzait = true;
        return true;
    }

    public String zzc(zzd com_google_android_gms_dynamic_zzd) {
        Context context = (Context) zze.zzad(com_google_android_gms_dynamic_zzd);
        String zzb = this.zzaiq.zzb(context);
        if (this.zzais == null || !this.zzait) {
            return zzb;
        }
        zzb = this.zzais.zza(zzb, this.zzais.zzb(context));
        this.zzait = false;
        return zzb;
    }

    public void zzd(zzd com_google_android_gms_dynamic_zzd) {
        this.zzair.zza((MotionEvent) zze.zzad(com_google_android_gms_dynamic_zzd));
    }

    public String zzdg() {
        return "ms";
    }

    public void zzk(String str) {
        this.zzair.zzk(str);
    }
}
