package com.google.android.gms.internal;

import android.support.v4.media.TransportMediator;
import java.io.IOException;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ReadOnlyBufferException;

public final class zzaov {
    private final ByteBuffer bia;

    public static class zza extends IOException {
        zza(int i, int i2) {
            StringBuilder stringBuilder = new StringBuilder(108);
            stringBuilder.append("CodedOutputStream was writing to a flat byte array and ran out of space (pos ");
            stringBuilder.append(i);
            stringBuilder.append(" limit ");
            stringBuilder.append(i2);
            stringBuilder.append(").");
            super(stringBuilder.toString());
        }
    }

    private zzaov(ByteBuffer byteBuffer) {
        this.bia = byteBuffer;
        this.bia.order(ByteOrder.LITTLE_ENDIAN);
    }

    private zzaov(byte[] bArr, int i, int i2) {
        this(ByteBuffer.wrap(bArr, i, i2));
    }

    private static int zza(CharSequence charSequence, int i) {
        int length = charSequence.length();
        int i2 = 0;
        while (i < length) {
            char charAt = charSequence.charAt(i);
            if (charAt < 'ࠀ') {
                i2 += (127 - charAt) >>> 31;
            } else {
                i2 += 2;
                if ('?' <= charAt && charAt <= '?') {
                    if (Character.codePointAt(charSequence, i) < 65536) {
                        StringBuilder stringBuilder = new StringBuilder(39);
                        stringBuilder.append("Unpaired surrogate at index ");
                        stringBuilder.append(i);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    i++;
                }
            }
            i++;
        }
        return i2;
    }

    private static int zza(CharSequence charSequence, byte[] bArr, int i, int i2) {
        int length = charSequence.length();
        i2 += i;
        int i3 = 0;
        while (i3 < length) {
            int i4 = i3 + i;
            if (i4 >= i2) {
                break;
            }
            char charAt = charSequence.charAt(i3);
            if (charAt >= '') {
                break;
            }
            bArr[i4] = (byte) charAt;
            i3++;
        }
        if (i3 == length) {
            return i + length;
        }
        i += i3;
        while (i3 < length) {
            int i5;
            char charAt2 = charSequence.charAt(i3);
            if (charAt2 < '' && i < i2) {
                i5 = i + 1;
                bArr[i] = (byte) charAt2;
            } else if (charAt2 < 'ࠀ' && i <= i2 - 2) {
                i5 = i + 1;
                bArr[i] = (byte) (960 | (charAt2 >>> 6));
                i = i5 + 1;
                bArr[i5] = (byte) ((charAt2 & 63) | 128);
                i3++;
            } else if ((charAt2 < '?' || '?' < charAt2) && i <= i2 - 3) {
                i5 = i + 1;
                bArr[i] = (byte) (480 | (charAt2 >>> 12));
                i = i5 + 1;
                bArr[i5] = (byte) (((charAt2 >>> 6) & 63) | 128);
                i5 = i + 1;
                bArr[i] = (byte) ((charAt2 & 63) | 128);
            } else if (i <= i2 - 4) {
                i5 = i3 + 1;
                if (i5 != charSequence.length()) {
                    char charAt3 = charSequence.charAt(i5);
                    if (Character.isSurrogatePair(charAt2, charAt3)) {
                        i3 = Character.toCodePoint(charAt2, charAt3);
                        i4 = i + 1;
                        bArr[i] = (byte) (240 | (i3 >>> 18));
                        i = i4 + 1;
                        bArr[i4] = (byte) (((i3 >>> 12) & 63) | 128);
                        i4 = i + 1;
                        bArr[i] = (byte) (((i3 >>> 6) & 63) | 128);
                        i = i4 + 1;
                        bArr[i4] = (byte) ((i3 & 63) | 128);
                        i3 = i5;
                        i3++;
                    } else {
                        i3 = i5;
                    }
                }
                i3--;
                r9 = new StringBuilder(39);
                r9.append("Unpaired surrogate at index ");
                r9.append(i3);
                throw new IllegalArgumentException(r9.toString());
            } else {
                r9 = new StringBuilder(37);
                r9.append("Failed writing ");
                r9.append(charAt2);
                r9.append(" at index ");
                r9.append(i);
                throw new ArrayIndexOutOfBoundsException(r9.toString());
            }
            i = i5;
            i3++;
        }
        return i;
    }

    private static void zza(CharSequence charSequence, ByteBuffer byteBuffer) {
        if (byteBuffer.isReadOnly()) {
            throw new ReadOnlyBufferException();
        } else if (byteBuffer.hasArray()) {
            try {
                byteBuffer.position(zza(charSequence, byteBuffer.array(), byteBuffer.arrayOffset() + byteBuffer.position(), byteBuffer.remaining()) - byteBuffer.arrayOffset());
            } catch (Throwable e) {
                BufferOverflowException bufferOverflowException = new BufferOverflowException();
                bufferOverflowException.initCause(e);
                throw bufferOverflowException;
            }
        } else {
            zzb(charSequence, byteBuffer);
        }
    }

    public static int zzaeo(int i) {
        return i >= 0 ? zzaet(i) : 10;
    }

    public static int zzaep(int i) {
        return zzaet(zzaev(i));
    }

    public static int zzaer(int i) {
        return zzaet(zzapf.zzaj(i, 0));
    }

    public static int zzaet(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (i & -268435456) == 0 ? 4 : 5;
    }

    public static int zzaev(int i) {
        return (i >> 31) ^ (i << 1);
    }

    public static int zzag(int i, int i2) {
        return zzaer(i) + zzaeo(i2);
    }

    public static int zzah(int i, int i2) {
        return zzaer(i) + zzaep(i2);
    }

    public static int zzb(int i, double d) {
        return zzaer(i) + zzp(d);
    }

    public static int zzb(int i, zzapc com_google_android_gms_internal_zzapc) {
        return (zzaer(i) * 2) + zzd(com_google_android_gms_internal_zzapc);
    }

    public static int zzb(int i, byte[] bArr) {
        return zzaer(i) + zzbc(bArr);
    }

    private static void zzb(CharSequence charSequence, ByteBuffer byteBuffer) {
        int length = charSequence.length();
        int i = 0;
        while (i < length) {
            int charAt = charSequence.charAt(i);
            if (charAt >= 128) {
                int i2;
                if (charAt < 2048) {
                    i2 = 960 | (charAt >>> 6);
                } else {
                    if (charAt >= 55296) {
                        if (57343 >= charAt) {
                            i2 = i + 1;
                            if (i2 != charSequence.length()) {
                                char charAt2 = charSequence.charAt(i2);
                                if (Character.isSurrogatePair(charAt, charAt2)) {
                                    i = Character.toCodePoint(charAt, charAt2);
                                    byteBuffer.put((byte) (240 | (i >>> 18)));
                                    byteBuffer.put((byte) (((i >>> 12) & 63) | 128));
                                    byteBuffer.put((byte) (((i >>> 6) & 63) | 128));
                                    byteBuffer.put((byte) ((i & 63) | 128));
                                    i = i2;
                                    i++;
                                } else {
                                    i = i2;
                                }
                            }
                            i--;
                            StringBuilder stringBuilder = new StringBuilder(39);
                            stringBuilder.append("Unpaired surrogate at index ");
                            stringBuilder.append(i);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                    }
                    byteBuffer.put((byte) (480 | (charAt >>> 12)));
                    i2 = ((charAt >>> 6) & 63) | 128;
                }
                byteBuffer.put((byte) i2);
                charAt = (charAt & 63) | 128;
            }
            byteBuffer.put((byte) charAt);
            i++;
        }
    }

    public static zzaov zzba(byte[] bArr) {
        return zzc(bArr, 0, bArr.length);
    }

    public static int zzbc(byte[] bArr) {
        return zzaet(bArr.length) + bArr.length;
    }

    public static int zzc(int i, zzapc com_google_android_gms_internal_zzapc) {
        return zzaer(i) + zze(com_google_android_gms_internal_zzapc);
    }

    public static zzaov zzc(byte[] bArr, int i, int i2) {
        return new zzaov(bArr, i, i2);
    }

    public static int zzcv(long j) {
        return zzda(j);
    }

    public static int zzcw(long j) {
        return zzda(j);
    }

    public static int zzcx(long j) {
        return 8;
    }

    public static int zzcy(long j) {
        return zzda(zzdc(j));
    }

    public static int zzd(int i, float f) {
        return zzaer(i) + zzl(f);
    }

    public static int zzd(zzapc com_google_android_gms_internal_zzapc) {
        return com_google_android_gms_internal_zzapc.ao();
    }

    private static int zzd(CharSequence charSequence) {
        int length = charSequence.length();
        int i = 0;
        while (i < length && charSequence.charAt(i) < '') {
            i++;
        }
        int i2 = length;
        while (i < length) {
            char charAt = charSequence.charAt(i);
            if (charAt >= 'ࠀ') {
                i2 += zza(charSequence, i);
                break;
            }
            i2 += (127 - charAt) >>> 31;
            i++;
        }
        if (i2 >= length) {
            return i2;
        }
        long j = ((long) i2) + 4294967296L;
        StringBuilder stringBuilder = new StringBuilder(54);
        stringBuilder.append("UTF-8 length does not fit in int: ");
        stringBuilder.append(j);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static int zzda(long j) {
        return (j & -128) == 0 ? 1 : (j & -16384) == 0 ? 2 : (j & -2097152) == 0 ? 3 : (j & -268435456) == 0 ? 4 : (j & -34359738368L) == 0 ? 5 : (j & -4398046511104L) == 0 ? 6 : (j & -562949953421312L) == 0 ? 7 : (j & -72057594037927936L) == 0 ? 8 : (j & Long.MIN_VALUE) == 0 ? 9 : 10;
    }

    public static long zzdc(long j) {
        return (j << 1) ^ (j >> 63);
    }

    public static int zzdf(boolean z) {
        return 1;
    }

    public static int zze(int i, long j) {
        return zzaer(i) + zzcw(j);
    }

    public static int zze(zzapc com_google_android_gms_internal_zzapc) {
        int ao = com_google_android_gms_internal_zzapc.ao();
        return zzaet(ao) + ao;
    }

    public static int zzf(int i, long j) {
        return zzaer(i) + zzcx(j);
    }

    public static int zzg(int i, long j) {
        return zzaer(i) + zzcy(j);
    }

    public static int zzk(int i, boolean z) {
        return zzaer(i) + zzdf(z);
    }

    public static int zzl(float f) {
        return 4;
    }

    public static int zzp(double d) {
        return 8;
    }

    public static int zzs(int i, String str) {
        return zzaer(i) + zztg(str);
    }

    public static int zztg(String str) {
        int zzd = zzd((CharSequence) str);
        return zzaet(zzd) + zzd;
    }

    public int aa() {
        return this.bia.remaining();
    }

    public void ab() {
        if (aa() != 0) {
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    public void zza(int i, double d) throws IOException {
        zzai(i, 1);
        zzo(d);
    }

    public void zza(int i, long j) throws IOException {
        zzai(i, 0);
        zzcr(j);
    }

    public void zza(int i, zzapc com_google_android_gms_internal_zzapc) throws IOException {
        zzai(i, 2);
        zzc(com_google_android_gms_internal_zzapc);
    }

    public void zza(int i, byte[] bArr) throws IOException {
        zzai(i, 2);
        zzbb(bArr);
    }

    public void zzae(int i, int i2) throws IOException {
        zzai(i, 0);
        zzaem(i2);
    }

    public void zzaem(int i) throws IOException {
        if (i >= 0) {
            zzaes(i);
        } else {
            zzcz((long) i);
        }
    }

    public void zzaen(int i) throws IOException {
        zzaes(zzaev(i));
    }

    public void zzaeq(int i) throws IOException {
        zzc((byte) i);
    }

    public void zzaes(int i) throws IOException {
        while ((i & -128) != 0) {
            zzaeq((i & TransportMediator.KEYCODE_MEDIA_PAUSE) | 128);
            i >>>= 7;
        }
        zzaeq(i);
    }

    public void zzaeu(int i) throws IOException {
        if (this.bia.remaining() < 4) {
            throw new zza(this.bia.position(), this.bia.limit());
        }
        this.bia.putInt(i);
    }

    public void zzaf(int i, int i2) throws IOException {
        zzai(i, 0);
        zzaen(i2);
    }

    public void zzai(int i, int i2) throws IOException {
        zzaes(zzapf.zzaj(i, i2));
    }

    public void zzb(int i, long j) throws IOException {
        zzai(i, 0);
        zzcs(j);
    }

    public void zzb(zzapc com_google_android_gms_internal_zzapc) throws IOException {
        com_google_android_gms_internal_zzapc.zza(this);
    }

    public void zzbb(byte[] bArr) throws IOException {
        zzaes(bArr.length);
        zzbd(bArr);
    }

    public void zzbd(byte[] bArr) throws IOException {
        zzd(bArr, 0, bArr.length);
    }

    public void zzc(byte b) throws IOException {
        if (this.bia.hasRemaining()) {
            this.bia.put(b);
            return;
        }
        throw new zza(this.bia.position(), this.bia.limit());
    }

    public void zzc(int i, float f) throws IOException {
        zzai(i, 5);
        zzk(f);
    }

    public void zzc(int i, long j) throws IOException {
        zzai(i, 1);
        zzct(j);
    }

    public void zzc(zzapc com_google_android_gms_internal_zzapc) throws IOException {
        zzaes(com_google_android_gms_internal_zzapc.an());
        com_google_android_gms_internal_zzapc.zza(this);
    }

    public void zzcr(long j) throws IOException {
        zzcz(j);
    }

    public void zzcs(long j) throws IOException {
        zzcz(j);
    }

    public void zzct(long j) throws IOException {
        zzdb(j);
    }

    public void zzcu(long j) throws IOException {
        zzcz(zzdc(j));
    }

    public void zzcz(long j) throws IOException {
        while ((j & -128) != 0) {
            zzaeq((((int) j) & TransportMediator.KEYCODE_MEDIA_PAUSE) | 128);
            j >>>= 7;
        }
        zzaeq((int) j);
    }

    public void zzd(int i, long j) throws IOException {
        zzai(i, 0);
        zzcu(j);
    }

    public void zzd(byte[] bArr, int i, int i2) throws IOException {
        if (this.bia.remaining() >= i2) {
            this.bia.put(bArr, i, i2);
            return;
        }
        throw new zza(this.bia.position(), this.bia.limit());
    }

    public void zzdb(long j) throws IOException {
        if (this.bia.remaining() < 8) {
            throw new zza(this.bia.position(), this.bia.limit());
        }
        this.bia.putLong(j);
    }

    public void zzde(boolean z) throws IOException {
        zzaeq(z);
    }

    public void zzj(int i, boolean z) throws IOException {
        zzai(i, 0);
        zzde(z);
    }

    public void zzk(float f) throws IOException {
        zzaeu(Float.floatToIntBits(f));
    }

    public void zzo(double d) throws IOException {
        zzdb(Double.doubleToLongBits(d));
    }

    public void zzr(int i, String str) throws IOException {
        zzai(i, 2);
        zztf(str);
    }

    public void zztf(String str) throws IOException {
        try {
            int zzaet = zzaet(str.length());
            if (zzaet == zzaet(str.length() * 3)) {
                int position = this.bia.position();
                if (this.bia.remaining() < zzaet) {
                    throw new zza(position + zzaet, this.bia.limit());
                }
                this.bia.position(position + zzaet);
                zza((CharSequence) str, this.bia);
                int position2 = this.bia.position();
                this.bia.position(position);
                zzaes((position2 - position) - zzaet);
                this.bia.position(position2);
                return;
            }
            zzaes(zzd((CharSequence) str));
            zza((CharSequence) str, this.bia);
        } catch (Throwable e) {
            zza com_google_android_gms_internal_zzaov_zza = new zza(this.bia.position(), this.bia.limit());
            com_google_android_gms_internal_zzaov_zza.initCause(e);
            throw com_google_android_gms_internal_zzaov_zza;
        }
    }
}
