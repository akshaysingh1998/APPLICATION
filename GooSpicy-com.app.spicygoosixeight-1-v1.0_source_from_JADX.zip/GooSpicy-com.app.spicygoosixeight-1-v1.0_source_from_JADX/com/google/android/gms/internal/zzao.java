package com.google.android.gms.internal;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import com.google.android.gms.internal.zzae.zza;
import java.util.Iterator;
import java.util.LinkedList;

public abstract class zzao implements zzan {
    protected MotionEvent zzafd;
    protected LinkedList<MotionEvent> zzafe = new LinkedList();
    protected long zzaff = 0;
    protected long zzafg = 0;
    protected long zzafh = 0;
    protected long zzafi = 0;
    protected long zzafj = 0;
    private boolean zzafk = false;
    protected DisplayMetrics zzafl;

    protected zzao(android.content.Context r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r2.<init>();
        r0 = new java.util.LinkedList;
        r0.<init>();
        r2.zzafe = r0;
        r0 = 0;
        r2.zzaff = r0;
        r2.zzafg = r0;
        r2.zzafh = r0;
        r2.zzafi = r0;
        r2.zzafj = r0;
        r0 = 0;
        r2.zzafk = r0;
        com.google.android.gms.internal.zzak.zzas();
        r3 = r3.getResources();	 Catch:{ UnsupportedOperationException -> 0x0027 }
        r3 = r3.getDisplayMetrics();	 Catch:{ UnsupportedOperationException -> 0x0027 }
        r2.zzafl = r3;	 Catch:{ UnsupportedOperationException -> 0x0027 }
        return;
    L_0x0027:
        r3 = new android.util.DisplayMetrics;
        r3.<init>();
        r2.zzafl = r3;
        r3 = r2.zzafl;
        r0 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r3.density = r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzao.<init>(android.content.Context):void");
    }

    private java.lang.String zza(android.content.Context r4, java.lang.String r5, boolean r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = 7;
        r1 = 1;
        if (r6 == 0) goto L_0x000b;
    L_0x0004:
        r4 = r3.zzd(r4);	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        r3.zzafk = r1;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        goto L_0x000f;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
    L_0x000b:
        r4 = r3.zzc(r4);	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
    L_0x000f:
        if (r4 == 0) goto L_0x0022;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
    L_0x0011:
        r2 = r4.ao();	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        if (r2 != 0) goto L_0x0018;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
    L_0x0017:
        goto L_0x0022;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
    L_0x0018:
        r6 = zzb(r6);	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        r6 = r6 ^ r1;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        r4 = com.google.android.gms.internal.zzak.zza(r4, r5, r6);	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        return r4;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
    L_0x0022:
        r4 = 5;	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        r4 = java.lang.Integer.toString(r4);	 Catch:{ NoSuchAlgorithmException -> 0x002e, NoSuchAlgorithmException -> 0x002e, Throwable -> 0x0028 }
        return r4;
    L_0x0028:
        r4 = 3;
        r4 = java.lang.Integer.toString(r4);
        return r4;
    L_0x002e:
        r4 = java.lang.Integer.toString(r0);
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzao.zza(android.content.Context, java.lang.String, boolean):java.lang.String");
    }

    private void zzaw() {
        if (((Boolean) zzdc.zzbbr.get()).booleanValue()) {
            StackTraceElement[] stackTrace = new Throwable().getStackTrace();
            int i = 0;
            int length = stackTrace.length - 1;
            while (length >= 0) {
                i++;
                if (stackTrace[length].toString().startsWith("com.google.android.ads.")) {
                    break;
                } else if (stackTrace[length].toString().startsWith("com.google.android.gms.")) {
                    break;
                } else {
                    length--;
                }
            }
            this.zzafj = (long) i;
        }
    }

    private static boolean zzb(boolean z) {
        return !((Boolean) zzdc.zzbbj.get()).booleanValue() ? true : ((Boolean) zzdc.zzbbs.get()).booleanValue() && z;
    }

    public void zza(int i, int i2, int i3) {
        if (this.zzafd != null) {
            r0.zzafd.recycle();
        }
        r0.zzafd = MotionEvent.obtain(0, (long) i3, 1, r0.zzafl.density * ((float) i), r0.zzafl.density * ((float) i2), 0.0f, 0.0f, 0, 0.0f, 0.0f, 0, 0);
    }

    public void zza(MotionEvent motionEvent) {
        if (this.zzafk) {
            this.zzafi = 0;
            this.zzafh = 0;
            this.zzafg = 0;
            this.zzaff = 0;
            this.zzafj = 0;
            Iterator it = this.zzafe.iterator();
            while (it.hasNext()) {
                ((MotionEvent) it.next()).recycle();
            }
            this.zzafe.clear();
            this.zzafd = null;
            this.zzafk = false;
        }
        switch (motionEvent.getAction()) {
            case 0:
                this.zzaff++;
                return;
            case 1:
                this.zzafd = MotionEvent.obtain(motionEvent);
                this.zzafe.add(this.zzafd);
                if (this.zzafe.size() > 6) {
                    ((MotionEvent) this.zzafe.remove()).recycle();
                }
                this.zzafh++;
                zzaw();
                return;
            case 2:
                this.zzafg += (long) (motionEvent.getHistorySize() + 1);
                return;
            case 3:
                this.zzafi++;
                return;
            default:
                return;
        }
    }

    public String zzb(Context context) {
        return zza(context, null, false);
    }

    public String zzb(Context context, String str) {
        return zza(context, str, true);
    }

    protected abstract zza zzc(Context context);

    protected abstract zza zzd(Context context);
}
