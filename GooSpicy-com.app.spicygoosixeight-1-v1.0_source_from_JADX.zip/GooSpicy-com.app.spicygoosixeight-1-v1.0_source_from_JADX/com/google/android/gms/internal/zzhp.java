package com.google.android.gms.internal;

import android.content.Context;
import android.os.Handler;

@zzir
public class zzhp extends Handler {
    private final zzho zzbwk;

    public zzhp(Context context) {
        if (context.getApplicationContext() != null) {
            context = context.getApplicationContext();
        }
        this(new zzhq(context));
    }

    public zzhp(zzho com_google_android_gms_internal_zzho) {
        this.zzbwk = com_google_android_gms_internal_zzho;
    }

    private void zze(org.json.JSONObject r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = r4.zzbwk;	 Catch:{ Exception -> 0x0017 }
        r1 = "request_id";	 Catch:{ Exception -> 0x0017 }
        r1 = r5.getString(r1);	 Catch:{ Exception -> 0x0017 }
        r2 = "base_url";	 Catch:{ Exception -> 0x0017 }
        r2 = r5.getString(r2);	 Catch:{ Exception -> 0x0017 }
        r3 = "html";	 Catch:{ Exception -> 0x0017 }
        r5 = r5.getString(r3);	 Catch:{ Exception -> 0x0017 }
        r0.zza(r1, r2, r5);	 Catch:{ Exception -> 0x0017 }
    L_0x0017:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhp.zze(org.json.JSONObject):void");
    }

    public void handleMessage(android.os.Message r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r3 = r3.getData();	 Catch:{ Exception -> 0x0023 }
        if (r3 != 0) goto L_0x0007;	 Catch:{ Exception -> 0x0023 }
    L_0x0006:
        return;	 Catch:{ Exception -> 0x0023 }
    L_0x0007:
        r0 = new org.json.JSONObject;	 Catch:{ Exception -> 0x0023 }
        r1 = "data";	 Catch:{ Exception -> 0x0023 }
        r3 = r3.getString(r1);	 Catch:{ Exception -> 0x0023 }
        r0.<init>(r3);	 Catch:{ Exception -> 0x0023 }
        r3 = "fetch_html";	 Catch:{ Exception -> 0x0023 }
        r1 = "message_name";	 Catch:{ Exception -> 0x0023 }
        r1 = r0.getString(r1);	 Catch:{ Exception -> 0x0023 }
        r3 = r3.equals(r1);	 Catch:{ Exception -> 0x0023 }
        if (r3 == 0) goto L_0x0023;	 Catch:{ Exception -> 0x0023 }
    L_0x0020:
        r2.zze(r0);	 Catch:{ Exception -> 0x0023 }
    L_0x0023:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhp.handleMessage(android.os.Message):void");
    }
}
