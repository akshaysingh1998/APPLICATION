package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.security.NetworkSecurityPolicy;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.util.zzs;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.ads.dynamite.ModuleDescriptor;
import com.google.android.gms.internal.zzkj.zzb;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.Future;

@zzir
public class zzkb implements zzb {
    private Context mContext;
    private final Object zzail = new Object();
    private zzcg zzaju;
    private VersionInfoParcel zzalm;
    private boolean zzamr = false;
    private zzcn zzasi = null;
    private zzcm zzasj = null;
    private String zzbjj;
    private boolean zzcfj = true;
    private boolean zzcfk = true;
    private boolean zzcfs = false;
    private final String zzcjq;
    private final zzkc zzcjr;
    private BigInteger zzcjs = BigInteger.ONE;
    private final HashSet<zzjz> zzcjt = new HashSet();
    private final HashMap<String, zzke> zzcju = new HashMap();
    private boolean zzcjv = false;
    private int zzcjw = 0;
    private zzde zzcjx = null;
    private zzco zzcjy = null;
    private String zzcjz;
    private Boolean zzcka = null;
    private boolean zzckb = false;
    private boolean zzckc = false;
    private boolean zzckd = false;
    private String zzcke = "";
    private long zzckf = 0;

    public zzkb(zzkl com_google_android_gms_internal_zzkl) {
        this.zzcjq = com_google_android_gms_internal_zzkl.zztg();
        this.zzcjr = new zzkc(this.zzcjq);
    }

    public Resources getResources() {
        if (this.zzalm.zzcnq) {
            return this.mContext.getResources();
        }
        try {
            zzsj zza = zzsj.zza(this.mContext, zzsj.Mg, ModuleDescriptor.MODULE_ID);
            return zza != null ? zza.zzbcw().getResources() : null;
        } catch (Throwable e) {
            com.google.android.gms.ads.internal.util.client.zzb.zzd("Cannot load resource from dynamite apk or local jar", e);
            return null;
        }
    }

    public String getSessionId() {
        return this.zzcjq;
    }

    public Bundle zza(Context context, zzkd com_google_android_gms_internal_zzkd, String str) {
        Bundle bundle;
        synchronized (this.zzail) {
            bundle = new Bundle();
            bundle.putBundle("app", this.zzcjr.zzf(context, str));
            Bundle bundle2 = new Bundle();
            for (String str2 : this.zzcju.keySet()) {
                bundle2.putBundle(str2, ((zzke) this.zzcju.get(str2)).toBundle());
            }
            bundle.putBundle("slots", bundle2);
            ArrayList arrayList = new ArrayList();
            Iterator it = this.zzcjt.iterator();
            while (it.hasNext()) {
                arrayList.add(((zzjz) it.next()).toBundle());
            }
            bundle.putParcelableArrayList("ads", arrayList);
            com_google_android_gms_internal_zzkd.zza(this.zzcjt);
            this.zzcjt.clear();
        }
        return bundle;
    }

    public void zza(zzjz com_google_android_gms_internal_zzjz) {
        synchronized (this.zzail) {
            this.zzcjt.add(com_google_android_gms_internal_zzjz);
        }
    }

    public void zza(String str, zzke com_google_android_gms_internal_zzke) {
        synchronized (this.zzail) {
            this.zzcju.put(str, com_google_android_gms_internal_zzke);
        }
    }

    public void zza(Thread thread) {
        zziq.zza(this.mContext, thread, this.zzalm);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.android.gms.internal.zzco zzaa(android.content.Context r8) {
        /*
        r7 = this;
        r0 = com.google.android.gms.internal.zzdc.zzazf;
        r0 = r0.get();
        r0 = (java.lang.Boolean) r0;
        r0 = r0.booleanValue();
        r1 = 0;
        if (r0 == 0) goto L_0x006f;
    L_0x000f:
        r0 = com.google.android.gms.common.util.zzs.zzavm();
        if (r0 == 0) goto L_0x006f;
    L_0x0015:
        r0 = r7.zzsj();
        if (r0 == 0) goto L_0x001c;
    L_0x001b:
        return r1;
    L_0x001c:
        r0 = r7.zzail;
        monitor-enter(r0);
        r2 = android.os.Looper.getMainLooper();	 Catch:{ all -> 0x006c }
        if (r2 == 0) goto L_0x006a;
    L_0x0025:
        if (r8 != 0) goto L_0x0028;
    L_0x0027:
        goto L_0x006a;
    L_0x0028:
        r2 = r7.zzasi;	 Catch:{ all -> 0x006c }
        if (r2 != 0) goto L_0x003e;
    L_0x002c:
        r2 = r8.getApplicationContext();	 Catch:{ all -> 0x006c }
        r2 = (android.app.Application) r2;	 Catch:{ all -> 0x006c }
        r3 = new com.google.android.gms.internal.zzcn;	 Catch:{ all -> 0x006c }
        if (r2 != 0) goto L_0x0039;
    L_0x0036:
        r2 = r8;
        r2 = (android.app.Application) r2;	 Catch:{ all -> 0x006c }
    L_0x0039:
        r3.<init>(r2, r8);	 Catch:{ all -> 0x006c }
        r7.zzasi = r3;	 Catch:{ all -> 0x006c }
    L_0x003e:
        r8 = r7.zzasj;	 Catch:{ all -> 0x006c }
        if (r8 != 0) goto L_0x0049;
    L_0x0042:
        r8 = new com.google.android.gms.internal.zzcm;	 Catch:{ all -> 0x006c }
        r8.<init>();	 Catch:{ all -> 0x006c }
        r7.zzasj = r8;	 Catch:{ all -> 0x006c }
    L_0x0049:
        r8 = r7.zzcjy;	 Catch:{ all -> 0x006c }
        if (r8 != 0) goto L_0x0061;
    L_0x004d:
        r8 = new com.google.android.gms.internal.zzco;	 Catch:{ all -> 0x006c }
        r2 = r7.zzasi;	 Catch:{ all -> 0x006c }
        r3 = r7.zzasj;	 Catch:{ all -> 0x006c }
        r4 = new com.google.android.gms.internal.zziq;	 Catch:{ all -> 0x006c }
        r5 = r7.mContext;	 Catch:{ all -> 0x006c }
        r6 = r7.zzalm;	 Catch:{ all -> 0x006c }
        r4.<init>(r5, r6, r1, r1);	 Catch:{ all -> 0x006c }
        r8.<init>(r2, r3, r4);	 Catch:{ all -> 0x006c }
        r7.zzcjy = r8;	 Catch:{ all -> 0x006c }
    L_0x0061:
        r8 = r7.zzcjy;	 Catch:{ all -> 0x006c }
        r8.zzhz();	 Catch:{ all -> 0x006c }
        r8 = r7.zzcjy;	 Catch:{ all -> 0x006c }
        monitor-exit(r0);	 Catch:{ all -> 0x006c }
        return r8;
    L_0x006a:
        monitor-exit(r0);	 Catch:{ all -> 0x006c }
        return r1;
    L_0x006c:
        r8 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x006c }
        throw r8;
    L_0x006f:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkb.zzaa(android.content.Context):com.google.android.gms.internal.zzco");
    }

    public void zzae(boolean z) {
        synchronized (this.zzail) {
            if (this.zzcfk != z) {
                zzkj.zze(this.mContext, z);
            }
            this.zzcfk = z;
            zzco zzaa = zzaa(this.mContext);
            if (!(zzaa == null || zzaa.isAlive())) {
                com.google.android.gms.ads.internal.util.client.zzb.zzcx("start fetching content...");
                zzaa.zzhz();
            }
        }
    }

    public void zzaf(boolean z) {
        this.zzckd = z;
    }

    public void zzag(boolean z) {
        synchronized (this.zzail) {
            this.zzckb = z;
        }
    }

    @TargetApi(23)
    public void zzb(Context context, VersionInfoParcel versionInfoParcel) {
        synchronized (this.zzail) {
            if (!this.zzamr) {
                this.mContext = context.getApplicationContext();
                this.zzalm = versionInfoParcel;
                zzkj.zza(context, this);
                zzkj.zzb(context, this);
                zzkj.zzc(context, (zzb) this);
                zzkj.zzd(context, this);
                zzkj.zze(context, (zzb) this);
                zzkj.zzf(context, (zzb) this);
                zza(Thread.currentThread());
                this.zzbjj = zzu.zzfq().zzh(context, versionInfoParcel.zzcs);
                if (zzs.zzavt() && !NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted()) {
                    this.zzckc = true;
                }
                this.zzaju = new zzcg(context.getApplicationContext(), this.zzalm, zzu.zzfq().zzc(context, versionInfoParcel));
                zzsx();
                zzu.zzga().zzt(this.mContext);
                this.zzamr = true;
            }
        }
    }

    public void zzb(Boolean bool) {
        synchronized (this.zzail) {
            this.zzcka = bool;
        }
    }

    public void zzb(Throwable th, boolean z) {
        new zziq(this.mContext, this.zzalm, null, null).zza(th, z);
    }

    public void zzb(HashSet<zzjz> hashSet) {
        synchronized (this.zzail) {
            this.zzcjt.addAll(hashSet);
        }
    }

    public Future zzc(Context context, boolean z) {
        synchronized (this.zzail) {
            if (z != this.zzcfj) {
                this.zzcfj = z;
                Future zzc = zzkj.zzc(context, z);
                return zzc;
            }
            return null;
        }
    }

    public Future zzcn(String str) {
        synchronized (this.zzail) {
            if (str != null) {
                if (!str.equals(this.zzcjz)) {
                    this.zzcjz = str;
                    Future zzg = zzkj.zzg(this.mContext, str);
                    return zzg;
                }
            }
            return null;
        }
    }

    public Future zzd(Context context, boolean z) {
        synchronized (this.zzail) {
            if (z != this.zzcfs) {
                this.zzcfs = z;
                Future zzf = zzkj.zzf(context, z);
                return zzf;
            }
            return null;
        }
    }

    public Future zze(Context context, String str) {
        this.zzckf = zzu.zzfu().currentTimeMillis();
        synchronized (this.zzail) {
            if (str != null) {
                if (!str.equals(this.zzcke)) {
                    this.zzcke = str;
                    Future zza = zzkj.zza(context, str, this.zzckf);
                    return zza;
                }
            }
            return null;
        }
    }

    public void zzg(Bundle bundle) {
        synchronized (this.zzail) {
            this.zzcfj = bundle.containsKey("use_https") ? bundle.getBoolean("use_https") : this.zzcfj;
            this.zzcjw = bundle.containsKey("webview_cache_version") ? bundle.getInt("webview_cache_version") : this.zzcjw;
            if (bundle.containsKey("content_url_opted_out")) {
                zzae(bundle.getBoolean("content_url_opted_out"));
            }
            if (bundle.containsKey("content_url_hashes")) {
                this.zzcjz = bundle.getString("content_url_hashes");
            }
            this.zzcfs = bundle.containsKey("auto_collect_location") ? bundle.getBoolean("auto_collect_location") : this.zzcfs;
            this.zzcke = bundle.containsKey("app_settings_json") ? bundle.getString("app_settings_json") : this.zzcke;
            this.zzckf = bundle.containsKey("app_settings_last_update_ms") ? bundle.getLong("app_settings_last_update_ms") : 0;
        }
    }

    public boolean zzsj() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcfk;
        }
        return z;
    }

    public String zzsk() {
        String bigInteger;
        synchronized (this.zzail) {
            bigInteger = this.zzcjs.toString();
            this.zzcjs = this.zzcjs.add(BigInteger.ONE);
        }
        return bigInteger;
    }

    public zzkc zzsl() {
        zzkc com_google_android_gms_internal_zzkc;
        synchronized (this.zzail) {
            com_google_android_gms_internal_zzkc = this.zzcjr;
        }
        return com_google_android_gms_internal_zzkc;
    }

    public zzde zzsm() {
        zzde com_google_android_gms_internal_zzde;
        synchronized (this.zzail) {
            com_google_android_gms_internal_zzde = this.zzcjx;
        }
        return com_google_android_gms_internal_zzde;
    }

    public boolean zzsn() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcjv;
            this.zzcjv = true;
        }
        return z;
    }

    public boolean zzso() {
        boolean z;
        synchronized (this.zzail) {
            if (!this.zzcfj) {
                if (!this.zzckc) {
                    z = false;
                }
            }
            z = true;
        }
        return z;
    }

    public String zzsp() {
        String str;
        synchronized (this.zzail) {
            str = this.zzbjj;
        }
        return str;
    }

    public String zzsq() {
        String str;
        synchronized (this.zzail) {
            str = this.zzcjz;
        }
        return str;
    }

    public Boolean zzsr() {
        Boolean bool;
        synchronized (this.zzail) {
            bool = this.zzcka;
        }
        return bool;
    }

    public boolean zzss() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcfs;
        }
        return z;
    }

    public boolean zzst() {
        return this.zzckd;
    }

    public zzka zzsu() {
        zzka com_google_android_gms_internal_zzka;
        synchronized (this.zzail) {
            com_google_android_gms_internal_zzka = new zzka(this.zzcke, this.zzckf);
        }
        return com_google_android_gms_internal_zzka;
    }

    public zzcg zzsv() {
        return this.zzaju;
    }

    public boolean zzsw() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzckb;
        }
        return z;
    }

    void zzsx() {
        try {
            this.zzcjx = zzu.zzfv().zza(new zzdd(this.mContext, this.zzalm.zzcs));
        } catch (Throwable e) {
            com.google.android.gms.ads.internal.util.client.zzb.zzd("Cannot initialize CSI reporter.", e);
        }
    }
}
