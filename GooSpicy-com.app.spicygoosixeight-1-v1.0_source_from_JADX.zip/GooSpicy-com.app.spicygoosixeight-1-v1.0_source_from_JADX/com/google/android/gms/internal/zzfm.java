package com.google.android.gms.internal;

import android.os.Handler;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzl;
import com.google.android.gms.ads.internal.zzu;
import java.util.LinkedList;
import java.util.List;

@zzir
class zzfm {
    private final List<zza> zzala = new LinkedList();

    interface zza {
        void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException;
    }

    class C10991 extends com.google.android.gms.ads.internal.client.zzq.zza {
        final /* synthetic */ zzfm zzbjx;

        class C08971 implements zza {
            final /* synthetic */ C10991 zzbjy;

            C08971(C10991 c10991) {
                this.zzbjy = c10991;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzald != null) {
                    com_google_android_gms_internal_zzfn.zzald.onAdClosed();
                }
                zzu.zzgb().zzlq();
            }
        }

        class C08993 implements zza {
            final /* synthetic */ C10991 zzbjy;

            C08993(C10991 c10991) {
                this.zzbjy = c10991;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzald != null) {
                    com_google_android_gms_internal_zzfn.zzald.onAdLeftApplication();
                }
            }
        }

        class C09004 implements zza {
            final /* synthetic */ C10991 zzbjy;

            C09004(C10991 c10991) {
                this.zzbjy = c10991;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzald != null) {
                    com_google_android_gms_internal_zzfn.zzald.onAdLoaded();
                }
            }
        }

        class C09015 implements zza {
            final /* synthetic */ C10991 zzbjy;

            C09015(C10991 c10991) {
                this.zzbjy = c10991;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzald != null) {
                    com_google_android_gms_internal_zzfn.zzald.onAdOpened();
                }
            }
        }

        C10991(zzfm com_google_android_gms_internal_zzfm) {
            this.zzbjx = com_google_android_gms_internal_zzfm;
        }

        public void onAdClosed() throws RemoteException {
            this.zzbjx.zzala.add(new C08971(this));
        }

        public void onAdFailedToLoad(final int i) throws RemoteException {
            this.zzbjx.zzala.add(new zza(this) {
                final /* synthetic */ C10991 zzbjy;

                public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                    if (com_google_android_gms_internal_zzfn.zzald != null) {
                        com_google_android_gms_internal_zzfn.zzald.onAdFailedToLoad(i);
                    }
                }
            });
            zzkh.m83v("Pooled interstitial failed to load.");
        }

        public void onAdLeftApplication() throws RemoteException {
            this.zzbjx.zzala.add(new C08993(this));
        }

        public void onAdLoaded() throws RemoteException {
            this.zzbjx.zzala.add(new C09004(this));
            zzkh.m83v("Pooled interstitial loaded.");
        }

        public void onAdOpened() throws RemoteException {
            this.zzbjx.zzala.add(new C09015(this));
        }
    }

    class C11002 extends com.google.android.gms.ads.internal.client.zzw.zza {
        final /* synthetic */ zzfm zzbjx;

        C11002(zzfm com_google_android_gms_internal_zzfm) {
            this.zzbjx = com_google_android_gms_internal_zzfm;
        }

        public void onAppEvent(final String str, final String str2) throws RemoteException {
            this.zzbjx.zzala.add(new zza(this) {
                final /* synthetic */ C11002 zzbkb;

                public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                    if (com_google_android_gms_internal_zzfn.zzbkl != null) {
                        com_google_android_gms_internal_zzfn.zzbkl.onAppEvent(str, str2);
                    }
                }
            });
        }
    }

    class C11013 extends com.google.android.gms.internal.zzhs.zza {
        final /* synthetic */ zzfm zzbjx;

        C11013(zzfm com_google_android_gms_internal_zzfm) {
            this.zzbjx = com_google_android_gms_internal_zzfm;
        }

        public void zza(final zzhr com_google_android_gms_internal_zzhr) throws RemoteException {
            this.zzbjx.zzala.add(new zza(this) {
                final /* synthetic */ C11013 zzbkd;

                public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                    if (com_google_android_gms_internal_zzfn.zzbkm != null) {
                        com_google_android_gms_internal_zzfn.zzbkm.zza(com_google_android_gms_internal_zzhr);
                    }
                }
            });
        }
    }

    class C11024 extends com.google.android.gms.internal.zzdo.zza {
        final /* synthetic */ zzfm zzbjx;

        C11024(zzfm com_google_android_gms_internal_zzfm) {
            this.zzbjx = com_google_android_gms_internal_zzfm;
        }

        public void zza(final zzdn com_google_android_gms_internal_zzdn) throws RemoteException {
            this.zzbjx.zzala.add(new zza(this) {
                final /* synthetic */ C11024 zzbkf;

                public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                    if (com_google_android_gms_internal_zzfn.zzbkn != null) {
                        com_google_android_gms_internal_zzfn.zzbkn.zza(com_google_android_gms_internal_zzdn);
                    }
                }
            });
        }
    }

    class C11035 extends com.google.android.gms.ads.internal.client.zzp.zza {
        final /* synthetic */ zzfm zzbjx;

        class C09051 implements zza {
            final /* synthetic */ C11035 zzbkg;

            C09051(C11035 c11035) {
                this.zzbkg = c11035;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzbko != null) {
                    com_google_android_gms_internal_zzfn.zzbko.onAdClicked();
                }
            }
        }

        C11035(zzfm com_google_android_gms_internal_zzfm) {
            this.zzbjx = com_google_android_gms_internal_zzfm;
        }

        public void onAdClicked() throws RemoteException {
            this.zzbjx.zzala.add(new C09051(this));
        }
    }

    class C11046 extends com.google.android.gms.ads.internal.reward.client.zzd.zza {
        final /* synthetic */ zzfm zzbjx;

        class C09061 implements zza {
            final /* synthetic */ C11046 zzbkh;

            C09061(C11046 c11046) {
                this.zzbkh = c11046;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzbkp != null) {
                    com_google_android_gms_internal_zzfn.zzbkp.onRewardedVideoAdLoaded();
                }
            }
        }

        class C09072 implements zza {
            final /* synthetic */ C11046 zzbkh;

            C09072(C11046 c11046) {
                this.zzbkh = c11046;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzbkp != null) {
                    com_google_android_gms_internal_zzfn.zzbkp.onRewardedVideoAdOpened();
                }
            }
        }

        class C09083 implements zza {
            final /* synthetic */ C11046 zzbkh;

            C09083(C11046 c11046) {
                this.zzbkh = c11046;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzbkp != null) {
                    com_google_android_gms_internal_zzfn.zzbkp.onRewardedVideoStarted();
                }
            }
        }

        class C09094 implements zza {
            final /* synthetic */ C11046 zzbkh;

            C09094(C11046 c11046) {
                this.zzbkh = c11046;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzbkp != null) {
                    com_google_android_gms_internal_zzfn.zzbkp.onRewardedVideoAdClosed();
                }
            }
        }

        class C09116 implements zza {
            final /* synthetic */ C11046 zzbkh;

            C09116(C11046 c11046) {
                this.zzbkh = c11046;
            }

            public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                if (com_google_android_gms_internal_zzfn.zzbkp != null) {
                    com_google_android_gms_internal_zzfn.zzbkp.onRewardedVideoAdLeftApplication();
                }
            }
        }

        C11046(zzfm com_google_android_gms_internal_zzfm) {
            this.zzbjx = com_google_android_gms_internal_zzfm;
        }

        public void onRewardedVideoAdClosed() throws RemoteException {
            this.zzbjx.zzala.add(new C09094(this));
        }

        public void onRewardedVideoAdFailedToLoad(final int i) throws RemoteException {
            this.zzbjx.zzala.add(new zza(this) {
                final /* synthetic */ C11046 zzbkh;

                public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                    if (com_google_android_gms_internal_zzfn.zzbkp != null) {
                        com_google_android_gms_internal_zzfn.zzbkp.onRewardedVideoAdFailedToLoad(i);
                    }
                }
            });
        }

        public void onRewardedVideoAdLeftApplication() throws RemoteException {
            this.zzbjx.zzala.add(new C09116(this));
        }

        public void onRewardedVideoAdLoaded() throws RemoteException {
            this.zzbjx.zzala.add(new C09061(this));
        }

        public void onRewardedVideoAdOpened() throws RemoteException {
            this.zzbjx.zzala.add(new C09072(this));
        }

        public void onRewardedVideoStarted() throws RemoteException {
            this.zzbjx.zzala.add(new C09083(this));
        }

        public void zza(final com.google.android.gms.ads.internal.reward.client.zza com_google_android_gms_ads_internal_reward_client_zza) throws RemoteException {
            this.zzbjx.zzala.add(new zza(this) {
                final /* synthetic */ C11046 zzbkh;

                public void zzb(zzfn com_google_android_gms_internal_zzfn) throws RemoteException {
                    if (com_google_android_gms_internal_zzfn.zzbkp != null) {
                        com_google_android_gms_internal_zzfn.zzbkp.zza(com_google_android_gms_ads_internal_reward_client_zza);
                    }
                }
            });
        }
    }

    zzfm() {
    }

    void zza(final zzfn com_google_android_gms_internal_zzfn) {
        Handler handler = zzkl.zzclg;
        for (final zza com_google_android_gms_internal_zzfm_zza : this.zzala) {
            handler.post(new Runnable(this) {
                final /* synthetic */ zzfm zzbjx;

                public void run() {
                    try {
                        com_google_android_gms_internal_zzfm_zza.zzb(com_google_android_gms_internal_zzfn);
                    } catch (Throwable e) {
                        zzb.zzd("Could not propagate interstitial ad event.", e);
                    }
                }
            });
        }
    }

    void zzc(zzl com_google_android_gms_ads_internal_zzl) {
        com_google_android_gms_ads_internal_zzl.zza(new C10991(this));
        com_google_android_gms_ads_internal_zzl.zza(new C11002(this));
        com_google_android_gms_ads_internal_zzl.zza(new C11013(this));
        com_google_android_gms_ads_internal_zzl.zza(new C11024(this));
        com_google_android_gms_ads_internal_zzl.zza(new C11035(this));
        com_google_android_gms_ads_internal_zzl.zza(new C11046(this));
    }
}
