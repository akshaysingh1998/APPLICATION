package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.SystemClock;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.zzu;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

@zzir
public class zzjz {
    private final Object zzail;
    private final zzkb zzanz;
    private boolean zzcfe;
    private final LinkedList<zza> zzciv;
    private final String zzciw;
    private final String zzcix;
    private long zzciy;
    private long zzciz;
    private long zzcja;
    private long zzcjb;
    private long zzcjc;
    private long zzcjd;

    @zzir
    private static final class zza {
        private long zzcje = -1;
        private long zzcjf = -1;

        public Bundle toBundle() {
            Bundle bundle = new Bundle();
            bundle.putLong("topen", this.zzcje);
            bundle.putLong("tclose", this.zzcjf);
            return bundle;
        }

        public long zzsc() {
            return this.zzcjf;
        }

        public void zzsd() {
            this.zzcjf = SystemClock.elapsedRealtime();
        }

        public void zzse() {
            this.zzcje = SystemClock.elapsedRealtime();
        }
    }

    public zzjz(zzkb com_google_android_gms_internal_zzkb, String str, String str2) {
        this.zzail = new Object();
        this.zzciy = -1;
        this.zzciz = -1;
        this.zzcfe = false;
        this.zzcja = -1;
        this.zzcjb = 0;
        this.zzcjc = -1;
        this.zzcjd = -1;
        this.zzanz = com_google_android_gms_internal_zzkb;
        this.zzciw = str;
        this.zzcix = str2;
        this.zzciv = new LinkedList();
    }

    public zzjz(String str, String str2) {
        this(zzu.zzft(), str, str2);
    }

    public Bundle toBundle() {
        Bundle bundle;
        synchronized (this.zzail) {
            bundle = new Bundle();
            bundle.putString("seq_num", this.zzciw);
            bundle.putString("slotid", this.zzcix);
            bundle.putBoolean("ismediation", this.zzcfe);
            bundle.putLong("treq", this.zzcjc);
            bundle.putLong("tresponse", this.zzcjd);
            bundle.putLong("timp", this.zzciz);
            bundle.putLong("tload", this.zzcja);
            bundle.putLong("pcc", this.zzcjb);
            bundle.putLong("tfetch", this.zzciy);
            ArrayList arrayList = new ArrayList();
            Iterator it = this.zzciv.iterator();
            while (it.hasNext()) {
                arrayList.add(((zza) it.next()).toBundle());
            }
            bundle.putParcelableArrayList("tclick", arrayList);
        }
        return bundle;
    }

    public void zzac(boolean z) {
        synchronized (this.zzail) {
            if (this.zzcjd != -1) {
                this.zzcja = SystemClock.elapsedRealtime();
                if (!z) {
                    this.zzciz = this.zzcja;
                    this.zzanz.zza(this);
                }
            }
        }
    }

    public void zzad(boolean z) {
        synchronized (this.zzail) {
            if (this.zzcjd != -1) {
                this.zzcfe = z;
                this.zzanz.zza(this);
            }
        }
    }

    public void zzl(long j) {
        synchronized (this.zzail) {
            this.zzcjd = j;
            if (this.zzcjd != -1) {
                this.zzanz.zza(this);
            }
        }
    }

    public void zzm(long j) {
        synchronized (this.zzail) {
            if (this.zzcjd != -1) {
                this.zzciy = j;
                this.zzanz.zza(this);
            }
        }
    }

    public void zzq(AdRequestParcel adRequestParcel) {
        synchronized (this.zzail) {
            this.zzcjc = SystemClock.elapsedRealtime();
            this.zzanz.zzsl().zzb(adRequestParcel, this.zzcjc);
        }
    }

    public void zzrz() {
        synchronized (this.zzail) {
            if (this.zzcjd != -1 && this.zzciz == -1) {
                this.zzciz = SystemClock.elapsedRealtime();
                this.zzanz.zza(this);
            }
            this.zzanz.zzsl().zzrz();
        }
    }

    public void zzsa() {
        synchronized (this.zzail) {
            if (this.zzcjd != -1) {
                zza com_google_android_gms_internal_zzjz_zza = new zza();
                com_google_android_gms_internal_zzjz_zza.zzse();
                this.zzciv.add(com_google_android_gms_internal_zzjz_zza);
                this.zzcjb++;
                this.zzanz.zzsl().zzsa();
                this.zzanz.zza(this);
            }
        }
    }

    public void zzsb() {
        synchronized (this.zzail) {
            if (!(this.zzcjd == -1 || this.zzciv.isEmpty())) {
                zza com_google_android_gms_internal_zzjz_zza = (zza) this.zzciv.getLast();
                if (com_google_android_gms_internal_zzjz_zza.zzsc() == -1) {
                    com_google_android_gms_internal_zzjz_zza.zzsd();
                    this.zzanz.zza(this);
                }
            }
        }
    }
}
