package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.zzae.zza;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class zzar extends zzaq {
    private static final String TAG = "zzar";

    protected zzar(Context context, String str, boolean z) {
        super(context, str, z);
    }

    public static zzar zza(String str, Context context, boolean z) {
        zzaq.zza(context, z);
        return new zzar(context, str, z);
    }

    protected List<Callable<Void>> zzb(zzax com_google_android_gms_internal_zzax, zza com_google_android_gms_internal_zzae_zza) {
        if (com_google_android_gms_internal_zzax.zzce() != null) {
            if (this.zzafn) {
                int zzau = com_google_android_gms_internal_zzax.zzau();
                List<Callable<Void>> arrayList = new ArrayList();
                arrayList.addAll(super.zzb(com_google_android_gms_internal_zzax, com_google_android_gms_internal_zzae_zza));
                arrayList.add(new zzbh(com_google_android_gms_internal_zzax, zzav.zzbm(), zzav.zzbn(), com_google_android_gms_internal_zzae_zza, zzau, 24));
                return arrayList;
            }
        }
        return super.zzb(com_google_android_gms_internal_zzax, com_google_android_gms_internal_zzae_zza);
    }
}
