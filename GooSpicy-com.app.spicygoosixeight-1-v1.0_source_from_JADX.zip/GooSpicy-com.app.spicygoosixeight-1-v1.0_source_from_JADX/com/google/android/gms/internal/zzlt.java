package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.bumptech.glide.load.Key;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@TargetApi(11)
@zzir
public class zzlt extends zzlm {
    public zzlt(zzll com_google_android_gms_internal_zzll, boolean z) {
        super(com_google_android_gms_internal_zzll, z);
    }

    public WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
        if (this.zzcow != null) {
            this.zzcow.zzck(str);
        }
        String str2;
        try {
            if (!"mraid.js".equalsIgnoreCase(new File(str).getName())) {
                return super.shouldInterceptRequest(webView, str);
            }
            if (webView instanceof zzll) {
                zzll com_google_android_gms_internal_zzll = (zzll) webView;
                com_google_android_gms_internal_zzll.zzuk().zznz();
                Object obj = com_google_android_gms_internal_zzll.zzdo().zzauq ? zzdc.zzazb.get() : com_google_android_gms_internal_zzll.zzuo() ? zzdc.zzaza.get() : zzdc.zzayz.get();
                str2 = (String) obj;
                StringBuilder stringBuilder = new StringBuilder(24 + String.valueOf(str2).length());
                stringBuilder.append("shouldInterceptRequest(");
                stringBuilder.append(str2);
                stringBuilder.append(")");
                zzkh.m83v(stringBuilder.toString());
                return zzd(com_google_android_gms_internal_zzll.getContext(), this.zzbgj.zzun().zzcs, str2);
            }
            zzb.zzcy("Tried to intercept request from a WebView that wasn't an AdWebView.");
            return super.shouldInterceptRequest(webView, str);
        } catch (Exception e) {
            str2 = "Could not fetch MRAID JS. ";
            String valueOf = String.valueOf(e.getMessage());
            zzb.zzcy(valueOf.length() == 0 ? new String(str2) : str2.concat(valueOf));
            return super.shouldInterceptRequest(webView, str);
        }
    }

    protected WebResourceResponse zzd(Context context, String str, String str2) throws IOException, ExecutionException, InterruptedException, TimeoutException {
        Map hashMap = new HashMap();
        hashMap.put("User-Agent", zzu.zzfq().zzh(context, str));
        hashMap.put("Cache-Control", "max-stale=3600");
        String str3 = (String) new zzkr(context).zzb(str2, hashMap).get(60, TimeUnit.SECONDS);
        return str3 == null ? null : new WebResourceResponse("application/javascript", Key.STRING_CHARSET_NAME, new ByteArrayInputStream(str3.getBytes(Key.STRING_CHARSET_NAME)));
    }
}
