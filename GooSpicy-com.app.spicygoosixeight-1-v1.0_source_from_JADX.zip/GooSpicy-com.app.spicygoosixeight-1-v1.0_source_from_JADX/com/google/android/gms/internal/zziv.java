package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.internal.zzfw.zzc;
import java.util.Map;
import java.util.concurrent.Future;

@zzir
public final class zziv {
    private final Object zzail = new Object();
    private String zzbvu;
    private String zzceq;
    private zzkz<zziy> zzcer = new zzkz();
    zzc zzces;
    public final zzet zzcet = new C09401(this);
    public final zzet zzceu = new C09412(this);
    public final zzet zzcev = new C09423(this);

    class C09401 implements zzet {
        final /* synthetic */ zziv zzcew;

        C09401(zziv com_google_android_gms_internal_zziv) {
            this.zzcew = com_google_android_gms_internal_zziv;
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            synchronized (this.zzcew.zzail) {
                if (this.zzcew.zzcer.isDone()) {
                } else if (this.zzcew.zzbvu.equals(map.get("request_id"))) {
                    zziy com_google_android_gms_internal_zziy = new zziy(1, map);
                    String valueOf = String.valueOf(com_google_android_gms_internal_zziy.getType());
                    String valueOf2 = String.valueOf(com_google_android_gms_internal_zziy.zzrk());
                    StringBuilder stringBuilder = new StringBuilder((24 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length());
                    stringBuilder.append("Invalid ");
                    stringBuilder.append(valueOf);
                    stringBuilder.append(" request error: ");
                    stringBuilder.append(valueOf2);
                    zzb.zzcy(stringBuilder.toString());
                    this.zzcew.zzcer.zzi(com_google_android_gms_internal_zziy);
                }
            }
        }
    }

    class C09412 implements zzet {
        final /* synthetic */ zziv zzcew;

        C09412(zziv com_google_android_gms_internal_zziv) {
            this.zzcew = com_google_android_gms_internal_zziv;
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            synchronized (this.zzcew.zzail) {
                if (this.zzcew.zzcer.isDone()) {
                    return;
                }
                zziy com_google_android_gms_internal_zziy = new zziy(-2, map);
                if (this.zzcew.zzbvu.equals(com_google_android_gms_internal_zziy.getRequestId())) {
                    String url = com_google_android_gms_internal_zziy.getUrl();
                    if (url == null) {
                        zzb.zzcy("URL missing in loadAdUrl GMSG.");
                        return;
                    }
                    if (url.contains("%40mediation_adapters%40")) {
                        String replaceAll = url.replaceAll("%40mediation_adapters%40", zzkf.zza(com_google_android_gms_internal_zzll.getContext(), (String) map.get("check_adapters"), this.zzcew.zzceq));
                        com_google_android_gms_internal_zziy.setUrl(replaceAll);
                        String str = "Ad request URL modified to ";
                        replaceAll = String.valueOf(replaceAll);
                        zzkh.m83v(replaceAll.length() != 0 ? str.concat(replaceAll) : new String(str));
                    }
                    this.zzcew.zzcer.zzi(com_google_android_gms_internal_zziy);
                    return;
                }
            }
        }
    }

    class C09423 implements zzet {
        final /* synthetic */ zziv zzcew;

        C09423(zziv com_google_android_gms_internal_zziv) {
            this.zzcew = com_google_android_gms_internal_zziv;
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            synchronized (this.zzcew.zzail) {
                if (this.zzcew.zzcer.isDone()) {
                    return;
                }
                zziy com_google_android_gms_internal_zziy = new zziy(-2, map);
                if (this.zzcew.zzbvu.equals(com_google_android_gms_internal_zziy.getRequestId())) {
                    com_google_android_gms_internal_zziy.zzrn();
                    this.zzcew.zzcer.zzi(com_google_android_gms_internal_zziy);
                    return;
                }
            }
        }
    }

    public zziv(String str, String str2) {
        this.zzceq = str2;
        this.zzbvu = str;
    }

    public void zzb(zzc com_google_android_gms_internal_zzfw_zzc) {
        this.zzces = com_google_android_gms_internal_zzfw_zzc;
    }

    public zzc zzrh() {
        return this.zzces;
    }

    public Future<zziy> zzri() {
        return this.zzcer;
    }

    public void zzrj() {
    }
}
