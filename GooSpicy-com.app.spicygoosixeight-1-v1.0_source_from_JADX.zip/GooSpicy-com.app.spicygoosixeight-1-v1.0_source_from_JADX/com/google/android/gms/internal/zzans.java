package com.google.android.gms.internal;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public final class zzans {
    private final Map<Type, zzamu<?>> ben;

    class C08402 implements zzanx<T> {
        final /* synthetic */ zzans beP;

        C08402(zzans com_google_android_gms_internal_zzans) {
            this.beP = com_google_android_gms_internal_zzans;
        }

        public T mo2294a() {
            return new LinkedHashMap();
        }
    }

    class C08413 implements zzanx<T> {
        final /* synthetic */ zzans beP;

        C08413(zzans com_google_android_gms_internal_zzans) {
            this.beP = com_google_android_gms_internal_zzans;
        }

        public T mo2294a() {
            return new zzanw();
        }
    }

    class C08457 implements zzanx<T> {
        final /* synthetic */ zzans beP;

        C08457(zzans com_google_android_gms_internal_zzans) {
            this.beP = com_google_android_gms_internal_zzans;
        }

        public T mo2294a() {
            return new TreeSet();
        }
    }

    class C08479 implements zzanx<T> {
        final /* synthetic */ zzans beP;

        C08479(zzans com_google_android_gms_internal_zzans) {
            this.beP = com_google_android_gms_internal_zzans;
        }

        public T mo2294a() {
            return new LinkedHashSet();
        }
    }

    public zzans(Map<Type, zzamu<?>> map) {
        this.ben = map;
    }

    private <T> zzanx<T> zzc(final Type type, Class<? super T> cls) {
        return Collection.class.isAssignableFrom(cls) ? SortedSet.class.isAssignableFrom(cls) ? new C08457(this) : EnumSet.class.isAssignableFrom(cls) ? new zzanx<T>(this) {
            final /* synthetic */ zzans beP;

            public T mo2294a() {
                if (type instanceof ParameterizedType) {
                    Type type = ((ParameterizedType) type).getActualTypeArguments()[0];
                    if (type instanceof Class) {
                        return EnumSet.noneOf((Class) type);
                    }
                    String str = "Invalid EnumSet type: ";
                    String valueOf = String.valueOf(type.toString());
                    throw new zzamz(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                }
                str = "Invalid EnumSet type: ";
                valueOf = String.valueOf(type.toString());
                throw new zzamz(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            }
        } : Set.class.isAssignableFrom(cls) ? new C08479(this) : Queue.class.isAssignableFrom(cls) ? new zzanx<T>(this) {
            final /* synthetic */ zzans beP;

            {
                this.beP = r1;
            }

            public T mo2294a() {
                return new LinkedList();
            }
        } : new zzanx<T>(this) {
            final /* synthetic */ zzans beP;

            {
                this.beP = r1;
            }

            public T mo2294a() {
                return new ArrayList();
            }
        } : Map.class.isAssignableFrom(cls) ? SortedMap.class.isAssignableFrom(cls) ? new zzanx<T>(this) {
            final /* synthetic */ zzans beP;

            {
                this.beP = r1;
            }

            public T mo2294a() {
                return new TreeMap();
            }
        } : (!(type instanceof ParameterizedType) || String.class.isAssignableFrom(zzaoo.zzl(((ParameterizedType) type).getActualTypeArguments()[0]).m15s())) ? new C08413(this) : new C08402(this) : null;
    }

    private <T> zzanx<T> zzd(final Type type, final Class<? super T> cls) {
        return new zzanx<T>(this) {
            final /* synthetic */ zzans beP;
            private final zzaoa beQ = zzaoa.m14f();

            public T mo2294a() {
                try {
                    return this.beQ.zzf(cls);
                } catch (Throwable e) {
                    String valueOf = String.valueOf(type);
                    StringBuilder stringBuilder = new StringBuilder(116 + String.valueOf(valueOf).length());
                    stringBuilder.append("Unable to invoke no-args constructor for ");
                    stringBuilder.append(valueOf);
                    stringBuilder.append(". ");
                    stringBuilder.append("Register an InstanceCreator with Gson for this type may fix this problem.");
                    throw new RuntimeException(stringBuilder.toString(), e);
                }
            }
        };
    }

    private <T> com.google.android.gms.internal.zzanx<T> zzl(java.lang.Class<? super T> r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = 0;
        r0 = new java.lang.Class[r0];	 Catch:{ NoSuchMethodException -> 0x0017 }
        r2 = r2.getDeclaredConstructor(r0);	 Catch:{ NoSuchMethodException -> 0x0017 }
        r0 = r2.isAccessible();	 Catch:{ NoSuchMethodException -> 0x0017 }
        if (r0 != 0) goto L_0x0011;	 Catch:{ NoSuchMethodException -> 0x0017 }
    L_0x000d:
        r0 = 1;	 Catch:{ NoSuchMethodException -> 0x0017 }
        r2.setAccessible(r0);	 Catch:{ NoSuchMethodException -> 0x0017 }
    L_0x0011:
        r0 = new com.google.android.gms.internal.zzans$6;	 Catch:{ NoSuchMethodException -> 0x0017 }
        r0.<init>(r1, r2);	 Catch:{ NoSuchMethodException -> 0x0017 }
        return r0;
    L_0x0017:
        r2 = 0;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzans.zzl(java.lang.Class):com.google.android.gms.internal.zzanx<T>");
    }

    public String toString() {
        return this.ben.toString();
    }

    public <T> zzanx<T> zzb(zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
        final Type t = com_google_android_gms_internal_zzaoo_T.m16t();
        Class s = com_google_android_gms_internal_zzaoo_T.m15s();
        final zzamu com_google_android_gms_internal_zzamu = (zzamu) this.ben.get(t);
        if (com_google_android_gms_internal_zzamu != null) {
            return new zzanx<T>(this) {
                final /* synthetic */ zzans beP;

                public T mo2294a() {
                    return com_google_android_gms_internal_zzamu.zza(t);
                }
            };
        }
        com_google_android_gms_internal_zzamu = (zzamu) this.ben.get(s);
        if (com_google_android_gms_internal_zzamu != null) {
            return new zzanx<T>(this) {
                final /* synthetic */ zzans beP;

                public T mo2294a() {
                    return com_google_android_gms_internal_zzamu.zza(t);
                }
            };
        }
        zzanx<T> zzl = zzl(s);
        if (zzl != null) {
            return zzl;
        }
        zzl = zzc(t, s);
        return zzl != null ? zzl : zzd(t, s);
    }
}
