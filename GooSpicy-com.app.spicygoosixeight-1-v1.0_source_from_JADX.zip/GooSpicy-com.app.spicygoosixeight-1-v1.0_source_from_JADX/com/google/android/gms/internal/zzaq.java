package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import com.google.android.gms.internal.zzae.zza;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public abstract class zzaq extends zzao {
    private static final String TAG = "zzaq";
    private static long startTime = 0;
    protected static volatile zzax zzaey = null;
    private static Method zzafo = null;
    static boolean zzafq = false;
    protected static final Object zzaft = new Object();
    protected boolean zzafn = false;
    protected String zzafp;
    protected boolean zzafr = false;
    protected boolean zzafs = false;

    protected zzaq(Context context, String str) {
        super(context);
        this.zzafp = str;
        this.zzafn = false;
    }

    protected zzaq(Context context, String str, boolean z) {
        super(context);
        this.zzafp = str;
        this.zzafn = z;
    }

    static List<Long> zza(zzax com_google_android_gms_internal_zzax, MotionEvent motionEvent, DisplayMetrics displayMetrics) throws zzaw {
        zzafo = com_google_android_gms_internal_zzax.zzc(zzav.zzcc(), zzav.zzcd());
        if (zzafo != null) {
            if (motionEvent != null) {
                try {
                    return (ArrayList) zzafo.invoke(null, new Object[]{motionEvent, displayMetrics});
                } catch (Throwable e) {
                    throw new zzaw(e);
                } catch (Throwable e2) {
                    throw new zzaw(e2);
                }
            }
        }
        throw new zzaw();
    }

    protected static synchronized void zza(Context context, boolean z) {
        synchronized (zzaq.class) {
            if (!zzafq) {
                startTime = Calendar.getInstance().getTime().getTime() / 1000;
                zzaey = zzb(context, z);
                zzafq = true;
            }
        }
    }

    private static void zza(zzax com_google_android_gms_internal_zzax) {
        List singletonList = Collections.singletonList(Context.class);
        com_google_android_gms_internal_zzax.zza(zzav.zzbo(), zzav.zzbp(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzbm(), zzav.zzbn(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzby(), zzav.zzbz(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzbw(), zzav.zzbx(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzbg(), zzav.zzbh(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzbe(), zzav.zzbf(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzbc(), zzav.zzbd(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzbs(), zzav.zzbt(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzba(), zzav.zzbb(), singletonList);
        com_google_android_gms_internal_zzax.zza(zzav.zzcc(), zzav.zzcd(), Arrays.asList(new Class[]{MotionEvent.class, DisplayMetrics.class}));
        com_google_android_gms_internal_zzax.zza(zzav.zzbk(), zzav.zzbl(), Collections.emptyList());
        com_google_android_gms_internal_zzax.zza(zzav.zzca(), zzav.zzcb(), Collections.emptyList());
        com_google_android_gms_internal_zzax.zza(zzav.zzbu(), zzav.zzbv(), Collections.emptyList());
        com_google_android_gms_internal_zzax.zza(zzav.zzbi(), zzav.zzbj(), Collections.emptyList());
        com_google_android_gms_internal_zzax.zza(zzav.zzbq(), zzav.zzbr(), Collections.emptyList());
    }

    protected static zzax zzb(Context context, boolean z) {
        if (zzaey == null) {
            synchronized (zzaft) {
                if (zzaey == null) {
                    zzax zza = zzax.zza(context, zzav.getKey(), zzav.zzaz(), z);
                    zza(zza);
                    zzaey = zza;
                }
            }
        }
        return zzaey;
    }

    protected void zza(zzax com_google_android_gms_internal_zzax, zza com_google_android_gms_internal_zzae_zza) {
        if (com_google_android_gms_internal_zzax.zzce() != null) {
            zza(zzb(com_google_android_gms_internal_zzax, com_google_android_gms_internal_zzae_zza));
        }
    }

    protected void zza(List<Callable<Void>> list) {
        if (zzaey != null) {
            ExecutorService zzce = zzaey.zzce();
            if (!(zzce == null || list.isEmpty())) {
                try {
                    zzce.invokeAll(list, ((Long) zzdc.zzbbh.get()).longValue(), TimeUnit.MILLISECONDS);
                } catch (Throwable e) {
                    Log.d(TAG, String.format("class methods got exception: %s", new Object[]{zzay.zza(e)}));
                }
            }
        }
    }

    protected List<Callable<Void>> zzb(zzax com_google_android_gms_internal_zzax, zza com_google_android_gms_internal_zzae_zza) {
        int zzau = com_google_android_gms_internal_zzax.zzau();
        List<Callable<Void>> arrayList = new ArrayList();
        zzax com_google_android_gms_internal_zzax2 = com_google_android_gms_internal_zzax;
        zza com_google_android_gms_internal_zzae_zza2 = com_google_android_gms_internal_zzae_zza;
        arrayList.add(new zzbb(com_google_android_gms_internal_zzax2, zzav.zzbo(), zzav.zzbp(), com_google_android_gms_internal_zzae_zza2, zzau, 27));
        arrayList.add(new zzbg(com_google_android_gms_internal_zzax2, zzav.zzbk(), zzav.zzbl(), com_google_android_gms_internal_zzae_zza2, startTime, zzau, 25));
        int i = zzau;
        arrayList.add(new zzbl(com_google_android_gms_internal_zzax2, zzav.zzbu(), zzav.zzbv(), com_google_android_gms_internal_zzae_zza2, i, 1));
        arrayList.add(new zzbm(com_google_android_gms_internal_zzax2, zzav.zzbw(), zzav.zzbx(), com_google_android_gms_internal_zzae_zza2, i, 31));
        arrayList.add(new zzbn(com_google_android_gms_internal_zzax2, zzav.zzca(), zzav.zzcb(), com_google_android_gms_internal_zzae_zza2, i, 33));
        arrayList.add(new zzba(com_google_android_gms_internal_zzax2, zzav.zzby(), zzav.zzbz(), com_google_android_gms_internal_zzae_zza2, i, 29));
        arrayList.add(new zzbe(com_google_android_gms_internal_zzax2, zzav.zzbg(), zzav.zzbh(), com_google_android_gms_internal_zzae_zza2, i, 5));
        arrayList.add(new zzbk(com_google_android_gms_internal_zzax2, zzav.zzbs(), zzav.zzbt(), com_google_android_gms_internal_zzae_zza2, i, 12));
        arrayList.add(new zzaz(com_google_android_gms_internal_zzax2, zzav.zzba(), zzav.zzbb(), com_google_android_gms_internal_zzae_zza2, i, 3));
        arrayList.add(new zzbd(com_google_android_gms_internal_zzax2, zzav.zzbe(), zzav.zzbf(), com_google_android_gms_internal_zzae_zza2, i, 34));
        arrayList.add(new zzbc(com_google_android_gms_internal_zzax2, zzav.zzbc(), zzav.zzbd(), com_google_android_gms_internal_zzae_zza2, i, 35));
        if (((Boolean) zzdc.zzbbl.get()).booleanValue()) {
            arrayList.add(new zzbf(com_google_android_gms_internal_zzax, zzav.zzbi(), zzav.zzbj(), com_google_android_gms_internal_zzae_zza, zzau, 44));
        }
        if (((Boolean) zzdc.zzbbo.get()).booleanValue()) {
            arrayList.add(new zzbj(com_google_android_gms_internal_zzax, zzav.zzbq(), zzav.zzbr(), com_google_android_gms_internal_zzae_zza, zzau, 22));
        }
        return arrayList;
    }

    protected zza zzc(Context context) {
        zza com_google_android_gms_internal_zzae_zza = new zza();
        if (!TextUtils.isEmpty(this.zzafp)) {
            com_google_android_gms_internal_zzae_zza.zzcs = this.zzafp;
        }
        zzax zzb = zzb(context, this.zzafn);
        zzb.zzct();
        zza(zzb, com_google_android_gms_internal_zzae_zza);
        zzb.zzcu();
        return com_google_android_gms_internal_zzae_zza;
    }

    protected List<Callable<Void>> zzc(zzax com_google_android_gms_internal_zzax, zza com_google_android_gms_internal_zzae_zza) {
        List<Callable<Void>> arrayList = new ArrayList();
        if (com_google_android_gms_internal_zzax.zzce() == null) {
            return arrayList;
        }
        int zzau = com_google_android_gms_internal_zzax.zzau();
        arrayList.add(new zzbi(com_google_android_gms_internal_zzax, com_google_android_gms_internal_zzae_zza));
        zzax com_google_android_gms_internal_zzax2 = com_google_android_gms_internal_zzax;
        zza com_google_android_gms_internal_zzae_zza2 = com_google_android_gms_internal_zzae_zza;
        arrayList.add(new zzbl(com_google_android_gms_internal_zzax2, zzav.zzbu(), zzav.zzbv(), com_google_android_gms_internal_zzae_zza2, zzau, 1));
        arrayList.add(new zzbg(com_google_android_gms_internal_zzax2, zzav.zzbk(), zzav.zzbl(), com_google_android_gms_internal_zzae_zza2, startTime, zzau, 25));
        if (((Boolean) zzdc.zzbbm.get()).booleanValue()) {
            arrayList.add(new zzbf(com_google_android_gms_internal_zzax, zzav.zzbi(), zzav.zzbj(), com_google_android_gms_internal_zzae_zza, zzau, 44));
        }
        arrayList.add(new zzaz(com_google_android_gms_internal_zzax, zzav.zzba(), zzav.zzbb(), com_google_android_gms_internal_zzae_zza, zzau, 3));
        if (((Boolean) zzdc.zzbbp.get()).booleanValue()) {
            arrayList.add(new zzbj(com_google_android_gms_internal_zzax, zzav.zzbq(), zzav.zzbr(), com_google_android_gms_internal_zzae_zza, zzau, 22));
        }
        return arrayList;
    }

    protected zza zzd(Context context) {
        zza com_google_android_gms_internal_zzae_zza = new zza();
        if (!TextUtils.isEmpty(this.zzafp)) {
            com_google_android_gms_internal_zzae_zza.zzcs = this.zzafp;
        }
        zzax zzb = zzb(context, this.zzafn);
        zzb.zzct();
        zzd(zzb, com_google_android_gms_internal_zzae_zza);
        zzb.zzcu();
        return com_google_android_gms_internal_zzae_zza;
    }

    protected void zzd(com.google.android.gms.internal.zzax r10, com.google.android.gms.internal.zzae.zza r11) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r9 = this;
        r0 = 0;
        r1 = 1;
        r2 = 0;
        r4 = r9.zzafd;	 Catch:{ zzaw -> 0x0045 }
        r5 = r9.zzafl;	 Catch:{ zzaw -> 0x0045 }
        r4 = zza(r10, r4, r5);	 Catch:{ zzaw -> 0x0045 }
        r5 = r4.get(r0);	 Catch:{ zzaw -> 0x0045 }
        r5 = (java.lang.Long) r5;	 Catch:{ zzaw -> 0x0045 }
        r11.zzdf = r5;	 Catch:{ zzaw -> 0x0045 }
        r5 = r4.get(r1);	 Catch:{ zzaw -> 0x0045 }
        r5 = (java.lang.Long) r5;	 Catch:{ zzaw -> 0x0045 }
        r11.zzdg = r5;	 Catch:{ zzaw -> 0x0045 }
        r5 = 2;	 Catch:{ zzaw -> 0x0045 }
        r6 = r4.get(r5);	 Catch:{ zzaw -> 0x0045 }
        r6 = (java.lang.Long) r6;	 Catch:{ zzaw -> 0x0045 }
        r6 = r6.longValue();	 Catch:{ zzaw -> 0x0045 }
        r8 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));	 Catch:{ zzaw -> 0x0045 }
        if (r8 < 0) goto L_0x0033;	 Catch:{ zzaw -> 0x0045 }
    L_0x002b:
        r5 = r4.get(r5);	 Catch:{ zzaw -> 0x0045 }
        r5 = (java.lang.Long) r5;	 Catch:{ zzaw -> 0x0045 }
        r11.zzdh = r5;	 Catch:{ zzaw -> 0x0045 }
    L_0x0033:
        r5 = 3;	 Catch:{ zzaw -> 0x0045 }
        r5 = r4.get(r5);	 Catch:{ zzaw -> 0x0045 }
        r5 = (java.lang.Long) r5;	 Catch:{ zzaw -> 0x0045 }
        r11.zzdv = r5;	 Catch:{ zzaw -> 0x0045 }
        r5 = 4;	 Catch:{ zzaw -> 0x0045 }
        r4 = r4.get(r5);	 Catch:{ zzaw -> 0x0045 }
        r4 = (java.lang.Long) r4;	 Catch:{ zzaw -> 0x0045 }
        r11.zzdw = r4;	 Catch:{ zzaw -> 0x0045 }
    L_0x0045:
        r4 = r9.zzaff;
        r6 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1));
        if (r6 <= 0) goto L_0x0053;
    L_0x004b:
        r4 = r9.zzaff;
        r4 = java.lang.Long.valueOf(r4);
        r11.zzea = r4;
    L_0x0053:
        r4 = r9.zzafg;
        r6 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1));
        if (r6 <= 0) goto L_0x0061;
    L_0x0059:
        r4 = r9.zzafg;
        r4 = java.lang.Long.valueOf(r4);
        r11.zzdz = r4;
    L_0x0061:
        r4 = r9.zzafh;
        r6 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1));
        if (r6 <= 0) goto L_0x006f;
    L_0x0067:
        r4 = r9.zzafh;
        r4 = java.lang.Long.valueOf(r4);
        r11.zzdy = r4;
    L_0x006f:
        r4 = r9.zzafi;
        r6 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1));
        if (r6 <= 0) goto L_0x007d;
    L_0x0075:
        r4 = r9.zzafi;
        r4 = java.lang.Long.valueOf(r4);
        r11.zzeb = r4;
    L_0x007d:
        r4 = r9.zzafj;
        r6 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1));
        if (r6 <= 0) goto L_0x008b;
    L_0x0083:
        r2 = r9.zzafj;
        r2 = java.lang.Long.valueOf(r2);
        r11.zzed = r2;
    L_0x008b:
        r2 = r9.zzafe;	 Catch:{ zzaw -> 0x00c5 }
        r2 = r2.size();	 Catch:{ zzaw -> 0x00c5 }
        r2 = r2 - r1;	 Catch:{ zzaw -> 0x00c5 }
        if (r2 <= 0) goto L_0x00c8;	 Catch:{ zzaw -> 0x00c5 }
    L_0x0094:
        r3 = new com.google.android.gms.internal.zzae.zza.zza[r2];	 Catch:{ zzaw -> 0x00c5 }
        r11.zzee = r3;	 Catch:{ zzaw -> 0x00c5 }
        r3 = r0;	 Catch:{ zzaw -> 0x00c5 }
    L_0x0099:
        if (r3 >= r2) goto L_0x00c8;	 Catch:{ zzaw -> 0x00c5 }
    L_0x009b:
        r4 = r9.zzafe;	 Catch:{ zzaw -> 0x00c5 }
        r4 = r4.get(r3);	 Catch:{ zzaw -> 0x00c5 }
        r4 = (android.view.MotionEvent) r4;	 Catch:{ zzaw -> 0x00c5 }
        r5 = r9.zzafl;	 Catch:{ zzaw -> 0x00c5 }
        r4 = zza(r10, r4, r5);	 Catch:{ zzaw -> 0x00c5 }
        r5 = new com.google.android.gms.internal.zzae$zza$zza;	 Catch:{ zzaw -> 0x00c5 }
        r5.<init>();	 Catch:{ zzaw -> 0x00c5 }
        r6 = r4.get(r0);	 Catch:{ zzaw -> 0x00c5 }
        r6 = (java.lang.Long) r6;	 Catch:{ zzaw -> 0x00c5 }
        r5.zzdf = r6;	 Catch:{ zzaw -> 0x00c5 }
        r4 = r4.get(r1);	 Catch:{ zzaw -> 0x00c5 }
        r4 = (java.lang.Long) r4;	 Catch:{ zzaw -> 0x00c5 }
        r5.zzdg = r4;	 Catch:{ zzaw -> 0x00c5 }
        r4 = r11.zzee;	 Catch:{ zzaw -> 0x00c5 }
        r4[r3] = r5;	 Catch:{ zzaw -> 0x00c5 }
        r3 = r3 + 1;
        goto L_0x0099;
    L_0x00c5:
        r0 = 0;
        r11.zzee = r0;
    L_0x00c8:
        r10 = r9.zzc(r10, r11);
        r9.zza(r10);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaq.zzd(com.google.android.gms.internal.zzax, com.google.android.gms.internal.zzae$zza):void");
    }
}
