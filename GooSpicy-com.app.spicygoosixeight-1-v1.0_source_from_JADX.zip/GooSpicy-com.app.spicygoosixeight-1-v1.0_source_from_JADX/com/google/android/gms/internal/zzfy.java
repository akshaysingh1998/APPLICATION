package com.google.android.gms.internal;

public interface zzfy extends zzfx {
    void zzmh();
}
