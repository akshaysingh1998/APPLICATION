package com.google.android.gms.internal;

import java.util.HashSet;

public interface zzkd {
    void zza(HashSet<zzjz> hashSet);
}
