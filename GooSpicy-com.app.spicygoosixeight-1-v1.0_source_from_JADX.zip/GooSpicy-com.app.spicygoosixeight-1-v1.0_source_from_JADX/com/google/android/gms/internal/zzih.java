package com.google.android.gms.internal;

import android.content.Context;
import com.bumptech.glide.load.Key;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzlm.zza;

@zzir
public class zzih extends zzic implements zza {
    zzih(Context context, zzjy.zza com_google_android_gms_internal_zzjy_zza, zzll com_google_android_gms_internal_zzll, zzig.zza com_google_android_gms_internal_zzig_zza) {
        super(context, com_google_android_gms_internal_zzjy_zza, com_google_android_gms_internal_zzll, com_google_android_gms_internal_zzig_zza);
    }

    protected void zzpx() {
        if (this.zzbxw.errorCode == -2) {
            this.zzbgj.zzuk().zza((zza) this);
            zzqe();
            zzb.zzcw("Loading HTML in WebView.");
            this.zzbgj.loadDataWithBaseURL(zzu.zzfq().zzcp(this.zzbxw.zzbts), this.zzbxw.body, "text/html", Key.STRING_CHARSET_NAME, null);
        }
    }

    protected void zzqe() {
    }
}
