package com.google.android.gms.internal;

public interface zzkp<T> {
    void zzd(T t);
}
