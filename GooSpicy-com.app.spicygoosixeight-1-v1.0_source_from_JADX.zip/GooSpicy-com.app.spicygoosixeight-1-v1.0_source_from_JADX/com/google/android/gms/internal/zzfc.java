package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.Map;

@zzir
public class zzfc implements zzet {
    private final zza zzbjc;

    public interface zza {
        void zzb(RewardItemParcel rewardItemParcel);

        void zzev();
    }

    public zzfc(zza com_google_android_gms_internal_zzfc_zza) {
        this.zzbjc = com_google_android_gms_internal_zzfc_zza;
    }

    public static void zza(zzll com_google_android_gms_internal_zzll, zza com_google_android_gms_internal_zzfc_zza) {
        com_google_android_gms_internal_zzll.zzuk().zza("/reward", new zzfc(com_google_android_gms_internal_zzfc_zza));
    }

    private void zze(Map<String, String> map) {
        RewardItemParcel rewardItemParcel = null;
        try {
            int parseInt = Integer.parseInt((String) map.get("amount"));
            String str = (String) map.get("type");
            if (!TextUtils.isEmpty(str)) {
                rewardItemParcel = new RewardItemParcel(str, parseInt);
            }
        } catch (Throwable e) {
            zzb.zzd("Unable to parse reward amount.", e);
        }
        this.zzbjc.zzb(rewardItemParcel);
    }

    private void zzf(Map<String, String> map) {
        this.zzbjc.zzev();
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str = (String) map.get("action");
        if ("grant".equals(str)) {
            zze(map);
            return;
        }
        if ("video_start".equals(str)) {
            zzf(map);
        }
    }
}
