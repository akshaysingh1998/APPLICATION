package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.customtabs.CustomTabsIntent;
import android.support.customtabs.CustomTabsIntent.Builder;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.zzg;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.internal.zzdq.zza;

@zzir
public class zzhc implements MediationInterstitialAdapter {
    private Uri mUri;
    private Activity zzbpy;
    private zzdq zzbpz;
    private MediationInterstitialListener zzbqa;

    class C09261 implements zza {
        final /* synthetic */ zzhc zzbqb;

        C09261(zzhc com_google_android_gms_internal_zzhc) {
            this.zzbqb = com_google_android_gms_internal_zzhc;
        }

        public void zzkn() {
            zzb.zzcw("Hinting CustomTabsService for the load of the new url.");
        }

        public void zzko() {
            zzb.zzcw("Disconnecting from CustomTabs service.");
        }
    }

    class C09272 implements zzg {
        final /* synthetic */ zzhc zzbqb;

        C09272(zzhc com_google_android_gms_internal_zzhc) {
            this.zzbqb = com_google_android_gms_internal_zzhc;
        }

        public void onPause() {
            zzb.zzcw("AdMobCustomTabsAdapter overlay is paused.");
        }

        public void onResume() {
            zzb.zzcw("AdMobCustomTabsAdapter overlay is resumed.");
        }

        public void zzdy() {
            zzb.zzcw("AdMobCustomTabsAdapter overlay is closed.");
            this.zzbqb.zzbqa.onAdClosed(this.zzbqb);
            this.zzbqb.zzbpz.zzd(this.zzbqb.zzbpy);
        }

        public void zzdz() {
            zzb.zzcw("Opening AdMobCustomTabsAdapter overlay.");
            this.zzbqb.zzbqa.onAdOpened(this.zzbqb);
        }
    }

    public static boolean zzp(Context context) {
        return zzdq.zzo(context);
    }

    public void onDestroy() {
        zzb.zzcw("Destroying AdMobCustomTabsAdapter adapter.");
        try {
            this.zzbpz.zzd(this.zzbpy);
        } catch (Throwable e) {
            zzb.zzb("Exception while unbinding from CustomTabsService.", e);
        }
    }

    public void onPause() {
        zzb.zzcw("Pausing AdMobCustomTabsAdapter adapter.");
    }

    public void onResume() {
        zzb.zzcw("Resuming AdMobCustomTabsAdapter adapter.");
    }

    public void requestInterstitialAd(Context context, MediationInterstitialListener mediationInterstitialListener, Bundle bundle, MediationAdRequest mediationAdRequest, Bundle bundle2) {
        this.zzbqa = mediationInterstitialListener;
        if (this.zzbqa == null) {
            zzb.zzcy("Listener not set for mediation. Returning.");
        } else if (!(context instanceof Activity)) {
            zzb.zzcy("AdMobCustomTabs can only work with Activity context. Bailing out.");
            this.zzbqa.onAdFailedToLoad(this, 0);
        } else if (zzp(context)) {
            Object string = bundle.getString("tab_url");
            if (TextUtils.isEmpty(string)) {
                zzb.zzcy("The tab_url retrieved from mediation metadata is empty. Bailing out.");
                this.zzbqa.onAdFailedToLoad(this, 0);
                return;
            }
            this.zzbpy = (Activity) context;
            this.mUri = Uri.parse(string);
            this.zzbpz = new zzdq();
            this.zzbpz.zza(new C09261(this));
            this.zzbpz.zze(this.zzbpy);
            this.zzbqa.onAdLoaded(this);
        } else {
            zzb.zzcy("Default browser does not support custom tabs. Bailing out.");
            this.zzbqa.onAdFailedToLoad(this, 0);
        }
    }

    public void showInterstitial() {
        CustomTabsIntent build = new Builder(this.zzbpz.zzkl()).build();
        build.intent.setData(this.mUri);
        final AdOverlayInfoParcel adOverlayInfoParcel = new AdOverlayInfoParcel(new AdLauncherIntentInfoParcel(build.intent), null, new C09272(this), null, new VersionInfoParcel(0, 0, false));
        zzkl.zzclg.post(new Runnable(this) {
            final /* synthetic */ zzhc zzbqb;

            public void run() {
                zzu.zzfo().zza(this.zzbqb.zzbpy, adOverlayInfoParcel);
            }
        });
        zzu.zzft().zzaf(false);
    }
}
