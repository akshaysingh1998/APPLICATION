package com.google.android.gms.internal;

import android.content.Context;
import android.util.Log;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import com.google.android.gms.internal.zzug.zza;

public class zzuf {
    private zzug Qq = null;
    private boolean zzamr = false;

    public void initialize(Context context) {
        synchronized (this) {
            if (this.zzamr) {
                return;
            }
            try {
                this.Qq = zza.asInterface(zzsj.zza(context, zzsj.Mg, ModuleDescriptor.MODULE_ID).zziv("com.google.android.gms.flags.impl.FlagProviderImpl"));
                this.Qq.init(zze.zzae(context));
                this.zzamr = true;
            } catch (Throwable e) {
                Log.w("FlagValueProvider", "Failed to initialize flags module.", e);
            }
        }
    }

    public <T> T zzb(zzud<T> com_google_android_gms_internal_zzud_T) {
        synchronized (this) {
            if (this.zzamr) {
                return com_google_android_gms_internal_zzud_T.zza(this.Qq);
            }
            T zzjw = com_google_android_gms_internal_zzud_T.zzjw();
            return zzjw;
        }
    }
}
