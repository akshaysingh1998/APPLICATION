package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzamu<T> {
    T zza(Type type);
}
