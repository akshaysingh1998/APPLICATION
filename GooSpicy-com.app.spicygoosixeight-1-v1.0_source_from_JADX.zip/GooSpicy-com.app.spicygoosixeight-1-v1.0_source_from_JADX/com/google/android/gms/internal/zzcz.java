package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@zzir
public class zzcz {
    private final Collection<zzcy> zzaxp = new ArrayList();
    private final Collection<zzcy<String>> zzaxq = new ArrayList();
    private final Collection<zzcy<String>> zzaxr = new ArrayList();

    public void zza(zzcy com_google_android_gms_internal_zzcy) {
        this.zzaxp.add(com_google_android_gms_internal_zzcy);
    }

    public void zzb(zzcy<String> com_google_android_gms_internal_zzcy_java_lang_String) {
        this.zzaxq.add(com_google_android_gms_internal_zzcy_java_lang_String);
    }

    public void zzc(zzcy<String> com_google_android_gms_internal_zzcy_java_lang_String) {
        this.zzaxr.add(com_google_android_gms_internal_zzcy_java_lang_String);
    }

    public List<String> zzjx() {
        List<String> arrayList = new ArrayList();
        for (zzcy com_google_android_gms_internal_zzcy : this.zzaxq) {
            String str = (String) com_google_android_gms_internal_zzcy.get();
            if (str != null) {
                arrayList.add(str);
            }
        }
        return arrayList;
    }

    public List<String> zzjy() {
        List<String> zzjx = zzjx();
        for (zzcy com_google_android_gms_internal_zzcy : this.zzaxr) {
            String str = (String) com_google_android_gms_internal_zzcy.get();
            if (str != null) {
                zzjx.add(str);
            }
        }
        return zzjx;
    }
}
