package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@zzir
public class zzgk implements zzgc {
    private final Context mContext;
    private final Object zzail = new Object();
    private final zzgn zzajz;
    private final boolean zzarj;
    private final boolean zzawl;
    private final zzge zzboi;
    private final AdRequestInfoParcel zzbox;
    private final long zzboy;
    private final long zzboz;
    private final int zzbpa;
    private boolean zzbpb = false;
    private final Map<zzlc<zzgi>, zzgh> zzbpc = new HashMap();
    private List<zzgi> zzbpd = new ArrayList();

    public zzgk(Context context, AdRequestInfoParcel adRequestInfoParcel, zzgn com_google_android_gms_internal_zzgn, zzge com_google_android_gms_internal_zzge, boolean z, boolean z2, long j, long j2, int i) {
        this.mContext = context;
        this.zzbox = adRequestInfoParcel;
        this.zzajz = com_google_android_gms_internal_zzgn;
        this.zzboi = com_google_android_gms_internal_zzge;
        this.zzarj = z;
        this.zzawl = z2;
        this.zzboy = j;
        this.zzboz = j2;
        this.zzbpa = i;
    }

    private void zza(final zzlc<zzgi> com_google_android_gms_internal_zzlc_com_google_android_gms_internal_zzgi) {
        zzkl.zzclg.post(new Runnable(this) {
            final /* synthetic */ zzgk zzbpf;

            public void run() {
                for (zzlc com_google_android_gms_internal_zzlc : this.zzbpf.zzbpc.keySet()) {
                    if (com_google_android_gms_internal_zzlc != com_google_android_gms_internal_zzlc_com_google_android_gms_internal_zzgi) {
                        ((zzgh) this.zzbpf.zzbpc.get(com_google_android_gms_internal_zzlc)).cancel();
                    }
                }
            }
        });
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.google.android.gms.internal.zzgi zze(java.util.List<com.google.android.gms.internal.zzlc<com.google.android.gms.internal.zzgi>> r4) {
        /*
        r3 = this;
        r0 = r3.zzail;
        monitor-enter(r0);
        r1 = r3.zzbpb;	 Catch:{ all -> 0x0047 }
        if (r1 == 0) goto L_0x000f;
    L_0x0007:
        r4 = new com.google.android.gms.internal.zzgi;	 Catch:{ all -> 0x0047 }
        r1 = -1;
        r4.<init>(r1);	 Catch:{ all -> 0x0047 }
        monitor-exit(r0);	 Catch:{ all -> 0x0047 }
        return r4;
    L_0x000f:
        monitor-exit(r0);	 Catch:{ all -> 0x0047 }
        r4 = r4.iterator();
    L_0x0014:
        r0 = r4.hasNext();
        if (r0 == 0) goto L_0x003c;
    L_0x001a:
        r0 = r4.next();
        r0 = (com.google.android.gms.internal.zzlc) r0;
        r1 = r0.get();	 Catch:{ InterruptedException -> 0x0035, InterruptedException -> 0x0035 }
        r1 = (com.google.android.gms.internal.zzgi) r1;	 Catch:{ InterruptedException -> 0x0035, InterruptedException -> 0x0035 }
        r2 = r3.zzbpd;	 Catch:{ InterruptedException -> 0x0035, InterruptedException -> 0x0035 }
        r2.add(r1);	 Catch:{ InterruptedException -> 0x0035, InterruptedException -> 0x0035 }
        if (r1 == 0) goto L_0x0014;
    L_0x002d:
        r2 = r1.zzboq;	 Catch:{ InterruptedException -> 0x0035, InterruptedException -> 0x0035 }
        if (r2 != 0) goto L_0x0014;
    L_0x0031:
        r3.zza(r0);	 Catch:{ InterruptedException -> 0x0035, InterruptedException -> 0x0035 }
        return r1;
    L_0x0035:
        r0 = move-exception;
        r1 = "Exception while processing an adapter; continuing with other adapters";
        com.google.android.gms.ads.internal.util.client.zzb.zzd(r1, r0);
        goto L_0x0014;
    L_0x003c:
        r4 = 0;
        r3.zza(r4);
        r4 = new com.google.android.gms.internal.zzgi;
        r0 = 1;
        r4.<init>(r0);
        return r4;
    L_0x0047:
        r4 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x0047 }
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgk.zze(java.util.List):com.google.android.gms.internal.zzgi");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.google.android.gms.internal.zzgi zzf(java.util.List<com.google.android.gms.internal.zzlc<com.google.android.gms.internal.zzgi>> r15) {
        /*
        r14 = this;
        r0 = r14.zzail;
        monitor-enter(r0);
        r1 = r14.zzbpb;	 Catch:{ all -> 0x00ab }
        r2 = -1;
        if (r1 == 0) goto L_0x000f;
    L_0x0008:
        r15 = new com.google.android.gms.internal.zzgi;	 Catch:{ all -> 0x00ab }
        r15.<init>(r2);	 Catch:{ all -> 0x00ab }
        monitor-exit(r0);	 Catch:{ all -> 0x00ab }
        return r15;
    L_0x000f:
        monitor-exit(r0);	 Catch:{ all -> 0x00ab }
        r0 = r14.zzboi;
        r0 = r0.zzboa;
        r3 = -1;
        r5 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1));
        if (r5 == 0) goto L_0x001f;
    L_0x001a:
        r0 = r14.zzboi;
        r0 = r0.zzboa;
        goto L_0x0021;
    L_0x001f:
        r0 = 10000; // 0x2710 float:1.4013E-41 double:4.9407E-320;
    L_0x0021:
        r15 = r15.iterator();
        r3 = 0;
        r4 = r2;
        r1 = r0;
        r0 = r3;
    L_0x0029:
        r5 = r15.hasNext();
        if (r5 == 0) goto L_0x009e;
    L_0x002f:
        r5 = r15.next();
        r5 = (com.google.android.gms.internal.zzlc) r5;
        r6 = com.google.android.gms.ads.internal.zzu.zzfu();
        r6 = r6.currentTimeMillis();
        r8 = 0;
        r10 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1));
        if (r10 != 0) goto L_0x0054;
    L_0x0043:
        r10 = r5.isDone();	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        if (r10 == 0) goto L_0x0054;
    L_0x0049:
        r10 = r5.get();	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
    L_0x004d:
        r10 = (com.google.android.gms.internal.zzgi) r10;	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        goto L_0x005b;
    L_0x0050:
        r15 = move-exception;
        goto L_0x008e;
    L_0x0052:
        r5 = move-exception;
        goto L_0x0078;
    L_0x0054:
        r10 = java.util.concurrent.TimeUnit.MILLISECONDS;	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        r10 = r5.get(r1, r10);	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        goto L_0x004d;
    L_0x005b:
        r11 = r14.zzbpd;	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        r11.add(r10);	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        if (r10 == 0) goto L_0x007d;
    L_0x0062:
        r11 = r10.zzboq;	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        if (r11 != 0) goto L_0x007d;
    L_0x0066:
        r11 = r10.zzbov;	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        if (r11 == 0) goto L_0x007d;
    L_0x006a:
        r12 = r11.zzmo();	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        if (r12 <= r4) goto L_0x007d;
    L_0x0070:
        r11 = r11.zzmo();	 Catch:{ InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052, InterruptedException -> 0x0052 }
        r3 = r5;
        r0 = r10;
        r4 = r11;
        goto L_0x007d;
    L_0x0078:
        r10 = "Exception while processing an adapter; continuing with other adapters";
        com.google.android.gms.ads.internal.util.client.zzb.zzd(r10, r5);	 Catch:{ all -> 0x0050 }
    L_0x007d:
        r5 = com.google.android.gms.ads.internal.zzu.zzfu();
        r10 = r5.currentTimeMillis();
        r12 = r10 - r6;
        r5 = r1 - r12;
        r1 = java.lang.Math.max(r5, r8);
        goto L_0x0029;
    L_0x008e:
        r0 = com.google.android.gms.ads.internal.zzu.zzfu();
        r3 = r0.currentTimeMillis();
        r10 = r3 - r6;
        r3 = r1 - r10;
        java.lang.Math.max(r3, r8);
        throw r15;
    L_0x009e:
        r14.zza(r3);
        if (r0 != 0) goto L_0x00aa;
    L_0x00a3:
        r15 = new com.google.android.gms.internal.zzgi;
        r0 = 1;
        r15.<init>(r0);
        return r15;
    L_0x00aa:
        return r0;
    L_0x00ab:
        r15 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x00ab }
        throw r15;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgk.zzf(java.util.List):com.google.android.gms.internal.zzgi");
    }

    public void cancel() {
        synchronized (this.zzail) {
            this.zzbpb = true;
            for (zzgh cancel : this.zzbpc.values()) {
                cancel.cancel();
            }
        }
    }

    public zzgi zzd(List<zzgd> list) {
        zzgk com_google_android_gms_internal_zzgk = this;
        zzb.zzcw("Starting mediation.");
        ExecutorService newCachedThreadPool = Executors.newCachedThreadPool();
        List arrayList = new ArrayList();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            zzgd com_google_android_gms_internal_zzgd = (zzgd) it.next();
            String str = "Trying mediation network: ";
            String valueOf = String.valueOf(com_google_android_gms_internal_zzgd.zzbmz);
            zzb.zzcx(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            Iterator it2 = com_google_android_gms_internal_zzgd.zzbna.iterator();
            while (it2.hasNext()) {
                String str2 = (String) it2.next();
                Context context = com_google_android_gms_internal_zzgk.mContext;
                zzgn com_google_android_gms_internal_zzgn = com_google_android_gms_internal_zzgk.zzajz;
                zzge com_google_android_gms_internal_zzge = com_google_android_gms_internal_zzgk.zzboi;
                AdRequestParcel adRequestParcel = com_google_android_gms_internal_zzgk.zzbox.zzcav;
                AdSizeParcel adSizeParcel = com_google_android_gms_internal_zzgk.zzbox.zzaoy;
                VersionInfoParcel versionInfoParcel = com_google_android_gms_internal_zzgk.zzbox.zzaou;
                Iterator it3 = it;
                boolean z = com_google_android_gms_internal_zzgk.zzarj;
                zzgd com_google_android_gms_internal_zzgd2 = com_google_android_gms_internal_zzgd;
                zzgd com_google_android_gms_internal_zzgd3 = com_google_android_gms_internal_zzgd;
                final zzgh com_google_android_gms_internal_zzgh = r5;
                boolean z2 = z;
                Iterator it4 = it2;
                zzgh com_google_android_gms_internal_zzgh2 = new zzgh(context, str2, com_google_android_gms_internal_zzgn, com_google_android_gms_internal_zzge, com_google_android_gms_internal_zzgd2, adRequestParcel, adSizeParcel, versionInfoParcel, z2, com_google_android_gms_internal_zzgk.zzawl, com_google_android_gms_internal_zzgk.zzbox.zzapm, com_google_android_gms_internal_zzgk.zzbox.zzapq);
                zzlc zza = zzkk.zza(newCachedThreadPool, new Callable<zzgi>(com_google_android_gms_internal_zzgk) {
                    final /* synthetic */ zzgk zzbpf;

                    public /* synthetic */ Object call() throws Exception {
                        return zzmp();
                    }

                    public zzgi zzmp() throws Exception {
                        synchronized (this.zzbpf.zzail) {
                            if (this.zzbpf.zzbpb) {
                                return null;
                            }
                            return com_google_android_gms_internal_zzgh.zza(this.zzbpf.zzboy, this.zzbpf.zzboz);
                        }
                    }
                });
                com_google_android_gms_internal_zzgk.zzbpc.put(zza, com_google_android_gms_internal_zzgh);
                arrayList.add(zza);
                it = it3;
                it2 = it4;
                com_google_android_gms_internal_zzgd = com_google_android_gms_internal_zzgd3;
            }
        }
        return com_google_android_gms_internal_zzgk.zzbpa != 2 ? zze(arrayList) : zzf(arrayList);
    }

    public List<zzgi> zzmi() {
        return this.zzbpd;
    }
}
