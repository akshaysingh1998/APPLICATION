package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import org.json.JSONObject;

@zzir
public class zzhh {
    private final boolean zzbrb;
    private final boolean zzbrc;
    private final boolean zzbrd;
    private final boolean zzbre;
    private final boolean zzbrf;

    public static final class zza {
        private boolean zzbrb;
        private boolean zzbrc;
        private boolean zzbrd;
        private boolean zzbre;
        private boolean zzbrf;

        public zzhh zzna() {
            return new zzhh();
        }

        public zza zzt(boolean z) {
            this.zzbrb = z;
            return this;
        }

        public zza zzu(boolean z) {
            this.zzbrc = z;
            return this;
        }

        public zza zzv(boolean z) {
            this.zzbrd = z;
            return this;
        }

        public zza zzw(boolean z) {
            this.zzbre = z;
            return this;
        }

        public zza zzx(boolean z) {
            this.zzbrf = z;
            return this;
        }
    }

    private zzhh(zza com_google_android_gms_internal_zzhh_zza) {
        this.zzbrb = com_google_android_gms_internal_zzhh_zza.zzbrb;
        this.zzbrc = com_google_android_gms_internal_zzhh_zza.zzbrc;
        this.zzbrd = com_google_android_gms_internal_zzhh_zza.zzbrd;
        this.zzbre = com_google_android_gms_internal_zzhh_zza.zzbre;
        this.zzbrf = com_google_android_gms_internal_zzhh_zza.zzbrf;
    }

    public JSONObject toJson() {
        try {
            return new JSONObject().put("sms", this.zzbrb).put("tel", this.zzbrc).put("calendar", this.zzbrd).put("storePicture", this.zzbre).put("inlineVideo", this.zzbrf);
        } catch (Throwable e) {
            zzb.zzb("Error occured while obtaining the MRAID capabilities.", e);
            return null;
        }
    }
}
