package com.google.android.gms.internal;

public interface zzch {
    void zza(zzcd com_google_android_gms_internal_zzcd);
}
