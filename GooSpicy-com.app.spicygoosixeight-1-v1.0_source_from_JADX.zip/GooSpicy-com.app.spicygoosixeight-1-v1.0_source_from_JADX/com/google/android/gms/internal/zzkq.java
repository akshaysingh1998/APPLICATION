package com.google.android.gms.internal;

import com.google.android.gms.common.internal.zzaa;
import java.util.ArrayList;
import java.util.List;

@zzir
public class zzkq {
    private final String[] zzclv;
    private final double[] zzclw;
    private final double[] zzclx;
    private final int[] zzcly;
    private int zzclz;

    public static class zza {
        public final int count;
        public final String name;
        public final double zzcma;
        public final double zzcmb;
        public final double zzcmc;

        public zza(String str, double d, double d2, double d3, int i) {
            this.name = str;
            this.zzcmb = d;
            this.zzcma = d2;
            this.zzcmc = d3;
            this.count = i;
        }

        public boolean equals(Object obj) {
            boolean z = false;
            if (!(obj instanceof zza)) {
                return false;
            }
            zza com_google_android_gms_internal_zzkq_zza = (zza) obj;
            if (zzaa.equal(this.name, com_google_android_gms_internal_zzkq_zza.name) && this.zzcma == com_google_android_gms_internal_zzkq_zza.zzcma && this.zzcmb == com_google_android_gms_internal_zzkq_zza.zzcmb && this.count == com_google_android_gms_internal_zzkq_zza.count && Double.compare(this.zzcmc, com_google_android_gms_internal_zzkq_zza.zzcmc) == 0) {
                z = true;
            }
            return z;
        }

        public int hashCode() {
            return zzaa.hashCode(this.name, Double.valueOf(this.zzcma), Double.valueOf(this.zzcmb), Double.valueOf(this.zzcmc), Integer.valueOf(this.count));
        }

        public String toString() {
            return zzaa.zzz(this).zzg("name", this.name).zzg("minBound", Double.valueOf(this.zzcmb)).zzg("maxBound", Double.valueOf(this.zzcma)).zzg("percent", Double.valueOf(this.zzcmc)).zzg("count", Integer.valueOf(this.count)).toString();
        }
    }

    public static class zzb {
        private final List<String> zzcmd = new ArrayList();
        private final List<Double> zzcme = new ArrayList();
        private final List<Double> zzcmf = new ArrayList();

        public zzb zza(String str, double d, double d2) {
            int i = 0;
            while (i < this.zzcmd.size()) {
                double doubleValue = ((Double) this.zzcmf.get(i)).doubleValue();
                double doubleValue2 = ((Double) this.zzcme.get(i)).doubleValue();
                if (d >= doubleValue) {
                    if (doubleValue == d && d2 < doubleValue2) {
                        break;
                    }
                    i++;
                } else {
                    break;
                }
            }
            this.zzcmd.add(i, str);
            this.zzcmf.add(i, Double.valueOf(d));
            this.zzcme.add(i, Double.valueOf(d2));
            return this;
        }

        public zzkq zztp() {
            return new zzkq();
        }
    }

    private zzkq(zzb com_google_android_gms_internal_zzkq_zzb) {
        int size = com_google_android_gms_internal_zzkq_zzb.zzcme.size();
        this.zzclv = (String[]) com_google_android_gms_internal_zzkq_zzb.zzcmd.toArray(new String[size]);
        this.zzclw = zzm(com_google_android_gms_internal_zzkq_zzb.zzcme);
        this.zzclx = zzm(com_google_android_gms_internal_zzkq_zzb.zzcmf);
        this.zzcly = new int[size];
        this.zzclz = 0;
    }

    private double[] zzm(List<Double> list) {
        double[] dArr = new double[list.size()];
        for (int i = 0; i < dArr.length; i++) {
            dArr[i] = ((Double) list.get(i)).doubleValue();
        }
        return dArr;
    }

    public List<zza> getBuckets() {
        List<zza> arrayList = new ArrayList(this.zzclv.length);
        for (int i = 0; i < this.zzclv.length; i++) {
            arrayList.add(new zza(this.zzclv[i], this.zzclx[i], this.zzclw[i], ((double) this.zzcly[i]) / ((double) this.zzclz), this.zzcly[i]));
        }
        return arrayList;
    }

    public void zza(double d) {
        this.zzclz++;
        int i = 0;
        while (i < this.zzclx.length) {
            if (this.zzclx[i] <= d && d < this.zzclw[i]) {
                int[] iArr = this.zzcly;
                iArr[i] = iArr[i] + 1;
            }
            if (d >= this.zzclx[i]) {
                i++;
            } else {
                return;
            }
        }
    }
}
