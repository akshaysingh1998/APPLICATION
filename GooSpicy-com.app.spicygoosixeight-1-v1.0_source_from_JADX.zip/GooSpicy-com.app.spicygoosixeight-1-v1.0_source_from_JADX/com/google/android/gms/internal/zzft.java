package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.overlay.zzg;
import com.google.android.gms.ads.internal.overlay.zzp;
import com.google.android.gms.ads.internal.zze;

public interface zzft extends zzfx {

    public interface zza {
        void zzmb();
    }

    void destroy();

    void zza(com.google.android.gms.ads.internal.client.zza com_google_android_gms_ads_internal_client_zza, zzg com_google_android_gms_ads_internal_overlay_zzg, zzeo com_google_android_gms_internal_zzeo, zzp com_google_android_gms_ads_internal_overlay_zzp, boolean z, zzev com_google_android_gms_internal_zzev, zzex com_google_android_gms_internal_zzex, zze com_google_android_gms_ads_internal_zze, zzhk com_google_android_gms_internal_zzhk);

    void zza(zza com_google_android_gms_internal_zzft_zza);

    void zzbh(String str);

    void zzbi(String str);

    void zzbj(String str);

    zzfy zzma();
}
