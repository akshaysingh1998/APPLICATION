package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.zze;
import java.util.concurrent.Callable;

@zzir
public class zzdb {
    private final Object zzail = new Object();
    private boolean zzamr = false;
    private SharedPreferences zzaxs = null;

    public void initialize(Context context) {
        synchronized (this.zzail) {
            if (this.zzamr) {
                return;
            }
            context = zze.getRemoteContext(context);
            if (context == null) {
                return;
            }
            this.zzaxs = zzu.zzfx().zzn(context);
            this.zzamr = true;
        }
    }

    public <T> T zzd(final zzcy<T> com_google_android_gms_internal_zzcy_T) {
        synchronized (this.zzail) {
            if (this.zzamr) {
                return zzkx.zzb(new Callable<T>(this) {
                    final /* synthetic */ zzdb zzaxu;

                    public T call() {
                        return com_google_android_gms_internal_zzcy_T.zza(this.zzaxu.zzaxs);
                    }
                });
            }
            T zzjw = com_google_android_gms_internal_zzcy_T.zzjw();
            return zzjw;
        }
    }
}
