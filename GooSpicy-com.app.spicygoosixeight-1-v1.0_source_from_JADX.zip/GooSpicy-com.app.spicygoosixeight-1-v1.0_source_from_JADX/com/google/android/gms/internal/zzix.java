package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;

public interface zzix {
    void zza(Context context, String str, @NonNull Bundle bundle);
}
