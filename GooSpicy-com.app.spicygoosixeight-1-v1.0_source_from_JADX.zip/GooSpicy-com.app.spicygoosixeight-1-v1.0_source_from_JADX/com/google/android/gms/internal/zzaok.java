package com.google.android.gms.internal;

import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public final class zzaok extends zzank<Date> {
    public static final zzanl bfE = new C08591();
    private final DateFormat bge = new SimpleDateFormat("MMM d, yyyy");

    static class C08591 implements zzanl {
        C08591() {
        }

        public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
            return com_google_android_gms_internal_zzaoo_T.m15s() == Date.class ? new zzaok() : null;
        }
    }

    public synchronized void zza(zzaor com_google_android_gms_internal_zzaor, Date date) throws IOException {
        com_google_android_gms_internal_zzaor.zztb(date == null ? null : this.bge.format(date));
    }

    public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
        return zzm(com_google_android_gms_internal_zzaop);
    }

    public synchronized Date zzm(zzaop com_google_android_gms_internal_zzaop) throws IOException {
        if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
            com_google_android_gms_internal_zzaop.nextNull();
            return null;
        }
        try {
            return new Date(this.bge.parse(com_google_android_gms_internal_zzaop.nextString()).getTime());
        } catch (Throwable e) {
            throw new zzanh(e);
        }
    }
}
