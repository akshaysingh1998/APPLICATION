package com.google.android.gms.internal;

public interface zzgf {
    void zzea();

    void zzeb();

    void zzec();

    void zzed();

    void zzee();

    void zzef();
}
