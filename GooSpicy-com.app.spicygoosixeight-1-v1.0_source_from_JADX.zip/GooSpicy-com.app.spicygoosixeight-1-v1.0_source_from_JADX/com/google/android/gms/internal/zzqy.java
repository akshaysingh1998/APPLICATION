package com.google.android.gms.internal;

public interface zzqy {
    void zzafy();
}
