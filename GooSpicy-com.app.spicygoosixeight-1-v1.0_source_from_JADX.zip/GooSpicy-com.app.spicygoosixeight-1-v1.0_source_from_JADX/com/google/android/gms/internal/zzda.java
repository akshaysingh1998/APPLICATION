package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;

@zzir
public class zzda {
    public SharedPreferences zzn(Context context) {
        return context.getSharedPreferences("google_ads_flags", 1);
    }
}
