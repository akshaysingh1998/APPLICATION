package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.client.zzab.zza;
import com.google.android.gms.ads.internal.client.zzac;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.util.zzf;
import java.util.HashMap;
import java.util.Map;

@zzir
public class zzlq extends zza {
    private final Object zzail = new Object();
    private boolean zzaio = true;
    private final zzll zzbgj;
    private final float zzcqb;
    private int zzcqc;
    private zzac zzcqd;
    private boolean zzcqe;
    private boolean zzcqf;
    private float zzcqg;

    public zzlq(zzll com_google_android_gms_internal_zzll, float f) {
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.zzcqb = f;
    }

    private void zzc(String str, @Nullable Map<String, String> map) {
        final Map hashMap = map == null ? new HashMap() : new HashMap(map);
        hashMap.put("action", str);
        zzu.zzfq().runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzlq zzcqi;

            public void run() {
                this.zzcqi.zzbgj.zza("pubVideoCmd", hashMap);
            }
        });
    }

    private void zzde(String str) {
        zzc(str, null);
    }

    private void zzi(final int i, final int i2) {
        zzu.zzfq().runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzlq zzcqi;

            public void run() {
                synchronized (this.zzcqi.zzail) {
                    boolean z = false;
                    boolean z2 = i != i2;
                    boolean z3 = !this.zzcqi.zzcqe && i2 == 1;
                    boolean z4 = z2 && i2 == 1;
                    boolean z5 = z2 && i2 == 2;
                    z2 = z2 && i2 == 3;
                    zzlq com_google_android_gms_internal_zzlq = this.zzcqi;
                    if (this.zzcqi.zzcqe || z3) {
                        z = true;
                    }
                    com_google_android_gms_internal_zzlq.zzcqe = z;
                    if (this.zzcqi.zzcqd == null) {
                        return;
                    }
                    if (z3) {
                        try {
                            this.zzcqi.zzcqd.zzjb();
                        } catch (Throwable e) {
                            zzb.zzd("Unable to call onVideoStart()", e);
                        }
                    }
                    if (z4) {
                        try {
                            this.zzcqi.zzcqd.zzjc();
                        } catch (Throwable e2) {
                            zzb.zzd("Unable to call onVideoPlay()", e2);
                        }
                    }
                    if (z5) {
                        try {
                            this.zzcqi.zzcqd.zzjd();
                        } catch (Throwable e22) {
                            zzb.zzd("Unable to call onVideoPause()", e22);
                        }
                    }
                    if (z2) {
                        try {
                            this.zzcqi.zzcqd.onVideoEnd();
                        } catch (Throwable e3) {
                            zzb.zzd("Unable to call onVideoEnd()", e3);
                        }
                    }
                }
                return;
            }
        });
    }

    public int getPlaybackState() {
        int i;
        synchronized (this.zzail) {
            i = this.zzcqc;
        }
        return i;
    }

    public boolean isMuted() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcqf;
        }
        return z;
    }

    public void pause() {
        zzde("pause");
    }

    public void play() {
        zzde("play");
    }

    public void zza(float f, int i, boolean z) {
        int i2;
        synchronized (this.zzail) {
            this.zzcqg = f;
            this.zzcqf = z;
            i2 = this.zzcqc;
            this.zzcqc = i;
        }
        zzi(i2, i);
    }

    public void zza(zzac com_google_android_gms_ads_internal_client_zzac) {
        synchronized (this.zzail) {
            this.zzcqd = com_google_android_gms_ads_internal_client_zzac;
        }
    }

    public void zzam(boolean z) {
        synchronized (this.zzail) {
            this.zzaio = z;
        }
        zzc("initialState", zzf.zze("muteStart", z ? "1" : "0"));
    }

    public float zziz() {
        return this.zzcqb;
    }

    public float zzja() {
        float f;
        synchronized (this.zzail) {
            f = this.zzcqg;
        }
        return f;
    }

    public void zzm(boolean z) {
        zzde(z ? "mute" : "unmute");
    }
}
