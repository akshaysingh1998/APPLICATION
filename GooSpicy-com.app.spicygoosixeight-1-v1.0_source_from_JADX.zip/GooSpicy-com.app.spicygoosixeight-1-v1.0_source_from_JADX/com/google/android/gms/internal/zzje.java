package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;

@zzir
public class zzje extends zzjb {
    public void zza(Context context, zziv com_google_android_gms_internal_zziv, VersionInfoParcel versionInfoParcel) {
        zze(com_google_android_gms_internal_zziv);
    }
}
