package com.google.android.gms.internal;

public final class zzamz extends zzanc {
    public zzamz(String str) {
        super(str);
    }

    public zzamz(Throwable th) {
        super(th);
    }
}
