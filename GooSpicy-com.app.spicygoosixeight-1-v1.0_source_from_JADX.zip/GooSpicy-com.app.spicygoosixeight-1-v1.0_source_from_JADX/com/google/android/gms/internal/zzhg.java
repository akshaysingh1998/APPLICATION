package com.google.android.gms.internal;

import android.app.AlertDialog.Builder;
import android.app.DownloadManager.Request;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;
import android.webkit.URLUtil;
import com.google.android.gms.C0323R;
import com.google.android.gms.ads.internal.zzu;
import java.util.Map;

@zzir
public class zzhg extends zzhj {
    private final Context mContext;
    private final Map<String, String> zzbee;

    class C04502 implements OnClickListener {
        final /* synthetic */ zzhg zzbra;

        C04502(zzhg com_google_android_gms_internal_zzhg) {
            this.zzbra = com_google_android_gms_internal_zzhg;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            this.zzbra.zzbu("User canceled the download.");
        }
    }

    public zzhg(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        super(com_google_android_gms_internal_zzll, "storePicture");
        this.zzbee = map;
        this.mContext = com_google_android_gms_internal_zzll.zzuf();
    }

    public void execute() {
        if (this.mContext == null) {
            zzbu("Activity context is not available");
        } else if (zzu.zzfq().zzag(this.mContext).zzjr()) {
            final String str = (String) this.zzbee.get("iurl");
            if (TextUtils.isEmpty(str)) {
                zzbu("Image url cannot be empty.");
            } else if (URLUtil.isValidUrl(str)) {
                r1 = zzbt(str);
                if (zzu.zzfq().zzcr(r1)) {
                    Resources resources = zzu.zzft().getResources();
                    Builder zzaf = zzu.zzfq().zzaf(this.mContext);
                    zzaf.setTitle(resources != null ? resources.getString(C0323R.string.store_picture_title) : "Save image");
                    zzaf.setMessage(resources != null ? resources.getString(C0323R.string.store_picture_message) : "Allow Ad to store image in Picture gallery?");
                    zzaf.setPositiveButton(resources != null ? resources.getString(C0323R.string.accept) : "Accept", new OnClickListener(this) {
                        final /* synthetic */ zzhg zzbra;

                        public void onClick(android.content.DialogInterface r3, int r4) {
                            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
                            /*
                            r2 = this;
                            r3 = r2.zzbra;
                            r3 = r3.mContext;
                            r4 = "download";
                            r3 = r3.getSystemService(r4);
                            r3 = (android.app.DownloadManager) r3;
                            r4 = r2.zzbra;	 Catch:{ IllegalStateException -> 0x001c }
                            r0 = r0;	 Catch:{ IllegalStateException -> 0x001c }
                            r1 = r1;	 Catch:{ IllegalStateException -> 0x001c }
                            r4 = r4.zzk(r0, r1);	 Catch:{ IllegalStateException -> 0x001c }
                            r3.enqueue(r4);	 Catch:{ IllegalStateException -> 0x001c }
                            return;
                        L_0x001c:
                            r3 = r2.zzbra;
                            r4 = "Could not store picture.";
                            r3.zzbu(r4);
                            return;
                            */
                            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhg.1.onClick(android.content.DialogInterface, int):void");
                        }
                    });
                    zzaf.setNegativeButton(resources != null ? resources.getString(C0323R.string.decline) : "Decline", new C04502(this));
                    zzaf.create().show();
                    return;
                }
                str = "Image type not recognized: ";
                r1 = String.valueOf(r1);
                zzbu(r1.length() != 0 ? str.concat(r1) : new String(str));
            } else {
                r1 = "Invalid image url: ";
                str = String.valueOf(str);
                zzbu(str.length() != 0 ? r1.concat(str) : new String(r1));
            }
        } else {
            zzbu("Feature is not supported by the device.");
        }
    }

    String zzbt(String str) {
        return Uri.parse(str).getLastPathSegment();
    }

    Request zzk(String str, String str2) {
        Request request = new Request(Uri.parse(str));
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, str2);
        zzu.zzfs().zza(request);
        return request;
    }
}
