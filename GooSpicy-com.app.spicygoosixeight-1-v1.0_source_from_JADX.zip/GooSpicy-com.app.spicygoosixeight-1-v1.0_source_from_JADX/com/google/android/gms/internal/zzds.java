package com.google.android.gms.internal;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.common.util.zze;

@zzir
public class zzds {
    private static final Object zzamp = new Object();
    private static zzds zzber;
    private final Context mContext;
    private final zze zzaoa;
    private final zza zzbes = new zza(this.mContext);
    private long zzbet;

    private static class zza extends SQLiteOpenHelper {
        public zza(Context context) {
            super(context, "direct_app_install_log.db", null, 1);
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL("CREATE TABLE directappinstall( column_id INTEGER PRIMARY KEY AUTOINCREMENT, reference LONG, package TEXT, tracking_url TEXT, timestamp INTEGER, path TEXT);");
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS directappinstall");
            onCreate(sQLiteDatabase);
        }
    }

    private zzds(Context context, zze com_google_android_gms_common_util_zze) {
        this.mContext = context;
        this.zzaoa = com_google_android_gms_common_util_zze;
        this.zzbet = zzdr.zzbeq;
    }

    public static zzds zza(Context context, zze com_google_android_gms_common_util_zze) {
        zzds com_google_android_gms_internal_zzds;
        synchronized (zzamp) {
            if (zzber == null) {
                zzber = new zzds(context, com_google_android_gms_common_util_zze);
            }
            com_google_android_gms_internal_zzds = zzber;
        }
        return com_google_android_gms_internal_zzds;
    }

    private void zza(android.database.sqlite.SQLiteDatabase r11, java.lang.String r12) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r10 = this;
        r3 = "package = ?";
        r8 = 0;
        r9 = 1;
        r1 = "directappinstall";	 Catch:{ SQLiteException -> 0x0019 }
        r2 = new java.lang.String[r9];	 Catch:{ SQLiteException -> 0x0019 }
        r0 = "path";	 Catch:{ SQLiteException -> 0x0019 }
        r2[r8] = r0;	 Catch:{ SQLiteException -> 0x0019 }
        r4 = new java.lang.String[r9];	 Catch:{ SQLiteException -> 0x0019 }
        r4[r8] = r12;	 Catch:{ SQLiteException -> 0x0019 }
        r5 = 0;	 Catch:{ SQLiteException -> 0x0019 }
        r6 = 0;	 Catch:{ SQLiteException -> 0x0019 }
        r7 = 0;	 Catch:{ SQLiteException -> 0x0019 }
        r0 = r11;	 Catch:{ SQLiteException -> 0x0019 }
        r0 = r0.query(r1, r2, r3, r4, r5, r6, r7);	 Catch:{ SQLiteException -> 0x0019 }
        goto L_0x003e;
    L_0x0019:
        r0 = new java.lang.StringBuilder;
        r1 = 70;
        r2 = java.lang.String.valueOf(r12);
        r2 = r2.length();
        r1 = r1 + r2;
        r0.<init>(r1);
        r1 = "No package name ";
        r0.append(r1);
        r0.append(r12);
        r1 = " was recorded. Cleaning up records older than one day.";
        r0.append(r1);
        r0 = r0.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r0);
        r0 = 0;
    L_0x003e:
        if (r0 == 0) goto L_0x0070;
    L_0x0040:
        r1 = r0.getCount();
        if (r1 <= 0) goto L_0x006d;
    L_0x0046:
        r0.moveToFirst();
        r1 = "path";
        r1 = r0.getColumnIndex(r1);
        r1 = r0.getString(r1);
        r2 = android.text.TextUtils.isEmpty(r1);
        if (r2 != 0) goto L_0x0062;
    L_0x0059:
        r2 = com.google.android.gms.internal.zzdt.zzkq();
        r3 = r10.mContext;
        r2.zzd(r3, r1);
    L_0x0062:
        r1 = "package = ?";
        r2 = new java.lang.String[r9];
        r2[r8] = r12;
        r12 = "directappinstall";
        r11.delete(r12, r1, r2);
    L_0x006d:
        r0.close();
    L_0x0070:
        r12 = r10.zzaoa;
        r0 = r12.currentTimeMillis();
        r2 = r10.zzkp();
        r4 = r0 - r2;
        r12 = java.lang.Long.valueOf(r4);
        r0 = "timestamp < ?";
        r1 = new java.lang.String[r9];
        r2 = r12.longValue();
        r12 = java.lang.Long.toString(r2);
        r1[r8] = r12;
        r12 = "directappinstall";
        r11.delete(r12, r0, r1);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzds.zza(android.database.sqlite.SQLiteDatabase, java.lang.String):void");
    }

    private long zzkp() {
        return this.zzbet;
    }

    public void zza(long j, String str, String str2) {
        SQLiteDatabase writableDatabase = this.zzbes.getWritableDatabase();
        zza(writableDatabase, str);
        ContentValues contentValues = new ContentValues();
        contentValues.put("reference", Long.valueOf(j));
        contentValues.put("package", str);
        contentValues.put("tracking_url", str2);
        contentValues.put("timestamp", Long.valueOf(this.zzaoa.currentTimeMillis()));
        writableDatabase.insert("directappinstall", null, contentValues);
        this.zzbes.close();
    }

    public boolean zzat(String str) {
        String str2 = "Deleting entry in direct app install log with file path: ";
        String valueOf = String.valueOf(str);
        zzb.zzcw(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        boolean z = true;
        if (this.zzbes.getWritableDatabase().delete("directappinstall", "path = ?", new String[]{str}) <= 0) {
            z = false;
        }
        this.zzbes.close();
        return z;
    }
}
