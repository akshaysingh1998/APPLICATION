package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzamx<T> {
    T zzb(zzamy com_google_android_gms_internal_zzamy, Type type, zzamw com_google_android_gms_internal_zzamw) throws zzanc;
}
