package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zza;
import java.util.ArrayList;
import java.util.List;

@zzir
class zzld {
    private final Object zzcob = new Object();
    private final List<Runnable> zzcoc = new ArrayList();
    private final List<Runnable> zzcod = new ArrayList();
    private boolean zzcoe = false;

    private void zzd(Runnable runnable) {
        zzkk.zza(runnable);
    }

    private void zze(Runnable runnable) {
        zza.zzcnf.post(runnable);
    }

    public void zzb(Runnable runnable) {
        synchronized (this.zzcob) {
            if (this.zzcoe) {
                zzd(runnable);
            } else {
                this.zzcoc.add(runnable);
            }
        }
    }

    public void zzc(Runnable runnable) {
        synchronized (this.zzcob) {
            if (this.zzcoe) {
                zze(runnable);
            } else {
                this.zzcod.add(runnable);
            }
        }
    }

    public void zzua() {
        synchronized (this.zzcob) {
            if (this.zzcoe) {
                return;
            }
            for (Runnable zzd : this.zzcoc) {
                zzd(zzd);
            }
            for (Runnable zzd2 : this.zzcod) {
                zze(zzd2);
            }
            this.zzcoc.clear();
            this.zzcod.clear();
            this.zzcoe = true;
        }
    }
}
