package com.google.android.gms.internal;

import android.support.annotation.Nullable;

@zzir
public class zzdi {
    private final long zzbdz;
    @Nullable
    private final String zzbea;
    @Nullable
    private final zzdi zzbeb;

    public zzdi(long j, @Nullable String str, @Nullable zzdi com_google_android_gms_internal_zzdi) {
        this.zzbdz = j;
        this.zzbea = str;
        this.zzbeb = com_google_android_gms_internal_zzdi;
    }

    long getTime() {
        return this.zzbdz;
    }

    String zzkd() {
        return this.zzbea;
    }

    zzdi zzke() {
        return this.zzbeb;
    }
}
