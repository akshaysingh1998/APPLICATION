package com.google.android.gms.internal;

public interface zzo {
    void zza(zzr com_google_android_gms_internal_zzr) throws zzr;

    int zzc();

    int zzd();
}
