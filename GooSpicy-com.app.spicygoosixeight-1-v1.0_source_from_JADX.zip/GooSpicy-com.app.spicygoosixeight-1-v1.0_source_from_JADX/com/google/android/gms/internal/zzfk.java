package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.io.File;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@zzir
public class zzfk extends zzfh {
    private static final Set<String> zzbjt = Collections.synchronizedSet(new HashSet());
    private static final DecimalFormat zzbju = new DecimalFormat("#,###");
    private File zzbjv;
    private boolean zzbjw;

    public zzfk(zzll com_google_android_gms_internal_zzll) {
        super(com_google_android_gms_internal_zzll);
        File cacheDir = this.mContext.getCacheDir();
        if (cacheDir == null) {
            zzb.zzcy("Context.getCacheDir() returned null");
            return;
        }
        this.zzbjv = new File(cacheDir, "admobVideoStreams");
        if (this.zzbjv.isDirectory() || this.zzbjv.mkdirs()) {
            if (this.zzbjv.setReadable(true, false)) {
                if (this.zzbjv.setExecutable(true, false)) {
                    return;
                }
            }
            String str = "Could not set cache file permissions at ";
            String valueOf = String.valueOf(this.zzbjv.getAbsolutePath());
            zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            this.zzbjv = null;
            return;
        }
        str = "Could not create preload cache directory at ";
        valueOf = String.valueOf(this.zzbjv.getAbsolutePath());
        zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        this.zzbjv = null;
    }

    private File zzb(File file) {
        return new File(this.zzbjv, String.valueOf(file.getName()).concat(".done"));
    }

    private static void zzc(java.io.File r2) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = r2.isFile();
        if (r0 == 0) goto L_0x000e;
    L_0x0006:
        r0 = java.lang.System.currentTimeMillis();
        r2.setLastModified(r0);
        return;
    L_0x000e:
        r2.createNewFile();	 Catch:{ IOException -> 0x0011 }
    L_0x0011:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfk.zzc(java.io.File):void");
    }

    public void abort() {
        this.zzbjw = true;
    }

    public boolean zzba(java.lang.String r28) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r27 = this;
        r7 = r27;
        r8 = r28;
        r1 = r7.zzbjv;
        r9 = 0;
        r10 = 0;
        if (r1 != 0) goto L_0x0010;
    L_0x000a:
        r1 = "noCacheDir";
    L_0x000c:
        r7.zza(r8, r10, r1, r10);
        return r9;
    L_0x0010:
        r1 = r27.zzln();
        r2 = com.google.android.gms.internal.zzdc.zzayk;
        r2 = r2.get();
        r2 = (java.lang.Integer) r2;
        r2 = r2.intValue();
        if (r1 <= r2) goto L_0x0030;
    L_0x0022:
        r1 = r27.zzlo();
        if (r1 != 0) goto L_0x0010;
    L_0x0028:
        r1 = "Unable to expire stream cache";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);
        r1 = "expireFailed";
        goto L_0x000c;
    L_0x0030:
        r1 = r27.zzbb(r28);
        r11 = new java.io.File;
        r2 = r7.zzbjv;
        r11.<init>(r2, r1);
        r12 = r7.zzb(r11);
        r1 = r11.isFile();
        r13 = 1;
        if (r1 == 0) goto L_0x0073;
    L_0x0046:
        r1 = r12.isFile();
        if (r1 == 0) goto L_0x0073;
    L_0x004c:
        r1 = r11.length();
        r1 = (int) r1;
        r2 = "Stream cache hit at ";
        r3 = java.lang.String.valueOf(r28);
        r4 = r3.length();
        if (r4 == 0) goto L_0x0062;
    L_0x005d:
        r2 = r2.concat(r3);
        goto L_0x0068;
    L_0x0062:
        r3 = new java.lang.String;
        r3.<init>(r2);
        r2 = r3;
    L_0x0068:
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r2);
        r2 = r11.getAbsolutePath();
        r7.zza(r8, r2, r1);
        return r13;
    L_0x0073:
        r1 = r7.zzbjv;
        r1 = r1.getAbsolutePath();
        r1 = java.lang.String.valueOf(r1);
        r2 = java.lang.String.valueOf(r28);
        r3 = r2.length();
        if (r3 == 0) goto L_0x008d;
    L_0x0087:
        r1 = r1.concat(r2);
        r14 = r1;
        goto L_0x0093;
    L_0x008d:
        r2 = new java.lang.String;
        r2.<init>(r1);
        r14 = r2;
    L_0x0093:
        r1 = zzbjt;
        monitor-enter(r1);
        r2 = zzbjt;	 Catch:{ all -> 0x045e }
        r2 = r2.contains(r14);	 Catch:{ all -> 0x045e }
        if (r2 == 0) goto L_0x00c3;	 Catch:{ all -> 0x045e }
    L_0x009e:
        r2 = "Stream cache already in progress at ";	 Catch:{ all -> 0x045e }
        r3 = java.lang.String.valueOf(r28);	 Catch:{ all -> 0x045e }
        r4 = r3.length();	 Catch:{ all -> 0x045e }
        if (r4 == 0) goto L_0x00af;	 Catch:{ all -> 0x045e }
    L_0x00aa:
        r2 = r2.concat(r3);	 Catch:{ all -> 0x045e }
        goto L_0x00b5;	 Catch:{ all -> 0x045e }
    L_0x00af:
        r3 = new java.lang.String;	 Catch:{ all -> 0x045e }
        r3.<init>(r2);	 Catch:{ all -> 0x045e }
        r2 = r3;	 Catch:{ all -> 0x045e }
    L_0x00b5:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r2);	 Catch:{ all -> 0x045e }
        r2 = r11.getAbsolutePath();	 Catch:{ all -> 0x045e }
        r3 = "inProgress";	 Catch:{ all -> 0x045e }
        r7.zza(r8, r2, r3, r10);	 Catch:{ all -> 0x045e }
        monitor-exit(r1);	 Catch:{ all -> 0x045e }
        return r9;	 Catch:{ all -> 0x045e }
    L_0x00c3:
        r2 = zzbjt;	 Catch:{ all -> 0x045e }
        r2.add(r14);	 Catch:{ all -> 0x045e }
        monitor-exit(r1);	 Catch:{ all -> 0x045e }
        r15 = "error";
        r1 = new java.net.URL;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r1.<init>(r8);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r1 = r1.openConnection();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = com.google.android.gms.internal.zzdc.zzayp;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = r2.get();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = (java.lang.Integer) r2;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = r2.intValue();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r1.setConnectTimeout(r2);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r1.setReadTimeout(r2);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = r1 instanceof java.net.HttpURLConnection;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        if (r2 == 0) goto L_0x014c;
    L_0x00ea:
        r2 = r1;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r2 = (java.net.HttpURLConnection) r2;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r2 = r2.getResponseCode();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = 400; // 0x190 float:5.6E-43 double:1.976E-321;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        if (r2 < r3) goto L_0x014c;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
    L_0x00f5:
        r1 = "badUrl";	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = "HTTP request failed. Code: ";	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
        r4 = java.lang.Integer.toString(r2);	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
        r4 = java.lang.String.valueOf(r4);	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
        r5 = r4.length();	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
        if (r5 == 0) goto L_0x010c;	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
    L_0x0107:
        r3 = r3.concat(r4);	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
        goto L_0x0112;	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
    L_0x010c:
        r4 = new java.lang.String;	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
        r4.<init>(r3);	 Catch:{ IOException -> 0x013f, IOException -> 0x013f }
        r3 = r4;
    L_0x0112:
        r4 = new java.io.IOException;	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r5 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r6 = 32;	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r12 = java.lang.String.valueOf(r28);	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r12 = r12.length();	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r6 = r6 + r12;	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r5.<init>(r6);	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r6 = "HTTP status code ";	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r5.append(r6);	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r5.append(r2);	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r2 = " at ";	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r5.append(r2);	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r5.append(r8);	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r2 = r5.toString();	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        r4.<init>(r2);	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
        throw r4;	 Catch:{ IOException -> 0x013c, IOException -> 0x013c }
    L_0x013c:
        r0 = move-exception;
        r15 = r1;
        goto L_0x0142;
    L_0x013f:
        r0 = move-exception;
        r15 = r1;
        r3 = r10;
    L_0x0142:
        r2 = r14;
    L_0x0143:
        r1 = r0;
        goto L_0x03ca;
    L_0x0146:
        r0 = move-exception;
        r1 = r0;
        r3 = r10;
        r2 = r14;
        goto L_0x03ca;
    L_0x014c:
        r6 = r1.getContentLength();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        if (r6 >= 0) goto L_0x017b;
    L_0x0152:
        r1 = "Stream cache aborted, missing content-length header at ";	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r2 = java.lang.String.valueOf(r28);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = r2.length();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        if (r3 == 0) goto L_0x0163;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
    L_0x015e:
        r1 = r1.concat(r2);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        goto L_0x0169;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
    L_0x0163:
        r2 = new java.lang.String;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r2.<init>(r1);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1 = r2;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
    L_0x0169:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1 = r11.getAbsolutePath();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r2 = "contentLengthMissing";	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r7.zza(r8, r1, r2, r10);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1 = zzbjt;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1.remove(r14);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        return r9;
    L_0x017b:
        r2 = zzbju;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3 = (long) r6;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = r2.format(r3);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3 = com.google.android.gms.internal.zzdc.zzayl;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3 = r3.get();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3 = (java.lang.Integer) r3;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r5 = r3.intValue();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        if (r6 <= r5) goto L_0x01e6;
    L_0x0190:
        r1 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = 33;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r4 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r4 = r4.length();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = r3 + r4;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r4 = java.lang.String.valueOf(r28);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r4 = r4.length();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = r3 + r4;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1.<init>(r3);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = "Content length ";	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1.append(r3);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1.append(r2);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = " exceeds limit at ";	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1.append(r3);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1.append(r8);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1 = r1.toString();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1 = "File too big for full file cache. Size: ";	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r2 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = r2.length();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        if (r3 == 0) goto L_0x01d1;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
    L_0x01cc:
        r1 = r1.concat(r2);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        goto L_0x01d7;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
    L_0x01d1:
        r2 = new java.lang.String;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r2.<init>(r1);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1 = r2;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
    L_0x01d7:
        r2 = r11.getAbsolutePath();	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r3 = "sizeExceeded";	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r7.zza(r8, r2, r3, r1);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1 = zzbjt;	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        r1.remove(r14);	 Catch:{ IOException -> 0x0146, IOException -> 0x0146 }
        return r9;
    L_0x01e6:
        r3 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r4 = 20;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r10 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r10 = r10.length();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r4 = r4 + r10;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r10 = java.lang.String.valueOf(r28);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r10 = r10.length();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r4 = r4 + r10;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3.<init>(r4);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r4 = "Caching ";	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3.append(r4);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3.append(r2);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = " bytes from ";	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3.append(r2);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3.append(r8);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r2 = r3.toString();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r2);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r1 = r1.getInputStream();	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r10 = java.nio.channels.Channels.newChannel(r1);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r4 = new java.io.FileOutputStream;	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r4.<init>(r11);	 Catch:{ IOException -> 0x03c5, IOException -> 0x03c5 }
        r3 = r4.getChannel();	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r1 = 1048576; // 0x100000 float:1.469368E-39 double:5.180654E-318;	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r2 = java.nio.ByteBuffer.allocate(r1);	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r1 = com.google.android.gms.ads.internal.zzu.zzfu();	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r16 = r1.currentTimeMillis();	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r9 = com.google.android.gms.internal.zzdc.zzayo;	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r9 = r9.get();	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r9 = (java.lang.Long) r9;	 Catch:{ IOException -> 0x03be, IOException -> 0x03be }
        r18 = r14;
        r13 = r9.longValue();	 Catch:{ IOException -> 0x03b9, IOException -> 0x03b9 }
        r9 = new com.google.android.gms.internal.zzkv;	 Catch:{ IOException -> 0x03b9, IOException -> 0x03b9 }
        r9.<init>(r13);	 Catch:{ IOException -> 0x03b9, IOException -> 0x03b9 }
        r13 = com.google.android.gms.internal.zzdc.zzayn;	 Catch:{ IOException -> 0x03b9, IOException -> 0x03b9 }
        r13 = r13.get();	 Catch:{ IOException -> 0x03b9, IOException -> 0x03b9 }
        r13 = (java.lang.Long) r13;	 Catch:{ IOException -> 0x03b9, IOException -> 0x03b9 }
        r13 = r13.longValue();	 Catch:{ IOException -> 0x03b9, IOException -> 0x03b9 }
        r19 = r4;
        r4 = 0;
    L_0x0257:
        r20 = r10.read(r2);	 Catch:{ IOException -> 0x03b3, IOException -> 0x03b3 }
        if (r20 < 0) goto L_0x0351;
    L_0x025d:
        r4 = r4 + r20;
        if (r4 <= r5) goto L_0x02a1;
    L_0x0261:
        r1 = "sizeExceeded";	 Catch:{ IOException -> 0x0299, IOException -> 0x0299 }
        r2 = "File too big for full file cache. Size: ";	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3 = java.lang.Integer.toString(r4);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3 = java.lang.String.valueOf(r3);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r4 = r3.length();	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        if (r4 == 0) goto L_0x0279;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
    L_0x0273:
        r2 = r2.concat(r3);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r10 = r2;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        goto L_0x027f;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
    L_0x0279:
        r3 = new java.lang.String;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3.<init>(r2);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r10 = r3;
    L_0x027f:
        r2 = new java.io.IOException;	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
        r3 = "stream cache file size limit exceeded";	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
        r2.<init>(r3);	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
        throw r2;	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
    L_0x0287:
        r0 = move-exception;
        r15 = r1;
        r3 = r10;
        r2 = r18;
        r10 = r19;
        goto L_0x0143;
    L_0x0290:
        r0 = move-exception;
        r15 = r1;
        r2 = r18;
        r10 = r19;
        r3 = 0;
        goto L_0x0143;
    L_0x0299:
        r0 = move-exception;
        r1 = r0;
        r2 = r18;
        r10 = r19;
        goto L_0x03c3;
    L_0x02a1:
        r2.flip();	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
    L_0x02a4:
        r20 = r3.write(r2);	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
        if (r20 <= 0) goto L_0x02ab;	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
    L_0x02aa:
        goto L_0x02a4;	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
    L_0x02ab:
        r2.clear();	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
        r20 = r1.currentTimeMillis();	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
        r22 = r20 - r16;
        r20 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r20 = r20 * r13;
        r24 = (r22 > r20 ? 1 : (r22 == r20 ? 0 : -1));
        if (r24 <= 0) goto L_0x02ef;
    L_0x02bc:
        r1 = "downloadTimeout";	 Catch:{ IOException -> 0x0299, IOException -> 0x0299 }
        r2 = java.lang.Long.toString(r13);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r2 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r4 = 29;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r5 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r5 = r5.length();	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r4 = r4 + r5;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3.<init>(r4);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r4 = "Timeout exceeded. Limit: ";	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3.append(r4);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3.append(r2);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r2 = " sec";	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3.append(r2);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r10 = r3.toString();	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r2 = new java.io.IOException;	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
        r3 = "stream cache time limit exceeded";	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
        r2.<init>(r3);	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
        throw r2;	 Catch:{ IOException -> 0x0287, IOException -> 0x0287 }
    L_0x02ef:
        r25 = r1;
        r1 = r7.zzbjw;	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
        if (r1 == 0) goto L_0x02ff;
    L_0x02f5:
        r1 = "externalAbort";	 Catch:{ IOException -> 0x0299, IOException -> 0x0299 }
        r2 = new java.io.IOException;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r3 = "abort requested";	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        r2.<init>(r3);	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
        throw r2;	 Catch:{ IOException -> 0x0290, IOException -> 0x0290 }
    L_0x02ff:
        r1 = r9.tryAcquire();	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
        if (r1 == 0) goto L_0x0326;	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
    L_0x0305:
        r20 = r11.getAbsolutePath();	 Catch:{ IOException -> 0x0348, IOException -> 0x0348 }
        r21 = 0;
        r22 = r25;
        r1 = r7;
        r23 = r2;
        r2 = r8;
        r24 = r3;
        r3 = r20;
        r26 = r9;
        r9 = r19;
        r19 = r4;
        r20 = r5;
        r5 = r6;
        r25 = r6;
        r6 = r21;
        r1.zza(r2, r3, r4, r5, r6);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        goto L_0x0336;
    L_0x0326:
        r23 = r2;
        r24 = r3;
        r20 = r5;
        r26 = r9;
        r9 = r19;
        r22 = r25;
        r19 = r4;
        r25 = r6;
    L_0x0336:
        r4 = r19;
        r5 = r20;
        r1 = r22;
        r2 = r23;
        r3 = r24;
        r6 = r25;
        r19 = r9;
        r9 = r26;
        goto L_0x0257;
    L_0x0348:
        r0 = move-exception;
        r9 = r19;
    L_0x034b:
        r1 = r0;
        r10 = r9;
        r2 = r18;
        goto L_0x03c3;
    L_0x0351:
        r9 = r19;
        r9.close();	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        r1 = 3;	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        r1 = com.google.android.gms.ads.internal.util.client.zzb.zzaz(r1);	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        if (r1 == 0) goto L_0x0397;
    L_0x035d:
        r1 = zzbju;	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r2 = (long) r4;	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r1 = r1.format(r2);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r2 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r3 = 22;	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r5 = java.lang.String.valueOf(r1);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r5 = r5.length();	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r3 = r3 + r5;	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r5 = java.lang.String.valueOf(r28);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r5 = r5.length();	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r3 = r3 + r5;	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r2.<init>(r3);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r3 = "Preloaded ";	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r2.append(r3);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r2.append(r1);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r1 = " bytes from ";	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r2.append(r1);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r2.append(r8);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        r1 = r2.toString();	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r1);	 Catch:{ IOException -> 0x0395, IOException -> 0x0395 }
        goto L_0x0397;
    L_0x0395:
        r0 = move-exception;
        goto L_0x034b;
    L_0x0397:
        r1 = 0;
        r2 = 1;
        r11.setReadable(r2, r1);	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        zzc(r12);	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        r1 = r11.getAbsolutePath();	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        r7.zza(r8, r1, r4);	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        r1 = zzbjt;	 Catch:{ IOException -> 0x03b1, IOException -> 0x03b1 }
        r2 = r18;
        r1.remove(r2);	 Catch:{ IOException -> 0x03af, IOException -> 0x03af }
        r1 = 1;
        return r1;
    L_0x03af:
        r0 = move-exception;
        goto L_0x03c1;
    L_0x03b1:
        r0 = move-exception;
        goto L_0x03bb;
    L_0x03b3:
        r0 = move-exception;
        r2 = r18;
        r9 = r19;
        goto L_0x03c1;
    L_0x03b9:
        r0 = move-exception;
        r9 = r4;
    L_0x03bb:
        r2 = r18;
        goto L_0x03c1;
    L_0x03be:
        r0 = move-exception;
        r9 = r4;
        r2 = r14;
    L_0x03c1:
        r1 = r0;
        r10 = r9;
    L_0x03c3:
        r3 = 0;
        goto L_0x03ca;
    L_0x03c5:
        r0 = move-exception;
        r2 = r14;
        r1 = r0;
        r3 = 0;
        r10 = 0;
    L_0x03ca:
        r4 = r1 instanceof java.lang.RuntimeException;
        if (r4 == 0) goto L_0x03d6;
    L_0x03ce:
        r4 = com.google.android.gms.ads.internal.zzu.zzft();
        r5 = 1;
        r4.zzb(r1, r5);
    L_0x03d6:
        r10.close();	 Catch:{ IOException -> 0x03d9, IOException -> 0x03d9 }
    L_0x03d9:
        r4 = r7.zzbjw;
        if (r4 == 0) goto L_0x0402;
    L_0x03dd:
        r1 = new java.lang.StringBuilder;
        r4 = 26;
        r5 = java.lang.String.valueOf(r28);
        r5 = r5.length();
        r4 = r4 + r5;
        r1.<init>(r4);
        r4 = "Preload aborted for URL \"";
        r1.append(r4);
        r1.append(r8);
        r4 = "\"";
        r1.append(r4);
        r1 = r1.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcx(r1);
        goto L_0x0426;
    L_0x0402:
        r4 = new java.lang.StringBuilder;
        r5 = 25;
        r6 = java.lang.String.valueOf(r28);
        r6 = r6.length();
        r5 = r5 + r6;
        r4.<init>(r5);
        r5 = "Preload failed for URL \"";
        r4.append(r5);
        r4.append(r8);
        r5 = "\"";
        r4.append(r5);
        r4 = r4.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzd(r4, r1);
    L_0x0426:
        r1 = r11.exists();
        if (r1 == 0) goto L_0x0450;
    L_0x042c:
        r1 = r11.delete();
        if (r1 != 0) goto L_0x0450;
    L_0x0432:
        r1 = "Could not delete partial cache file at ";
        r4 = r11.getAbsolutePath();
        r4 = java.lang.String.valueOf(r4);
        r5 = r4.length();
        if (r5 == 0) goto L_0x0447;
    L_0x0442:
        r1 = r1.concat(r4);
        goto L_0x044d;
    L_0x0447:
        r4 = new java.lang.String;
        r4.<init>(r1);
        r1 = r4;
    L_0x044d:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r1);
    L_0x0450:
        r1 = r11.getAbsolutePath();
        r7.zza(r8, r1, r15, r3);
        r1 = zzbjt;
        r1.remove(r2);
        r1 = 0;
        return r1;
    L_0x045e:
        r0 = move-exception;
        r2 = r0;
        monitor-exit(r1);	 Catch:{ all -> 0x045e }
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfk.zzba(java.lang.String):boolean");
    }

    public int zzln() {
        int i = 0;
        if (this.zzbjv == null) {
            return 0;
        }
        File[] listFiles = this.zzbjv.listFiles();
        int length = listFiles.length;
        int i2 = 0;
        while (i < length) {
            if (!listFiles[i].getName().endsWith(".done")) {
                i2++;
            }
            i++;
        }
        return i2;
    }

    public boolean zzlo() {
        boolean z = false;
        if (this.zzbjv == null) {
            return false;
        }
        long j = Long.MAX_VALUE;
        File file = null;
        for (File file2 : this.zzbjv.listFiles()) {
            if (!file2.getName().endsWith(".done")) {
                long lastModified = file2.lastModified();
                if (lastModified < j) {
                    file = file2;
                    j = lastModified;
                }
            }
        }
        if (file != null) {
            z = file.delete();
            File zzb = zzb(file);
            if (zzb.isFile()) {
                z &= zzb.delete();
            }
        }
        return z;
    }
}
