package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import org.json.JSONObject;

@zzir
public class zzci extends zzcd {
    private final zzfx zzarn;

    public zzci(Context context, AdSizeParcel adSizeParcel, zzjy com_google_android_gms_internal_zzjy, VersionInfoParcel versionInfoParcel, zzck com_google_android_gms_internal_zzck, zzfx com_google_android_gms_internal_zzfx) {
        super(context, adSizeParcel, com_google_android_gms_internal_zzjy, versionInfoParcel, com_google_android_gms_internal_zzck);
        this.zzarn = com_google_android_gms_internal_zzfx;
        zzc(this.zzarn);
        zzgw();
        zzk(3);
        String str = "Tracking ad unit: ";
        String valueOf = String.valueOf(this.zzaqi.zzhn());
        zzb.zzcw(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
    }

    protected void destroy() {
        synchronized (this.zzail) {
            super.destroy();
            zzd(this.zzarn);
        }
    }

    protected void zzb(JSONObject jSONObject) {
        this.zzarn.zza("AFMA_updateActiveView", jSONObject);
    }

    public void zzgy() {
        destroy();
    }

    protected boolean zzhe() {
        return true;
    }
}
