package com.google.android.gms.internal;

import android.content.Context;
import com.bumptech.glide.load.Key;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.overlay.zzg;
import com.google.android.gms.ads.internal.overlay.zzp;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zze;
import com.google.android.gms.ads.internal.zzu;
import org.json.JSONObject;

@zzir
public class zzfv implements zzft {
    private final zzll zzbgj;

    public zzfv(Context context, VersionInfoParcel versionInfoParcel, zzas com_google_android_gms_internal_zzas) {
        this.zzbgj = zzu.zzfr().zza(context, new AdSizeParcel(), false, false, com_google_android_gms_internal_zzas, versionInfoParcel);
        this.zzbgj.getWebView().setWillNotDraw(true);
    }

    private void runOnUiThread(Runnable runnable) {
        if (zzm.zziw().zzty()) {
            runnable.run();
        } else {
            zzkl.zzclg.post(runnable);
        }
    }

    public void destroy() {
        this.zzbgj.destroy();
    }

    public void zza(zza com_google_android_gms_ads_internal_client_zza, zzg com_google_android_gms_ads_internal_overlay_zzg, zzeo com_google_android_gms_internal_zzeo, zzp com_google_android_gms_ads_internal_overlay_zzp, boolean z, zzev com_google_android_gms_internal_zzev, zzex com_google_android_gms_internal_zzex, zze com_google_android_gms_ads_internal_zze, zzhk com_google_android_gms_internal_zzhk) {
        this.zzbgj.zzuk().zza(com_google_android_gms_ads_internal_client_zza, com_google_android_gms_ads_internal_overlay_zzg, com_google_android_gms_internal_zzeo, com_google_android_gms_ads_internal_overlay_zzp, z, com_google_android_gms_internal_zzev, com_google_android_gms_internal_zzex, new zze(this.zzbgj.getContext(), false), com_google_android_gms_internal_zzhk, null);
    }

    public void zza(final zzft.zza com_google_android_gms_internal_zzft_zza) {
        this.zzbgj.zzuk().zza(new zzlm.zza(this) {
            final /* synthetic */ zzfv zzblr;

            public void zza(zzll com_google_android_gms_internal_zzll, boolean z) {
                com_google_android_gms_internal_zzft_zza.zzmb();
            }
        });
    }

    public void zza(String str, zzet com_google_android_gms_internal_zzet) {
        this.zzbgj.zzuk().zza(str, com_google_android_gms_internal_zzet);
    }

    public void zza(final String str, final JSONObject jSONObject) {
        runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzfv zzblr;

            public void run() {
                this.zzblr.zzbgj.zza(str, jSONObject);
            }
        });
    }

    public void zzb(String str, zzet com_google_android_gms_internal_zzet) {
        this.zzbgj.zzuk().zzb(str, com_google_android_gms_internal_zzet);
    }

    public void zzb(String str, JSONObject jSONObject) {
        this.zzbgj.zzb(str, jSONObject);
    }

    public void zzbh(String str) {
        str = String.format("<!DOCTYPE html><html><head><script src=\"%s\"></script></head><body></body></html>", new Object[]{str});
        runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzfv zzblr;

            public void run() {
                this.zzblr.zzbgj.loadData(str, "text/html", Key.STRING_CHARSET_NAME);
            }
        });
    }

    public void zzbi(final String str) {
        runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzfv zzblr;

            public void run() {
                this.zzblr.zzbgj.loadUrl(str);
            }
        });
    }

    public void zzbj(final String str) {
        runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzfv zzblr;

            public void run() {
                this.zzblr.zzbgj.loadData(str, "text/html", Key.STRING_CHARSET_NAME);
            }
        });
    }

    public void zzj(final String str, final String str2) {
        runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzfv zzblr;

            public void run() {
                this.zzblr.zzbgj.zzj(str, str2);
            }
        });
    }

    public zzfy zzma() {
        return new zzfz(this);
    }
}
