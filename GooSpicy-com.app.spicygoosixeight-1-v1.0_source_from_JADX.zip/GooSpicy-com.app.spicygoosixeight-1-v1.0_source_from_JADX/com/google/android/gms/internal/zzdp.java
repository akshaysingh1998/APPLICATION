package com.google.android.gms.internal;

import com.google.android.gms.ads.doubleclick.OnCustomRenderedAdLoadedListener;
import com.google.android.gms.internal.zzdo.zza;

@zzir
public final class zzdp extends zza {
    private final OnCustomRenderedAdLoadedListener zzawg;

    public zzdp(OnCustomRenderedAdLoadedListener onCustomRenderedAdLoadedListener) {
        this.zzawg = onCustomRenderedAdLoadedListener;
    }

    public void zza(zzdn com_google_android_gms_internal_zzdn) {
        this.zzawg.onCustomRenderedAdLoaded(new zzdm(com_google_android_gms_internal_zzdn));
    }
}
