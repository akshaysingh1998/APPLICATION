package com.google.android.gms.internal;

import java.util.Map;

public interface zzet {
    void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map);
}
