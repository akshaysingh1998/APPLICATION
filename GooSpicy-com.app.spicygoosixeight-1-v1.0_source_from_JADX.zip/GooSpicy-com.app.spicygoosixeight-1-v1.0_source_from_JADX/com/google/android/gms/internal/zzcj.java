package com.google.android.gms.internal;

import com.google.android.gms.internal.zzfw.zzc;
import com.google.android.gms.internal.zzle.zza;
import com.google.android.gms.internal.zzle.zzb;
import org.json.JSONObject;

@zzir
public class zzcj extends zzcd {
    private zzc zzaro;
    private boolean zzarp;

    class C08762 implements zza {
        final /* synthetic */ zzcj zzarr;

        C08762(zzcj com_google_android_gms_internal_zzcj) {
            this.zzarr = com_google_android_gms_internal_zzcj;
        }

        public void run() {
        }
    }

    class C08773 implements zzle.zzc<zzfx> {
        final /* synthetic */ zzcj zzarr;

        C08773(zzcj com_google_android_gms_internal_zzcj) {
            this.zzarr = com_google_android_gms_internal_zzcj;
        }

        public void zzb(zzfx com_google_android_gms_internal_zzfx) {
            this.zzarr.zzarp = true;
            this.zzarr.zzc(com_google_android_gms_internal_zzfx);
            this.zzarr.zzgw();
            this.zzarr.zzk(3);
        }

        public /* synthetic */ void zzd(Object obj) {
            zzb((zzfx) obj);
        }
    }

    class C08784 implements zza {
        final /* synthetic */ zzcj zzarr;

        C08784(zzcj com_google_android_gms_internal_zzcj) {
            this.zzarr = com_google_android_gms_internal_zzcj;
        }

        public void run() {
            this.zzarr.destroy();
        }
    }

    class C08806 implements zzle.zzc<zzfx> {
        final /* synthetic */ zzcj zzarr;

        C08806(zzcj com_google_android_gms_internal_zzcj) {
            this.zzarr = com_google_android_gms_internal_zzcj;
        }

        public void zzb(zzfx com_google_android_gms_internal_zzfx) {
            this.zzarr.zzd(com_google_android_gms_internal_zzfx);
        }

        public /* synthetic */ void zzd(Object obj) {
            zzb((zzfx) obj);
        }
    }

    public zzcj(android.content.Context r1, com.google.android.gms.ads.internal.client.AdSizeParcel r2, com.google.android.gms.internal.zzjy r3, com.google.android.gms.ads.internal.util.client.VersionInfoParcel r4, com.google.android.gms.internal.zzck r5, com.google.android.gms.internal.zzfw r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = this;
        r0.<init>(r1, r2, r3, r4, r5);
        r1 = r6.zzmc();
        r0.zzaro = r1;
        r1 = r5.zzhj();	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r1 = r1.zzhh();	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r1 = r0.zzd(r1);	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r2 = r0.zzaro;	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r3 = new com.google.android.gms.internal.zzcj$1;	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r3.<init>(r0, r1);	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r1 = new com.google.android.gms.internal.zzcj$2;	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r1.<init>(r0);	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        r2.zza(r3, r1);	 Catch:{ JSONException -> 0x002b, RuntimeException -> 0x0025 }
        goto L_0x002b;
    L_0x0025:
        r1 = move-exception;
        r2 = "Failure while processing active view data.";
        com.google.android.gms.ads.internal.util.client.zzb.zzb(r2, r1);
    L_0x002b:
        r1 = r0.zzaro;
        r2 = new com.google.android.gms.internal.zzcj$3;
        r2.<init>(r0);
        r3 = new com.google.android.gms.internal.zzcj$4;
        r3.<init>(r0);
        r1.zza(r2, r3);
        r1 = "Tracking ad unit: ";
        r2 = r0.zzaqi;
        r2 = r2.zzhn();
        r2 = java.lang.String.valueOf(r2);
        r3 = r2.length();
        if (r3 == 0) goto L_0x0051;
    L_0x004c:
        r1 = r1.concat(r2);
        goto L_0x0057;
    L_0x0051:
        r2 = new java.lang.String;
        r2.<init>(r1);
        r1 = r2;
    L_0x0057:
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r1);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzcj.<init>(android.content.Context, com.google.android.gms.ads.internal.client.AdSizeParcel, com.google.android.gms.internal.zzjy, com.google.android.gms.ads.internal.util.client.VersionInfoParcel, com.google.android.gms.internal.zzck, com.google.android.gms.internal.zzfw):void");
    }

    protected void destroy() {
        synchronized (this.zzail) {
            super.destroy();
            this.zzaro.zza(new C08806(this), new zzb());
            this.zzaro.release();
        }
    }

    protected void zzb(final JSONObject jSONObject) {
        this.zzaro.zza(new zzle.zzc<zzfx>(this) {
            final /* synthetic */ zzcj zzarr;

            public void zzb(zzfx com_google_android_gms_internal_zzfx) {
                com_google_android_gms_internal_zzfx.zza("AFMA_updateActiveView", jSONObject);
            }

            public /* synthetic */ void zzd(Object obj) {
                zzb((zzfx) obj);
            }
        }, new zzb());
    }

    protected boolean zzhe() {
        return this.zzarp;
    }
}
