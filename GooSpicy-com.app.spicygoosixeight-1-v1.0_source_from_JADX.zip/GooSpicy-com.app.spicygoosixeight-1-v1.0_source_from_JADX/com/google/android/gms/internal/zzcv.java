package com.google.android.gms.internal;

import android.text.TextUtils;

@zzir
public final class zzcv {
    private String zzaxl;

    public zzcv() {
        this((String) zzdc.zzaxw.zzjw());
    }

    public zzcv(String str) {
        if (TextUtils.isEmpty(str)) {
            str = (String) zzdc.zzaxw.zzjw();
        }
        this.zzaxl = str;
    }

    public String zzjv() {
        return this.zzaxl;
    }
}
