package com.google.android.gms.internal;

import android.net.Uri;
import android.net.Uri.Builder;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.AutoClickProtectionConfigurationParcel;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

@zzir
public final class zziw {
    private int mOrientation = -1;
    private boolean zzawl = false;
    private String zzbfm;
    private final AdRequestInfoParcel zzbox;
    private List<String> zzbzj;
    private String zzcex;
    private String zzcey;
    private List<String> zzcez;
    private String zzcfa;
    private String zzcfb;
    private List<String> zzcfc;
    private long zzcfd = -1;
    private boolean zzcfe = false;
    private final long zzcff = -1;
    private long zzcfg = -1;
    private boolean zzcfh = false;
    private boolean zzcfi = false;
    private boolean zzcfj = false;
    private boolean zzcfk = true;
    private String zzcfl = "";
    private boolean zzcfm = false;
    private RewardItemParcel zzcfn;
    private List<String> zzcfo;
    private List<String> zzcfp;
    private boolean zzcfq = false;
    private AutoClickProtectionConfigurationParcel zzcfr;
    private boolean zzcfs = false;
    private String zzcft;
    private List<String> zzcfu;
    private String zzcfv;
    private boolean zzcfw;
    private String zzcfx;

    public zziw(AdRequestInfoParcel adRequestInfoParcel) {
        this.zzbox = adRequestInfoParcel;
    }

    private void zzaa(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Gws-Query-Id");
        if (list != null && !list.isEmpty()) {
            this.zzcfl = (String) list.get(0);
        }
    }

    private void zzab(Map<String, List<String>> map) {
        String zzd = zzd(map, "X-Afma-Fluid");
        if (zzd != null && zzd.equals("height")) {
            this.zzcfm = true;
        }
    }

    private void zzac(Map<String, List<String>> map) {
        this.zzawl = "native_express".equals(zzd(map, "X-Afma-Ad-Format"));
    }

    private void zzad(Map<String, List<String>> map) {
        this.zzcfn = RewardItemParcel.zzci(zzd(map, "X-Afma-Rewards"));
    }

    private void zzae(Map<String, List<String>> map) {
        if (this.zzcfo == null) {
            this.zzcfo = zzf(map, "X-Afma-Reward-Video-Start-Urls");
        }
    }

    private void zzaf(Map<String, List<String>> map) {
        if (this.zzcfp == null) {
            this.zzcfp = zzf(map, "X-Afma-Reward-Video-Complete-Urls");
        }
    }

    private void zzag(Map<String, List<String>> map) {
        this.zzcfq = zzg(map, "X-Afma-Use-Displayed-Impression") | this.zzcfq;
    }

    private void zzah(Map<String, List<String>> map) {
        this.zzcfs = zzg(map, "X-Afma-Auto-Collect-Location") | this.zzcfs;
    }

    private void zzai(Map<String, List<String>> map) {
        List zzf = zzf(map, "X-Afma-Remote-Ping-Urls");
        if (zzf != null) {
            this.zzcfu = zzf;
        }
    }

    private void zzaj(Map<String, List<String>> map) {
        Object zzd = zzd(map, "X-Afma-Auto-Protection-Configuration");
        if (zzd != null) {
            if (!TextUtils.isEmpty(zzd)) {
                try {
                    this.zzcfr = AutoClickProtectionConfigurationParcel.zzh(new JSONObject(zzd));
                    return;
                } catch (Throwable e) {
                    zzb.zzd("Error parsing configuration JSON", e);
                    this.zzcfr = new AutoClickProtectionConfigurationParcel();
                    return;
                }
            }
        }
        Builder buildUpon = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204").buildUpon();
        buildUpon.appendQueryParameter("id", "gmob-apps-blocked-navigation");
        if (!TextUtils.isEmpty(this.zzcfa)) {
            buildUpon.appendQueryParameter("debugDialog", this.zzcfa);
        }
        boolean booleanValue = ((Boolean) zzdc.zzaye.get()).booleanValue();
        String[] strArr = new String[1];
        String valueOf = String.valueOf(buildUpon.toString());
        String valueOf2 = String.valueOf("navigationURL");
        StringBuilder stringBuilder = new StringBuilder((18 + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length());
        stringBuilder.append(valueOf);
        stringBuilder.append("&");
        stringBuilder.append(valueOf2);
        stringBuilder.append("={NAVIGATION_URL}");
        strArr[0] = stringBuilder.toString();
        this.zzcfr = new AutoClickProtectionConfigurationParcel(booleanValue, Arrays.asList(strArr));
    }

    private void zzak(Map<String, List<String>> map) {
        this.zzcft = zzd(map, "Set-Cookie");
    }

    private void zzal(Map<String, List<String>> map) {
        this.zzcfv = zzd(map, "X-Afma-Safe-Browsing");
    }

    static String zzd(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        return (list == null || list.isEmpty()) ? null : (String) list.get(0);
    }

    static long zze(java.util.Map<java.lang.String, java.util.List<java.lang.String>> r3, java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = r3.get(r4);
        r3 = (java.util.List) r3;
        if (r3 == 0) goto L_0x004e;
    L_0x0008:
        r0 = r3.isEmpty();
        if (r0 != 0) goto L_0x004e;
    L_0x000e:
        r0 = 0;
        r3 = r3.get(r0);
        r3 = (java.lang.String) r3;
        r0 = java.lang.Float.parseFloat(r3);	 Catch:{ NumberFormatException -> 0x001e }
        r3 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r0 * r3;
        r3 = (long) r0;
        return r3;
    L_0x001e:
        r0 = new java.lang.StringBuilder;
        r1 = 36;
        r2 = java.lang.String.valueOf(r4);
        r2 = r2.length();
        r1 = r1 + r2;
        r2 = java.lang.String.valueOf(r3);
        r2 = r2.length();
        r1 = r1 + r2;
        r0.<init>(r1);
        r1 = "Could not parse float from ";
        r0.append(r1);
        r0.append(r4);
        r4 = " header: ";
        r0.append(r4);
        r0.append(r3);
        r3 = r0.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r3);
    L_0x004e:
        r3 = -1;
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zziw.zze(java.util.Map, java.lang.String):long");
    }

    static List<String> zzf(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (!(list == null || list.isEmpty())) {
            String str2 = (String) list.get(0);
            if (str2 != null) {
                return Arrays.asList(str2.trim().split("\\s+"));
            }
        }
        return null;
    }

    private boolean zzg(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        return (list == null || list.isEmpty() || !Boolean.valueOf((String) list.get(0)).booleanValue()) ? false : true;
    }

    private void zzk(Map<String, List<String>> map) {
        this.zzcex = zzd(map, "X-Afma-Ad-Size");
    }

    private void zzl(Map<String, List<String>> map) {
        this.zzcfx = zzd(map, "X-Afma-Ad-Slot-Size");
    }

    private void zzm(Map<String, List<String>> map) {
        List zzf = zzf(map, "X-Afma-Click-Tracking-Urls");
        if (zzf != null) {
            this.zzcez = zzf;
        }
    }

    private void zzn(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Debug-Dialog");
        if (list != null && !list.isEmpty()) {
            this.zzcfa = (String) list.get(0);
        }
    }

    private void zzo(Map<String, List<String>> map) {
        List zzf = zzf(map, "X-Afma-Tracking-Urls");
        if (zzf != null) {
            this.zzcfc = zzf;
        }
    }

    private void zzp(Map<String, List<String>> map) {
        long zze = zze(map, "X-Afma-Interstitial-Timeout");
        if (zze != -1) {
            this.zzcfd = zze;
        }
    }

    private void zzq(Map<String, List<String>> map) {
        this.zzcfb = zzd(map, "X-Afma-ActiveView");
    }

    private void zzr(Map<String, List<String>> map) {
        this.zzcfi = "native".equals(zzd(map, "X-Afma-Ad-Format"));
    }

    private void zzs(Map<String, List<String>> map) {
        this.zzcfh = zzg(map, "X-Afma-Custom-Rendering-Allowed") | this.zzcfh;
    }

    private void zzt(Map<String, List<String>> map) {
        this.zzcfe = zzg(map, "X-Afma-Mediation") | this.zzcfe;
    }

    private void zzu(Map<String, List<String>> map) {
        this.zzcfw = zzg(map, "X-Afma-Render-In-Browser") | this.zzcfw;
    }

    private void zzv(Map<String, List<String>> map) {
        List zzf = zzf(map, "X-Afma-Manual-Tracking-Urls");
        if (zzf != null) {
            this.zzbzj = zzf;
        }
    }

    private void zzw(Map<String, List<String>> map) {
        long zze = zze(map, "X-Afma-Refresh-Rate");
        if (zze != -1) {
            this.zzcfg = zze;
        }
    }

    private void zzx(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Orientation");
        if (!(list == null || list.isEmpty())) {
            int zztl;
            String str = (String) list.get(0);
            if ("portrait".equalsIgnoreCase(str)) {
                zztl = zzu.zzfs().zztl();
            } else if ("landscape".equalsIgnoreCase(str)) {
                zztl = zzu.zzfs().zztk();
            }
            this.mOrientation = zztl;
        }
    }

    private void zzy(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Use-HTTPS");
        if (list != null && !list.isEmpty()) {
            this.zzcfj = Boolean.valueOf((String) list.get(0)).booleanValue();
        }
    }

    private void zzz(Map<String, List<String>> map) {
        List list = (List) map.get("X-Afma-Content-Url-Opted-Out");
        if (list != null && !list.isEmpty()) {
            this.zzcfk = Boolean.valueOf((String) list.get(0)).booleanValue();
        }
    }

    public void zzb(String str, Map<String, List<String>> map, String str2) {
        this.zzcey = str;
        this.zzbfm = str2;
        zzj((Map) map);
    }

    public AdResponseParcel zzj(long j) {
        AdRequestInfoParcel adRequestInfoParcel = this.zzbox;
        String str = this.zzcey;
        String str2 = this.zzbfm;
        List list = this.zzcez;
        List list2 = this.zzcfc;
        long j2 = this.zzcfd;
        boolean z = this.zzcfe;
        List list3 = this.zzbzj;
        long j3 = this.zzcfg;
        int i = this.mOrientation;
        String str3 = this.zzcex;
        String str4 = this.zzcfa;
        String str5 = str3;
        return new AdResponseParcel(adRequestInfoParcel, str, str2, list, list2, j2, z, -1, list3, j3, i, str5, j, str4, this.zzcfb, this.zzcfh, this.zzcfi, this.zzcfj, this.zzcfk, false, this.zzcfl, this.zzcfm, this.zzawl, this.zzcfn, this.zzcfo, this.zzcfp, this.zzcfq, this.zzcfr, this.zzcfs, this.zzcft, this.zzcfu, this.zzcfv, this.zzcfw, this.zzcfx);
    }

    public void zzj(Map<String, List<String>> map) {
        zzk(map);
        zzl(map);
        zzm(map);
        zzn(map);
        zzo(map);
        zzp(map);
        zzt(map);
        zzv(map);
        zzw(map);
        zzx(map);
        zzq(map);
        zzy(map);
        zzs(map);
        zzr(map);
        zzz(map);
        zzaa(map);
        zzab(map);
        zzac(map);
        zzad(map);
        zzae(map);
        zzaf(map);
        zzag(map);
        zzah(map);
        zzak(map);
        zzaj(map);
        zzai(map);
        zzal(map);
        zzu(map);
    }
}
