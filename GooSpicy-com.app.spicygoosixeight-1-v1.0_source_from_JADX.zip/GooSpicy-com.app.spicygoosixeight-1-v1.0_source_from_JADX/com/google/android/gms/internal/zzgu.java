package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.NativeAdMapper;
import com.google.android.gms.ads.mediation.NativeAppInstallAdMapper;
import com.google.android.gms.ads.mediation.NativeContentAdMapper;
import com.google.android.gms.ads.mediation.OnContextChangedListener;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzgo.zza;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

@zzir
public final class zzgu extends zza {
    private final MediationAdapter zzbpm;
    private zzgv zzbpn;

    public zzgu(MediationAdapter mediationAdapter) {
        this.zzbpm = mediationAdapter;
    }

    private Bundle zza(String str, int i, String str2) throws RemoteException {
        String str3 = "Server parameters: ";
        String valueOf = String.valueOf(str);
        zzb.zzcy(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
        try {
            Bundle bundle;
            Bundle bundle2 = new Bundle();
            if (str != null) {
                JSONObject jSONObject = new JSONObject(str);
                bundle = new Bundle();
                Iterator keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String str4 = (String) keys.next();
                    bundle.putString(str4, jSONObject.getString(str4));
                }
            } else {
                bundle = bundle2;
            }
            if (this.zzbpm instanceof AdMobAdapter) {
                bundle.putString("adJson", str2);
                bundle.putInt("tagForChildDirectedTreatment", i);
            }
            return bundle;
        } catch (Throwable th) {
            zzb.zzd("Could not get Server Parameters Bundle.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public void destroy() throws RemoteException {
        try {
            this.zzbpm.onDestroy();
        } catch (Throwable th) {
            zzb.zzd("Could not destroy adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public Bundle getInterstitialAdapterInfo() {
        if (this.zzbpm instanceof zzlx) {
            return ((zzlx) this.zzbpm).getInterstitialAdapterInfo();
        }
        String str = "MediationAdapter is not a v2 MediationInterstitialAdapter: ";
        String valueOf = String.valueOf(this.zzbpm.getClass().getCanonicalName());
        zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        return new Bundle();
    }

    public zzd getView() throws RemoteException {
        if (this.zzbpm instanceof MediationBannerAdapter) {
            try {
                return zze.zzae(((MediationBannerAdapter) this.zzbpm).getBannerView());
            } catch (Throwable th) {
                zzb.zzd("Could not get banner view from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str = "MediationAdapter is not a MediationBannerAdapter: ";
            String valueOf = String.valueOf(this.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            throw new RemoteException();
        }
    }

    public boolean isInitialized() throws RemoteException {
        if (this.zzbpm instanceof MediationRewardedVideoAdAdapter) {
            zzb.zzcw("Check if adapter is initialized.");
            try {
                return ((MediationRewardedVideoAdAdapter) this.zzbpm).isInitialized();
            } catch (Throwable th) {
                zzb.zzd("Could not check if adapter is initialized.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str = "MediationAdapter is not a MediationRewardedVideoAdAdapter: ";
            String valueOf = String.valueOf(this.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            throw new RemoteException();
        }
    }

    public void pause() throws RemoteException {
        try {
            this.zzbpm.onPause();
        } catch (Throwable th) {
            zzb.zzd("Could not pause adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public void resume() throws RemoteException {
        try {
            this.zzbpm.onResume();
        } catch (Throwable th) {
            zzb.zzd("Could not resume adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public void showInterstitial() throws RemoteException {
        if (this.zzbpm instanceof MediationInterstitialAdapter) {
            zzb.zzcw("Showing interstitial from adapter.");
            try {
                ((MediationInterstitialAdapter) this.zzbpm).showInterstitial();
            } catch (Throwable th) {
                zzb.zzd("Could not show interstitial from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str = "MediationAdapter is not a MediationInterstitialAdapter: ";
            String valueOf = String.valueOf(this.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            throw new RemoteException();
        }
    }

    public void showVideo() throws RemoteException {
        if (this.zzbpm instanceof MediationRewardedVideoAdAdapter) {
            zzb.zzcw("Show rewarded video ad from adapter.");
            try {
                ((MediationRewardedVideoAdAdapter) this.zzbpm).showVideo();
            } catch (Throwable th) {
                zzb.zzd("Could not show rewarded video ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str = "MediationAdapter is not a MediationRewardedVideoAdAdapter: ";
            String valueOf = String.valueOf(this.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            throw new RemoteException();
        }
    }

    public void zza(AdRequestParcel adRequestParcel, String str, String str2) throws RemoteException {
        if (this.zzbpm instanceof MediationRewardedVideoAdAdapter) {
            zzb.zzcw("Requesting rewarded video ad from adapter.");
            try {
                MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter = (MediationRewardedVideoAdAdapter) this.zzbpm;
                Bundle bundle = null;
                MediationAdRequest com_google_android_gms_internal_zzgt = new zzgt(adRequestParcel.zzatk == -1 ? null : new Date(adRequestParcel.zzatk), adRequestParcel.zzatl, adRequestParcel.zzatm != null ? new HashSet(adRequestParcel.zzatm) : null, adRequestParcel.zzats, adRequestParcel.zzatn, adRequestParcel.zzato, adRequestParcel.zzatz);
                if (adRequestParcel.zzatu != null) {
                    bundle = adRequestParcel.zzatu.getBundle(mediationRewardedVideoAdAdapter.getClass().getName());
                }
                mediationRewardedVideoAdAdapter.loadAd(com_google_android_gms_internal_zzgt, zza(str, adRequestParcel.zzato, str2), bundle);
            } catch (Throwable th) {
                zzb.zzd("Could not load rewarded video ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str3 = "MediationAdapter is not a MediationRewardedVideoAdAdapter: ";
            str = String.valueOf(this.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(str.length() != 0 ? str3.concat(str) : new String(str3));
            throw new RemoteException();
        }
    }

    public void zza(zzd com_google_android_gms_dynamic_zzd, AdRequestParcel adRequestParcel, String str, com.google.android.gms.ads.internal.reward.mediation.client.zza com_google_android_gms_ads_internal_reward_mediation_client_zza, String str2) throws RemoteException {
        AdRequestParcel adRequestParcel2 = adRequestParcel;
        if (this.zzbpm instanceof MediationRewardedVideoAdAdapter) {
            zzb.zzcw("Initialize rewarded video adapter.");
            try {
                MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter = (MediationRewardedVideoAdAdapter) r1.zzbpm;
                mediationRewardedVideoAdAdapter.initialize((Context) zze.zzad(com_google_android_gms_dynamic_zzd), new zzgt(adRequestParcel2.zzatk == -1 ? null : new Date(adRequestParcel2.zzatk), adRequestParcel2.zzatl, adRequestParcel2.zzatm != null ? new HashSet(adRequestParcel2.zzatm) : null, adRequestParcel2.zzats, adRequestParcel2.zzatn, adRequestParcel2.zzato, adRequestParcel2.zzatz), str, new com.google.android.gms.ads.internal.reward.mediation.client.zzb(com_google_android_gms_ads_internal_reward_mediation_client_zza), zza(str2, adRequestParcel2.zzato, null), adRequestParcel2.zzatu != null ? adRequestParcel2.zzatu.getBundle(mediationRewardedVideoAdAdapter.getClass().getName()) : null);
            } catch (Throwable th) {
                zzb.zzd("Could not initialize rewarded video adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str3 = "MediationAdapter is not a MediationRewardedVideoAdAdapter: ";
            String valueOf = String.valueOf(r1.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            throw new RemoteException();
        }
    }

    public void zza(zzd com_google_android_gms_dynamic_zzd, AdRequestParcel adRequestParcel, String str, zzgp com_google_android_gms_internal_zzgp) throws RemoteException {
        zza(com_google_android_gms_dynamic_zzd, adRequestParcel, str, null, com_google_android_gms_internal_zzgp);
    }

    public void zza(zzd com_google_android_gms_dynamic_zzd, AdRequestParcel adRequestParcel, String str, String str2, zzgp com_google_android_gms_internal_zzgp) throws RemoteException {
        AdRequestParcel adRequestParcel2 = adRequestParcel;
        if (this.zzbpm instanceof MediationInterstitialAdapter) {
            zzb.zzcw("Requesting interstitial ad from adapter.");
            try {
                MediationInterstitialAdapter mediationInterstitialAdapter = (MediationInterstitialAdapter) r1.zzbpm;
                Bundle bundle = null;
                zzgt com_google_android_gms_internal_zzgt = new zzgt(adRequestParcel2.zzatk == -1 ? null : new Date(adRequestParcel2.zzatk), adRequestParcel2.zzatl, adRequestParcel2.zzatm != null ? new HashSet(adRequestParcel2.zzatm) : null, adRequestParcel2.zzats, adRequestParcel2.zzatn, adRequestParcel2.zzato, adRequestParcel2.zzatz);
                if (adRequestParcel2.zzatu != null) {
                    bundle = adRequestParcel2.zzatu.getBundle(mediationInterstitialAdapter.getClass().getName());
                }
                mediationInterstitialAdapter.requestInterstitialAd((Context) zze.zzad(com_google_android_gms_dynamic_zzd), new zzgv(com_google_android_gms_internal_zzgp), zza(str, adRequestParcel2.zzato, str2), com_google_android_gms_internal_zzgt, bundle);
            } catch (Throwable th) {
                zzb.zzd("Could not request interstitial ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str3 = "MediationAdapter is not a MediationInterstitialAdapter: ";
            String valueOf = String.valueOf(r1.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            throw new RemoteException();
        }
    }

    public void zza(zzd com_google_android_gms_dynamic_zzd, AdRequestParcel adRequestParcel, String str, String str2, zzgp com_google_android_gms_internal_zzgp, NativeAdOptionsParcel nativeAdOptionsParcel, List<String> list) throws RemoteException {
        AdRequestParcel adRequestParcel2 = adRequestParcel;
        if (this.zzbpm instanceof MediationNativeAdapter) {
            try {
                MediationNativeAdapter mediationNativeAdapter = (MediationNativeAdapter) r1.zzbpm;
                Bundle bundle = null;
                zzgy com_google_android_gms_internal_zzgy = new zzgy(adRequestParcel2.zzatk == -1 ? null : new Date(adRequestParcel2.zzatk), adRequestParcel2.zzatl, adRequestParcel2.zzatm != null ? new HashSet(adRequestParcel2.zzatm) : null, adRequestParcel2.zzats, adRequestParcel2.zzatn, adRequestParcel2.zzato, nativeAdOptionsParcel, list, adRequestParcel2.zzatz);
                if (adRequestParcel2.zzatu != null) {
                    bundle = adRequestParcel2.zzatu.getBundle(mediationNativeAdapter.getClass().getName());
                }
                Bundle bundle2 = bundle;
                r1.zzbpn = new zzgv(com_google_android_gms_internal_zzgp);
                mediationNativeAdapter.requestNativeAd((Context) zze.zzad(com_google_android_gms_dynamic_zzd), r1.zzbpn, zza(str, adRequestParcel2.zzato, str2), com_google_android_gms_internal_zzgy, bundle2);
            } catch (Throwable th) {
                zzb.zzd("Could not request native ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str3 = "MediationAdapter is not a MediationNativeAdapter: ";
            String valueOf = String.valueOf(r1.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            throw new RemoteException();
        }
    }

    public void zza(zzd com_google_android_gms_dynamic_zzd, AdSizeParcel adSizeParcel, AdRequestParcel adRequestParcel, String str, zzgp com_google_android_gms_internal_zzgp) throws RemoteException {
        zza(com_google_android_gms_dynamic_zzd, adSizeParcel, adRequestParcel, str, null, com_google_android_gms_internal_zzgp);
    }

    public void zza(zzd com_google_android_gms_dynamic_zzd, AdSizeParcel adSizeParcel, AdRequestParcel adRequestParcel, String str, String str2, zzgp com_google_android_gms_internal_zzgp) throws RemoteException {
        AdSizeParcel adSizeParcel2 = adSizeParcel;
        AdRequestParcel adRequestParcel2 = adRequestParcel;
        if (this.zzbpm instanceof MediationBannerAdapter) {
            zzb.zzcw("Requesting banner ad from adapter.");
            try {
                MediationBannerAdapter mediationBannerAdapter = (MediationBannerAdapter) r1.zzbpm;
                Bundle bundle = null;
                zzgt com_google_android_gms_internal_zzgt = new zzgt(adRequestParcel2.zzatk == -1 ? null : new Date(adRequestParcel2.zzatk), adRequestParcel2.zzatl, adRequestParcel2.zzatm != null ? new HashSet(adRequestParcel2.zzatm) : null, adRequestParcel2.zzats, adRequestParcel2.zzatn, adRequestParcel2.zzato, adRequestParcel2.zzatz);
                if (adRequestParcel2.zzatu != null) {
                    bundle = adRequestParcel2.zzatu.getBundle(mediationBannerAdapter.getClass().getName());
                }
                mediationBannerAdapter.requestBannerAd((Context) zze.zzad(com_google_android_gms_dynamic_zzd), new zzgv(com_google_android_gms_internal_zzgp), zza(str, adRequestParcel2.zzato, str2), com.google.android.gms.ads.zza.zza(adSizeParcel2.width, adSizeParcel2.height, adSizeParcel2.zzaup), com_google_android_gms_internal_zzgt, bundle);
            } catch (Throwable th) {
                zzb.zzd("Could not request banner ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            String str3 = "MediationAdapter is not a MediationBannerAdapter: ";
            String valueOf = String.valueOf(r1.zzbpm.getClass().getCanonicalName());
            zzb.zzcy(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            throw new RemoteException();
        }
    }

    public void zzc(AdRequestParcel adRequestParcel, String str) throws RemoteException {
        zza(adRequestParcel, str, null);
    }

    public void zzj(zzd com_google_android_gms_dynamic_zzd) throws RemoteException {
        try {
            ((OnContextChangedListener) this.zzbpm).onContextChanged((Context) zze.zzad(com_google_android_gms_dynamic_zzd));
        } catch (Throwable th) {
            zzb.zza("Could not inform adapter of changed context", th);
        }
    }

    public zzgr zzmq() {
        NativeAdMapper zzmu = this.zzbpn.zzmu();
        return zzmu instanceof NativeAppInstallAdMapper ? new zzgw((NativeAppInstallAdMapper) zzmu) : null;
    }

    public zzgs zzmr() {
        NativeAdMapper zzmu = this.zzbpn.zzmu();
        return zzmu instanceof NativeContentAdMapper ? new zzgx((NativeContentAdMapper) zzmu) : null;
    }

    public Bundle zzms() {
        if (this.zzbpm instanceof zzlw) {
            return ((zzlw) this.zzbpm).zzms();
        }
        String str = "MediationAdapter is not a v2 MediationBannerAdapter: ";
        String valueOf = String.valueOf(this.zzbpm.getClass().getCanonicalName());
        zzb.zzcy(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        return new Bundle();
    }

    public Bundle zzmt() {
        return new Bundle();
    }
}
