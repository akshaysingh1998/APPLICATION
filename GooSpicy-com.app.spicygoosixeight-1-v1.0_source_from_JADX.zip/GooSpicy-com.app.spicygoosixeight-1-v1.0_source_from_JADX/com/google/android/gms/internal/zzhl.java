package com.google.android.gms.internal;

import android.app.Activity;
import android.os.IBinder;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.dynamic.zzg;
import com.google.android.gms.internal.zzhn.zza;

@zzir
public final class zzhl extends zzg<zzhn> {
    public zzhl() {
        super("com.google.android.gms.ads.AdOverlayCreatorImpl");
    }

    protected zzhn zzap(IBinder iBinder) {
        return zza.zzar(iBinder);
    }

    protected /* synthetic */ Object zzc(IBinder iBinder) {
        return zzap(iBinder);
    }

    public zzhm zzf(Activity activity) {
        try {
            return zzhm.zza.zzaq(((zzhn) zzcr(activity)).zzn(zze.zzae(activity)));
        } catch (Throwable e) {
            zzb.zzd("Could not create remote AdOverlay.", e);
            return null;
        }
    }
}
