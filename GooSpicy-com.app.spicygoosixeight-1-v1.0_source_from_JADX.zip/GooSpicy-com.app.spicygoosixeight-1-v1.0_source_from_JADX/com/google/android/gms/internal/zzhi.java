package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzhh.zza;
import java.util.Map;

@zzir
public class zzhi extends zzhj implements zzet {
    private final Context mContext;
    private final WindowManager zzaqk;
    private final zzll zzbgj;
    private final zzcu zzbrg;
    DisplayMetrics zzbrh;
    private float zzbri;
    int zzbrj = -1;
    int zzbrk = -1;
    private int zzbrl;
    int zzbrm = -1;
    int zzbrn = -1;
    int zzbro = -1;
    int zzbrp = -1;

    public zzhi(zzll com_google_android_gms_internal_zzll, Context context, zzcu com_google_android_gms_internal_zzcu) {
        super(com_google_android_gms_internal_zzll);
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.mContext = context;
        this.zzbrg = com_google_android_gms_internal_zzcu;
        this.zzaqk = (WindowManager) context.getSystemService("window");
    }

    private void zznb() {
        this.zzbrh = new DisplayMetrics();
        Display defaultDisplay = this.zzaqk.getDefaultDisplay();
        defaultDisplay.getMetrics(this.zzbrh);
        this.zzbri = this.zzbrh.density;
        this.zzbrl = defaultDisplay.getRotation();
    }

    private void zzng() {
        int[] iArr = new int[2];
        this.zzbgj.getLocationOnScreen(iArr);
        zze(zzm.zziw().zzb(this.mContext, iArr[0]), zzm.zziw().zzb(this.mContext, iArr[1]));
    }

    private zzhh zznj() {
        return new zza().zzu(this.zzbrg.zzjp()).zzt(this.zzbrg.zzjq()).zzv(this.zzbrg.zzju()).zzw(this.zzbrg.zzjr()).zzx(this.zzbrg.zzjs()).zzna();
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        zzne();
    }

    public void zze(int i, int i2) {
        int i3 = 0;
        if (this.mContext instanceof Activity) {
            i3 = zzu.zzfq().zzk((Activity) this.mContext)[0];
        }
        zzc(i, i2 - i3, this.zzbro, this.zzbrp);
        this.zzbgj.zzuk().zzd(i, i2);
    }

    void zznc() {
        int zzb;
        this.zzbrj = zzm.zziw().zzb(this.zzbrh, this.zzbrh.widthPixels);
        this.zzbrk = zzm.zziw().zzb(this.zzbrh, this.zzbrh.heightPixels);
        Activity zzuf = this.zzbgj.zzuf();
        if (zzuf != null) {
            if (zzuf.getWindow() != null) {
                int[] zzh = zzu.zzfq().zzh(zzuf);
                this.zzbrm = zzm.zziw().zzb(this.zzbrh, zzh[0]);
                zzb = zzm.zziw().zzb(this.zzbrh, zzh[1]);
                this.zzbrn = zzb;
            }
        }
        this.zzbrm = this.zzbrj;
        zzb = this.zzbrk;
        this.zzbrn = zzb;
    }

    void zznd() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:6:0x003c in {2, 4, 5} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r3.zzbgj;
        r0 = r0.zzdo();
        r0 = r0.zzauq;
        if (r0 == 0) goto L_0x0013;
    L_0x000a:
        r0 = r3.zzbrj;
        r3.zzbro = r0;
        r0 = r3.zzbrk;
    L_0x0010:
        r3.zzbrp = r0;
        return;
    L_0x0013:
        r0 = r3.zzbgj;
        r1 = 0;
        r0.measure(r1, r1);
        r0 = com.google.android.gms.ads.internal.client.zzm.zziw();
        r1 = r3.mContext;
        r2 = r3.zzbgj;
        r2 = r2.getMeasuredWidth();
        r0 = r0.zzb(r1, r2);
        r3.zzbro = r0;
        r0 = com.google.android.gms.ads.internal.client.zzm.zziw();
        r1 = r3.mContext;
        r2 = r3.zzbgj;
        r2 = r2.getMeasuredHeight();
        r0 = r0.zzb(r1, r2);
        goto L_0x0010;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzhi.zznd():void");
    }

    public void zzne() {
        zznb();
        zznc();
        zznd();
        zznh();
        zzni();
        zzng();
        zznf();
    }

    void zznf() {
        if (zzb.zzaz(2)) {
            zzb.zzcx("Dispatching Ready Event.");
        }
        zzbv(this.zzbgj.zzun().zzcs);
    }

    void zznh() {
        zza(this.zzbrj, this.zzbrk, this.zzbrm, this.zzbrn, this.zzbri, this.zzbrl);
    }

    void zzni() {
        this.zzbgj.zzb("onDeviceFeaturesReceived", zznj().toJson());
    }
}
