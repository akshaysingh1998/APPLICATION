package com.google.android.gms.internal;

import com.google.android.gms.ads.purchase.PlayStorePurchaseListener;
import com.google.android.gms.internal.zzhw.zza;

@zzir
public final class zzib extends zza {
    private final PlayStorePurchaseListener zzawh;

    public zzib(PlayStorePurchaseListener playStorePurchaseListener) {
        this.zzawh = playStorePurchaseListener;
    }

    public boolean isValidPurchase(String str) {
        return this.zzawh.isValidPurchase(str);
    }

    public void zza(zzhv com_google_android_gms_internal_zzhv) {
        this.zzawh.onInAppPurchaseFinished(new zzhz(com_google_android_gms_internal_zzhv));
    }
}
