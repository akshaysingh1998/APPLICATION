package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.util.ArrayMap;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Map.Entry;
import java.util.WeakHashMap;

public final class zzra extends Fragment implements zzqp {
    private static WeakHashMap<FragmentActivity, WeakReference<zzra>> vb = new WeakHashMap();
    private Map<String, zzqo> vc = new ArrayMap();
    private Bundle vd;
    private int zzblz = 0;

    public static zzra zza(FragmentActivity fragmentActivity) {
        zzra com_google_android_gms_internal_zzra;
        WeakReference weakReference = (WeakReference) vb.get(fragmentActivity);
        if (weakReference != null) {
            com_google_android_gms_internal_zzra = (zzra) weakReference.get();
            if (com_google_android_gms_internal_zzra != null) {
                return com_google_android_gms_internal_zzra;
            }
        }
        try {
            com_google_android_gms_internal_zzra = (zzra) fragmentActivity.getSupportFragmentManager().findFragmentByTag("SupportLifecycleFragmentImpl");
            if (com_google_android_gms_internal_zzra == null || com_google_android_gms_internal_zzra.isRemoving()) {
                com_google_android_gms_internal_zzra = new zzra();
                fragmentActivity.getSupportFragmentManager().beginTransaction().add((Fragment) com_google_android_gms_internal_zzra, "SupportLifecycleFragmentImpl").commitAllowingStateLoss();
            }
            vb.put(fragmentActivity, new WeakReference(com_google_android_gms_internal_zzra));
            return com_google_android_gms_internal_zzra;
        } catch (Throwable e) {
            throw new IllegalStateException("Fragment with tag SupportLifecycleFragmentImpl is not a SupportLifecycleFragmentImpl", e);
        }
    }

    private void zzb(final String str, @NonNull final zzqo com_google_android_gms_internal_zzqo) {
        if (this.zzblz > 0) {
            new Handler(Looper.getMainLooper()).post(new Runnable(this) {
                final /* synthetic */ zzra vj;

                public void run() {
                    if (this.vj.zzblz >= 1) {
                        com_google_android_gms_internal_zzqo.onCreate(this.vj.vd != null ? this.vj.vd.getBundle(str) : null);
                    }
                    if (this.vj.zzblz >= 2) {
                        com_google_android_gms_internal_zzqo.onStart();
                    }
                    if (this.vj.zzblz >= 3) {
                        com_google_android_gms_internal_zzqo.onStop();
                    }
                }
            });
        }
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        for (zzqo dump : this.vc.values()) {
            dump.dump(str, fileDescriptor, printWriter, strArr);
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        for (zzqo onActivityResult : this.vc.values()) {
            onActivityResult.onActivityResult(i, i2, intent);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.zzblz = 1;
        this.vd = bundle;
        for (Entry entry : this.vc.entrySet()) {
            ((zzqo) entry.getValue()).onCreate(bundle != null ? bundle.getBundle((String) entry.getKey()) : null);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (bundle != null) {
            for (Entry entry : this.vc.entrySet()) {
                Bundle bundle2 = new Bundle();
                ((zzqo) entry.getValue()).onSaveInstanceState(bundle2);
                bundle.putBundle((String) entry.getKey(), bundle2);
            }
        }
    }

    public void onStart() {
        super.onStop();
        this.zzblz = 2;
        for (zzqo onStart : this.vc.values()) {
            onStart.onStart();
        }
    }

    public void onStop() {
        super.onStop();
        this.zzblz = 3;
        for (zzqo onStop : this.vc.values()) {
            onStop.onStop();
        }
    }

    public <T extends zzqo> T zza(String str, Class<T> cls) {
        return (zzqo) cls.cast(this.vc.get(str));
    }

    public void zza(String str, @NonNull zzqo com_google_android_gms_internal_zzqo) {
        if (this.vc.containsKey(str)) {
            StringBuilder stringBuilder = new StringBuilder(59 + String.valueOf(str).length());
            stringBuilder.append("LifecycleCallback with tag ");
            stringBuilder.append(str);
            stringBuilder.append(" already added to this fragment.");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        this.vc.put(str, com_google_android_gms_internal_zzqo);
        zzb(str, com_google_android_gms_internal_zzqo);
    }

    public /* synthetic */ Activity zzaqp() {
        return zzaqr();
    }

    public FragmentActivity zzaqr() {
        return getActivity();
    }
}
