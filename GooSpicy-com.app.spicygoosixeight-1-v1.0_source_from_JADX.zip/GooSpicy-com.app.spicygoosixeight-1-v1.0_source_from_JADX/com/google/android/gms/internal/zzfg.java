package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzu;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

@zzir
public class zzfg implements Iterable<zzff> {
    private final List<zzff> zzbji = new LinkedList();

    private zzff zzg(zzll com_google_android_gms_internal_zzll) {
        Iterator it = zzu.zzgj().iterator();
        while (it.hasNext()) {
            zzff com_google_android_gms_internal_zzff = (zzff) it.next();
            if (com_google_android_gms_internal_zzff.zzbgj == com_google_android_gms_internal_zzll) {
                return com_google_android_gms_internal_zzff;
            }
        }
        return null;
    }

    public Iterator<zzff> iterator() {
        return this.zzbji.iterator();
    }

    public void zza(zzff com_google_android_gms_internal_zzff) {
        this.zzbji.add(com_google_android_gms_internal_zzff);
    }

    public void zzb(zzff com_google_android_gms_internal_zzff) {
        this.zzbji.remove(com_google_android_gms_internal_zzff);
    }

    public boolean zze(zzll com_google_android_gms_internal_zzll) {
        zzff zzg = zzg(com_google_android_gms_internal_zzll);
        if (zzg == null) {
            return false;
        }
        zzg.zzbjf.abort();
        return true;
    }

    public boolean zzf(zzll com_google_android_gms_internal_zzll) {
        return zzg(com_google_android_gms_internal_zzll) != null;
    }

    public int zzlm() {
        return this.zzbji.size();
    }
}
