package com.google.android.gms.internal;

public interface zzfj {
    zzfh zza(zzll com_google_android_gms_internal_zzll, int i, String str);
}
