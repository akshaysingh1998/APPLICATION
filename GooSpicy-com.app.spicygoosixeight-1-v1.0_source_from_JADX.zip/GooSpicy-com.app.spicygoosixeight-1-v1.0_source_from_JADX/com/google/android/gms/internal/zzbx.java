package com.google.android.gms.internal;

public final class zzbx extends Exception {
}
