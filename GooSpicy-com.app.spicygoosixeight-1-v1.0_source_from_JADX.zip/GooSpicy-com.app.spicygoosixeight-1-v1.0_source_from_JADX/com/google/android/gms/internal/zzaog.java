package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public final class zzaog extends zzaor {
    private static final Writer bfM = new C03971();
    private static final zzane bfN = new zzane("closed");
    private final List<zzamy> bfL = new ArrayList();
    private String bfO;
    private zzamy bfP = zzana.bes;

    static class C03971 extends Writer {
        C03971() {
        }

        public void close() throws IOException {
            throw new AssertionError();
        }

        public void flush() throws IOException {
            throw new AssertionError();
        }

        public void write(char[] cArr, int i, int i2) {
            throw new AssertionError();
        }
    }

    public zzaog() {
        super(bfM);
    }

    private zzamy m76m() {
        return (zzamy) this.bfL.get(this.bfL.size() - 1);
    }

    private void zzd(zzamy com_google_android_gms_internal_zzamy) {
        if (this.bfO != null) {
            if (!com_google_android_gms_internal_zzamy.zzczp() || m32E()) {
                ((zzanb) m76m()).zza(this.bfO, com_google_android_gms_internal_zzamy);
            }
            this.bfO = null;
        } else if (this.bfL.isEmpty()) {
            this.bfP = com_google_android_gms_internal_zzamy;
        } else {
            zzamy m = m76m();
            if (m instanceof zzamv) {
                ((zzamv) m).zzc(com_google_android_gms_internal_zzamy);
                return;
            }
            throw new IllegalStateException();
        }
    }

    public void close() throws IOException {
        if (this.bfL.isEmpty()) {
            this.bfL.add(bfN);
            return;
        }
        throw new IOException("Incomplete document");
    }

    public void flush() throws IOException {
    }

    public zzamy m77l() {
        if (this.bfL.isEmpty()) {
            return this.bfP;
        }
        String valueOf = String.valueOf(this.bfL);
        StringBuilder stringBuilder = new StringBuilder(34 + String.valueOf(valueOf).length());
        stringBuilder.append("Expected one JSON element but was ");
        stringBuilder.append(valueOf);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public zzaor mo2314n() throws IOException {
        zzamy com_google_android_gms_internal_zzamv = new zzamv();
        zzd(com_google_android_gms_internal_zzamv);
        this.bfL.add(com_google_android_gms_internal_zzamv);
        return this;
    }

    public zzaor mo2315o() throws IOException {
        if (!this.bfL.isEmpty()) {
            if (this.bfO == null) {
                if (m76m() instanceof zzamv) {
                    this.bfL.remove(this.bfL.size() - 1);
                    return this;
                }
                throw new IllegalStateException();
            }
        }
        throw new IllegalStateException();
    }

    public zzaor mo2316p() throws IOException {
        zzamy com_google_android_gms_internal_zzanb = new zzanb();
        zzd(com_google_android_gms_internal_zzanb);
        this.bfL.add(com_google_android_gms_internal_zzanb);
        return this;
    }

    public zzaor mo2317q() throws IOException {
        if (!this.bfL.isEmpty()) {
            if (this.bfO == null) {
                if (m76m() instanceof zzanb) {
                    this.bfL.remove(this.bfL.size() - 1);
                    return this;
                }
                throw new IllegalStateException();
            }
        }
        throw new IllegalStateException();
    }

    public zzaor mo2318r() throws IOException {
        zzd(zzana.bes);
        return this;
    }

    public zzaor zza(Number number) throws IOException {
        if (number == null) {
            return mo2318r();
        }
        if (!isLenient()) {
            double doubleValue = number.doubleValue();
            if (Double.isNaN(doubleValue) || Double.isInfinite(doubleValue)) {
                String valueOf = String.valueOf(number);
                StringBuilder stringBuilder = new StringBuilder(33 + String.valueOf(valueOf).length());
                stringBuilder.append("JSON forbids NaN and infinities: ");
                stringBuilder.append(valueOf);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        zzd(new zzane(number));
        return this;
    }

    public zzaor zzcp(long j) throws IOException {
        zzd(new zzane(Long.valueOf(j)));
        return this;
    }

    public zzaor zzcz(boolean z) throws IOException {
        zzd(new zzane(Boolean.valueOf(z)));
        return this;
    }

    public zzaor zzta(String str) throws IOException {
        if (!this.bfL.isEmpty()) {
            if (this.bfO == null) {
                if (m76m() instanceof zzanb) {
                    this.bfO = str;
                    return this;
                }
                throw new IllegalStateException();
            }
        }
        throw new IllegalStateException();
    }

    public zzaor zztb(String str) throws IOException {
        if (str == null) {
            return mo2318r();
        }
        zzd(new zzane(str));
        return this;
    }
}
