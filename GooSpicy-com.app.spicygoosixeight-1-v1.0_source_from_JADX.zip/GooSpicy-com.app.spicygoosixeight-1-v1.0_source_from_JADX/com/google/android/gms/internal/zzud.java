package com.google.android.gms.internal;

public abstract class zzud<T> {
    private final int zzaxm;
    private final String zzaxn;
    private final T zzaxo;

    public static class zza extends zzud<Boolean> {
        public zza(int i, String str, Boolean bool) {
            super(i, str, bool);
        }

        public /* synthetic */ Object zza(zzug com_google_android_gms_internal_zzug) {
            return zzb(com_google_android_gms_internal_zzug);
        }

        public java.lang.Boolean zzb(com.google.android.gms.internal.zzug r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            r0 = r3.getKey();	 Catch:{ RemoteException -> 0x001b }
            r1 = r3.zzjw();	 Catch:{ RemoteException -> 0x001b }
            r1 = (java.lang.Boolean) r1;	 Catch:{ RemoteException -> 0x001b }
            r1 = r1.booleanValue();	 Catch:{ RemoteException -> 0x001b }
            r2 = r3.getSource();	 Catch:{ RemoteException -> 0x001b }
            r4 = r4.getBooleanFlagValue(r0, r1, r2);	 Catch:{ RemoteException -> 0x001b }
            r4 = java.lang.Boolean.valueOf(r4);	 Catch:{ RemoteException -> 0x001b }
            return r4;
        L_0x001b:
            r4 = r3.zzjw();
            r4 = (java.lang.Boolean) r4;
            return r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzud.zza.zzb(com.google.android.gms.internal.zzug):java.lang.Boolean");
        }
    }

    public static class zzb extends zzud<Integer> {
        public zzb(int i, String str, Integer num) {
            super(i, str, num);
        }

        public /* synthetic */ Object zza(zzug com_google_android_gms_internal_zzug) {
            return zzc(com_google_android_gms_internal_zzug);
        }

        public java.lang.Integer zzc(com.google.android.gms.internal.zzug r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            r0 = r3.getKey();	 Catch:{ RemoteException -> 0x001b }
            r1 = r3.zzjw();	 Catch:{ RemoteException -> 0x001b }
            r1 = (java.lang.Integer) r1;	 Catch:{ RemoteException -> 0x001b }
            r1 = r1.intValue();	 Catch:{ RemoteException -> 0x001b }
            r2 = r3.getSource();	 Catch:{ RemoteException -> 0x001b }
            r4 = r4.getIntFlagValue(r0, r1, r2);	 Catch:{ RemoteException -> 0x001b }
            r4 = java.lang.Integer.valueOf(r4);	 Catch:{ RemoteException -> 0x001b }
            return r4;
        L_0x001b:
            r4 = r3.zzjw();
            r4 = (java.lang.Integer) r4;
            return r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzud.zzb.zzc(com.google.android.gms.internal.zzug):java.lang.Integer");
        }
    }

    public static class zzc extends zzud<Long> {
        public zzc(int i, String str, Long l) {
            super(i, str, l);
        }

        public /* synthetic */ Object zza(zzug com_google_android_gms_internal_zzug) {
            return zzd(com_google_android_gms_internal_zzug);
        }

        public java.lang.Long zzd(com.google.android.gms.internal.zzug r5) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r4 = this;
            r0 = r4.getKey();	 Catch:{ RemoteException -> 0x001b }
            r1 = r4.zzjw();	 Catch:{ RemoteException -> 0x001b }
            r1 = (java.lang.Long) r1;	 Catch:{ RemoteException -> 0x001b }
            r1 = r1.longValue();	 Catch:{ RemoteException -> 0x001b }
            r3 = r4.getSource();	 Catch:{ RemoteException -> 0x001b }
            r0 = r5.getLongFlagValue(r0, r1, r3);	 Catch:{ RemoteException -> 0x001b }
            r5 = java.lang.Long.valueOf(r0);	 Catch:{ RemoteException -> 0x001b }
            return r5;
        L_0x001b:
            r5 = r4.zzjw();
            r5 = (java.lang.Long) r5;
            return r5;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzud.zzc.zzd(com.google.android.gms.internal.zzug):java.lang.Long");
        }
    }

    public static class zzd extends zzud<String> {
        public zzd(int i, String str, String str2) {
            super(i, str, str2);
        }

        public /* synthetic */ Object zza(zzug com_google_android_gms_internal_zzug) {
            return zze(com_google_android_gms_internal_zzug);
        }

        public java.lang.String zze(com.google.android.gms.internal.zzug r4) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            r0 = r3.getKey();	 Catch:{ RemoteException -> 0x0013 }
            r1 = r3.zzjw();	 Catch:{ RemoteException -> 0x0013 }
            r1 = (java.lang.String) r1;	 Catch:{ RemoteException -> 0x0013 }
            r2 = r3.getSource();	 Catch:{ RemoteException -> 0x0013 }
            r4 = r4.getStringFlagValue(r0, r1, r2);	 Catch:{ RemoteException -> 0x0013 }
            return r4;
        L_0x0013:
            r4 = r3.zzjw();
            r4 = (java.lang.String) r4;
            return r4;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzud.zzd.zze(com.google.android.gms.internal.zzug):java.lang.String");
        }
    }

    private zzud(int i, String str, T t) {
        this.zzaxm = i;
        this.zzaxn = str;
        this.zzaxo = t;
        zzuh.zzbfr().zza(this);
    }

    public static zza zzb(int i, String str, Boolean bool) {
        return new zza(i, str, bool);
    }

    public static zzb zzb(int i, String str, int i2) {
        return new zzb(i, str, Integer.valueOf(i2));
    }

    public static zzc zzb(int i, String str, long j) {
        return new zzc(i, str, Long.valueOf(j));
    }

    public static zzd zzc(int i, String str, String str2) {
        return new zzd(i, str, str2);
    }

    public T get() {
        return zzuh.zzbfs().zzb(this);
    }

    public String getKey() {
        return this.zzaxn;
    }

    public int getSource() {
        return this.zzaxm;
    }

    protected abstract T zza(zzug com_google_android_gms_internal_zzug);

    public T zzjw() {
        return this.zzaxo;
    }
}
