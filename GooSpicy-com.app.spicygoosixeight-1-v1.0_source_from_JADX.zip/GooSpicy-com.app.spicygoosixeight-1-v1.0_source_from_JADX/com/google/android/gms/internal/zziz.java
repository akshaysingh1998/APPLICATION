package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.common.util.zzi;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.Locale;

@zzir
public final class zziz {
    public final int zzcbf;
    public final int zzcbg;
    public final float zzcbh;
    public final int zzcgh;
    public final boolean zzcgi;
    public final boolean zzcgj;
    public final String zzcgk;
    public final String zzcgl;
    public final boolean zzcgm;
    public final boolean zzcgn;
    public final boolean zzcgo;
    public final boolean zzcgp;
    public final String zzcgq;
    public final String zzcgr;
    public final int zzcgs;
    public final int zzcgt;
    public final int zzcgu;
    public final int zzcgv;
    public final int zzcgw;
    public final int zzcgx;
    public final double zzcgy;
    public final boolean zzcgz;
    public final boolean zzcha;
    public final int zzchb;
    public final String zzchc;
    public final boolean zzchd;

    public static final class zza {
        private int zzcbf;
        private int zzcbg;
        private float zzcbh;
        private int zzcgh;
        private boolean zzcgi;
        private boolean zzcgj;
        private String zzcgk;
        private String zzcgl;
        private boolean zzcgm;
        private boolean zzcgn;
        private boolean zzcgo;
        private boolean zzcgp;
        private String zzcgq;
        private String zzcgr;
        private int zzcgs;
        private int zzcgt;
        private int zzcgu;
        private int zzcgv;
        private int zzcgw;
        private int zzcgx;
        private double zzcgy;
        private boolean zzcgz;
        private boolean zzcha;
        private int zzchb;
        private String zzchc;
        private boolean zzchd;

        public zza(Context context) {
            PackageManager packageManager = context.getPackageManager();
            zzv(context);
            zza(context, packageManager);
            zzw(context);
            Locale locale = Locale.getDefault();
            boolean z = false;
            this.zzcgi = zza(packageManager, "geo:0,0?q=donuts") != null;
            if (zza(packageManager, "http://www.google.com") != null) {
                z = true;
            }
            this.zzcgj = z;
            this.zzcgl = locale.getCountry();
            this.zzcgm = zzm.zziw().zztx();
            this.zzcgn = zzi.zzcl(context);
            this.zzcgq = locale.getLanguage();
            this.zzcgr = zza(packageManager);
            Resources resources = context.getResources();
            if (resources != null) {
                DisplayMetrics displayMetrics = resources.getDisplayMetrics();
                if (displayMetrics != null) {
                    this.zzcbh = displayMetrics.density;
                    this.zzcbf = displayMetrics.widthPixels;
                    this.zzcbg = displayMetrics.heightPixels;
                }
            }
        }

        public zza(Context context, zziz com_google_android_gms_internal_zziz) {
            PackageManager packageManager = context.getPackageManager();
            zzv(context);
            zza(context, packageManager);
            zzw(context);
            zzx(context);
            this.zzcgi = com_google_android_gms_internal_zziz.zzcgi;
            this.zzcgj = com_google_android_gms_internal_zziz.zzcgj;
            this.zzcgl = com_google_android_gms_internal_zziz.zzcgl;
            this.zzcgm = com_google_android_gms_internal_zziz.zzcgm;
            this.zzcgn = com_google_android_gms_internal_zziz.zzcgn;
            this.zzcgq = com_google_android_gms_internal_zziz.zzcgq;
            this.zzcgr = com_google_android_gms_internal_zziz.zzcgr;
            this.zzcbh = com_google_android_gms_internal_zziz.zzcbh;
            this.zzcbf = com_google_android_gms_internal_zziz.zzcbf;
            this.zzcbg = com_google_android_gms_internal_zziz.zzcbg;
        }

        private static ResolveInfo zza(PackageManager packageManager, String str) {
            return packageManager.resolveActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)), 65536);
        }

        private static java.lang.String zza(android.content.pm.PackageManager r5) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r0 = "market://details?id=com.google.android.gms.ads";
            r0 = zza(r5, r0);
            r1 = 0;
            if (r0 != 0) goto L_0x000a;
        L_0x0009:
            return r1;
        L_0x000a:
            r0 = r0.activityInfo;
            if (r0 != 0) goto L_0x000f;
        L_0x000e:
            return r1;
        L_0x000f:
            r2 = r0.packageName;	 Catch:{ NameNotFoundException -> 0x0042 }
            r3 = 0;	 Catch:{ NameNotFoundException -> 0x0042 }
            r5 = r5.getPackageInfo(r2, r3);	 Catch:{ NameNotFoundException -> 0x0042 }
            if (r5 == 0) goto L_0x0040;	 Catch:{ NameNotFoundException -> 0x0042 }
        L_0x0018:
            r5 = r5.versionCode;	 Catch:{ NameNotFoundException -> 0x0042 }
            r0 = r0.packageName;	 Catch:{ NameNotFoundException -> 0x0042 }
            r0 = java.lang.String.valueOf(r0);	 Catch:{ NameNotFoundException -> 0x0042 }
            r2 = new java.lang.StringBuilder;	 Catch:{ NameNotFoundException -> 0x0042 }
            r3 = 12;	 Catch:{ NameNotFoundException -> 0x0042 }
            r4 = java.lang.String.valueOf(r0);	 Catch:{ NameNotFoundException -> 0x0042 }
            r4 = r4.length();	 Catch:{ NameNotFoundException -> 0x0042 }
            r3 = r3 + r4;	 Catch:{ NameNotFoundException -> 0x0042 }
            r2.<init>(r3);	 Catch:{ NameNotFoundException -> 0x0042 }
            r2.append(r5);	 Catch:{ NameNotFoundException -> 0x0042 }
            r5 = ".";	 Catch:{ NameNotFoundException -> 0x0042 }
            r2.append(r5);	 Catch:{ NameNotFoundException -> 0x0042 }
            r2.append(r0);	 Catch:{ NameNotFoundException -> 0x0042 }
            r5 = r2.toString();	 Catch:{ NameNotFoundException -> 0x0042 }
            return r5;
        L_0x0040:
            r5 = r1;
            return r5;
        L_0x0042:
            return r1;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zziz.zza.zza(android.content.pm.PackageManager):java.lang.String");
        }

        @TargetApi(16)
        private void zza(Context context, PackageManager packageManager) {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
            this.zzcgk = telephonyManager.getNetworkOperator();
            this.zzcgu = telephonyManager.getNetworkType();
            this.zzcgv = telephonyManager.getPhoneType();
            this.zzcgt = -2;
            this.zzcha = false;
            this.zzchb = -1;
            if (zzu.zzfq().zza(packageManager, context.getPackageName(), "android.permission.ACCESS_NETWORK_STATE")) {
                NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
                if (activeNetworkInfo != null) {
                    this.zzcgt = activeNetworkInfo.getType();
                    this.zzchb = activeNetworkInfo.getDetailedState().ordinal();
                } else {
                    this.zzcgt = -1;
                }
                if (VERSION.SDK_INT >= 16) {
                    this.zzcha = connectivityManager.isActiveNetworkMetered();
                }
            }
        }

        private void zzv(Context context) {
            AudioManager zzak = zzu.zzfq().zzak(context);
            if (zzak != null) {
                try {
                    this.zzcgh = zzak.getMode();
                    this.zzcgo = zzak.isMusicActive();
                    this.zzcgp = zzak.isSpeakerphoneOn();
                    this.zzcgs = zzak.getStreamVolume(3);
                    this.zzcgw = zzak.getRingerMode();
                    this.zzcgx = zzak.getStreamVolume(2);
                    return;
                } catch (Throwable th) {
                    zzu.zzft().zzb(th, true);
                }
            }
            this.zzcgh = -2;
            this.zzcgo = false;
            this.zzcgp = false;
            this.zzcgs = 0;
            this.zzcgw = 0;
            this.zzcgx = 0;
        }

        private void zzw(Context context) {
            Intent registerReceiver = context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
            boolean z = false;
            if (registerReceiver != null) {
                int intExtra = registerReceiver.getIntExtra("status", -1);
                this.zzcgy = (double) (((float) registerReceiver.getIntExtra(Param.LEVEL, -1)) / ((float) registerReceiver.getIntExtra("scale", -1)));
                if (intExtra == 2 || intExtra == 5) {
                    z = true;
                }
            } else {
                this.zzcgy = -1.0d;
            }
            this.zzcgz = z;
        }

        private void zzx(Context context) {
            this.zzchc = Build.FINGERPRINT;
            this.zzchd = zzdq.zzo(context);
        }

        public zziz zzro() {
            int i = this.zzcgh;
            boolean z = this.zzcgi;
            boolean z2 = this.zzcgj;
            String str = this.zzcgk;
            String str2 = this.zzcgl;
            boolean z3 = this.zzcgm;
            boolean z4 = this.zzcgn;
            boolean z5 = this.zzcgo;
            boolean z6 = this.zzcgp;
            String str3 = this.zzcgq;
            String str4 = this.zzcgr;
            int i2 = this.zzcgs;
            int i3 = this.zzcgt;
            int i4 = this.zzcgu;
            int i5 = this.zzcgv;
            int i6 = i4;
            int i7 = this.zzcgw;
            int i8 = this.zzcgx;
            float f = this.zzcbh;
            int i9 = this.zzcbf;
            int i10 = i3;
            int i11 = this.zzcbg;
            double d = this.zzcgy;
            boolean z7 = this.zzcgz;
            boolean z8 = this.zzcha;
            boolean z9 = z7;
            boolean z10 = z8;
            return new zziz(i, z, z2, str, str2, z3, z4, z5, z6, str3, str4, i2, i10, i6, i5, i7, i8, f, i9, i11, d, z9, z10, this.zzchb, this.zzchc, this.zzchd);
        }
    }

    zziz(int i, boolean z, boolean z2, String str, String str2, boolean z3, boolean z4, boolean z5, boolean z6, String str3, String str4, int i2, int i3, int i4, int i5, int i6, int i7, float f, int i8, int i9, double d, boolean z7, boolean z8, int i10, String str5, boolean z9) {
        this.zzcgh = i;
        this.zzcgi = z;
        this.zzcgj = z2;
        this.zzcgk = str;
        this.zzcgl = str2;
        this.zzcgm = z3;
        this.zzcgn = z4;
        this.zzcgo = z5;
        this.zzcgp = z6;
        this.zzcgq = str3;
        this.zzcgr = str4;
        this.zzcgs = i2;
        this.zzcgt = i3;
        this.zzcgu = i4;
        this.zzcgv = i5;
        this.zzcgw = i6;
        this.zzcgx = i7;
        this.zzcbh = f;
        this.zzcbf = i8;
        this.zzcbg = i9;
        this.zzcgy = d;
        this.zzcgz = z7;
        this.zzcha = z8;
        this.zzchb = i10;
        this.zzchc = str5;
        this.zzchd = z9;
    }
}
