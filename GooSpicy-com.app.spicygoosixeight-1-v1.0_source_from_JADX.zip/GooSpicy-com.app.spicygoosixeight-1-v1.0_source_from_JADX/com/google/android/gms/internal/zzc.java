package com.google.android.gms.internal;

import java.util.concurrent.BlockingQueue;

public class zzc extends Thread {
    private static final boolean DEBUG = zzs.DEBUG;
    private final BlockingQueue<zzk<?>> zzg;
    private final BlockingQueue<zzk<?>> zzh;
    private final zzb zzi;
    private final zzn zzj;
    private volatile boolean zzk = false;

    public zzc(BlockingQueue<zzk<?>> blockingQueue, BlockingQueue<zzk<?>> blockingQueue2, zzb com_google_android_gms_internal_zzb, zzn com_google_android_gms_internal_zzn) {
        super("VolleyCacheDispatcher");
        this.zzg = blockingQueue;
        this.zzh = blockingQueue2;
        this.zzi = com_google_android_gms_internal_zzb;
        this.zzj = com_google_android_gms_internal_zzn;
    }

    public void quit() {
        this.zzk = true;
        interrupt();
    }

    public void run() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r5 = this;
        r0 = DEBUG;
        if (r0 == 0) goto L_0x000c;
    L_0x0004:
        r0 = "start new dispatcher";
        r1 = 0;
        r1 = new java.lang.Object[r1];
        com.google.android.gms.internal.zzs.zza(r0, r1);
    L_0x000c:
        r0 = 10;
        android.os.Process.setThreadPriority(r0);
        r0 = r5.zzi;
        r0.initialize();
    L_0x0016:
        r0 = r5.zzg;	 Catch:{ InterruptedException -> 0x008e }
        r0 = r0.take();	 Catch:{ InterruptedException -> 0x008e }
        r0 = (com.google.android.gms.internal.zzk) r0;	 Catch:{ InterruptedException -> 0x008e }
        r1 = "cache-queue-take";	 Catch:{ InterruptedException -> 0x008e }
        r0.zzc(r1);	 Catch:{ InterruptedException -> 0x008e }
        r1 = r0.isCanceled();	 Catch:{ InterruptedException -> 0x008e }
        if (r1 == 0) goto L_0x002f;	 Catch:{ InterruptedException -> 0x008e }
    L_0x0029:
        r1 = "cache-discard-canceled";	 Catch:{ InterruptedException -> 0x008e }
        r0.zzd(r1);	 Catch:{ InterruptedException -> 0x008e }
        goto L_0x0016;	 Catch:{ InterruptedException -> 0x008e }
    L_0x002f:
        r1 = r5.zzi;	 Catch:{ InterruptedException -> 0x008e }
        r2 = r0.zzg();	 Catch:{ InterruptedException -> 0x008e }
        r1 = r1.zza(r2);	 Catch:{ InterruptedException -> 0x008e }
        if (r1 != 0) goto L_0x0046;	 Catch:{ InterruptedException -> 0x008e }
    L_0x003b:
        r1 = "cache-miss";	 Catch:{ InterruptedException -> 0x008e }
        r0.zzc(r1);	 Catch:{ InterruptedException -> 0x008e }
    L_0x0040:
        r1 = r5.zzh;	 Catch:{ InterruptedException -> 0x008e }
        r1.put(r0);	 Catch:{ InterruptedException -> 0x008e }
        goto L_0x0016;	 Catch:{ InterruptedException -> 0x008e }
    L_0x0046:
        r2 = r1.zza();	 Catch:{ InterruptedException -> 0x008e }
        if (r2 == 0) goto L_0x0055;	 Catch:{ InterruptedException -> 0x008e }
    L_0x004c:
        r2 = "cache-hit-expired";	 Catch:{ InterruptedException -> 0x008e }
        r0.zzc(r2);	 Catch:{ InterruptedException -> 0x008e }
        r0.zza(r1);	 Catch:{ InterruptedException -> 0x008e }
        goto L_0x0040;	 Catch:{ InterruptedException -> 0x008e }
    L_0x0055:
        r2 = "cache-hit";	 Catch:{ InterruptedException -> 0x008e }
        r0.zzc(r2);	 Catch:{ InterruptedException -> 0x008e }
        r2 = new com.google.android.gms.internal.zzi;	 Catch:{ InterruptedException -> 0x008e }
        r3 = r1.data;	 Catch:{ InterruptedException -> 0x008e }
        r4 = r1.zzf;	 Catch:{ InterruptedException -> 0x008e }
        r2.<init>(r3, r4);	 Catch:{ InterruptedException -> 0x008e }
        r2 = r0.zza(r2);	 Catch:{ InterruptedException -> 0x008e }
        r3 = "cache-hit-parsed";	 Catch:{ InterruptedException -> 0x008e }
        r0.zzc(r3);	 Catch:{ InterruptedException -> 0x008e }
        r3 = r1.zzb();	 Catch:{ InterruptedException -> 0x008e }
        if (r3 != 0) goto L_0x0078;	 Catch:{ InterruptedException -> 0x008e }
    L_0x0072:
        r1 = r5.zzj;	 Catch:{ InterruptedException -> 0x008e }
        r1.zza(r0, r2);	 Catch:{ InterruptedException -> 0x008e }
        goto L_0x0016;	 Catch:{ InterruptedException -> 0x008e }
    L_0x0078:
        r3 = "cache-hit-refresh-needed";	 Catch:{ InterruptedException -> 0x008e }
        r0.zzc(r3);	 Catch:{ InterruptedException -> 0x008e }
        r0.zza(r1);	 Catch:{ InterruptedException -> 0x008e }
        r1 = 1;	 Catch:{ InterruptedException -> 0x008e }
        r2.zzbh = r1;	 Catch:{ InterruptedException -> 0x008e }
        r1 = r5.zzj;	 Catch:{ InterruptedException -> 0x008e }
        r3 = new com.google.android.gms.internal.zzc$1;	 Catch:{ InterruptedException -> 0x008e }
        r3.<init>(r5, r0);	 Catch:{ InterruptedException -> 0x008e }
        r1.zza(r0, r2, r3);	 Catch:{ InterruptedException -> 0x008e }
        goto L_0x0016;
    L_0x008e:
        r0 = r5.zzk;
        if (r0 == 0) goto L_0x0016;
    L_0x0092:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzc.run():void");
    }
}
