package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzu;

@zzir
public class zzkv {
    private Object zzail = new Object();
    private long zzcmw;
    private long zzcmx = Long.MIN_VALUE;

    public zzkv(long j) {
        this.zzcmw = j;
    }

    public boolean tryAcquire() {
        synchronized (this.zzail) {
            long elapsedRealtime = zzu.zzfu().elapsedRealtime();
            if (this.zzcmx + this.zzcmw > elapsedRealtime) {
                return false;
            }
            this.zzcmx = elapsedRealtime;
            return true;
        }
    }
}
