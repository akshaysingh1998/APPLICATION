package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;

@zzir
public abstract class zzjb {
    public abstract void zza(Context context, zziv com_google_android_gms_internal_zziv, VersionInfoParcel versionInfoParcel);

    protected void zze(zziv com_google_android_gms_internal_zziv) {
        com_google_android_gms_internal_zziv.zzrj();
        if (com_google_android_gms_internal_zziv.zzrh() != null) {
            com_google_android_gms_internal_zziv.zzrh().release();
        }
    }
}
