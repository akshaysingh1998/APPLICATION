package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzw;
import com.google.android.gms.ads.internal.reward.client.zzd;
import com.google.android.gms.ads.internal.zzl;
import com.google.android.gms.ads.internal.zzu;

@zzir
class zzfn {
    zzq zzald;
    zzw zzbkl;
    zzhs zzbkm;
    zzdo zzbkn;
    zzp zzbko;
    zzd zzbkp;

    private class zza extends com.google.android.gms.ads.internal.client.zzq.zza {
        zzq zzbkq;
        final /* synthetic */ zzfn zzbkr;

        zza(zzfn com_google_android_gms_internal_zzfn, zzq com_google_android_gms_ads_internal_client_zzq) {
            this.zzbkr = com_google_android_gms_internal_zzfn;
            this.zzbkq = com_google_android_gms_ads_internal_client_zzq;
        }

        public void onAdClosed() throws RemoteException {
            this.zzbkq.onAdClosed();
            zzu.zzgb().zzlq();
        }

        public void onAdFailedToLoad(int i) throws RemoteException {
            this.zzbkq.onAdFailedToLoad(i);
        }

        public void onAdLeftApplication() throws RemoteException {
            this.zzbkq.onAdLeftApplication();
        }

        public void onAdLoaded() throws RemoteException {
            this.zzbkq.onAdLoaded();
        }

        public void onAdOpened() throws RemoteException {
            this.zzbkq.onAdOpened();
        }
    }

    zzfn() {
    }

    void zzc(zzl com_google_android_gms_ads_internal_zzl) {
        if (this.zzald != null) {
            com_google_android_gms_ads_internal_zzl.zza(new zza(this, this.zzald));
        }
        if (this.zzbkl != null) {
            com_google_android_gms_ads_internal_zzl.zza(this.zzbkl);
        }
        if (this.zzbkm != null) {
            com_google_android_gms_ads_internal_zzl.zza(this.zzbkm);
        }
        if (this.zzbkn != null) {
            com_google_android_gms_ads_internal_zzl.zza(this.zzbkn);
        }
        if (this.zzbko != null) {
            com_google_android_gms_ads_internal_zzl.zza(this.zzbko);
        }
        if (this.zzbkp != null) {
            com_google_android_gms_ads_internal_zzl.zza(this.zzbkp);
        }
    }
}
