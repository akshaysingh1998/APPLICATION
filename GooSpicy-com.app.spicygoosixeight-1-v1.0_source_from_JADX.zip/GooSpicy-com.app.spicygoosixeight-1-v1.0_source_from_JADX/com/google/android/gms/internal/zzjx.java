package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;

public interface zzjx {
    String zzf(AdRequestInfoParcel adRequestInfoParcel);
}
