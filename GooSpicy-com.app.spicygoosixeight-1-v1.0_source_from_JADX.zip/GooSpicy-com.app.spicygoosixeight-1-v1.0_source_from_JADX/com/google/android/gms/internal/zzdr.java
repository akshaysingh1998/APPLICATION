package com.google.android.gms.internal;

import java.util.concurrent.TimeUnit;

@zzir
public class zzdr {
    static final long zzbeq = TimeUnit.DAYS.toMillis(1);
}
