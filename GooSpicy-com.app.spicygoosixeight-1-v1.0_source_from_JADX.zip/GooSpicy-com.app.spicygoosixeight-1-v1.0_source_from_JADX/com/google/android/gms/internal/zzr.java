package com.google.android.gms.internal;

public class zzr extends Exception {
    private long zzab;
    public final zzi zzbi;

    public zzr() {
        this.zzbi = null;
    }

    public zzr(zzi com_google_android_gms_internal_zzi) {
        this.zzbi = com_google_android_gms_internal_zzi;
    }

    public zzr(Throwable th) {
        super(th);
        this.zzbi = null;
    }

    void zza(long j) {
        this.zzab = j;
    }
}
