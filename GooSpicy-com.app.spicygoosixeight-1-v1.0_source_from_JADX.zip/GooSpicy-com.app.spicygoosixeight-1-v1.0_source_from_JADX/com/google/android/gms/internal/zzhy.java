package com.google.android.gms.internal;

import android.app.Activity;
import android.os.IBinder;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.dynamic.zzg;
import com.google.android.gms.internal.zzhu.zza;

@zzir
public final class zzhy extends zzg<zzhu> {
    public zzhy() {
        super("com.google.android.gms.ads.InAppPurchaseManagerCreatorImpl");
    }

    protected zzhu zzaz(IBinder iBinder) {
        return zza.zzaw(iBinder);
    }

    protected /* synthetic */ Object zzc(IBinder iBinder) {
        return zzaz(iBinder);
    }

    public zzht zzg(Activity activity) {
        try {
            return zzht.zza.zzav(((zzhu) zzcr(activity)).zzo(zze.zzae(activity)));
        } catch (Throwable e) {
            zzb.zzd("Could not create remote InAppPurchaseManager.", e);
            return null;
        }
    }
}
