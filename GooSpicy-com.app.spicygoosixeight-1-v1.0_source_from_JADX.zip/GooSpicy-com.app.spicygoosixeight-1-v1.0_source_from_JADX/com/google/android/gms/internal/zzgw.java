package com.google.android.gms.internal;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.formats.NativeAd.Image;
import com.google.android.gms.ads.internal.formats.zzc;
import com.google.android.gms.ads.mediation.NativeAppInstallAdMapper;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzgr.zza;
import java.util.ArrayList;
import java.util.List;

@zzir
public class zzgw extends zza {
    private final NativeAppInstallAdMapper zzbpq;

    public zzgw(NativeAppInstallAdMapper nativeAppInstallAdMapper) {
        this.zzbpq = nativeAppInstallAdMapper;
    }

    public String getBody() {
        return this.zzbpq.getBody();
    }

    public String getCallToAction() {
        return this.zzbpq.getCallToAction();
    }

    public Bundle getExtras() {
        return this.zzbpq.getExtras();
    }

    public String getHeadline() {
        return this.zzbpq.getHeadline();
    }

    public List getImages() {
        List<Image> images = this.zzbpq.getImages();
        if (images == null) {
            return null;
        }
        List arrayList = new ArrayList();
        for (Image image : images) {
            arrayList.add(new zzc(image.getDrawable(), image.getUri(), image.getScale()));
        }
        return arrayList;
    }

    public boolean getOverrideClickHandling() {
        return this.zzbpq.getOverrideClickHandling();
    }

    public boolean getOverrideImpressionRecording() {
        return this.zzbpq.getOverrideImpressionRecording();
    }

    public String getPrice() {
        return this.zzbpq.getPrice();
    }

    public double getStarRating() {
        return this.zzbpq.getStarRating();
    }

    public String getStore() {
        return this.zzbpq.getStore();
    }

    public void recordImpression() {
        this.zzbpq.recordImpression();
    }

    public void zzk(zzd com_google_android_gms_dynamic_zzd) {
        this.zzbpq.handleClick((View) zze.zzad(com_google_android_gms_dynamic_zzd));
    }

    public zzdu zzkw() {
        Image icon = this.zzbpq.getIcon();
        return icon != null ? new zzc(icon.getDrawable(), icon.getUri(), icon.getScale()) : null;
    }

    public void zzl(zzd com_google_android_gms_dynamic_zzd) {
        this.zzbpq.trackView((View) zze.zzad(com_google_android_gms_dynamic_zzd));
    }

    public void zzm(zzd com_google_android_gms_dynamic_zzd) {
        this.zzbpq.untrackView((View) zze.zzad(com_google_android_gms_dynamic_zzd));
    }
}
