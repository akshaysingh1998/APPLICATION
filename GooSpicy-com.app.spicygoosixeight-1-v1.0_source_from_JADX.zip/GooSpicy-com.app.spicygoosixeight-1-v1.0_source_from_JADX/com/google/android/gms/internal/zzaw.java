package com.google.android.gms.internal;

public class zzaw extends Exception {
    public zzaw(Throwable th) {
        super(th);
    }
}
