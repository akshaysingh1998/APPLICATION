package com.google.android.gms.internal;

import android.content.ContentResolver;
import android.content.Context;
import android.util.Log;
import com.bumptech.glide.load.Key;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzab;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

public class zzpl implements com.google.android.gms.clearcut.zzb.zzb {
    private static final Charset UTF_8 = Charset.forName(Key.STRING_CHARSET_NAME);
    static Boolean qK;
    final zza qL;

    static class zza {
        final ContentResolver mContentResolver;

        zza(Context context) {
            if (context != null) {
                if (zzbm(context)) {
                    this.mContentResolver = context.getContentResolver();
                    zzaer.zzb(this.mContentResolver, "gms:playlog:service:sampling_");
                    return;
                }
            }
            this.mContentResolver = null;
        }

        private String getString(String str, String str2) {
            return this.mContentResolver == null ? str2 : zzaer.zza(this.mContentResolver, str, str2);
        }

        private static boolean zzbm(Context context) {
            if (zzpl.qK == null) {
                zzpl.qK = Boolean.valueOf(context.checkCallingOrSelfPermission("com.google.android.providers.gsf.permission.READ_GSERVICES") == 0);
            }
            return zzpl.qK.booleanValue();
        }

        long zzanb() {
            return this.mContentResolver == null ? 0 : zzaer.getLong(this.mContentResolver, "android_id", 0);
        }

        String zzgv(String str) {
            String valueOf = String.valueOf("gms:playlog:service:sampling_");
            str = String.valueOf(str);
            return getString(str.length() != 0 ? valueOf.concat(str) : new String(valueOf), null);
        }
    }

    static class zzb {
        public final String qM;
        public final long qN;
        public final long qO;

        public zzb(String str, long j, long j2) {
            this.qM = str;
            this.qN = j;
            this.qO = j2;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzb)) {
                return false;
            }
            zzb com_google_android_gms_internal_zzpl_zzb = (zzb) obj;
            return zzaa.equal(this.qM, com_google_android_gms_internal_zzpl_zzb.qM) && zzaa.equal(Long.valueOf(this.qN), Long.valueOf(com_google_android_gms_internal_zzpl_zzb.qN)) && zzaa.equal(Long.valueOf(this.qO), Long.valueOf(com_google_android_gms_internal_zzpl_zzb.qO));
        }

        public int hashCode() {
            return zzaa.hashCode(this.qM, Long.valueOf(this.qN), Long.valueOf(this.qO));
        }
    }

    public zzpl() {
        this(new zza(null));
    }

    public zzpl(Context context) {
        this(new zza(context));
    }

    zzpl(zza com_google_android_gms_internal_zzpl_zza) {
        this.qL = (zza) zzab.zzaa(com_google_android_gms_internal_zzpl_zza);
    }

    static boolean zza(long j, long j2, long j3) {
        if (j2 >= 0) {
            if (j3 >= 0) {
                return j3 > 0 && zzpm.zzd(j, j3) < j2;
            }
        }
        StringBuilder stringBuilder = new StringBuilder(72);
        stringBuilder.append("negative values not supported: ");
        stringBuilder.append(j2);
        stringBuilder.append("/");
        stringBuilder.append(j3);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    static long zzag(long j) {
        return zzpi.zzm(ByteBuffer.allocate(8).putLong(j).array());
    }

    static long zzd(String str, long j) {
        if (str != null) {
            if (!str.isEmpty()) {
                byte[] bytes = str.getBytes(UTF_8);
                ByteBuffer allocate = ByteBuffer.allocate(bytes.length + 8);
                allocate.put(bytes);
                allocate.putLong(j);
                return zzpi.zzm(allocate.array());
            }
        }
        return zzag(j);
    }

    static zzb zzgu(String str) {
        if (str == null) {
            return null;
        }
        String str2 = "";
        int indexOf = str.indexOf(44);
        int i = 0;
        if (indexOf >= 0) {
            str2 = str.substring(0, indexOf);
            i = indexOf + 1;
        }
        String str3 = str2;
        int indexOf2 = str.indexOf(47, i);
        if (indexOf2 <= 0) {
            str2 = "LogSamplerImpl";
            String str4 = "Failed to parse the rule: ";
            str = String.valueOf(str);
            Log.e(str2, str.length() != 0 ? str4.concat(str) : new String(str4));
            return null;
        }
        try {
            long parseLong = Long.parseLong(str.substring(i, indexOf2));
            long parseLong2 = Long.parseLong(str.substring(indexOf2 + 1));
            if (parseLong >= 0) {
                if (parseLong2 >= 0) {
                    return new zzb(str3, parseLong, parseLong2);
                }
            }
            StringBuilder stringBuilder = new StringBuilder(72);
            stringBuilder.append("negative values not supported: ");
            stringBuilder.append(parseLong);
            stringBuilder.append("/");
            stringBuilder.append(parseLong2);
            Log.e("LogSamplerImpl", stringBuilder.toString());
            return null;
        } catch (Throwable e) {
            str4 = "LogSamplerImpl";
            String str5 = "parseLong() failed while parsing: ";
            str = String.valueOf(str);
            Log.e(str4, str.length() != 0 ? str5.concat(str) : new String(str5), e);
            return null;
        }
    }

    public boolean zzg(String str, int i) {
        if (str == null || str.isEmpty()) {
            str = i >= 0 ? String.valueOf(i) : null;
        }
        if (str == null) {
            return true;
        }
        long zzanb = this.qL.zzanb();
        zzb zzgu = zzgu(this.qL.zzgv(str));
        return zzgu == null ? true : zza(zzd(zzgu.qM, zzanb), zzgu.qN, zzgu.qO);
    }
}
