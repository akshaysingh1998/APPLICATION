package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collection;

public final class zzaoc implements zzanl {
    private final zzans beb;

    private static final class zza<E> extends zzank<Collection<E>> {
        private final zzank<E> bfH;
        private final zzanx<? extends Collection<E>> bfI;

        public zza(zzams com_google_android_gms_internal_zzams, Type type, zzank<E> com_google_android_gms_internal_zzank_E, zzanx<? extends Collection<E>> com_google_android_gms_internal_zzanx__extends_java_util_Collection_E) {
            this.bfH = new zzaom(com_google_android_gms_internal_zzams, com_google_android_gms_internal_zzank_E, type);
            this.bfI = com_google_android_gms_internal_zzanx__extends_java_util_Collection_E;
        }

        public void zza(zzaor com_google_android_gms_internal_zzaor, Collection<E> collection) throws IOException {
            if (collection == null) {
                com_google_android_gms_internal_zzaor.mo2318r();
                return;
            }
            com_google_android_gms_internal_zzaor.mo2314n();
            for (E zza : collection) {
                this.bfH.zza(com_google_android_gms_internal_zzaor, zza);
            }
            com_google_android_gms_internal_zzaor.mo2315o();
        }

        public /* synthetic */ Object zzb(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            return zzj(com_google_android_gms_internal_zzaop);
        }

        public Collection<E> zzj(zzaop com_google_android_gms_internal_zzaop) throws IOException {
            if (com_google_android_gms_internal_zzaop.mo2301h() == zzaoq.NULL) {
                com_google_android_gms_internal_zzaop.nextNull();
                return null;
            }
            Collection<E> collection = (Collection) this.bfI.mo2294a();
            com_google_android_gms_internal_zzaop.beginArray();
            while (com_google_android_gms_internal_zzaop.hasNext()) {
                collection.add(this.bfH.zzb(com_google_android_gms_internal_zzaop));
            }
            com_google_android_gms_internal_zzaop.endArray();
            return collection;
        }
    }

    public zzaoc(zzans com_google_android_gms_internal_zzans) {
        this.beb = com_google_android_gms_internal_zzans;
    }

    public <T> zzank<T> zza(zzams com_google_android_gms_internal_zzams, zzaoo<T> com_google_android_gms_internal_zzaoo_T) {
        Type t = com_google_android_gms_internal_zzaoo_T.m16t();
        Class s = com_google_android_gms_internal_zzaoo_T.m15s();
        if (!Collection.class.isAssignableFrom(s)) {
            return null;
        }
        t = zzanr.zza(t, s);
        return new zza(com_google_android_gms_internal_zzams, t, com_google_android_gms_internal_zzams.zza(zzaoo.zzl(t)), this.beb.zzb(com_google_android_gms_internal_zzaoo_T));
    }
}
