package com.google.android.gms.internal;

import android.content.Context;
import android.view.View;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.zzh;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.internal.zzcd.zza;
import com.google.android.gms.internal.zzcd.zzd;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.WeakHashMap;

@zzir
public class zzcg implements zzch {
    private final Object zzail = new Object();
    private final VersionInfoParcel zzalm;
    private final Context zzaqj;
    private final WeakHashMap<zzjy, zzcd> zzark = new WeakHashMap();
    private final ArrayList<zzcd> zzarl = new ArrayList();
    private final zzfw zzarm;

    public zzcg(Context context, VersionInfoParcel versionInfoParcel, zzfw com_google_android_gms_internal_zzfw) {
        this.zzaqj = context.getApplicationContext();
        this.zzalm = versionInfoParcel;
        this.zzarm = com_google_android_gms_internal_zzfw;
    }

    public zzcd zza(AdSizeParcel adSizeParcel, zzjy com_google_android_gms_internal_zzjy) {
        return zza(adSizeParcel, com_google_android_gms_internal_zzjy, com_google_android_gms_internal_zzjy.zzbtq.getView());
    }

    public zzcd zza(AdSizeParcel adSizeParcel, zzjy com_google_android_gms_internal_zzjy, View view) {
        return zza(adSizeParcel, com_google_android_gms_internal_zzjy, new zzd(view, com_google_android_gms_internal_zzjy), null);
    }

    public zzcd zza(AdSizeParcel adSizeParcel, zzjy com_google_android_gms_internal_zzjy, View view, zzfx com_google_android_gms_internal_zzfx) {
        return zza(adSizeParcel, com_google_android_gms_internal_zzjy, new zzd(view, com_google_android_gms_internal_zzjy), com_google_android_gms_internal_zzfx);
    }

    public zzcd zza(AdSizeParcel adSizeParcel, zzjy com_google_android_gms_internal_zzjy, zzh com_google_android_gms_ads_internal_formats_zzh) {
        return zza(adSizeParcel, com_google_android_gms_internal_zzjy, new zza(com_google_android_gms_ads_internal_formats_zzh), null);
    }

    public zzcd zza(AdSizeParcel adSizeParcel, zzjy com_google_android_gms_internal_zzjy, zzck com_google_android_gms_internal_zzck, zzfx com_google_android_gms_internal_zzfx) {
        synchronized (this.zzail) {
            if (zzh(com_google_android_gms_internal_zzjy)) {
                zzcd com_google_android_gms_internal_zzcd = (zzcd) this.zzark.get(com_google_android_gms_internal_zzjy);
                return com_google_android_gms_internal_zzcd;
            }
            zzcd com_google_android_gms_internal_zzci;
            if (com_google_android_gms_internal_zzfx != null) {
                com_google_android_gms_internal_zzci = new zzci(this.zzaqj, adSizeParcel, com_google_android_gms_internal_zzjy, this.zzalm, com_google_android_gms_internal_zzck, com_google_android_gms_internal_zzfx);
            } else {
                zzcd com_google_android_gms_internal_zzcj = new zzcj(this.zzaqj, adSizeParcel, com_google_android_gms_internal_zzjy, this.zzalm, com_google_android_gms_internal_zzck, this.zzarm);
            }
            com_google_android_gms_internal_zzci.zza((zzch) this);
            this.zzark.put(com_google_android_gms_internal_zzjy, com_google_android_gms_internal_zzci);
            this.zzarl.add(com_google_android_gms_internal_zzci);
            return com_google_android_gms_internal_zzci;
        }
    }

    public void zza(zzcd com_google_android_gms_internal_zzcd) {
        synchronized (this.zzail) {
            if (!com_google_android_gms_internal_zzcd.zzha()) {
                this.zzarl.remove(com_google_android_gms_internal_zzcd);
                Iterator it = this.zzark.entrySet().iterator();
                while (it.hasNext()) {
                    if (((Entry) it.next()).getValue() == com_google_android_gms_internal_zzcd) {
                        it.remove();
                    }
                }
            }
        }
    }

    public boolean zzh(zzjy com_google_android_gms_internal_zzjy) {
        boolean z;
        synchronized (this.zzail) {
            zzcd com_google_android_gms_internal_zzcd = (zzcd) this.zzark.get(com_google_android_gms_internal_zzjy);
            z = com_google_android_gms_internal_zzcd != null && com_google_android_gms_internal_zzcd.zzha();
        }
        return z;
    }

    public void zzi(zzjy com_google_android_gms_internal_zzjy) {
        synchronized (this.zzail) {
            zzcd com_google_android_gms_internal_zzcd = (zzcd) this.zzark.get(com_google_android_gms_internal_zzjy);
            if (com_google_android_gms_internal_zzcd != null) {
                com_google_android_gms_internal_zzcd.zzgy();
            }
        }
    }

    public void zzj(zzjy com_google_android_gms_internal_zzjy) {
        synchronized (this.zzail) {
            zzcd com_google_android_gms_internal_zzcd = (zzcd) this.zzark.get(com_google_android_gms_internal_zzjy);
            if (com_google_android_gms_internal_zzcd != null) {
                com_google_android_gms_internal_zzcd.stop();
            }
        }
    }

    public void zzk(zzjy com_google_android_gms_internal_zzjy) {
        synchronized (this.zzail) {
            zzcd com_google_android_gms_internal_zzcd = (zzcd) this.zzark.get(com_google_android_gms_internal_zzjy);
            if (com_google_android_gms_internal_zzcd != null) {
                com_google_android_gms_internal_zzcd.pause();
            }
        }
    }

    public void zzl(zzjy com_google_android_gms_internal_zzjy) {
        synchronized (this.zzail) {
            zzcd com_google_android_gms_internal_zzcd = (zzcd) this.zzark.get(com_google_android_gms_internal_zzjy);
            if (com_google_android_gms_internal_zzcd != null) {
                com_google_android_gms_internal_zzcd.resume();
            }
        }
    }
}
