package com.google.android.gms.internal;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug.MemoryInfo;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewCompat;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.SearchAdRequestParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.AutoClickProtectionConfigurationParcel;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zzjd.zza;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public final class zziu {
    private static final SimpleDateFormat zzcep = new SimpleDateFormat("yyyyMMdd", Locale.US);

    public static AdResponseParcel zza(Context context, AdRequestInfoParcel adRequestInfoParcel, String str) {
        AdRequestInfoParcel adRequestInfoParcel2 = adRequestInfoParcel;
        String optString;
        String str2;
        try {
            int zztl;
            int i;
            String str3;
            AdResponseParcel adResponseParcel;
            long j;
            JSONArray optJSONArray;
            List list;
            List list2;
            List list3;
            List zza;
            long j2;
            String optString2;
            boolean optBoolean;
            JSONObject jSONObject = new JSONObject(str);
            optString = jSONObject.optString("ad_base_url", null);
            Object optString3 = jSONObject.optString("ad_url", null);
            String optString4 = jSONObject.optString("ad_size", null);
            String optString5 = jSONObject.optString("ad_slot_size", optString4);
            boolean z = (adRequestInfoParcel2 == null || adRequestInfoParcel2.zzcbb == 0) ? false : true;
            CharSequence optString6 = jSONObject.optString("ad_json", null);
            if (optString6 == null) {
                optString6 = jSONObject.optString("ad_html", null);
            }
            if (optString6 == null) {
                optString6 = jSONObject.optString("body", null);
            }
            String optString7 = jSONObject.optString("debug_dialog", null);
            long j3 = jSONObject.has("interstitial_timeout") ? (long) (jSONObject.getDouble("interstitial_timeout") * 1000.0d) : -1;
            String optString8 = jSONObject.optString("orientation", null);
            if ("portrait".equals(optString8)) {
                zztl = zzu.zzfs().zztl();
            } else if ("landscape".equals(optString8)) {
                zztl = zzu.zzfs().zztk();
            } else {
                i = -1;
                if (TextUtils.isEmpty(optString6) || TextUtils.isEmpty(optString3)) {
                    optString8 = optString;
                    str3 = optString6;
                    adResponseParcel = null;
                    j = -1;
                } else {
                    adResponseParcel = zzit.zza(adRequestInfoParcel2, context, adRequestInfoParcel2.zzaou.zzcs, optString3, null, null, null, null);
                    str2 = adResponseParcel.zzbts;
                    optString8 = adResponseParcel.body;
                    j = adResponseParcel.zzccg;
                    str3 = optString8;
                    optString8 = str2;
                }
                if (str3 == null) {
                    return new AdResponseParcel(0);
                }
                optJSONArray = jSONObject.optJSONArray("click_urls");
                list = adResponseParcel != null ? null : adResponseParcel.zzbnq;
                if (optJSONArray != null) {
                    list = zza(optJSONArray, list);
                }
                optJSONArray = jSONObject.optJSONArray("impression_urls");
                list2 = adResponseParcel != null ? null : adResponseParcel.zzbnr;
                if (optJSONArray != null) {
                    list2 = zza(optJSONArray, list2);
                }
                optJSONArray = jSONObject.optJSONArray("manual_impression_urls");
                list3 = adResponseParcel != null ? null : adResponseParcel.zzcce;
                zza = optJSONArray == null ? zza(optJSONArray, list3) : list3;
                if (adResponseParcel != null) {
                    if (adResponseParcel.orientation != -1) {
                        i = adResponseParcel.orientation;
                    }
                    if (adResponseParcel.zzccb > 0) {
                        j2 = adResponseParcel.zzccb;
                        optString2 = jSONObject.optString("active_view");
                        optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
                        return new AdResponseParcel(adRequestInfoParcel2, optString8, str3, list, list2, j2, jSONObject.optBoolean("mediation", false), jSONObject.optLong("mediation_config_cache_time_milliseconds", -1), zza, jSONObject.optLong("refresh_interval_milliseconds", -1), i, optString4, j, optString7, optBoolean, optBoolean ? jSONObject.optString("ad_passback_url", null) : null, optString2, jSONObject.optBoolean("custom_render_allowed", false), z, adRequestInfoParcel2.zzcbd, jSONObject.optBoolean("content_url_opted_out", true), jSONObject.optBoolean("prefetch", false), jSONObject.optString("gws_query_id", ""), "height".equals(jSONObject.optString("fluid", "")), jSONObject.optBoolean("native_express", false), RewardItemParcel.zza(jSONObject.optJSONArray("rewards")), zza(jSONObject.optJSONArray("video_start_urls"), null), zza(jSONObject.optJSONArray("video_complete_urls"), null), jSONObject.optBoolean("use_displayed_impression", false), AutoClickProtectionConfigurationParcel.zzh(jSONObject.optJSONObject("auto_protection_configuration")), adRequestInfoParcel2.zzcbu, jSONObject.optString("set_cookie", ""), zza(jSONObject.optJSONArray("remote_ping_urls"), null), jSONObject.optString("safe_browsing"), jSONObject.optBoolean("render_in_browser", adRequestInfoParcel2.zzbnu), optString5);
                    }
                }
                j2 = j3;
                optString2 = jSONObject.optString("active_view");
                optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
                if (optBoolean) {
                }
                return new AdResponseParcel(adRequestInfoParcel2, optString8, str3, list, list2, j2, jSONObject.optBoolean("mediation", false), jSONObject.optLong("mediation_config_cache_time_milliseconds", -1), zza, jSONObject.optLong("refresh_interval_milliseconds", -1), i, optString4, j, optString7, optBoolean, optBoolean ? jSONObject.optString("ad_passback_url", null) : null, optString2, jSONObject.optBoolean("custom_render_allowed", false), z, adRequestInfoParcel2.zzcbd, jSONObject.optBoolean("content_url_opted_out", true), jSONObject.optBoolean("prefetch", false), jSONObject.optString("gws_query_id", ""), "height".equals(jSONObject.optString("fluid", "")), jSONObject.optBoolean("native_express", false), RewardItemParcel.zza(jSONObject.optJSONArray("rewards")), zza(jSONObject.optJSONArray("video_start_urls"), null), zza(jSONObject.optJSONArray("video_complete_urls"), null), jSONObject.optBoolean("use_displayed_impression", false), AutoClickProtectionConfigurationParcel.zzh(jSONObject.optJSONObject("auto_protection_configuration")), adRequestInfoParcel2.zzcbu, jSONObject.optString("set_cookie", ""), zza(jSONObject.optJSONArray("remote_ping_urls"), null), jSONObject.optString("safe_browsing"), jSONObject.optBoolean("render_in_browser", adRequestInfoParcel2.zzbnu), optString5);
            }
            i = zztl;
            if (TextUtils.isEmpty(optString6)) {
            }
            optString8 = optString;
            str3 = optString6;
            adResponseParcel = null;
            j = -1;
            if (str3 == null) {
                return new AdResponseParcel(0);
            }
            optJSONArray = jSONObject.optJSONArray("click_urls");
            if (adResponseParcel != null) {
            }
            if (optJSONArray != null) {
                list = zza(optJSONArray, list);
            }
            optJSONArray = jSONObject.optJSONArray("impression_urls");
            if (adResponseParcel != null) {
            }
            if (optJSONArray != null) {
                list2 = zza(optJSONArray, list2);
            }
            optJSONArray = jSONObject.optJSONArray("manual_impression_urls");
            if (adResponseParcel != null) {
            }
            if (optJSONArray == null) {
            }
            if (adResponseParcel != null) {
                if (adResponseParcel.orientation != -1) {
                    i = adResponseParcel.orientation;
                }
                if (adResponseParcel.zzccb > 0) {
                    j2 = adResponseParcel.zzccb;
                    optString2 = jSONObject.optString("active_view");
                    optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
                    if (optBoolean) {
                    }
                    return new AdResponseParcel(adRequestInfoParcel2, optString8, str3, list, list2, j2, jSONObject.optBoolean("mediation", false), jSONObject.optLong("mediation_config_cache_time_milliseconds", -1), zza, jSONObject.optLong("refresh_interval_milliseconds", -1), i, optString4, j, optString7, optBoolean, optBoolean ? jSONObject.optString("ad_passback_url", null) : null, optString2, jSONObject.optBoolean("custom_render_allowed", false), z, adRequestInfoParcel2.zzcbd, jSONObject.optBoolean("content_url_opted_out", true), jSONObject.optBoolean("prefetch", false), jSONObject.optString("gws_query_id", ""), "height".equals(jSONObject.optString("fluid", "")), jSONObject.optBoolean("native_express", false), RewardItemParcel.zza(jSONObject.optJSONArray("rewards")), zza(jSONObject.optJSONArray("video_start_urls"), null), zza(jSONObject.optJSONArray("video_complete_urls"), null), jSONObject.optBoolean("use_displayed_impression", false), AutoClickProtectionConfigurationParcel.zzh(jSONObject.optJSONObject("auto_protection_configuration")), adRequestInfoParcel2.zzcbu, jSONObject.optString("set_cookie", ""), zza(jSONObject.optJSONArray("remote_ping_urls"), null), jSONObject.optString("safe_browsing"), jSONObject.optBoolean("render_in_browser", adRequestInfoParcel2.zzbnu), optString5);
                }
            }
            j2 = j3;
            optString2 = jSONObject.optString("active_view");
            optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
            if (optBoolean) {
            }
            return new AdResponseParcel(adRequestInfoParcel2, optString8, str3, list, list2, j2, jSONObject.optBoolean("mediation", false), jSONObject.optLong("mediation_config_cache_time_milliseconds", -1), zza, jSONObject.optLong("refresh_interval_milliseconds", -1), i, optString4, j, optString7, optBoolean, optBoolean ? jSONObject.optString("ad_passback_url", null) : null, optString2, jSONObject.optBoolean("custom_render_allowed", false), z, adRequestInfoParcel2.zzcbd, jSONObject.optBoolean("content_url_opted_out", true), jSONObject.optBoolean("prefetch", false), jSONObject.optString("gws_query_id", ""), "height".equals(jSONObject.optString("fluid", "")), jSONObject.optBoolean("native_express", false), RewardItemParcel.zza(jSONObject.optJSONArray("rewards")), zza(jSONObject.optJSONArray("video_start_urls"), null), zza(jSONObject.optJSONArray("video_complete_urls"), null), jSONObject.optBoolean("use_displayed_impression", false), AutoClickProtectionConfigurationParcel.zzh(jSONObject.optJSONObject("auto_protection_configuration")), adRequestInfoParcel2.zzcbu, jSONObject.optString("set_cookie", ""), zza(jSONObject.optJSONArray("remote_ping_urls"), null), jSONObject.optString("safe_browsing"), jSONObject.optBoolean("render_in_browser", adRequestInfoParcel2.zzbnu), optString5);
        } catch (JSONException e) {
            str2 = "Could not parse the inline ad response: ";
            optString = String.valueOf(e.getMessage());
            zzb.zzcy(optString.length() != 0 ? str2.concat(optString) : new String(str2));
            return new AdResponseParcel(0);
        }
    }

    @Nullable
    private static List<String> zza(@Nullable JSONArray jSONArray, @Nullable List<String> list) throws JSONException {
        if (jSONArray == null) {
            return null;
        }
        if (list == null) {
            list = new LinkedList();
        }
        for (int i = 0; i < jSONArray.length(); i++) {
            list.add(jSONArray.getString(i));
        }
        return list;
    }

    @Nullable
    public static JSONObject zza(Context context, AdRequestInfoParcel adRequestInfoParcel, zziz com_google_android_gms_internal_zziz, zza com_google_android_gms_internal_zzjd_zza, Location location, zzcv com_google_android_gms_internal_zzcv, String str, List<String> list, Bundle bundle, String str2) {
        String str3;
        AdRequestInfoParcel adRequestInfoParcel2 = adRequestInfoParcel;
        zziz com_google_android_gms_internal_zziz2 = com_google_android_gms_internal_zziz;
        Location location2 = location;
        Bundle bundle2 = bundle;
        String valueOf;
        try {
            Map hashMap = new HashMap();
            if (list.size() > 0) {
                hashMap.put("eid", TextUtils.join(",", list));
            }
            if (adRequestInfoParcel2.zzcau != null) {
                hashMap.put("ad_pos", adRequestInfoParcel2.zzcau);
            }
            zza((HashMap) hashMap, adRequestInfoParcel2.zzcav);
            hashMap.put("format", adRequestInfoParcel2.zzaoy.zzaup);
            int i = -1;
            if (adRequestInfoParcel2.zzaoy.width == -1) {
                hashMap.put("smart_w", "full");
            }
            if (adRequestInfoParcel2.zzaoy.height == -2) {
                hashMap.put("smart_h", "auto");
            }
            if (adRequestInfoParcel2.zzaoy.zzaut) {
                hashMap.put("fluid", "height");
            }
            if (adRequestInfoParcel2.zzaoy.zzaur != null) {
                StringBuilder stringBuilder = new StringBuilder();
                for (AdSizeParcel adSizeParcel : adRequestInfoParcel2.zzaoy.zzaur) {
                    if (stringBuilder.length() != 0) {
                        stringBuilder.append("|");
                    }
                    stringBuilder.append(adSizeParcel.width == -1 ? (int) (((float) adSizeParcel.widthPixels) / com_google_android_gms_internal_zziz2.zzcbh) : adSizeParcel.width);
                    stringBuilder.append("x");
                    stringBuilder.append(adSizeParcel.height == -2 ? (int) (((float) adSizeParcel.heightPixels) / com_google_android_gms_internal_zziz2.zzcbh) : adSizeParcel.height);
                }
                hashMap.put("sz", stringBuilder);
            }
            if (adRequestInfoParcel2.zzcbb != 0) {
                hashMap.put("native_version", Integer.valueOf(adRequestInfoParcel2.zzcbb));
                if (!adRequestInfoParcel2.zzaoy.zzauu) {
                    hashMap.put("native_templates", adRequestInfoParcel2.zzapq);
                    hashMap.put("native_image_orientation", zzc(adRequestInfoParcel2.zzapm));
                    if (!adRequestInfoParcel2.zzcbm.isEmpty()) {
                        hashMap.put("native_custom_templates", adRequestInfoParcel2.zzcbm);
                    }
                }
            }
            hashMap.put("slotname", adRequestInfoParcel2.zzaos);
            hashMap.put("pn", adRequestInfoParcel2.applicationInfo.packageName);
            if (adRequestInfoParcel2.zzcaw != null) {
                hashMap.put("vc", Integer.valueOf(adRequestInfoParcel2.zzcaw.versionCode));
            }
            hashMap.put("ms", str);
            hashMap.put("seq_num", adRequestInfoParcel2.zzcay);
            hashMap.put("session_id", adRequestInfoParcel2.zzcaz);
            hashMap.put("js", adRequestInfoParcel2.zzaou.zzcs);
            zza(hashMap, com_google_android_gms_internal_zziz2, com_google_android_gms_internal_zzjd_zza, adRequestInfoParcel2.zzcbz);
            zza((HashMap) hashMap, str2);
            hashMap.put("platform", Build.MANUFACTURER);
            hashMap.put("submodel", Build.MODEL);
            if (location2 == null) {
                if (adRequestInfoParcel2.zzcav.versionCode >= 2 && adRequestInfoParcel2.zzcav.zzats != null) {
                    location2 = adRequestInfoParcel2.zzcav.zzats;
                }
                if (adRequestInfoParcel2.versionCode >= 2) {
                    hashMap.put("quality_signals", adRequestInfoParcel2.zzcba);
                }
                if (adRequestInfoParcel2.versionCode >= 4 && adRequestInfoParcel2.zzcbd) {
                    hashMap.put("forceHttps", Boolean.valueOf(adRequestInfoParcel2.zzcbd));
                }
                if (bundle2 != null) {
                    hashMap.put("content_info", bundle2);
                }
                if (adRequestInfoParcel2.versionCode < 5) {
                    hashMap.put("u_sd", Float.valueOf(adRequestInfoParcel2.zzcbh));
                    hashMap.put("sh", Integer.valueOf(adRequestInfoParcel2.zzcbg));
                    hashMap.put("sw", Integer.valueOf(adRequestInfoParcel2.zzcbf));
                } else {
                    hashMap.put("u_sd", Float.valueOf(com_google_android_gms_internal_zziz2.zzcbh));
                    hashMap.put("sh", Integer.valueOf(com_google_android_gms_internal_zziz2.zzcbg));
                    hashMap.put("sw", Integer.valueOf(com_google_android_gms_internal_zziz2.zzcbf));
                }
                if (adRequestInfoParcel2.versionCode >= 6) {
                    if (!TextUtils.isEmpty(adRequestInfoParcel2.zzcbi)) {
                        try {
                            hashMap.put("view_hierarchy", new JSONObject(adRequestInfoParcel2.zzcbi));
                        } catch (Throwable e) {
                            zzb.zzd("Problem serializing view hierarchy to JSON", e);
                        }
                    }
                    hashMap.put("correlation_id", Long.valueOf(adRequestInfoParcel2.zzcbj));
                }
                if (adRequestInfoParcel2.versionCode >= 7) {
                    hashMap.put("request_id", adRequestInfoParcel2.zzcbk);
                }
                if (adRequestInfoParcel2.versionCode >= 11 && adRequestInfoParcel2.zzcbo != null) {
                    hashMap.put("capability", adRequestInfoParcel2.zzcbo.toBundle());
                }
                if (adRequestInfoParcel2.versionCode >= 12 && !TextUtils.isEmpty(adRequestInfoParcel2.zzcbp)) {
                    hashMap.put("anchor", adRequestInfoParcel2.zzcbp);
                }
                if (adRequestInfoParcel2.versionCode >= 13) {
                    hashMap.put("android_app_volume", Float.valueOf(adRequestInfoParcel2.zzcbq));
                }
                if (adRequestInfoParcel2.versionCode >= 18) {
                    hashMap.put("android_app_muted", Boolean.valueOf(adRequestInfoParcel2.zzcbw));
                }
                if (adRequestInfoParcel2.versionCode >= 14 && adRequestInfoParcel2.zzcbr > 0) {
                    hashMap.put("target_api", Integer.valueOf(adRequestInfoParcel2.zzcbr));
                }
                if (adRequestInfoParcel2.versionCode >= 15) {
                    str3 = "scroll_index";
                    if (adRequestInfoParcel2.zzcbs == -1) {
                        i = adRequestInfoParcel2.zzcbs;
                    }
                    hashMap.put(str3, Integer.valueOf(i));
                }
                if (adRequestInfoParcel2.versionCode >= 16) {
                    hashMap.put("_activity_context", Boolean.valueOf(adRequestInfoParcel2.zzcbt));
                }
                if (adRequestInfoParcel2.versionCode >= 18) {
                    if (!TextUtils.isEmpty(adRequestInfoParcel2.zzcbx)) {
                        try {
                            hashMap.put("app_settings", new JSONObject(adRequestInfoParcel2.zzcbx));
                        } catch (Throwable e2) {
                            zzb.zzd("Problem creating json from app settings", e2);
                        }
                    }
                    hashMap.put("render_in_browser", Boolean.valueOf(adRequestInfoParcel2.zzbnu));
                }
                if (adRequestInfoParcel2.versionCode >= 18) {
                    hashMap.put("android_num_video_cache_tasks", Integer.valueOf(adRequestInfoParcel2.zzcby));
                }
                if (zzb.zzaz(2)) {
                    str3 = "Ad Request JSON: ";
                    valueOf = String.valueOf(zzu.zzfq().zzam(hashMap).toString(2));
                    zzkh.m83v(valueOf.length() == 0 ? str3.concat(valueOf) : new String(str3));
                }
                return zzu.zzfq().zzam(hashMap);
            }
            zza((HashMap) hashMap, location2);
            if (adRequestInfoParcel2.versionCode >= 2) {
                hashMap.put("quality_signals", adRequestInfoParcel2.zzcba);
            }
            hashMap.put("forceHttps", Boolean.valueOf(adRequestInfoParcel2.zzcbd));
            if (bundle2 != null) {
                hashMap.put("content_info", bundle2);
            }
            if (adRequestInfoParcel2.versionCode < 5) {
                hashMap.put("u_sd", Float.valueOf(com_google_android_gms_internal_zziz2.zzcbh));
                hashMap.put("sh", Integer.valueOf(com_google_android_gms_internal_zziz2.zzcbg));
                hashMap.put("sw", Integer.valueOf(com_google_android_gms_internal_zziz2.zzcbf));
            } else {
                hashMap.put("u_sd", Float.valueOf(adRequestInfoParcel2.zzcbh));
                hashMap.put("sh", Integer.valueOf(adRequestInfoParcel2.zzcbg));
                hashMap.put("sw", Integer.valueOf(adRequestInfoParcel2.zzcbf));
            }
            if (adRequestInfoParcel2.versionCode >= 6) {
                if (TextUtils.isEmpty(adRequestInfoParcel2.zzcbi)) {
                    hashMap.put("view_hierarchy", new JSONObject(adRequestInfoParcel2.zzcbi));
                }
                hashMap.put("correlation_id", Long.valueOf(adRequestInfoParcel2.zzcbj));
            }
            if (adRequestInfoParcel2.versionCode >= 7) {
                hashMap.put("request_id", adRequestInfoParcel2.zzcbk);
            }
            hashMap.put("capability", adRequestInfoParcel2.zzcbo.toBundle());
            hashMap.put("anchor", adRequestInfoParcel2.zzcbp);
            if (adRequestInfoParcel2.versionCode >= 13) {
                hashMap.put("android_app_volume", Float.valueOf(adRequestInfoParcel2.zzcbq));
            }
            if (adRequestInfoParcel2.versionCode >= 18) {
                hashMap.put("android_app_muted", Boolean.valueOf(adRequestInfoParcel2.zzcbw));
            }
            hashMap.put("target_api", Integer.valueOf(adRequestInfoParcel2.zzcbr));
            if (adRequestInfoParcel2.versionCode >= 15) {
                str3 = "scroll_index";
                if (adRequestInfoParcel2.zzcbs == -1) {
                    i = adRequestInfoParcel2.zzcbs;
                }
                hashMap.put(str3, Integer.valueOf(i));
            }
            if (adRequestInfoParcel2.versionCode >= 16) {
                hashMap.put("_activity_context", Boolean.valueOf(adRequestInfoParcel2.zzcbt));
            }
            if (adRequestInfoParcel2.versionCode >= 18) {
                if (TextUtils.isEmpty(adRequestInfoParcel2.zzcbx)) {
                    hashMap.put("app_settings", new JSONObject(adRequestInfoParcel2.zzcbx));
                }
                hashMap.put("render_in_browser", Boolean.valueOf(adRequestInfoParcel2.zzbnu));
            }
            if (adRequestInfoParcel2.versionCode >= 18) {
                hashMap.put("android_num_video_cache_tasks", Integer.valueOf(adRequestInfoParcel2.zzcby));
            }
            if (zzb.zzaz(2)) {
                str3 = "Ad Request JSON: ";
                valueOf = String.valueOf(zzu.zzfq().zzam(hashMap).toString(2));
                if (valueOf.length() == 0) {
                }
                zzkh.m83v(valueOf.length() == 0 ? str3.concat(valueOf) : new String(str3));
            }
            return zzu.zzfq().zzam(hashMap);
        } catch (JSONException e3) {
            str3 = "Problem serializing ad request to JSON: ";
            valueOf = String.valueOf(e3.getMessage());
            zzb.zzcy(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            return null;
        }
    }

    private static void zza(HashMap<String, Object> hashMap, Location location) {
        HashMap hashMap2 = new HashMap();
        Float valueOf = Float.valueOf(location.getAccuracy() * 1000.0f);
        Long valueOf2 = Long.valueOf(location.getTime() * 1000);
        Long valueOf3 = Long.valueOf((long) (location.getLatitude() * 1.0E7d));
        Long valueOf4 = Long.valueOf((long) (location.getLongitude() * 1.0E7d));
        hashMap2.put("radius", valueOf);
        hashMap2.put("lat", valueOf3);
        hashMap2.put("long", valueOf4);
        hashMap2.put("time", valueOf2);
        hashMap.put("uule", hashMap2);
    }

    private static void zza(HashMap<String, Object> hashMap, AdRequestParcel adRequestParcel) {
        String zzsz = zzkf.zzsz();
        if (zzsz != null) {
            hashMap.put("abf", zzsz);
        }
        if (adRequestParcel.zzatk != -1) {
            hashMap.put("cust_age", zzcep.format(new Date(adRequestParcel.zzatk)));
        }
        if (adRequestParcel.extras != null) {
            hashMap.put("extras", adRequestParcel.extras);
        }
        if (adRequestParcel.zzatl != -1) {
            hashMap.put("cust_gender", Integer.valueOf(adRequestParcel.zzatl));
        }
        if (adRequestParcel.zzatm != null) {
            hashMap.put("kw", adRequestParcel.zzatm);
        }
        if (adRequestParcel.zzato != -1) {
            hashMap.put("tag_for_child_directed_treatment", Integer.valueOf(adRequestParcel.zzato));
        }
        if (adRequestParcel.zzatn) {
            hashMap.put("adtest", "on");
        }
        if (adRequestParcel.versionCode >= 2) {
            if (adRequestParcel.zzatp) {
                hashMap.put("d_imp_hdr", Integer.valueOf(1));
            }
            if (!TextUtils.isEmpty(adRequestParcel.zzatq)) {
                hashMap.put("ppid", adRequestParcel.zzatq);
            }
            if (adRequestParcel.zzatr != null) {
                zza((HashMap) hashMap, adRequestParcel.zzatr);
            }
        }
        if (adRequestParcel.versionCode >= 3 && adRequestParcel.zzatt != null) {
            hashMap.put("url", adRequestParcel.zzatt);
        }
        if (adRequestParcel.versionCode >= 5) {
            if (adRequestParcel.zzatv != null) {
                hashMap.put("custom_targeting", adRequestParcel.zzatv);
            }
            if (adRequestParcel.zzatw != null) {
                hashMap.put("category_exclusions", adRequestParcel.zzatw);
            }
            if (adRequestParcel.zzatx != null) {
                hashMap.put("request_agent", adRequestParcel.zzatx);
            }
        }
        if (adRequestParcel.versionCode >= 6 && adRequestParcel.zzaty != null) {
            hashMap.put("request_pkg", adRequestParcel.zzaty);
        }
        if (adRequestParcel.versionCode >= 7) {
            hashMap.put("is_designed_for_families", Boolean.valueOf(adRequestParcel.zzatz));
        }
    }

    private static void zza(HashMap<String, Object> hashMap, SearchAdRequestParcel searchAdRequestParcel) {
        Object obj;
        if (Color.alpha(searchAdRequestParcel.zzawx) != 0) {
            hashMap.put("acolor", zzau(searchAdRequestParcel.zzawx));
        }
        if (Color.alpha(searchAdRequestParcel.backgroundColor) != 0) {
            hashMap.put("bgcolor", zzau(searchAdRequestParcel.backgroundColor));
        }
        if (!(Color.alpha(searchAdRequestParcel.zzawy) == 0 || Color.alpha(searchAdRequestParcel.zzawz) == 0)) {
            hashMap.put("gradientto", zzau(searchAdRequestParcel.zzawy));
            hashMap.put("gradientfrom", zzau(searchAdRequestParcel.zzawz));
        }
        if (Color.alpha(searchAdRequestParcel.zzaxa) != 0) {
            hashMap.put("bcolor", zzau(searchAdRequestParcel.zzaxa));
        }
        hashMap.put("bthick", Integer.toString(searchAdRequestParcel.zzaxb));
        Object obj2 = null;
        switch (searchAdRequestParcel.zzaxc) {
            case 0:
                obj = "none";
                break;
            case 1:
                obj = "dashed";
                break;
            case 2:
                obj = "dotted";
                break;
            case 3:
                obj = "solid";
                break;
            default:
                obj = null;
                break;
        }
        if (obj != null) {
            hashMap.put("btype", obj);
        }
        switch (searchAdRequestParcel.zzaxd) {
            case 0:
                obj2 = "light";
                break;
            case 1:
                obj2 = "medium";
                break;
            case 2:
                obj2 = "dark";
                break;
            default:
                break;
        }
        if (obj2 != null) {
            hashMap.put("callbuttoncolor", obj2);
        }
        if (searchAdRequestParcel.zzaxe != null) {
            hashMap.put("channel", searchAdRequestParcel.zzaxe);
        }
        if (Color.alpha(searchAdRequestParcel.zzaxf) != 0) {
            hashMap.put("dcolor", zzau(searchAdRequestParcel.zzaxf));
        }
        if (searchAdRequestParcel.zzaxg != null) {
            hashMap.put("font", searchAdRequestParcel.zzaxg);
        }
        if (Color.alpha(searchAdRequestParcel.zzaxh) != 0) {
            hashMap.put("hcolor", zzau(searchAdRequestParcel.zzaxh));
        }
        hashMap.put("headersize", Integer.toString(searchAdRequestParcel.zzaxi));
        if (searchAdRequestParcel.zzaxj != null) {
            hashMap.put("q", searchAdRequestParcel.zzaxj);
        }
    }

    private static void zza(HashMap<String, Object> hashMap, zziz com_google_android_gms_internal_zziz, zza com_google_android_gms_internal_zzjd_zza, Bundle bundle) {
        Bundle bundle2;
        hashMap.put("am", Integer.valueOf(com_google_android_gms_internal_zziz.zzcgh));
        hashMap.put("cog", zzab(com_google_android_gms_internal_zziz.zzcgi));
        hashMap.put("coh", zzab(com_google_android_gms_internal_zziz.zzcgj));
        if (!TextUtils.isEmpty(com_google_android_gms_internal_zziz.zzcgk)) {
            hashMap.put("carrier", com_google_android_gms_internal_zziz.zzcgk);
        }
        hashMap.put("gl", com_google_android_gms_internal_zziz.zzcgl);
        if (com_google_android_gms_internal_zziz.zzcgm) {
            hashMap.put("simulator", Integer.valueOf(1));
        }
        if (com_google_android_gms_internal_zziz.zzcgn) {
            hashMap.put("is_sidewinder", Integer.valueOf(1));
        }
        hashMap.put("ma", zzab(com_google_android_gms_internal_zziz.zzcgo));
        hashMap.put("sp", zzab(com_google_android_gms_internal_zziz.zzcgp));
        hashMap.put("hl", com_google_android_gms_internal_zziz.zzcgq);
        if (!TextUtils.isEmpty(com_google_android_gms_internal_zziz.zzcgr)) {
            hashMap.put("mv", com_google_android_gms_internal_zziz.zzcgr);
        }
        hashMap.put("muv", Integer.valueOf(com_google_android_gms_internal_zziz.zzcgs));
        if (com_google_android_gms_internal_zziz.zzcgt != -2) {
            hashMap.put("cnt", Integer.valueOf(com_google_android_gms_internal_zziz.zzcgt));
        }
        hashMap.put("gnt", Integer.valueOf(com_google_android_gms_internal_zziz.zzcgu));
        hashMap.put("pt", Integer.valueOf(com_google_android_gms_internal_zziz.zzcgv));
        hashMap.put("rm", Integer.valueOf(com_google_android_gms_internal_zziz.zzcgw));
        hashMap.put("riv", Integer.valueOf(com_google_android_gms_internal_zziz.zzcgx));
        Bundle bundle3 = new Bundle();
        bundle3.putString("build", com_google_android_gms_internal_zziz.zzchc);
        Bundle bundle4 = new Bundle();
        bundle4.putBoolean("is_charging", com_google_android_gms_internal_zziz.zzcgz);
        bundle4.putDouble("battery_level", com_google_android_gms_internal_zziz.zzcgy);
        bundle3.putBundle("battery", bundle4);
        bundle4 = new Bundle();
        bundle4.putInt("active_network_state", com_google_android_gms_internal_zziz.zzchb);
        bundle4.putBoolean("active_network_metered", com_google_android_gms_internal_zziz.zzcha);
        if (com_google_android_gms_internal_zzjd_zza != null) {
            bundle2 = new Bundle();
            bundle2.putInt("predicted_latency_micros", 0);
            bundle2.putLong("predicted_down_throughput_bps", 0);
            bundle2.putLong("predicted_up_throughput_bps", 0);
            bundle4.putBundle("predictions", bundle2);
        }
        bundle3.putBundle("network", bundle4);
        bundle2 = new Bundle();
        bundle2.putBoolean("is_browser_custom_tabs_capable", com_google_android_gms_internal_zziz.zzchd);
        bundle3.putBundle("browser", bundle2);
        if (bundle != null) {
            bundle3.putBundle("android_mem_info", zzf(bundle));
        }
        hashMap.put("device", bundle3);
    }

    private static void zza(HashMap<String, Object> hashMap, String str) {
        Bundle bundle = new Bundle();
        bundle.putString("doritos", str);
        hashMap.put("pii", bundle);
    }

    private static Integer zzab(boolean z) {
        return Integer.valueOf(z);
    }

    private static String zzau(int i) {
        return String.format(Locale.US, "#%06x", new Object[]{Integer.valueOf(i & ViewCompat.MEASURED_SIZE_MASK)});
    }

    private static String zzc(NativeAdOptionsParcel nativeAdOptionsParcel) {
        switch (nativeAdOptionsParcel != null ? nativeAdOptionsParcel.zzbgu : 0) {
            case 1:
                return "portrait";
            case 2:
                return "landscape";
            default:
                return "any";
        }
    }

    public static JSONObject zzc(AdResponseParcel adResponseParcel) throws JSONException {
        String str;
        Object obj;
        JSONObject jSONObject = new JSONObject();
        if (adResponseParcel.zzbts != null) {
            jSONObject.put("ad_base_url", adResponseParcel.zzbts);
        }
        if (adResponseParcel.zzccf != null) {
            jSONObject.put("ad_size", adResponseParcel.zzccf);
        }
        jSONObject.put("native", adResponseParcel.zzaus);
        jSONObject.put(adResponseParcel.zzaus ? "ad_json" : "ad_html", adResponseParcel.body);
        if (adResponseParcel.zzcch != null) {
            jSONObject.put("debug_dialog", adResponseParcel.zzcch);
        }
        if (adResponseParcel.zzccb != -1) {
            jSONObject.put("interstitial_timeout", ((double) adResponseParcel.zzccb) / 1000.0d);
        }
        if (adResponseParcel.orientation == zzu.zzfs().zztl()) {
            str = "orientation";
            obj = "portrait";
        } else {
            if (adResponseParcel.orientation == zzu.zzfs().zztk()) {
                str = "orientation";
                obj = "landscape";
            }
            if (adResponseParcel.zzbnq != null) {
                jSONObject.put("click_urls", zzk(adResponseParcel.zzbnq));
            }
            if (adResponseParcel.zzbnr != null) {
                jSONObject.put("impression_urls", zzk(adResponseParcel.zzbnr));
            }
            if (adResponseParcel.zzcce != null) {
                jSONObject.put("manual_impression_urls", zzk(adResponseParcel.zzcce));
            }
            if (adResponseParcel.zzcck != null) {
                jSONObject.put("active_view", adResponseParcel.zzcck);
            }
            jSONObject.put("ad_is_javascript", adResponseParcel.zzcci);
            if (adResponseParcel.zzccj != null) {
                jSONObject.put("ad_passback_url", adResponseParcel.zzccj);
            }
            jSONObject.put("mediation", adResponseParcel.zzccc);
            jSONObject.put("custom_render_allowed", adResponseParcel.zzccl);
            jSONObject.put("content_url_opted_out", adResponseParcel.zzccm);
            jSONObject.put("prefetch", adResponseParcel.zzccn);
            if (adResponseParcel.zzbnw != -1) {
                jSONObject.put("refresh_interval_milliseconds", adResponseParcel.zzbnw);
            }
            if (adResponseParcel.zzccd != -1) {
                jSONObject.put("mediation_config_cache_time_milliseconds", adResponseParcel.zzccd);
            }
            if (!TextUtils.isEmpty(adResponseParcel.zzccq)) {
                jSONObject.put("gws_query_id", adResponseParcel.zzccq);
            }
            jSONObject.put("fluid", adResponseParcel.zzaut ? "height" : "");
            jSONObject.put("native_express", adResponseParcel.zzauu);
            if (adResponseParcel.zzccs != null) {
                jSONObject.put("video_start_urls", zzk(adResponseParcel.zzccs));
            }
            if (adResponseParcel.zzcct != null) {
                jSONObject.put("video_complete_urls", zzk(adResponseParcel.zzcct));
            }
            if (adResponseParcel.zzccr != null) {
                jSONObject.put("rewards", adResponseParcel.zzccr.zzrx());
            }
            jSONObject.put("use_displayed_impression", adResponseParcel.zzccu);
            jSONObject.put("auto_protection_configuration", adResponseParcel.zzccv);
            jSONObject.put("render_in_browser", adResponseParcel.zzbnu);
            return jSONObject;
        }
        jSONObject.put(str, obj);
        if (adResponseParcel.zzbnq != null) {
            jSONObject.put("click_urls", zzk(adResponseParcel.zzbnq));
        }
        if (adResponseParcel.zzbnr != null) {
            jSONObject.put("impression_urls", zzk(adResponseParcel.zzbnr));
        }
        if (adResponseParcel.zzcce != null) {
            jSONObject.put("manual_impression_urls", zzk(adResponseParcel.zzcce));
        }
        if (adResponseParcel.zzcck != null) {
            jSONObject.put("active_view", adResponseParcel.zzcck);
        }
        jSONObject.put("ad_is_javascript", adResponseParcel.zzcci);
        if (adResponseParcel.zzccj != null) {
            jSONObject.put("ad_passback_url", adResponseParcel.zzccj);
        }
        jSONObject.put("mediation", adResponseParcel.zzccc);
        jSONObject.put("custom_render_allowed", adResponseParcel.zzccl);
        jSONObject.put("content_url_opted_out", adResponseParcel.zzccm);
        jSONObject.put("prefetch", adResponseParcel.zzccn);
        if (adResponseParcel.zzbnw != -1) {
            jSONObject.put("refresh_interval_milliseconds", adResponseParcel.zzbnw);
        }
        if (adResponseParcel.zzccd != -1) {
            jSONObject.put("mediation_config_cache_time_milliseconds", adResponseParcel.zzccd);
        }
        if (TextUtils.isEmpty(adResponseParcel.zzccq)) {
            jSONObject.put("gws_query_id", adResponseParcel.zzccq);
        }
        if (adResponseParcel.zzaut) {
        }
        jSONObject.put("fluid", adResponseParcel.zzaut ? "height" : "");
        jSONObject.put("native_express", adResponseParcel.zzauu);
        if (adResponseParcel.zzccs != null) {
            jSONObject.put("video_start_urls", zzk(adResponseParcel.zzccs));
        }
        if (adResponseParcel.zzcct != null) {
            jSONObject.put("video_complete_urls", zzk(adResponseParcel.zzcct));
        }
        if (adResponseParcel.zzccr != null) {
            jSONObject.put("rewards", adResponseParcel.zzccr.zzrx());
        }
        jSONObject.put("use_displayed_impression", adResponseParcel.zzccu);
        jSONObject.put("auto_protection_configuration", adResponseParcel.zzccv);
        jSONObject.put("render_in_browser", adResponseParcel.zzbnu);
        return jSONObject;
    }

    private static Bundle zzf(Bundle bundle) {
        Bundle bundle2 = new Bundle();
        bundle2.putString("runtime_free", Long.toString(bundle.getLong("runtime_free_memory", -1)));
        bundle2.putString("runtime_max", Long.toString(bundle.getLong("runtime_max_memory", -1)));
        bundle2.putString("runtime_total", Long.toString(bundle.getLong("runtime_total_memory", -1)));
        MemoryInfo memoryInfo = (MemoryInfo) bundle.getParcelable("debug_memory_info");
        if (memoryInfo != null) {
            bundle2.putString("debug_info_dalvik_private_dirty", Integer.toString(memoryInfo.dalvikPrivateDirty));
            bundle2.putString("debug_info_dalvik_pss", Integer.toString(memoryInfo.dalvikPss));
            bundle2.putString("debug_info_dalvik_shared_dirty", Integer.toString(memoryInfo.dalvikSharedDirty));
            bundle2.putString("debug_info_native_private_dirty", Integer.toString(memoryInfo.nativePrivateDirty));
            bundle2.putString("debug_info_native_pss", Integer.toString(memoryInfo.nativePss));
            bundle2.putString("debug_info_native_shared_dirty", Integer.toString(memoryInfo.nativeSharedDirty));
            bundle2.putString("debug_info_other_private_dirty", Integer.toString(memoryInfo.otherPrivateDirty));
            bundle2.putString("debug_info_other_pss", Integer.toString(memoryInfo.otherPss));
            bundle2.putString("debug_info_other_shared_dirty", Integer.toString(memoryInfo.otherSharedDirty));
        }
        return bundle2;
    }

    @Nullable
    static JSONArray zzk(List<String> list) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        for (String put : list) {
            jSONArray.put(put);
        }
        return jSONArray;
    }
}
