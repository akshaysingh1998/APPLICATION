package com.google.android.gms.internal;

import android.content.Context;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Map;

@zzir
public class zzkr {
    private static zzl zzcmg;
    private static final Object zzcmh = new Object();
    public static final zza<Void> zzcmi = new C09451();

    public interface zza<T> {
        T zzh(InputStream inputStream);

        T zzqv();
    }

    class C09451 implements zza<Void> {
        C09451() {
        }

        public /* synthetic */ Object zzh(InputStream inputStream) {
            return zzi(inputStream);
        }

        public Void zzi(InputStream inputStream) {
            return null;
        }

        public /* synthetic */ Object zzqv() {
            return zztq();
        }

        public Void zztq() {
            return null;
        }
    }

    private static class zzb<T> extends zzk<InputStream> {
        private final com.google.android.gms.internal.zzm.zzb<T> zzcg;
        private final zza<T> zzcmn;

        class C09471 implements com.google.android.gms.internal.zzm.zza {
            final /* synthetic */ com.google.android.gms.internal.zzm.zzb zzcmo;
            final /* synthetic */ zza zzcmp;

            C09471(com.google.android.gms.internal.zzm.zzb com_google_android_gms_internal_zzm_zzb, zza com_google_android_gms_internal_zzkr_zza) {
                this.zzcmo = com_google_android_gms_internal_zzm_zzb;
                this.zzcmp = com_google_android_gms_internal_zzkr_zza;
            }

            public void zze(zzr com_google_android_gms_internal_zzr) {
                this.zzcmo.zzb(this.zzcmp.zzqv());
            }
        }

        public zzb(String str, zza<T> com_google_android_gms_internal_zzkr_zza_T, com.google.android.gms.internal.zzm.zzb<T> com_google_android_gms_internal_zzm_zzb_T) {
            super(0, str, new C09471(com_google_android_gms_internal_zzm_zzb_T, com_google_android_gms_internal_zzkr_zza_T));
            this.zzcmn = com_google_android_gms_internal_zzkr_zza_T;
            this.zzcg = com_google_android_gms_internal_zzm_zzb_T;
        }

        protected zzm<InputStream> zza(zzi com_google_android_gms_internal_zzi) {
            return zzm.zza(new ByteArrayInputStream(com_google_android_gms_internal_zzi.data), zzx.zzb(com_google_android_gms_internal_zzi));
        }

        protected /* synthetic */ void zza(Object obj) {
            zzj((InputStream) obj);
        }

        protected void zzj(InputStream inputStream) {
            this.zzcg.zzb(this.zzcmn.zzh(inputStream));
        }
    }

    private class zzc<T> extends zzkz<T> implements com.google.android.gms.internal.zzm.zzb<T> {
        final /* synthetic */ zzkr zzcmk;

        private zzc(zzkr com_google_android_gms_internal_zzkr) {
            this.zzcmk = com_google_android_gms_internal_zzkr;
        }

        public void zzb(T t) {
            super.zzi(t);
        }
    }

    public zzkr(Context context) {
        zzap(context);
    }

    private static zzl zzap(Context context) {
        zzl com_google_android_gms_internal_zzl;
        synchronized (zzcmh) {
            if (zzcmg == null) {
                zzcmg = zzac.zza(context.getApplicationContext());
            }
            com_google_android_gms_internal_zzl = zzcmg;
        }
        return com_google_android_gms_internal_zzl;
    }

    public zzlc<String> zza(int i, final String str, Map<String, String> map, byte[] bArr) {
        final zzlc com_google_android_gms_internal_zzkr_zzc = new zzc();
        final byte[] bArr2 = bArr;
        final Map<String, String> map2 = map;
        zzcmg.zze(new zzab(this, i, str, com_google_android_gms_internal_zzkr_zzc, new com.google.android.gms.internal.zzm.zza(this) {
            final /* synthetic */ zzkr zzcmk;

            public void zze(zzr com_google_android_gms_internal_zzr) {
                String str = str;
                String valueOf = String.valueOf(com_google_android_gms_internal_zzr.toString());
                StringBuilder stringBuilder = new StringBuilder((21 + String.valueOf(str).length()) + String.valueOf(valueOf).length());
                stringBuilder.append("Failed to load URL: ");
                stringBuilder.append(str);
                stringBuilder.append("\n");
                stringBuilder.append(valueOf);
                com.google.android.gms.ads.internal.util.client.zzb.zzcy(stringBuilder.toString());
                com_google_android_gms_internal_zzkr_zzc.zzb(null);
            }
        }) {
            final /* synthetic */ zzkr zzcmk;

            public Map<String, String> getHeaders() throws zza {
                return map2 == null ? super.getHeaders() : map2;
            }

            public byte[] zzp() throws zza {
                return bArr2 == null ? super.zzp() : bArr2;
            }
        });
        return com_google_android_gms_internal_zzkr_zzc;
    }

    public <T> zzlc<T> zza(String str, zza<T> com_google_android_gms_internal_zzkr_zza_T) {
        Object com_google_android_gms_internal_zzkr_zzc = new zzc();
        zzcmg.zze(new zzb(str, com_google_android_gms_internal_zzkr_zza_T, com_google_android_gms_internal_zzkr_zzc));
        return com_google_android_gms_internal_zzkr_zzc;
    }

    public zzlc<String> zzb(String str, Map<String, String> map) {
        return zza(0, str, map, null);
    }
}
