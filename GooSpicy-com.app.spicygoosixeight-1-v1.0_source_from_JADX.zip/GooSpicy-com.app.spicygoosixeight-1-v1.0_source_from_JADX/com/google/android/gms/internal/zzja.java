package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzu;
import java.util.WeakHashMap;

@zzir
public final class zzja {
    private WeakHashMap<Context, zza> zzche = new WeakHashMap();

    private class zza {
        public final long zzchf = zzu.zzfu().currentTimeMillis();
        public final zziz zzchg;
        final /* synthetic */ zzja zzchh;

        public zza(zzja com_google_android_gms_internal_zzja, zziz com_google_android_gms_internal_zziz) {
            this.zzchh = com_google_android_gms_internal_zzja;
            this.zzchg = com_google_android_gms_internal_zziz;
        }

        public boolean hasExpired() {
            return this.zzchf + ((Long) zzdc.zzbar.get()).longValue() < zzu.zzfu().currentTimeMillis();
        }
    }

    public zziz zzy(Context context) {
        zza com_google_android_gms_internal_zzja_zza = (zza) this.zzche.get(context);
        zziz zzro = (com_google_android_gms_internal_zzja_zza == null || com_google_android_gms_internal_zzja_zza.hasExpired() || !((Boolean) zzdc.zzbaq.get()).booleanValue()) ? new com.google.android.gms.internal.zziz.zza(context).zzro() : new com.google.android.gms.internal.zziz.zza(context, com_google_android_gms_internal_zzja_zza.zzchg).zzro();
        this.zzche.put(context, new zza(this, zzro));
        return zzro;
    }
}
