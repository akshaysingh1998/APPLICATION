package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.view.View;
import android.webkit.WebChromeClient.CustomViewCallback;

@TargetApi(14)
@zzir
public final class zzlu extends zzls {
    public zzlu(zzll com_google_android_gms_internal_zzll) {
        super(com_google_android_gms_internal_zzll);
    }

    public void onShowCustomView(View view, int i, CustomViewCallback customViewCallback) {
        zza(view, i, customViewCallback);
    }
}
