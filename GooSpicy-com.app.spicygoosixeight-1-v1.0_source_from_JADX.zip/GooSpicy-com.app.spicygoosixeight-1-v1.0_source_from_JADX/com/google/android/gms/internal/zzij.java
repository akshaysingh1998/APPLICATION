package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.zzn;
import com.google.android.gms.internal.zzjy.zza;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@zzir
public class zzij extends zzif {
    private final zzdk zzajn;
    private zzgn zzajz;
    private final zzll zzbgj;
    private zzge zzboi;
    zzgc zzbyq;
    protected zzgi zzbyr;
    private boolean zzbys;

    zzij(Context context, zza com_google_android_gms_internal_zzjy_zza, zzgn com_google_android_gms_internal_zzgn, zzig.zza com_google_android_gms_internal_zzig_zza, zzdk com_google_android_gms_internal_zzdk, zzll com_google_android_gms_internal_zzll) {
        super(context, com_google_android_gms_internal_zzjy_zza, com_google_android_gms_internal_zzig_zza);
        this.zzajz = com_google_android_gms_internal_zzgn;
        this.zzboi = com_google_android_gms_internal_zzjy_zza.zzcik;
        this.zzajn = com_google_android_gms_internal_zzdk;
        this.zzbgj = com_google_android_gms_internal_zzll;
    }

    private static String zza(zzgi com_google_android_gms_internal_zzgi) {
        String str = com_google_android_gms_internal_zzgi.zzbor.zzbnb;
        int zzal = zzal(com_google_android_gms_internal_zzgi.zzboq);
        long j = com_google_android_gms_internal_zzgi.zzbow;
        StringBuilder stringBuilder = new StringBuilder(33 + String.valueOf(str).length());
        stringBuilder.append(str);
        stringBuilder.append(".");
        stringBuilder.append(zzal);
        stringBuilder.append(".");
        stringBuilder.append(j);
        return stringBuilder.toString();
    }

    private static int zzal(int i) {
        switch (i) {
            case -1:
                return 4;
            case 0:
                return 0;
            case 1:
                return 1;
            case 3:
                return 2;
            case 4:
                return 3;
            case 5:
                return 5;
            default:
                return 6;
        }
    }

    private static String zzg(List<zzgi> list) {
        String str = "";
        if (list == null) {
            return str.toString();
        }
        for (zzgi com_google_android_gms_internal_zzgi : list) {
            if (!(com_google_android_gms_internal_zzgi == null || com_google_android_gms_internal_zzgi.zzbor == null)) {
                if (!TextUtils.isEmpty(com_google_android_gms_internal_zzgi.zzbor.zzbnb)) {
                    str = String.valueOf(str);
                    String valueOf = String.valueOf(zza(com_google_android_gms_internal_zzgi));
                    StringBuilder stringBuilder = new StringBuilder((1 + String.valueOf(str).length()) + String.valueOf(valueOf).length());
                    stringBuilder.append(str);
                    stringBuilder.append(valueOf);
                    stringBuilder.append("_");
                    str = stringBuilder.toString();
                }
            }
        }
        return str.substring(0, Math.max(0, str.length() - 1));
    }

    private void zzqg() throws zza {
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        zzkl.zzclg.post(new Runnable(this) {
            final /* synthetic */ zzij zzbyt;

            public void run() {
                synchronized (this.zzbyt.zzbxy) {
                    this.zzbyt.zzbys = zzn.zza(this.zzbyt.zzbgj, this.zzbyt.zzbyr, countDownLatch);
                }
            }
        });
        try {
            countDownLatch.await(10, TimeUnit.SECONDS);
            synchronized (this.zzbxy) {
                if (!this.zzbys) {
                    throw new zza("View could not be prepared", 0);
                } else if (this.zzbgj.isDestroyed()) {
                    throw new zza("Assets not loaded, web view is destroyed", 0);
                }
            }
        } catch (InterruptedException e) {
            String valueOf = String.valueOf(e);
            StringBuilder stringBuilder = new StringBuilder(38 + String.valueOf(valueOf).length());
            stringBuilder.append("Interrupted while waiting for latch : ");
            stringBuilder.append(valueOf);
            throw new zza(stringBuilder.toString(), 0);
        }
    }

    public void onStop() {
        synchronized (this.zzbxy) {
            super.onStop();
            if (this.zzbyq != null) {
                this.zzbyq.cancel();
            }
        }
    }

    protected zzjy zzak(int i) {
        AdRequestInfoParcel adRequestInfoParcel = this.zzbxv.zzcit;
        AdRequestParcel adRequestParcel = adRequestInfoParcel.zzcav;
        zzll com_google_android_gms_internal_zzll = this.zzbgj;
        List list = this.zzbxw.zzbnq;
        List list2 = this.zzbxw.zzbnr;
        List list3 = this.zzbxw.zzcce;
        int i2 = this.zzbxw.orientation;
        long j = this.zzbxw.zzbnw;
        String str = adRequestInfoParcel.zzcay;
        boolean z = this.zzbxw.zzccc;
        zzgd com_google_android_gms_internal_zzgd = this.zzbyr != null ? r0.zzbyr.zzbor : null;
        zzgo com_google_android_gms_internal_zzgo = r0.zzbyr != null ? r0.zzbyr.zzbos : null;
        return new zzjy(adRequestParcel, com_google_android_gms_internal_zzll, list, i, list2, list3, i2, j, str, z, com_google_android_gms_internal_zzgd, com_google_android_gms_internal_zzgo, r0.zzbyr != null ? r0.zzbyr.zzbot : AdMobAdapter.class.getName(), r0.zzboi, r0.zzbyr != null ? r0.zzbyr.zzbou : null, r0.zzbxw.zzccd, r0.zzbxv.zzaoy, r0.zzbxw.zzccb, r0.zzbxv.zzcio, r0.zzbxw.zzccg, r0.zzbxw.zzcch, r0.zzbxv.zzcii, null, r0.zzbxw.zzccr, r0.zzbxw.zzccs, r0.zzbxw.zzcct, r0.zzboi != null ? r0.zzboi.zzbob : false, r0.zzbxw.zzccv, r0.zzbyq != null ? zzg(r0.zzbyq.zzmi()) : null, r0.zzbxw.zzbnt);
    }

    protected void zzh(long j) throws zza {
        boolean z;
        ListIterator listIterator;
        synchronized (this.zzbxy) {
            this.zzbyq = zzi(j);
        }
        List arrayList = new ArrayList(this.zzboi.zzbno);
        Bundle bundle = this.zzbxv.zzcit.zzcav.zzatu;
        String str = "com.google.ads.mediation.admob.AdMobAdapter";
        if (bundle != null) {
            bundle = bundle.getBundle(str);
            if (bundle != null) {
                z = bundle.getBoolean("_skipMediation");
                if (z) {
                    listIterator = arrayList.listIterator();
                    while (listIterator.hasNext()) {
                        if (!((zzgd) listIterator.next()).zzbna.contains(str)) {
                            listIterator.remove();
                        }
                    }
                }
                this.zzbyr = this.zzbyq.zzd(arrayList);
                switch (this.zzbyr.zzboq) {
                    case 0:
                        if (this.zzbyr.zzbor != null && this.zzbyr.zzbor.zzbnj != null) {
                            zzqg();
                            return;
                        }
                        return;
                    case 1:
                        throw new zza("No fill from any mediation ad networks.", 3);
                    default:
                        int i = this.zzbyr.zzboq;
                        StringBuilder stringBuilder = new StringBuilder(40);
                        stringBuilder.append("Unexpected mediation result: ");
                        stringBuilder.append(i);
                        throw new zza(stringBuilder.toString(), 0);
                }
            }
        }
        z = false;
        if (z) {
            listIterator = arrayList.listIterator();
            while (listIterator.hasNext()) {
                if (!((zzgd) listIterator.next()).zzbna.contains(str)) {
                    listIterator.remove();
                }
            }
        }
        this.zzbyr = this.zzbyq.zzd(arrayList);
        switch (this.zzbyr.zzboq) {
            case 0:
                if (this.zzbyr.zzbor != null) {
                    return;
                }
                return;
            case 1:
                throw new zza("No fill from any mediation ad networks.", 3);
            default:
                int i2 = this.zzbyr.zzboq;
                StringBuilder stringBuilder2 = new StringBuilder(40);
                stringBuilder2.append("Unexpected mediation result: ");
                stringBuilder2.append(i2);
                throw new zza(stringBuilder2.toString(), 0);
        }
    }

    zzgc zzi(long j) {
        if (this.zzboi.zzbnz != -1) {
            return new zzgk(r0.mContext, r0.zzbxv.zzcit, r0.zzajz, r0.zzboi, r0.zzbxw.zzaus, r0.zzbxw.zzauu, j, ((Long) zzdc.zzbbf.get()).longValue(), 2);
        }
        Context context = r0.mContext;
        AdRequestInfoParcel adRequestInfoParcel = r0.zzbxv.zzcit;
        zzgn com_google_android_gms_internal_zzgn = r0.zzajz;
        zzge com_google_android_gms_internal_zzge = r0.zzboi;
        boolean z = r0.zzbxw.zzaus;
        return new zzgl(context, adRequestInfoParcel, com_google_android_gms_internal_zzgn, com_google_android_gms_internal_zzge, z, r0.zzbxw.zzauu, j, ((Long) zzdc.zzbbf.get()).longValue(), r0.zzajn);
    }
}
