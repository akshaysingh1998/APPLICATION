package com.google.android.gms.internal;

import android.content.Context;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzq;
import com.google.android.gms.common.util.zzs;

@zzir
public class zzig {

    public interface zza {
        void zzb(zzjy com_google_android_gms_internal_zzjy);
    }

    public zzkn zza(Context context, com.google.android.gms.ads.internal.zza com_google_android_gms_ads_internal_zza, com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza, zzas com_google_android_gms_internal_zzas, @Nullable zzll com_google_android_gms_internal_zzll, zzgn com_google_android_gms_internal_zzgn, zza com_google_android_gms_internal_zzig_zza, zzdk com_google_android_gms_internal_zzdk) {
        zzkn com_google_android_gms_internal_zzie;
        String valueOf;
        Context context2 = context;
        com.google.android.gms.ads.internal.zza com_google_android_gms_ads_internal_zza2 = com_google_android_gms_ads_internal_zza;
        com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza2 = com_google_android_gms_internal_zzjy_zza;
        zzll com_google_android_gms_internal_zzll2 = com_google_android_gms_internal_zzll;
        zza com_google_android_gms_internal_zzig_zza2 = com_google_android_gms_internal_zzig_zza;
        AdResponseParcel adResponseParcel = com_google_android_gms_internal_zzjy_zza2.zzciu;
        if (adResponseParcel.zzccc) {
            zzkn com_google_android_gms_internal_zzij = new zzij(context2, com_google_android_gms_internal_zzjy_zza2, com_google_android_gms_internal_zzgn, com_google_android_gms_internal_zzig_zza2, com_google_android_gms_internal_zzdk, com_google_android_gms_internal_zzll2);
        } else if (!adResponseParcel.zzaus) {
            com_google_android_gms_internal_zzie = adResponseParcel.zzcci ? new zzie(context2, com_google_android_gms_internal_zzjy_zza2, com_google_android_gms_internal_zzll2, com_google_android_gms_internal_zzig_zza2) : (((Boolean) zzdc.zzazq.get()).booleanValue() && zzs.zzavq() && !zzs.isAtLeastL() && com_google_android_gms_internal_zzll2 != null && com_google_android_gms_internal_zzll2.zzdo().zzauq) ? new zzii(context2, com_google_android_gms_internal_zzjy_zza2, com_google_android_gms_internal_zzll2, com_google_android_gms_internal_zzig_zza2) : new zzih(context2, com_google_android_gms_internal_zzjy_zza2, com_google_android_gms_internal_zzll2, com_google_android_gms_internal_zzig_zza2);
        } else if (com_google_android_gms_ads_internal_zza2 instanceof zzq) {
            com_google_android_gms_internal_zzie = new zzik(context2, (zzq) com_google_android_gms_ads_internal_zza2, com_google_android_gms_internal_zzjy_zza2, com_google_android_gms_internal_zzas, com_google_android_gms_internal_zzig_zza2);
        } else {
            valueOf = String.valueOf(com_google_android_gms_ads_internal_zza2 != null ? com_google_android_gms_ads_internal_zza2.getClass().getName() : "null");
            StringBuilder stringBuilder = new StringBuilder(65 + String.valueOf(valueOf).length());
            stringBuilder.append("Invalid NativeAdManager type. Found: ");
            stringBuilder.append(valueOf);
            stringBuilder.append("; Required: NativeAdManager.");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        valueOf = "AdRenderer: ";
        String valueOf2 = String.valueOf(com_google_android_gms_internal_zzie.getClass().getName());
        zzb.zzcw(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
        com_google_android_gms_internal_zzie.zzpz();
        return com_google_android_gms_internal_zzie;
    }

    public zzkn zza(Context context, com.google.android.gms.internal.zzjy.zza com_google_android_gms_internal_zzjy_zza, zzjj com_google_android_gms_internal_zzjj) {
        zzkn com_google_android_gms_internal_zzjp = new zzjp(context, com_google_android_gms_internal_zzjy_zza, com_google_android_gms_internal_zzjj);
        String str = "AdRenderer: ";
        String valueOf = String.valueOf(com_google_android_gms_internal_zzjp.getClass().getName());
        zzb.zzcw(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        com_google_android_gms_internal_zzjp.zzpz();
        return com_google_android_gms_internal_zzjp;
    }
}
