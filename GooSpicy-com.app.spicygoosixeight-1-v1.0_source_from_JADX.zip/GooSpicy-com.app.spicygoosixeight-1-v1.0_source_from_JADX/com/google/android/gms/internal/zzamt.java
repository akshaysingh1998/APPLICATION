package com.google.android.gms.internal;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class zzamt {
    private final List<zzanl> bea = new ArrayList();
    private zzant bek = zzant.beU;
    private zzani bel = zzani.DEFAULT;
    private zzamr bem = zzamq.bdS;
    private final Map<Type, zzamu<?>> ben = new HashMap();
    private final List<zzanl> beo = new ArrayList();
    private int bep = 2;
    private int beq = 2;
    private boolean ber = true;

    private void zza(String str, int i, int i2, List<zzanl> list) {
        Object com_google_android_gms_internal_zzamn;
        if (str != null && !"".equals(str.trim())) {
            com_google_android_gms_internal_zzamn = new zzamn(str);
        } else if (i != 2 && i2 != 2) {
            com_google_android_gms_internal_zzamn = new zzamn(i, i2);
        } else {
            return;
        }
        list.add(zzanj.zza(zzaoo.zzr(Date.class), com_google_android_gms_internal_zzamn));
        list.add(zzanj.zza(zzaoo.zzr(Timestamp.class), com_google_android_gms_internal_zzamn));
        list.add(zzanj.zza(zzaoo.zzr(java.sql.Date.class), com_google_android_gms_internal_zzamn));
    }

    public zzamt zza(Type type, Object obj) {
        boolean z;
        boolean z2 = obj instanceof zzang;
        if (!(z2 || (obj instanceof zzamx) || (obj instanceof zzamu))) {
            if (!(obj instanceof zzank)) {
                z = false;
                zzanq.zzbn(z);
                if (obj instanceof zzamu) {
                    this.ben.put(type, (zzamu) obj);
                }
                if (z2 || (obj instanceof zzamx)) {
                    this.bea.add(zzanj.zzb(zzaoo.zzl(type), obj));
                }
                if (obj instanceof zzank) {
                    this.bea.add(zzaon.zza(zzaoo.zzl(type), (zzank) obj));
                }
                return this;
            }
        }
        z = true;
        zzanq.zzbn(z);
        if (obj instanceof zzamu) {
            this.ben.put(type, (zzamu) obj);
        }
        this.bea.add(zzanj.zzb(zzaoo.zzl(type), obj));
        if (obj instanceof zzank) {
            this.bea.add(zzaon.zza(zzaoo.zzl(type), (zzank) obj));
        }
        return this;
    }

    public zzamt zza(zzamo... com_google_android_gms_internal_zzamoArr) {
        for (zzamo zza : com_google_android_gms_internal_zzamoArr) {
            this.bek = this.bek.zza(zza, true, true);
        }
        return this;
    }

    public zzamt zzcze() {
        this.ber = false;
        return this;
    }

    public zzams zzczf() {
        List arrayList = new ArrayList();
        arrayList.addAll(this.bea);
        Collections.reverse(arrayList);
        arrayList.addAll(this.beo);
        zza(null, this.bep, this.beq, arrayList);
        return new zzams(this.bek, this.bem, this.ben, false, false, false, this.ber, false, false, this.bel, arrayList);
    }

    public zzamt zzd(int... iArr) {
        this.bek = this.bek.zze(iArr);
        return this;
    }
}
