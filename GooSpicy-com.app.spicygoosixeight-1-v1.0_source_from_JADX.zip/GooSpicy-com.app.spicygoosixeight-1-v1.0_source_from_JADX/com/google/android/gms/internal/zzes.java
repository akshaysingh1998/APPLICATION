package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

@zzir
public final class zzes implements zzet {
    public static void zzd(zzll com_google_android_gms_internal_zzll) {
        com_google_android_gms_internal_zzll.zza("/install", new zzes());
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str = (String) map.get("action");
        if ("is_updated".equals(str)) {
            String zzb = zzdt.zzkq().zzb(com_google_android_gms_internal_zzll.zzuf(), map);
            Map hashMap = new HashMap();
            hashMap.put("status", zzb);
            com_google_android_gms_internal_zzll.zza("installStatus", hashMap);
            return;
        }
        if ("install_apk".equals(str)) {
            zzdt.zzkq().zza(com_google_android_gms_internal_zzll.zzuf(), map);
        }
    }
}
