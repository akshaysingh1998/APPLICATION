package com.google.android.gms.internal;

import com.google.android.gms.internal.zzah.zzf;
import com.google.android.gms.internal.zzah.zzj;
import java.io.IOException;

public interface zzadx {

    public static final class zza extends zzaow<zza> {
        public long aDp;
        public zzj aDq;
        public zzf zzwq;

        public zza() {
            zzcgt();
        }

        public static zza zzap(byte[] bArr) throws zzapb {
            return (zza) zzapc.zza(new zza(), bArr);
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zza)) {
                return false;
            }
            zza com_google_android_gms_internal_zzadx_zza = (zza) obj;
            if (this.aDp != com_google_android_gms_internal_zzadx_zza.aDp) {
                return false;
            }
            if (this.zzwq == null) {
                if (com_google_android_gms_internal_zzadx_zza.zzwq != null) {
                    return false;
                }
            } else if (!this.zzwq.equals(com_google_android_gms_internal_zzadx_zza.zzwq)) {
                return false;
            }
            if (this.aDq == null) {
                if (com_google_android_gms_internal_zzadx_zza.aDq != null) {
                    return false;
                }
            } else if (!this.aDq.equals(com_google_android_gms_internal_zzadx_zza.aDq)) {
                return false;
            }
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    return this.bib.equals(com_google_android_gms_internal_zzadx_zza.bib);
                }
            }
            if (com_google_android_gms_internal_zzadx_zza.bib != null) {
                if (com_google_android_gms_internal_zzadx_zza.bib.isEmpty()) {
                    return true;
                }
                z = false;
            }
            return z;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = 31 * (((((((527 + getClass().getName().hashCode()) * 31) + ((int) (this.aDp ^ (this.aDp >>> 32)))) * 31) + (this.zzwq == null ? 0 : this.zzwq.hashCode())) * 31) + (this.aDq == null ? 0 : this.aDq.hashCode()));
            if (this.bib != null) {
                if (!this.bib.isEmpty()) {
                    i = this.bib.hashCode();
                }
            }
            return hashCode + i;
        }

        public void zza(zzaov com_google_android_gms_internal_zzaov) throws IOException {
            com_google_android_gms_internal_zzaov.zzb(1, this.aDp);
            if (this.zzwq != null) {
                com_google_android_gms_internal_zzaov.zza(2, this.zzwq);
            }
            if (this.aDq != null) {
                com_google_android_gms_internal_zzaov.zza(3, this.aDq);
            }
            super.zza(com_google_android_gms_internal_zzaov);
        }

        public /* synthetic */ zzapc zzb(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            return zzbt(com_google_android_gms_internal_zzaou);
        }

        public zza zzbt(zzaou com_google_android_gms_internal_zzaou) throws IOException {
            while (true) {
                int J = com_google_android_gms_internal_zzaou.m39J();
                if (J == 0) {
                    return this;
                }
                if (J != 8) {
                    zzapc com_google_android_gms_internal_zzapc;
                    if (J == 18) {
                        if (this.zzwq == null) {
                            this.zzwq = new zzf();
                        }
                        com_google_android_gms_internal_zzapc = this.zzwq;
                    } else if (J == 26) {
                        if (this.aDq == null) {
                            this.aDq = new zzj();
                        }
                        com_google_android_gms_internal_zzapc = this.aDq;
                    } else if (!super.zza(com_google_android_gms_internal_zzaou, J)) {
                        return this;
                    }
                    com_google_android_gms_internal_zzaou.zza(com_google_android_gms_internal_zzapc);
                } else {
                    this.aDp = com_google_android_gms_internal_zzaou.m42M();
                }
            }
        }

        public zza zzcgt() {
            this.aDp = 0;
            this.zzwq = null;
            this.aDq = null;
            this.bib = null;
            this.bik = -1;
            return this;
        }

        protected int zzy() {
            int zzy = super.zzy() + zzaov.zze(1, this.aDp);
            if (this.zzwq != null) {
                zzy += zzaov.zzc(2, this.zzwq);
            }
            return this.aDq != null ? zzy + zzaov.zzc(3, this.aDq) : zzy;
        }
    }
}
