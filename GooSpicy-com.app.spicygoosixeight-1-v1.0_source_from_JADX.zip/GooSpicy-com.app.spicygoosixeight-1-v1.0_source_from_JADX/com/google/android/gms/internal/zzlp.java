package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.graphics.Canvas;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzd;
import com.google.android.gms.ads.internal.zzs;
import com.google.android.gms.ads.internal.zzu;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

@zzir
class zzlp extends WebView implements OnGlobalLayoutListener, DownloadListener, zzll {
    private final Object zzail = new Object();
    private final zzd zzajv;
    private final VersionInfoParcel zzalm;
    private AdSizeParcel zzang;
    private zzky zzaqe;
    private final WindowManager zzaqk;
    private final zzas zzbgh;
    private int zzbrj = -1;
    private int zzbrk = -1;
    private int zzbrm = -1;
    private int zzbrn = -1;
    private String zzbvu = "";
    private Boolean zzcka;
    private final zza zzcpf;
    private final zzs zzcpg;
    private zzlm zzcph;
    private com.google.android.gms.ads.internal.overlay.zzd zzcpi;
    private boolean zzcpj;
    private boolean zzcpk;
    private boolean zzcpl;
    private boolean zzcpm;
    private int zzcpn;
    private boolean zzcpo = true;
    boolean zzcpp = false;
    private zzlq zzcpq;
    private boolean zzcpr;
    private zzdi zzcps;
    private zzdi zzcpt;
    private zzdi zzcpu;
    private zzdj zzcpv;
    private WeakReference<OnClickListener> zzcpw;
    private com.google.android.gms.ads.internal.overlay.zzd zzcpx;
    private Map<String, zzfh> zzcpy;

    class C04871 implements Runnable {
        final /* synthetic */ zzlp zzcpz;

        C04871(zzlp com_google_android_gms_internal_zzlp) {
            this.zzcpz = com_google_android_gms_internal_zzlp;
        }

        public void run() {
            super.destroy();
        }
    }

    @zzir
    public static class zza extends MutableContextWrapper {
        private Context zzaqj;
        private Activity zzcmz;
        private Context zzcqa;

        public zza(Context context) {
            super(context);
            setBaseContext(context);
        }

        public Object getSystemService(String str) {
            return this.zzcqa.getSystemService(str);
        }

        public void setBaseContext(Context context) {
            this.zzaqj = context.getApplicationContext();
            this.zzcmz = context instanceof Activity ? (Activity) context : null;
            this.zzcqa = context;
            super.setBaseContext(this.zzaqj);
        }

        public void startActivity(Intent intent) {
            if (this.zzcmz != null) {
                this.zzcmz.startActivity(intent);
                return;
            }
            intent.setFlags(268435456);
            this.zzaqj.startActivity(intent);
        }

        public Activity zzuf() {
            return this.zzcmz;
        }

        public Context zzug() {
            return this.zzcqa;
        }
    }

    protected zzlp(zza com_google_android_gms_internal_zzlp_zza, AdSizeParcel adSizeParcel, boolean z, boolean z2, zzas com_google_android_gms_internal_zzas, VersionInfoParcel versionInfoParcel, zzdk com_google_android_gms_internal_zzdk, zzs com_google_android_gms_ads_internal_zzs, zzd com_google_android_gms_ads_internal_zzd) {
        super(com_google_android_gms_internal_zzlp_zza);
        this.zzcpf = com_google_android_gms_internal_zzlp_zza;
        this.zzang = adSizeParcel;
        this.zzcpl = z;
        this.zzcpn = -1;
        this.zzbgh = com_google_android_gms_internal_zzas;
        this.zzalm = versionInfoParcel;
        this.zzcpg = com_google_android_gms_ads_internal_zzs;
        this.zzajv = com_google_android_gms_ads_internal_zzd;
        this.zzaqk = (WindowManager) getContext().getSystemService("window");
        setBackgroundColor(0);
        WebSettings settings = getSettings();
        settings.setAllowFileAccess(false);
        settings.setJavaScriptEnabled(true);
        settings.setSavePassword(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        if (VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(2);
        }
        zzu.zzfq().zza((Context) com_google_android_gms_internal_zzlp_zza, versionInfoParcel.zzcs, settings);
        zzu.zzfs().zza(getContext(), settings);
        setDownloadListener(this);
        zzvj();
        if (com.google.android.gms.common.util.zzs.zzavo()) {
            addJavascriptInterface(new zzlr(this), "googleAdsJsInterface");
        }
        if (com.google.android.gms.common.util.zzs.zzavj()) {
            removeJavascriptInterface("accessibility");
            removeJavascriptInterface("accessibilityTraversal");
        }
        this.zzaqe = new zzky(this.zzcpf.zzuf(), this, this, null);
        zzd(com_google_android_gms_internal_zzdk);
    }

    private void zzal(boolean z) {
        Map hashMap = new HashMap();
        hashMap.put("isVisible", z ? "1" : "0");
        zza("onAdVisibilityChanged", hashMap);
    }

    static zzlp zzb(Context context, AdSizeParcel adSizeParcel, boolean z, boolean z2, zzas com_google_android_gms_internal_zzas, VersionInfoParcel versionInfoParcel, zzdk com_google_android_gms_internal_zzdk, zzs com_google_android_gms_ads_internal_zzs, zzd com_google_android_gms_ads_internal_zzd) {
        return new zzlp(new zza(context), adSizeParcel, z, z2, com_google_android_gms_internal_zzas, versionInfoParcel, com_google_android_gms_internal_zzdk, com_google_android_gms_ads_internal_zzs, com_google_android_gms_ads_internal_zzd);
    }

    private void zzd(zzdk com_google_android_gms_internal_zzdk) {
        zzvn();
        this.zzcpv = new zzdj(new zzdk(true, "make_wv", this.zzang.zzaup));
        this.zzcpv.zzkf().zzc(com_google_android_gms_internal_zzdk);
        this.zzcpt = zzdg.zzb(this.zzcpv.zzkf());
        this.zzcpv.zza("native:view_create", this.zzcpt);
        this.zzcpu = null;
        this.zzcps = null;
    }

    private void zzvh() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r3.zzail;
        monitor-enter(r0);
        r1 = com.google.android.gms.ads.internal.zzu.zzft();	 Catch:{ all -> 0x002a }
        r1 = r1.zzsr();	 Catch:{ all -> 0x002a }
        r3.zzcka = r1;	 Catch:{ all -> 0x002a }
        r1 = r3.zzcka;	 Catch:{ all -> 0x002a }
        if (r1 != 0) goto L_0x0028;
    L_0x0011:
        r1 = "(function(){})()";	 Catch:{ IllegalStateException -> 0x0020 }
        r2 = 0;	 Catch:{ IllegalStateException -> 0x0020 }
        r3.evaluateJavascript(r1, r2);	 Catch:{ IllegalStateException -> 0x0020 }
        r1 = 1;	 Catch:{ IllegalStateException -> 0x0020 }
        r1 = java.lang.Boolean.valueOf(r1);	 Catch:{ IllegalStateException -> 0x0020 }
        r3.zzb(r1);	 Catch:{ IllegalStateException -> 0x0020 }
        goto L_0x0028;
    L_0x0020:
        r1 = 0;
        r1 = java.lang.Boolean.valueOf(r1);	 Catch:{ all -> 0x002a }
        r3.zzb(r1);	 Catch:{ all -> 0x002a }
    L_0x0028:
        monitor-exit(r0);	 Catch:{ all -> 0x002a }
        return;	 Catch:{ all -> 0x002a }
    L_0x002a:
        r1 = move-exception;	 Catch:{ all -> 0x002a }
        monitor-exit(r0);	 Catch:{ all -> 0x002a }
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzlp.zzvh():void");
    }

    private void zzvi() {
        zzdg.zza(this.zzcpv.zzkf(), this.zzcpt, "aeh2");
    }

    private void zzvj() {
        synchronized (this.zzail) {
            if (!this.zzcpl) {
                if (!this.zzang.zzauq) {
                    if (VERSION.SDK_INT < 18) {
                        zzb.zzcw("Disabling hardware acceleration on an AdView.");
                        zzvk();
                    } else {
                        zzb.zzcw("Enabling hardware acceleration on an AdView.");
                        zzvl();
                    }
                }
            }
            if (VERSION.SDK_INT < 14) {
                zzb.zzcw("Disabling hardware acceleration on an overlay.");
                zzvk();
            } else {
                zzb.zzcw("Enabling hardware acceleration on an overlay.");
                zzvl();
            }
        }
    }

    private void zzvk() {
        synchronized (this.zzail) {
            if (!this.zzcpm) {
                zzu.zzfs().zzp(this);
            }
            this.zzcpm = true;
        }
    }

    private void zzvl() {
        synchronized (this.zzail) {
            if (this.zzcpm) {
                zzu.zzfs().zzo(this);
            }
            this.zzcpm = false;
        }
    }

    private void zzvm() {
        synchronized (this.zzail) {
            this.zzcpy = null;
        }
    }

    private void zzvn() {
        if (this.zzcpv != null) {
            zzdk zzkf = this.zzcpv.zzkf();
            if (!(zzkf == null || zzu.zzft().zzsm() == null)) {
                zzu.zzft().zzsm().zza(zzkf);
            }
        }
    }

    public void destroy() {
        synchronized (this.zzail) {
            zzvn();
            this.zzaqe.zztu();
            if (this.zzcpi != null) {
                this.zzcpi.close();
                this.zzcpi.onDestroy();
                this.zzcpi = null;
            }
            this.zzcph.reset();
            if (this.zzcpk) {
                return;
            }
            zzu.zzgj().zze(this);
            zzvm();
            this.zzcpk = true;
            zzkh.m83v("Initiating WebView self destruct sequence in 3...");
            this.zzcph.zzva();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    @android.annotation.TargetApi(19)
    public void evaluateJavascript(java.lang.String r3, android.webkit.ValueCallback<java.lang.String> r4) {
        /*
        r2 = this;
        r0 = r2.zzail;
        monitor-enter(r0);
        r1 = r2.isDestroyed();	 Catch:{ all -> 0x001b }
        if (r1 == 0) goto L_0x0016;
    L_0x0009:
        r3 = "The webview is destroyed. Ignoring action.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r3);	 Catch:{ all -> 0x001b }
        if (r4 == 0) goto L_0x0014;
    L_0x0010:
        r3 = 0;
        r4.onReceiveValue(r3);	 Catch:{ all -> 0x001b }
    L_0x0014:
        monitor-exit(r0);	 Catch:{ all -> 0x001b }
        return;
    L_0x0016:
        super.evaluateJavascript(r3, r4);	 Catch:{ all -> 0x001b }
        monitor-exit(r0);	 Catch:{ all -> 0x001b }
        return;
    L_0x001b:
        r3 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x001b }
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzlp.evaluateJavascript(java.lang.String, android.webkit.ValueCallback):void");
    }

    protected void finalize() throws Throwable {
        synchronized (this.zzail) {
            if (!this.zzcpk) {
                this.zzcph.reset();
                zzu.zzgj().zze(this);
                zzvm();
            }
        }
        super.finalize();
    }

    public String getRequestId() {
        String str;
        synchronized (this.zzail) {
            str = this.zzbvu;
        }
        return str;
    }

    public int getRequestedOrientation() {
        int i;
        synchronized (this.zzail) {
            i = this.zzcpn;
        }
        return i;
    }

    public View getView() {
        return this;
    }

    public WebView getWebView() {
        return this;
    }

    public boolean isDestroyed() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcpk;
        }
        return z;
    }

    public void loadData(String str, String str2, String str3) {
        synchronized (this.zzail) {
            if (isDestroyed()) {
                zzb.zzcy("The webview is destroyed. Ignoring action.");
            } else {
                super.loadData(str, str2, str3);
            }
        }
    }

    public void loadDataWithBaseURL(String str, String str2, String str3, String str4, String str5) {
        synchronized (this.zzail) {
            if (isDestroyed()) {
                zzb.zzcy("The webview is destroyed. Ignoring action.");
            } else {
                super.loadDataWithBaseURL(str, str2, str3, str4, str5);
            }
        }
    }

    public void loadUrl(String str) {
        synchronized (this.zzail) {
            if (isDestroyed()) {
                str = "The webview is destroyed. Ignoring action.";
                zzb.zzcy(str);
            } else {
                try {
                    super.loadUrl(str);
                } catch (Throwable th) {
                    str = String.valueOf(th);
                    StringBuilder stringBuilder = new StringBuilder(24 + String.valueOf(str).length());
                    stringBuilder.append("Could not call loadUrl. ");
                    stringBuilder.append(str);
                    str = stringBuilder.toString();
                }
            }
        }
    }

    protected void onAttachedToWindow() {
        synchronized (this.zzail) {
            super.onAttachedToWindow();
            if (!isDestroyed()) {
                this.zzaqe.onAttachedToWindow();
            }
            zzal(this.zzcpr);
        }
    }

    protected void onDetachedFromWindow() {
        synchronized (this.zzail) {
            if (!isDestroyed()) {
                this.zzaqe.onDetachedFromWindow();
            }
            super.onDetachedFromWindow();
        }
        zzal(false);
    }

    public void onDownloadStart(java.lang.String r1, java.lang.String r2, java.lang.String r3, java.lang.String r4, long r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = this;
        r2 = new android.content.Intent;	 Catch:{ ActivityNotFoundException -> 0x001a }
        r3 = "android.intent.action.VIEW";	 Catch:{ ActivityNotFoundException -> 0x001a }
        r2.<init>(r3);	 Catch:{ ActivityNotFoundException -> 0x001a }
        r3 = android.net.Uri.parse(r1);	 Catch:{ ActivityNotFoundException -> 0x001a }
        r2.setDataAndType(r3, r4);	 Catch:{ ActivityNotFoundException -> 0x001a }
        r3 = com.google.android.gms.ads.internal.zzu.zzfq();	 Catch:{ ActivityNotFoundException -> 0x001a }
        r5 = r0.getContext();	 Catch:{ ActivityNotFoundException -> 0x001a }
        r3.zzb(r5, r2);	 Catch:{ ActivityNotFoundException -> 0x001a }
        return;
    L_0x001a:
        r2 = new java.lang.StringBuilder;
        r3 = 51;
        r5 = java.lang.String.valueOf(r1);
        r5 = r5.length();
        r3 = r3 + r5;
        r5 = java.lang.String.valueOf(r4);
        r5 = r5.length();
        r3 = r3 + r5;
        r2.<init>(r3);
        r3 = "Couldn't find an Activity to view url/mimetype: ";
        r2.append(r3);
        r2.append(r1);
        r1 = " / ";
        r2.append(r1);
        r2.append(r4);
        r1 = r2.toString();
        com.google.android.gms.ads.internal.util.client.zzb.zzcw(r1);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzlp.onDownloadStart(java.lang.String, java.lang.String, java.lang.String, java.lang.String, long):void");
    }

    @TargetApi(21)
    protected void onDraw(Canvas canvas) {
        if (!isDestroyed()) {
            if (VERSION.SDK_INT != 21 || !canvas.isHardwareAccelerated() || isAttachedToWindow()) {
                super.onDraw(canvas);
            }
        }
    }

    public void onGlobalLayout() {
        boolean zzvg = zzvg();
        com.google.android.gms.ads.internal.overlay.zzd zzui = zzui();
        if (zzui != null && zzvg) {
            zzui.zzob();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void onMeasure(int r8, int r9) {
        /*
        r7 = this;
        r0 = r7.zzail;
        monitor-enter(r0);
        r1 = r7.isDestroyed();	 Catch:{ all -> 0x00f3 }
        r2 = 0;
        if (r1 == 0) goto L_0x000f;
    L_0x000a:
        r7.setMeasuredDimension(r2, r2);	 Catch:{ all -> 0x00f3 }
        monitor-exit(r0);	 Catch:{ all -> 0x00f3 }
        return;
    L_0x000f:
        r1 = r7.isInEditMode();	 Catch:{ all -> 0x00f3 }
        if (r1 != 0) goto L_0x00ee;
    L_0x0015:
        r1 = r7.zzcpl;	 Catch:{ all -> 0x00f3 }
        if (r1 != 0) goto L_0x00ee;
    L_0x0019:
        r1 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r1 = r1.zzaus;	 Catch:{ all -> 0x00f3 }
        if (r1 != 0) goto L_0x00ee;
    L_0x001f:
        r1 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r1 = r1.zzaut;	 Catch:{ all -> 0x00f3 }
        if (r1 == 0) goto L_0x0027;
    L_0x0025:
        goto L_0x00ee;
    L_0x0027:
        r1 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r1 = r1.zzauq;	 Catch:{ all -> 0x00f3 }
        if (r1 == 0) goto L_0x0044;
    L_0x002d:
        r8 = new android.util.DisplayMetrics;	 Catch:{ all -> 0x00f3 }
        r8.<init>();	 Catch:{ all -> 0x00f3 }
        r9 = r7.zzaqk;	 Catch:{ all -> 0x00f3 }
        r9 = r9.getDefaultDisplay();	 Catch:{ all -> 0x00f3 }
        r9.getMetrics(r8);	 Catch:{ all -> 0x00f3 }
        r9 = r8.widthPixels;	 Catch:{ all -> 0x00f3 }
        r8 = r8.heightPixels;	 Catch:{ all -> 0x00f3 }
        r7.setMeasuredDimension(r9, r8);	 Catch:{ all -> 0x00f3 }
        monitor-exit(r0);	 Catch:{ all -> 0x00f3 }
        return;
    L_0x0044:
        r1 = android.view.View.MeasureSpec.getMode(r8);	 Catch:{ all -> 0x00f3 }
        r8 = android.view.View.MeasureSpec.getSize(r8);	 Catch:{ all -> 0x00f3 }
        r3 = android.view.View.MeasureSpec.getMode(r9);	 Catch:{ all -> 0x00f3 }
        r9 = android.view.View.MeasureSpec.getSize(r9);	 Catch:{ all -> 0x00f3 }
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r5 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r6 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        if (r1 == r5) goto L_0x0062;
    L_0x005d:
        if (r1 != r4) goto L_0x0060;
    L_0x005f:
        goto L_0x0062;
    L_0x0060:
        r1 = r6;
        goto L_0x0063;
    L_0x0062:
        r1 = r8;
    L_0x0063:
        if (r3 == r5) goto L_0x0067;
    L_0x0065:
        if (r3 != r4) goto L_0x0068;
    L_0x0067:
        r6 = r9;
    L_0x0068:
        r3 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r3 = r3.widthPixels;	 Catch:{ all -> 0x00f3 }
        r4 = 8;
        if (r3 > r1) goto L_0x008c;
    L_0x0070:
        r1 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r1 = r1.heightPixels;	 Catch:{ all -> 0x00f3 }
        if (r1 <= r6) goto L_0x0077;
    L_0x0076:
        goto L_0x008c;
    L_0x0077:
        r8 = r7.getVisibility();	 Catch:{ all -> 0x00f3 }
        if (r8 == r4) goto L_0x0080;
    L_0x007d:
        r7.setVisibility(r2);	 Catch:{ all -> 0x00f3 }
    L_0x0080:
        r8 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r8 = r8.widthPixels;	 Catch:{ all -> 0x00f3 }
        r9 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r9 = r9.heightPixels;	 Catch:{ all -> 0x00f3 }
        r7.setMeasuredDimension(r8, r9);	 Catch:{ all -> 0x00f3 }
        goto L_0x00ec;
    L_0x008c:
        r1 = r7.zzcpf;	 Catch:{ all -> 0x00f3 }
        r1 = r1.getResources();	 Catch:{ all -> 0x00f3 }
        r1 = r1.getDisplayMetrics();	 Catch:{ all -> 0x00f3 }
        r1 = r1.density;	 Catch:{ all -> 0x00f3 }
        r3 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r3 = r3.widthPixels;	 Catch:{ all -> 0x00f3 }
        r3 = (float) r3;	 Catch:{ all -> 0x00f3 }
        r3 = r3 / r1;
        r3 = (int) r3;	 Catch:{ all -> 0x00f3 }
        r5 = r7.zzang;	 Catch:{ all -> 0x00f3 }
        r5 = r5.heightPixels;	 Catch:{ all -> 0x00f3 }
        r5 = (float) r5;	 Catch:{ all -> 0x00f3 }
        r5 = r5 / r1;
        r5 = (int) r5;	 Catch:{ all -> 0x00f3 }
        r8 = (float) r8;	 Catch:{ all -> 0x00f3 }
        r8 = r8 / r1;
        r8 = (int) r8;	 Catch:{ all -> 0x00f3 }
        r9 = (float) r9;	 Catch:{ all -> 0x00f3 }
        r9 = r9 / r1;
        r9 = (int) r9;	 Catch:{ all -> 0x00f3 }
        r1 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00f3 }
        r6 = 103; // 0x67 float:1.44E-43 double:5.1E-322;
        r1.<init>(r6);	 Catch:{ all -> 0x00f3 }
        r6 = "Not enough space to show ad. Needs ";
        r1.append(r6);	 Catch:{ all -> 0x00f3 }
        r1.append(r3);	 Catch:{ all -> 0x00f3 }
        r3 = "x";
        r1.append(r3);	 Catch:{ all -> 0x00f3 }
        r1.append(r5);	 Catch:{ all -> 0x00f3 }
        r3 = " dp, but only has ";
        r1.append(r3);	 Catch:{ all -> 0x00f3 }
        r1.append(r8);	 Catch:{ all -> 0x00f3 }
        r8 = "x";
        r1.append(r8);	 Catch:{ all -> 0x00f3 }
        r1.append(r9);	 Catch:{ all -> 0x00f3 }
        r8 = " dp.";
        r1.append(r8);	 Catch:{ all -> 0x00f3 }
        r8 = r1.toString();	 Catch:{ all -> 0x00f3 }
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r8);	 Catch:{ all -> 0x00f3 }
        r8 = r7.getVisibility();	 Catch:{ all -> 0x00f3 }
        if (r8 == r4) goto L_0x00e9;
    L_0x00e5:
        r8 = 4;
        r7.setVisibility(r8);	 Catch:{ all -> 0x00f3 }
    L_0x00e9:
        r7.setMeasuredDimension(r2, r2);	 Catch:{ all -> 0x00f3 }
    L_0x00ec:
        monitor-exit(r0);	 Catch:{ all -> 0x00f3 }
        return;
    L_0x00ee:
        super.onMeasure(r8, r9);	 Catch:{ all -> 0x00f3 }
        monitor-exit(r0);	 Catch:{ all -> 0x00f3 }
        return;
    L_0x00f3:
        r8 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x00f3 }
        throw r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzlp.onMeasure(int, int):void");
    }

    public void onPause() {
        if (!isDestroyed()) {
            try {
                if (com.google.android.gms.common.util.zzs.zzavj()) {
                    super.onPause();
                }
            } catch (Throwable e) {
                zzb.zzb("Could not pause webview.", e);
            }
        }
    }

    public void onResume() {
        if (!isDestroyed()) {
            try {
                if (com.google.android.gms.common.util.zzs.zzavj()) {
                    super.onResume();
                }
            } catch (Throwable e) {
                zzb.zzb("Could not resume webview.", e);
            }
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.zzbgh != null) {
            this.zzbgh.zza(motionEvent);
        }
        return isDestroyed() ? false : super.onTouchEvent(motionEvent);
    }

    public void setContext(Context context) {
        this.zzcpf.setBaseContext(context);
        this.zzaqe.zzl(this.zzcpf.zzuf());
    }

    public void setOnClickListener(OnClickListener onClickListener) {
        this.zzcpw = new WeakReference(onClickListener);
        super.setOnClickListener(onClickListener);
    }

    public void setRequestedOrientation(int i) {
        synchronized (this.zzail) {
            this.zzcpn = i;
            if (this.zzcpi != null) {
                this.zzcpi.setRequestedOrientation(this.zzcpn);
            }
        }
    }

    public void setWebViewClient(WebViewClient webViewClient) {
        super.setWebViewClient(webViewClient);
        if (webViewClient instanceof zzlm) {
            this.zzcph = (zzlm) webViewClient;
        }
    }

    public void stopLoading() {
        if (!isDestroyed()) {
            try {
                super.stopLoading();
            } catch (Throwable e) {
                zzb.zzb("Could not stop loading webview.", e);
            }
        }
    }

    public void zza(Context context, AdSizeParcel adSizeParcel, zzdk com_google_android_gms_internal_zzdk) {
        synchronized (this.zzail) {
            this.zzaqe.zztu();
            setContext(context);
            this.zzcpi = null;
            this.zzang = adSizeParcel;
            this.zzcpl = false;
            this.zzcpj = false;
            this.zzbvu = "";
            this.zzcpn = -1;
            zzu.zzfs().zzk(this);
            loadUrl("about:blank");
            this.zzcph.reset();
            setOnTouchListener(null);
            setOnClickListener(null);
            this.zzcpo = true;
            this.zzcpp = false;
            this.zzcpq = null;
            zzd(com_google_android_gms_internal_zzdk);
            this.zzcpr = false;
            zzu.zzgj().zze(this);
            zzvm();
        }
    }

    public void zza(AdSizeParcel adSizeParcel) {
        synchronized (this.zzail) {
            this.zzang = adSizeParcel;
            requestLayout();
        }
    }

    public void zza(zzcd com_google_android_gms_internal_zzcd, boolean z) {
        synchronized (this.zzail) {
            this.zzcpr = z;
        }
        zzal(z);
    }

    public void zza(zzlq com_google_android_gms_internal_zzlq) {
        synchronized (this.zzail) {
            if (this.zzcpq != null) {
                zzb.m9e("Attempt to create multiple AdWebViewVideoControllers.");
                return;
            }
            this.zzcpq = com_google_android_gms_internal_zzlq;
        }
    }

    @TargetApi(19)
    protected void zza(String str, ValueCallback<String> valueCallback) {
        synchronized (this.zzail) {
            if (isDestroyed()) {
                zzb.zzcy("The webview is destroyed. Ignoring action.");
                if (valueCallback != null) {
                    valueCallback.onReceiveValue(null);
                }
            } else {
                evaluateJavascript(str, valueCallback);
            }
        }
    }

    public void zza(String str, zzet com_google_android_gms_internal_zzet) {
        if (this.zzcph != null) {
            this.zzcph.zza(str, com_google_android_gms_internal_zzet);
        }
    }

    public void zza(java.lang.String r2, java.util.Map<java.lang.String, ?> r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = com.google.android.gms.ads.internal.zzu.zzfq();	 Catch:{ JSONException -> 0x000c }
        r3 = r0.zzam(r3);	 Catch:{ JSONException -> 0x000c }
        r1.zzb(r2, r3);
        return;
    L_0x000c:
        r2 = "Could not convert parameters to JSON.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r2);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzlp.zza(java.lang.String, java.util.Map):void");
    }

    public void zza(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        zzj(str, jSONObject.toString());
    }

    public void zzaf(int i) {
        zzvi();
        Map hashMap = new HashMap(2);
        hashMap.put("closetype", String.valueOf(i));
        hashMap.put("version", this.zzalm.zzcs);
        zza("onhide", hashMap);
    }

    public void zzah(boolean z) {
        synchronized (this.zzail) {
            this.zzcpl = z;
            zzvj();
        }
    }

    public void zzai(boolean z) {
        synchronized (this.zzail) {
            if (this.zzcpi != null) {
                this.zzcpi.zza(this.zzcph.zzho(), z);
            } else {
                this.zzcpj = z;
            }
        }
    }

    public void zzaj(boolean z) {
        synchronized (this.zzail) {
            this.zzcpo = z;
        }
    }

    public void zzb(com.google.android.gms.ads.internal.overlay.zzd com_google_android_gms_ads_internal_overlay_zzd) {
        synchronized (this.zzail) {
            this.zzcpi = com_google_android_gms_ads_internal_overlay_zzd;
        }
    }

    void zzb(Boolean bool) {
        synchronized (this.zzail) {
            this.zzcka = bool;
        }
        zzu.zzft().zzb(bool);
    }

    public void zzb(String str, zzet com_google_android_gms_internal_zzet) {
        if (this.zzcph != null) {
            this.zzcph.zzb(str, com_google_android_gms_internal_zzet);
        }
    }

    public void zzb(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("AFMA_ReceiveMessage('");
        stringBuilder.append(str);
        stringBuilder.append("'");
        stringBuilder.append(",");
        stringBuilder.append(jSONObject2);
        stringBuilder.append(");");
        str = "Dispatching AFMA event: ";
        jSONObject2 = String.valueOf(stringBuilder.toString());
        zzkh.m83v(jSONObject2.length() != 0 ? str.concat(jSONObject2) : new String(str));
        zzdd(stringBuilder.toString());
    }

    public void zzc(com.google.android.gms.ads.internal.overlay.zzd com_google_android_gms_ads_internal_overlay_zzd) {
        synchronized (this.zzail) {
            this.zzcpx = com_google_android_gms_ads_internal_overlay_zzd;
        }
    }

    public void zzcz(String str) {
        synchronized (this.zzail) {
            try {
                super.loadUrl(str);
            } catch (Throwable th) {
                str = String.valueOf(th);
                StringBuilder stringBuilder = new StringBuilder(24 + String.valueOf(str).length());
                stringBuilder.append("Could not call loadUrl. ");
                stringBuilder.append(str);
                zzb.zzcy(stringBuilder.toString());
            }
        }
    }

    public void zzda(String str) {
        synchronized (this.zzail) {
            if (str == null) {
                str = "";
            }
            this.zzbvu = str;
        }
    }

    protected void zzdc(String str) {
        synchronized (this.zzail) {
            if (isDestroyed()) {
                zzb.zzcy("The webview is destroyed. Ignoring action.");
            } else {
                loadUrl(str);
            }
        }
    }

    protected void zzdd(String str) {
        String str2;
        if (com.google.android.gms.common.util.zzs.zzavq()) {
            if (zzsr() == null) {
                zzvh();
            }
            if (zzsr().booleanValue()) {
                zza(str, null);
                return;
            }
            str2 = "javascript:";
            str = String.valueOf(str);
            if (str.length() == 0) {
                str = new String(str2);
                zzdc(str);
            }
        } else {
            str2 = "javascript:";
            str = String.valueOf(str);
            if (str.length() == 0) {
                str = new String(str2);
                zzdc(str);
            }
        }
        str = str2.concat(str);
        zzdc(str);
    }

    public AdSizeParcel zzdo() {
        AdSizeParcel adSizeParcel;
        synchronized (this.zzail) {
            adSizeParcel = this.zzang;
        }
        return adSizeParcel;
    }

    public void zzeg() {
        synchronized (this.zzail) {
            this.zzcpp = true;
            if (this.zzcpg != null) {
                this.zzcpg.zzeg();
            }
        }
    }

    public void zzeh() {
        synchronized (this.zzail) {
            this.zzcpp = false;
            if (this.zzcpg != null) {
                this.zzcpg.zzeh();
            }
        }
    }

    public void zzj(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder((3 + String.valueOf(str).length()) + String.valueOf(str2).length());
        stringBuilder.append(str);
        stringBuilder.append("(");
        stringBuilder.append(str2);
        stringBuilder.append(");");
        zzdd(stringBuilder.toString());
    }

    public void zzoc() {
        if (this.zzcps == null) {
            zzdg.zza(this.zzcpv.zzkf(), this.zzcpu, "aes");
            this.zzcps = zzdg.zzb(this.zzcpv.zzkf());
            this.zzcpv.zza("native:view_show", this.zzcps);
        }
        Map hashMap = new HashMap(1);
        hashMap.put("version", this.zzalm.zzcs);
        zza("onshow", hashMap);
    }

    public boolean zzow() {
        boolean z;
        synchronized (this.zzail) {
            zzdg.zza(this.zzcpv.zzkf(), this.zzcpt, "aebb2");
            z = this.zzcpo;
        }
        return z;
    }

    Boolean zzsr() {
        Boolean bool;
        synchronized (this.zzail) {
            bool = this.zzcka;
        }
        return bool;
    }

    public void zzud() {
        zzvi();
        Map hashMap = new HashMap(1);
        hashMap.put("version", this.zzalm.zzcs);
        zza("onhide", hashMap);
    }

    public void zzue() {
        Map hashMap = new HashMap(3);
        hashMap.put("app_muted", String.valueOf(zzu.zzfq().zzfa()));
        hashMap.put("app_volume", String.valueOf(zzu.zzfq().zzey()));
        hashMap.put("device_volume", String.valueOf(zzu.zzfq().zzal(getContext())));
        zza("volume", hashMap);
    }

    public Activity zzuf() {
        return this.zzcpf.zzuf();
    }

    public Context zzug() {
        return this.zzcpf.zzug();
    }

    public zzd zzuh() {
        return this.zzajv;
    }

    public com.google.android.gms.ads.internal.overlay.zzd zzui() {
        com.google.android.gms.ads.internal.overlay.zzd com_google_android_gms_ads_internal_overlay_zzd;
        synchronized (this.zzail) {
            com_google_android_gms_ads_internal_overlay_zzd = this.zzcpi;
        }
        return com_google_android_gms_ads_internal_overlay_zzd;
    }

    public com.google.android.gms.ads.internal.overlay.zzd zzuj() {
        com.google.android.gms.ads.internal.overlay.zzd com_google_android_gms_ads_internal_overlay_zzd;
        synchronized (this.zzail) {
            com_google_android_gms_ads_internal_overlay_zzd = this.zzcpx;
        }
        return com_google_android_gms_ads_internal_overlay_zzd;
    }

    public zzlm zzuk() {
        return this.zzcph;
    }

    public boolean zzul() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcpj;
        }
        return z;
    }

    public zzas zzum() {
        return this.zzbgh;
    }

    public VersionInfoParcel zzun() {
        return this.zzalm;
    }

    public boolean zzuo() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcpl;
        }
        return z;
    }

    public void zzup() {
        synchronized (this.zzail) {
            zzkh.m83v("Destroying WebView!");
            zzkl.zzclg.post(new C04871(this));
        }
    }

    public boolean zzuq() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcpp;
        }
        return z;
    }

    public zzlk zzur() {
        return null;
    }

    public zzdi zzus() {
        return this.zzcpu;
    }

    public zzdj zzut() {
        return this.zzcpv;
    }

    public zzlq zzuu() {
        zzlq com_google_android_gms_internal_zzlq;
        synchronized (this.zzail) {
            com_google_android_gms_internal_zzlq = this.zzcpq;
        }
        return com_google_android_gms_internal_zzlq;
    }

    public void zzuv() {
        this.zzaqe.zztt();
    }

    public void zzuw() {
        if (this.zzcpu == null) {
            this.zzcpu = zzdg.zzb(this.zzcpv.zzkf());
            this.zzcpv.zza("native:view_load", this.zzcpu);
        }
    }

    public OnClickListener zzux() {
        return (OnClickListener) this.zzcpw.get();
    }

    public boolean zzvg() {
        boolean z = false;
        if (!zzuk().zzho()) {
            return false;
        }
        int zzb;
        int i;
        DisplayMetrics zza = zzu.zzfq().zza(this.zzaqk);
        int zzb2 = zzm.zziw().zzb(zza, zza.widthPixels);
        int zzb3 = zzm.zziw().zzb(zza, zza.heightPixels);
        Activity zzuf = zzuf();
        if (zzuf != null) {
            if (zzuf.getWindow() != null) {
                int[] zzh = zzu.zzfq().zzh(zzuf);
                int zzb4 = zzm.zziw().zzb(zza, zzh[0]);
                zzb = zzm.zziw().zzb(zza, zzh[1]);
                i = zzb4;
                if (this.zzbrj != zzb2 && this.zzbrk == zzb3 && this.zzbrm == i && this.zzbrn == zzb) {
                    return false;
                }
                if (!(this.zzbrj == zzb2 && this.zzbrk == zzb3)) {
                    z = true;
                }
                this.zzbrj = zzb2;
                this.zzbrk = zzb3;
                this.zzbrm = i;
                this.zzbrn = zzb;
                new zzhj(this).zza(zzb2, zzb3, i, zzb, zza.density, this.zzaqk.getDefaultDisplay().getRotation());
                return z;
            }
        }
        i = zzb2;
        zzb = zzb3;
        if (this.zzbrj != zzb2) {
        }
        z = true;
        this.zzbrj = zzb2;
        this.zzbrk = zzb3;
        this.zzbrm = i;
        this.zzbrn = zzb;
        new zzhj(this).zza(zzb2, zzb3, i, zzb, zza.density, this.zzaqk.getDefaultDisplay().getRotation());
        return z;
    }
}
