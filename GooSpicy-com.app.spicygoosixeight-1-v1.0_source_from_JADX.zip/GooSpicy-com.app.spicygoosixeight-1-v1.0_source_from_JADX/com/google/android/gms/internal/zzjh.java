package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.reward.client.zza.zza;

@zzir
public class zzjh extends zza {
    private final String zzcgd;
    private final int zzchi;

    public zzjh(String str, int i) {
        this.zzcgd = str;
        this.zzchi = i;
    }

    public int getAmount() {
        return this.zzchi;
    }

    public String getType() {
        return this.zzcgd;
    }
}
