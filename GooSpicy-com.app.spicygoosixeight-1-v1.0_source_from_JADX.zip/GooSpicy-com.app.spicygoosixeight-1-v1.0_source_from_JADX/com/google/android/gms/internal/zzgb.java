package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.location.Location;

@zzir
public final class zzgb implements zzga {
    public zzlc<Location> zza(ApplicationInfo applicationInfo) {
        return new zzla(null);
    }
}
