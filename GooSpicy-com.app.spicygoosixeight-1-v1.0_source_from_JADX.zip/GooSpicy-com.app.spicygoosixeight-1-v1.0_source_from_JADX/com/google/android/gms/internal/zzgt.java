package com.google.android.gms.internal;

import android.location.Location;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import java.util.Date;
import java.util.Set;

@zzir
public final class zzgt implements MediationAdRequest {
    private final int zzaub;
    private final boolean zzaun;
    private final int zzbpl;
    private final Date zzfp;
    private final Set<String> zzfr;
    private final boolean zzfs;
    private final Location zzft;

    public zzgt(@Nullable Date date, int i, @Nullable Set<String> set, @Nullable Location location, boolean z, int i2, boolean z2) {
        this.zzfp = date;
        this.zzaub = i;
        this.zzfr = set;
        this.zzft = location;
        this.zzfs = z;
        this.zzbpl = i2;
        this.zzaun = z2;
    }

    public Date getBirthday() {
        return this.zzfp;
    }

    public int getGender() {
        return this.zzaub;
    }

    public Set<String> getKeywords() {
        return this.zzfr;
    }

    public Location getLocation() {
        return this.zzft;
    }

    public boolean isDesignedForFamilies() {
        return this.zzaun;
    }

    public boolean isTesting() {
        return this.zzfs;
    }

    public int taggedForChildDirectedTreatment() {
        return this.zzbpl;
    }
}
