package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;

@zzir
public final class zzkf {
    private static final Object zzamp = new Object();
    private static String zzckn;

    public static String zza(Context context, String str, String str2) {
        String str3;
        synchronized (zzamp) {
            if (zzckn == null && !TextUtils.isEmpty(str)) {
                zzb(context, str, str2);
            }
            str3 = zzckn;
        }
        return str3;
    }

    private static void zzb(android.content.Context r6, java.lang.String r7, java.lang.String r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = 3;
        r6 = r6.createPackageContext(r8, r0);	 Catch:{ Throwable -> 0x0045 }
        r6 = r6.getClassLoader();	 Catch:{ Throwable -> 0x0045 }
        r8 = "com.google.ads.mediation.MediationAdapter";	 Catch:{ Throwable -> 0x0045 }
        r0 = 0;	 Catch:{ Throwable -> 0x0045 }
        r8 = java.lang.Class.forName(r8, r0, r6);	 Catch:{ Throwable -> 0x0045 }
        r1 = new java.math.BigInteger;
        r2 = 1;
        r3 = new byte[r2];
        r1.<init>(r3);
        r3 = ",";
        r7 = r7.split(r3);
        r3 = r1;
        r1 = r0;
    L_0x0020:
        r4 = r7.length;
        if (r1 >= r4) goto L_0x0036;
    L_0x0023:
        r4 = com.google.android.gms.ads.internal.zzu.zzfq();
        r5 = r7[r1];
        r4 = r4.zza(r6, r8, r5);
        if (r4 == 0) goto L_0x0033;
    L_0x002f:
        r3 = r3.setBit(r1);
    L_0x0033:
        r1 = r1 + 1;
        goto L_0x0020;
    L_0x0036:
        r6 = java.util.Locale.US;
        r7 = "%X";
        r8 = new java.lang.Object[r2];
        r8[r0] = r3;
        r6 = java.lang.String.format(r6, r7, r8);
    L_0x0042:
        zzckn = r6;
        return;
    L_0x0045:
        r6 = "err";
        goto L_0x0042;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzkf.zzb(android.content.Context, java.lang.String, java.lang.String):void");
    }

    public static String zzsz() {
        String str;
        synchronized (zzamp) {
            str = zzckn;
        }
        return str;
    }
}
