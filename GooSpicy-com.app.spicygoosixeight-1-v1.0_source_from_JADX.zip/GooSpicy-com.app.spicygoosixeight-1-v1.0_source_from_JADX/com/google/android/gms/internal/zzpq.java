package com.google.android.gms.internal;

import android.support.v4.util.ArrayMap;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.zza;
import com.google.android.gms.common.api.zzb;
import java.util.Set;

public final class zzpq extends zzpt<zzb> {
    private int sx;
    private boolean sy;

    private void zza(ConnectionResult connectionResult) {
        int i = 0;
        while (true) {
            ArrayMap arrayMap = null;
            if (i < arrayMap.size()) {
                zza((zzpo) arrayMap.keyAt(i), connectionResult);
                i++;
            } else {
                return;
            }
        }
    }

    public void zza(zzpo<?> com_google_android_gms_internal_zzpo_, ConnectionResult connectionResult) {
        ArrayMap arrayMap = null;
        synchronized (arrayMap) {
            arrayMap.put(com_google_android_gms_internal_zzpo_, connectionResult);
            this.sx--;
            if (!connectionResult.isSuccess()) {
                this.sy = true;
            }
            if (this.sx == 0) {
                Status status = this.sy ? new Status(13) : Status.sg;
                zzc(arrayMap.size() == 1 ? new zza(status, arrayMap) : new zzb(status, arrayMap));
            }
        }
    }

    public Set<zzpo<?>> zzaon() {
        ArrayMap arrayMap = null;
        return arrayMap.keySet();
    }

    protected /* synthetic */ Result zzc(Status status) {
        return zzy(status);
    }

    protected zzb zzy(Status status) {
        zzb com_google_android_gms_common_api_zza;
        ArrayMap arrayMap = null;
        synchronized (arrayMap) {
            zza(new ConnectionResult(8));
            com_google_android_gms_common_api_zza = arrayMap.size() == 1 ? new zza(status, arrayMap) : new zzb(status, arrayMap);
        }
        return com_google_android_gms_common_api_zza;
    }
}
