package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Writer;

public final class zzanz {

    private static final class zza extends Writer {
        private final Appendable bfx;
        private final zza bfy;

        static class zza implements CharSequence {
            char[] bfz;

            zza() {
            }

            public char charAt(int i) {
                return this.bfz[i];
            }

            public int length() {
                return this.bfz.length;
            }

            public CharSequence subSequence(int i, int i2) {
                return new String(this.bfz, i, i2 - i);
            }
        }

        private zza(Appendable appendable) {
            this.bfy = new zza();
            this.bfx = appendable;
        }

        public void close() {
        }

        public void flush() {
        }

        public void write(int i) throws IOException {
            this.bfx.append((char) i);
        }

        public void write(char[] cArr, int i, int i2) throws IOException {
            this.bfy.bfz = cArr;
            this.bfx.append(this.bfy, i, i2 + i);
        }
    }

    public static Writer zza(Appendable appendable) {
        return appendable instanceof Writer ? (Writer) appendable : new zza(appendable);
    }

    public static void zzb(zzamy com_google_android_gms_internal_zzamy, zzaor com_google_android_gms_internal_zzaor) throws IOException {
        zzaon.bgW.zza(com_google_android_gms_internal_zzaor, com_google_android_gms_internal_zzamy);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.internal.zzamy zzh(com.google.android.gms.internal.zzaop r2) throws com.google.android.gms.internal.zzanc {
        /*
        r2.mo2301h();	 Catch:{ EOFException -> 0x0024, zzaos -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        r0 = 0;
        r1 = com.google.android.gms.internal.zzaon.bgW;	 Catch:{ EOFException -> 0x000d, zzaos -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        r2 = r1.zzb(r2);	 Catch:{ EOFException -> 0x000d, zzaos -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        r2 = (com.google.android.gms.internal.zzamy) r2;	 Catch:{ EOFException -> 0x000d, zzaos -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        return r2;
    L_0x000d:
        r2 = move-exception;
        goto L_0x0026;
    L_0x000f:
        r2 = move-exception;
        r0 = new com.google.android.gms.internal.zzanh;
        r0.<init>(r2);
        throw r0;
    L_0x0016:
        r2 = move-exception;
        r0 = new com.google.android.gms.internal.zzamz;
        r0.<init>(r2);
        throw r0;
    L_0x001d:
        r2 = move-exception;
        r0 = new com.google.android.gms.internal.zzanh;
        r0.<init>(r2);
        throw r0;
    L_0x0024:
        r2 = move-exception;
        r0 = 1;
    L_0x0026:
        if (r0 == 0) goto L_0x002b;
    L_0x0028:
        r2 = com.google.android.gms.internal.zzana.bes;
        return r2;
    L_0x002b:
        r0 = new com.google.android.gms.internal.zzanh;
        r0.<init>(r2);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzanz.zzh(com.google.android.gms.internal.zzaop):com.google.android.gms.internal.zzamy");
    }
}
