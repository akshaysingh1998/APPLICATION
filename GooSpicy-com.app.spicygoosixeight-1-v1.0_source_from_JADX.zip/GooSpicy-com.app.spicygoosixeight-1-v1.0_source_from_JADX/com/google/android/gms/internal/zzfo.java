package com.google.android.gms.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Parcel;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.internal.zziz.zza;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;

@zzir
public class zzfo {
    private final Map<zzfp, zzfq> zzbks = new HashMap();
    private final LinkedList<zzfp> zzbkt = new LinkedList();
    private zzfl zzbku;

    private static void zza(String str, zzfp com_google_android_gms_internal_zzfp) {
        if (zzb.zzaz(2)) {
            zzkh.m83v(String.format(str, new Object[]{com_google_android_gms_internal_zzfp}));
        }
    }

    private java.lang.String[] zzbf(java.lang.String r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r5 = this;
        r0 = 0;
        r1 = "\u0000";	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r6 = r6.split(r1);	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r1 = r0;	 Catch:{ UnsupportedEncodingException -> 0x001e }
    L_0x0008:
        r2 = r6.length;	 Catch:{ UnsupportedEncodingException -> 0x001e }
        if (r1 >= r2) goto L_0x001d;	 Catch:{ UnsupportedEncodingException -> 0x001e }
    L_0x000b:
        r2 = new java.lang.String;	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r3 = r6[r1];	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r3 = android.util.Base64.decode(r3, r0);	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r4 = "UTF-8";	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r2.<init>(r3, r4);	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r6[r1] = r2;	 Catch:{ UnsupportedEncodingException -> 0x001e }
        r1 = r1 + 1;
        goto L_0x0008;
    L_0x001d:
        return r6;
    L_0x001e:
        r6 = new java.lang.String[r0];
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfo.zzbf(java.lang.String):java.lang.String[]");
    }

    private boolean zzbg(String str) {
        try {
            return Pattern.matches((String) zzdc.zzbaj.get(), str);
        } catch (Throwable e) {
            zzu.zzft().zzb(e, true);
            return false;
        }
    }

    private static void zzc(Bundle bundle, String str) {
        String[] split = str.split("/", 2);
        if (split.length != 0) {
            String str2 = split[0];
            if (split.length == 1) {
                bundle.remove(str2);
                return;
            }
            bundle = bundle.getBundle(str2);
            if (bundle != null) {
                zzc(bundle, split[1]);
            }
        }
    }

    @Nullable
    static Bundle zzi(AdRequestParcel adRequestParcel) {
        Bundle bundle = adRequestParcel.zzatu;
        return bundle == null ? null : bundle.getBundle("com.google.ads.mediation.admob.AdMobAdapter");
    }

    static AdRequestParcel zzj(AdRequestParcel adRequestParcel) {
        Parcel obtain = Parcel.obtain();
        adRequestParcel.writeToParcel(obtain, 0);
        obtain.setDataPosition(0);
        adRequestParcel = (AdRequestParcel) AdRequestParcel.CREATOR.createFromParcel(obtain);
        obtain.recycle();
        Bundle zzi = zzi(adRequestParcel);
        if (zzi == null) {
            zzi = new Bundle();
            adRequestParcel.zzatu.putBundle("com.google.ads.mediation.admob.AdMobAdapter", zzi);
        }
        zzi.putBoolean("_skipMediation", true);
        return adRequestParcel;
    }

    static boolean zzk(AdRequestParcel adRequestParcel) {
        Bundle bundle = adRequestParcel.zzatu;
        boolean z = false;
        if (bundle == null) {
            return false;
        }
        bundle = bundle.getBundle("com.google.ads.mediation.admob.AdMobAdapter");
        if (bundle != null && bundle.containsKey("_skipMediation")) {
            z = true;
        }
        return z;
    }

    private static AdRequestParcel zzl(AdRequestParcel adRequestParcel) {
        Parcel obtain = Parcel.obtain();
        int i = 0;
        adRequestParcel.writeToParcel(obtain, 0);
        obtain.setDataPosition(0);
        adRequestParcel = (AdRequestParcel) AdRequestParcel.CREATOR.createFromParcel(obtain);
        obtain.recycle();
        String[] split = ((String) zzdc.zzbaf.get()).split(",");
        int length = split.length;
        while (i < length) {
            zzc(adRequestParcel.zzatu, split[i]);
            i++;
        }
        return adRequestParcel;
    }

    private java.lang.String zzlr() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = new java.lang.StringBuilder;	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r0.<init>();	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r1 = r4.zzbkt;	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r1 = r1.iterator();	 Catch:{ UnsupportedEncodingException -> 0x003a }
    L_0x000b:
        r2 = r1.hasNext();	 Catch:{ UnsupportedEncodingException -> 0x003a }
        if (r2 == 0) goto L_0x0035;	 Catch:{ UnsupportedEncodingException -> 0x003a }
    L_0x0011:
        r2 = r1.next();	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r2 = (com.google.android.gms.internal.zzfp) r2;	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r2 = r2.toString();	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r3 = "UTF-8";	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r2 = r2.getBytes(r3);	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r3 = 0;	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r2 = android.util.Base64.encodeToString(r2, r3);	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r0.append(r2);	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r2 = r1.hasNext();	 Catch:{ UnsupportedEncodingException -> 0x003a }
        if (r2 == 0) goto L_0x000b;	 Catch:{ UnsupportedEncodingException -> 0x003a }
    L_0x002f:
        r2 = "\u0000";	 Catch:{ UnsupportedEncodingException -> 0x003a }
        r0.append(r2);	 Catch:{ UnsupportedEncodingException -> 0x003a }
        goto L_0x000b;	 Catch:{ UnsupportedEncodingException -> 0x003a }
    L_0x0035:
        r0 = r0.toString();	 Catch:{ UnsupportedEncodingException -> 0x003a }
        return r0;
    L_0x003a:
        r0 = "";
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfo.zzlr():java.lang.String");
    }

    void flush() {
        while (this.zzbkt.size() > 0) {
            zzfp com_google_android_gms_internal_zzfp = (zzfp) this.zzbkt.remove();
            zzfq com_google_android_gms_internal_zzfq = (zzfq) this.zzbks.get(com_google_android_gms_internal_zzfp);
            zza("Flushing interstitial queue for %s.", com_google_android_gms_internal_zzfp);
            while (com_google_android_gms_internal_zzfq.size() > 0) {
                com_google_android_gms_internal_zzfq.zzm(null).zzbkz.zzeu();
            }
            this.zzbks.remove(com_google_android_gms_internal_zzfp);
        }
    }

    void restore() {
        if (this.zzbku != null) {
            zzfp com_google_android_gms_internal_zzfp;
            int i = 0;
            SharedPreferences sharedPreferences = this.zzbku.getApplicationContext().getSharedPreferences("com.google.android.gms.ads.internal.interstitial.InterstitialAdPool", 0);
            flush();
            Map hashMap = new HashMap();
            for (Entry entry : sharedPreferences.getAll().entrySet()) {
                try {
                    if (!((String) entry.getKey()).equals("PoolKeys")) {
                        zzfs com_google_android_gms_internal_zzfs = new zzfs((String) entry.getValue());
                        com_google_android_gms_internal_zzfp = new zzfp(com_google_android_gms_internal_zzfs.zzana, com_google_android_gms_internal_zzfs.zzall, com_google_android_gms_internal_zzfs.zzbkx);
                        if (!this.zzbks.containsKey(com_google_android_gms_internal_zzfp)) {
                            this.zzbks.put(com_google_android_gms_internal_zzfp, new zzfq(com_google_android_gms_internal_zzfs.zzana, com_google_android_gms_internal_zzfs.zzall, com_google_android_gms_internal_zzfs.zzbkx));
                            hashMap.put(com_google_android_gms_internal_zzfp.toString(), com_google_android_gms_internal_zzfp);
                            zza("Restored interstitial queue for %s.", com_google_android_gms_internal_zzfp);
                        }
                    }
                } catch (Throwable e) {
                    zzb.zzd("Malformed preferences value for InterstitialAdPool.", e);
                }
            }
            String[] zzbf = zzbf(sharedPreferences.getString("PoolKeys", ""));
            int length = zzbf.length;
            while (i < length) {
                com_google_android_gms_internal_zzfp = (zzfp) hashMap.get(zzbf[i]);
                if (this.zzbks.containsKey(com_google_android_gms_internal_zzfp)) {
                    this.zzbkt.add(com_google_android_gms_internal_zzfp);
                }
                i++;
            }
        }
    }

    void save() {
        if (this.zzbku != null) {
            Editor edit = this.zzbku.getApplicationContext().getSharedPreferences("com.google.android.gms.ads.internal.interstitial.InterstitialAdPool", 0).edit();
            edit.clear();
            for (Entry entry : this.zzbks.entrySet()) {
                zzfp com_google_android_gms_internal_zzfp = (zzfp) entry.getKey();
                zzfq com_google_android_gms_internal_zzfq = (zzfq) entry.getValue();
                if (com_google_android_gms_internal_zzfq.zzlw()) {
                    edit.putString(com_google_android_gms_internal_zzfp.toString(), new zzfs(com_google_android_gms_internal_zzfq).zzlz());
                    zza("Saved interstitial queue for %s.", com_google_android_gms_internal_zzfp);
                }
            }
            edit.putString("PoolKeys", zzlr());
            edit.apply();
        }
    }

    zza zza(AdRequestParcel adRequestParcel, String str) {
        if (zzbg(str)) {
            return null;
        }
        int i = new zza(this.zzbku.getApplicationContext()).zzro().zzcgt;
        adRequestParcel = zzl(adRequestParcel);
        zzfp com_google_android_gms_internal_zzfp = new zzfp(adRequestParcel, str, i);
        zzfq com_google_android_gms_internal_zzfq = (zzfq) this.zzbks.get(com_google_android_gms_internal_zzfp);
        if (com_google_android_gms_internal_zzfq == null) {
            zza("Interstitial pool created at %s.", com_google_android_gms_internal_zzfp);
            com_google_android_gms_internal_zzfq = new zzfq(adRequestParcel, str, i);
            this.zzbks.put(com_google_android_gms_internal_zzfp, com_google_android_gms_internal_zzfq);
        }
        this.zzbkt.remove(com_google_android_gms_internal_zzfp);
        this.zzbkt.add(com_google_android_gms_internal_zzfp);
        com_google_android_gms_internal_zzfq.zzlv();
        while (this.zzbkt.size() > ((Integer) zzdc.zzbag.get()).intValue()) {
            zzfp com_google_android_gms_internal_zzfp2 = (zzfp) this.zzbkt.remove();
            zzfq com_google_android_gms_internal_zzfq2 = (zzfq) this.zzbks.get(com_google_android_gms_internal_zzfp2);
            zza("Evicting interstitial queue for %s.", com_google_android_gms_internal_zzfp2);
            while (com_google_android_gms_internal_zzfq2.size() > 0) {
                com_google_android_gms_internal_zzfq2.zzm(null).zzbkz.zzeu();
            }
            this.zzbks.remove(com_google_android_gms_internal_zzfp2);
        }
        while (com_google_android_gms_internal_zzfq.size() > 0) {
            zza zzm = com_google_android_gms_internal_zzfq.zzm(adRequestParcel);
            if (!zzm.zzbld || zzu.zzfu().currentTimeMillis() - zzm.zzblc <= 1000 * ((long) ((Integer) zzdc.zzbai.get()).intValue())) {
                String str2 = zzm.zzbla != null ? " (inline) " : " ";
                StringBuilder stringBuilder = new StringBuilder(34 + String.valueOf(str2).length());
                stringBuilder.append("Pooled interstitial");
                stringBuilder.append(str2);
                stringBuilder.append("returned at %s.");
                zza(stringBuilder.toString(), com_google_android_gms_internal_zzfp);
                return zzm;
            }
            zza("Expired interstitial at %s.", com_google_android_gms_internal_zzfp);
        }
        return null;
    }

    void zza(zzfl com_google_android_gms_internal_zzfl) {
        if (this.zzbku == null) {
            this.zzbku = com_google_android_gms_internal_zzfl.zzlp();
            restore();
        }
    }

    void zzb(AdRequestParcel adRequestParcel, String str) {
        if (this.zzbku != null) {
            int i = new zza(this.zzbku.getApplicationContext()).zzro().zzcgt;
            AdRequestParcel zzl = zzl(adRequestParcel);
            zzfp com_google_android_gms_internal_zzfp = new zzfp(zzl, str, i);
            zzfq com_google_android_gms_internal_zzfq = (zzfq) this.zzbks.get(com_google_android_gms_internal_zzfp);
            if (com_google_android_gms_internal_zzfq == null) {
                zza("Interstitial pool created at %s.", com_google_android_gms_internal_zzfp);
                com_google_android_gms_internal_zzfq = new zzfq(zzl, str, i);
                this.zzbks.put(com_google_android_gms_internal_zzfp, com_google_android_gms_internal_zzfq);
            }
            com_google_android_gms_internal_zzfq.zza(this.zzbku, adRequestParcel);
            com_google_android_gms_internal_zzfq.zzlv();
            zza("Inline entry added to the queue at %s.", com_google_android_gms_internal_zzfp);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    void zzlq() {
        /*
        r9 = this;
        r0 = r9.zzbku;
        if (r0 != 0) goto L_0x0005;
    L_0x0004:
        return;
    L_0x0005:
        r0 = r9.zzbks;
        r0 = r0.entrySet();
        r0 = r0.iterator();
    L_0x000f:
        r1 = r0.hasNext();
        if (r1 == 0) goto L_0x0076;
    L_0x0015:
        r1 = r0.next();
        r1 = (java.util.Map.Entry) r1;
        r2 = r1.getKey();
        r2 = (com.google.android.gms.internal.zzfp) r2;
        r1 = r1.getValue();
        r1 = (com.google.android.gms.internal.zzfq) r1;
        r3 = 2;
        r4 = com.google.android.gms.ads.internal.util.client.zzb.zzaz(r3);
        if (r4 == 0) goto L_0x0056;
    L_0x002e:
        r4 = r1.size();
        r5 = r1.zzlt();
        if (r5 >= r4) goto L_0x0056;
    L_0x0038:
        r6 = "Loading %s/%s pooled interstitials for %s.";
        r7 = 3;
        r7 = new java.lang.Object[r7];
        r8 = 0;
        r5 = r4 - r5;
        r5 = java.lang.Integer.valueOf(r5);
        r7[r8] = r5;
        r5 = 1;
        r4 = java.lang.Integer.valueOf(r4);
        r7[r5] = r4;
        r7[r3] = r2;
        r3 = java.lang.String.format(r6, r7);
        com.google.android.gms.internal.zzkh.m83v(r3);
    L_0x0056:
        r1.zzlu();
    L_0x0059:
        r3 = r1.size();
        r4 = com.google.android.gms.internal.zzdc.zzbah;
        r4 = r4.get();
        r4 = (java.lang.Integer) r4;
        r4 = r4.intValue();
        if (r3 >= r4) goto L_0x000f;
    L_0x006b:
        r3 = "Pooling and loading one new interstitial for %s.";
        zza(r3, r2);
        r3 = r9.zzbku;
        r1.zzb(r3);
        goto L_0x0059;
    L_0x0076:
        r9.save();
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzfo.zzlq():void");
    }
}
