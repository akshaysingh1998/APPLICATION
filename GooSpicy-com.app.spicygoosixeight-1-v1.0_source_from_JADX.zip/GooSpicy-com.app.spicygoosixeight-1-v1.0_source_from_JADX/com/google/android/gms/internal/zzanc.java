package com.google.android.gms.internal;

public class zzanc extends RuntimeException {
    public zzanc(String str) {
        super(str);
    }

    public zzanc(String str, Throwable th) {
        super(str, th);
    }

    public zzanc(Throwable th) {
        super(th);
    }
}
