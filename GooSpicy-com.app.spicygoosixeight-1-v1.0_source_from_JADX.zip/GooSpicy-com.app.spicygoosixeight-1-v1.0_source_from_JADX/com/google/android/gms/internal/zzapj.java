package com.google.android.gms.internal;

import android.support.customtabs.CustomTabsClient;

public interface zzapj {
    void zza(CustomTabsClient customTabsClient);

    void zzkm();
}
