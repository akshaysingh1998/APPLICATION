package com.google.android.gms.internal;

import com.google.android.gms.internal.zzle.zzc;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

@zzir
public class zzlf<T> implements zzle<T> {
    private final Object zzail = new Object();
    protected int zzblz = 0;
    protected final BlockingQueue<zza> zzcof = new LinkedBlockingQueue();
    protected T zzcog;

    class zza {
        public final zzc<T> zzcoh;
        public final com.google.android.gms.internal.zzle.zza zzcoi;
        final /* synthetic */ zzlf zzcoj;

        public zza(zzlf com_google_android_gms_internal_zzlf, zzc<T> com_google_android_gms_internal_zzle_zzc_T, com.google.android.gms.internal.zzle.zza com_google_android_gms_internal_zzle_zza) {
            this.zzcoj = com_google_android_gms_internal_zzlf;
            this.zzcoh = com_google_android_gms_internal_zzle_zzc_T;
            this.zzcoi = com_google_android_gms_internal_zzle_zza;
        }
    }

    public int getStatus() {
        return this.zzblz;
    }

    public void reject() {
        synchronized (this.zzail) {
            if (this.zzblz != 0) {
                throw new UnsupportedOperationException();
            }
            this.zzblz = -1;
            for (zza com_google_android_gms_internal_zzlf_zza : this.zzcof) {
                com_google_android_gms_internal_zzlf_zza.zzcoi.run();
            }
            this.zzcof.clear();
        }
    }

    public void zza(zzc<T> com_google_android_gms_internal_zzle_zzc_T, com.google.android.gms.internal.zzle.zza com_google_android_gms_internal_zzle_zza) {
        synchronized (this.zzail) {
            if (this.zzblz == 1) {
                com_google_android_gms_internal_zzle_zzc_T.zzd(this.zzcog);
            } else if (this.zzblz == -1) {
                com_google_android_gms_internal_zzle_zza.run();
            } else if (this.zzblz == 0) {
                this.zzcof.add(new zza(this, com_google_android_gms_internal_zzle_zzc_T, com_google_android_gms_internal_zzle_zza));
            }
        }
    }

    public void zzg(T t) {
        synchronized (this.zzail) {
            if (this.zzblz != 0) {
                throw new UnsupportedOperationException();
            }
            this.zzcog = t;
            this.zzblz = 1;
            for (zza com_google_android_gms_internal_zzlf_zza : this.zzcof) {
                com_google_android_gms_internal_zzlf_zza.zzcoh.zzd(t);
            }
            this.zzcof.clear();
        }
    }
}
