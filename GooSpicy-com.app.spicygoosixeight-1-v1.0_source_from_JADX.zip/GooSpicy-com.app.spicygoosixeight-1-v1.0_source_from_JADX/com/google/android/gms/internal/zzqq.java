package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Map.Entry;
import java.util.WeakHashMap;

@TargetApi(11)
public final class zzqq extends Fragment implements zzqp {
    private static WeakHashMap<Activity, WeakReference<zzqq>> vb = new WeakHashMap();
    private Map<String, zzqo> vc = new ArrayMap();
    private Bundle vd;
    private int zzblz = 0;

    private void zzb(final String str, @NonNull final zzqo com_google_android_gms_internal_zzqo) {
        if (this.zzblz > 0) {
            new Handler(Looper.getMainLooper()).post(new Runnable(this) {
                final /* synthetic */ zzqq vf;

                public void run() {
                    if (this.vf.zzblz >= 1) {
                        com_google_android_gms_internal_zzqo.onCreate(this.vf.vd != null ? this.vf.vd.getBundle(str) : null);
                    }
                    if (this.vf.zzblz >= 2) {
                        com_google_android_gms_internal_zzqo.onStart();
                    }
                    if (this.vf.zzblz >= 3) {
                        com_google_android_gms_internal_zzqo.onStop();
                    }
                }
            });
        }
    }

    public static zzqq zzt(Activity activity) {
        zzqq com_google_android_gms_internal_zzqq;
        WeakReference weakReference = (WeakReference) vb.get(activity);
        if (weakReference != null) {
            com_google_android_gms_internal_zzqq = (zzqq) weakReference.get();
            if (com_google_android_gms_internal_zzqq != null) {
                return com_google_android_gms_internal_zzqq;
            }
        }
        try {
            com_google_android_gms_internal_zzqq = (zzqq) activity.getFragmentManager().findFragmentByTag("LifecycleFragmentImpl");
            if (com_google_android_gms_internal_zzqq == null || com_google_android_gms_internal_zzqq.isRemoving()) {
                com_google_android_gms_internal_zzqq = new zzqq();
                activity.getFragmentManager().beginTransaction().add(com_google_android_gms_internal_zzqq, "LifecycleFragmentImpl").commitAllowingStateLoss();
            }
            vb.put(activity, new WeakReference(com_google_android_gms_internal_zzqq));
            return com_google_android_gms_internal_zzqq;
        } catch (Throwable e) {
            throw new IllegalStateException("Fragment with tag LifecycleFragmentImpl is not a LifecycleFragmentImpl", e);
        }
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        for (zzqo dump : this.vc.values()) {
            dump.dump(str, fileDescriptor, printWriter, strArr);
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        for (zzqo onActivityResult : this.vc.values()) {
            onActivityResult.onActivityResult(i, i2, intent);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.zzblz = 1;
        this.vd = bundle;
        for (Entry entry : this.vc.entrySet()) {
            ((zzqo) entry.getValue()).onCreate(bundle != null ? bundle.getBundle((String) entry.getKey()) : null);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (bundle != null) {
            for (Entry entry : this.vc.entrySet()) {
                Bundle bundle2 = new Bundle();
                ((zzqo) entry.getValue()).onSaveInstanceState(bundle2);
                bundle.putBundle((String) entry.getKey(), bundle2);
            }
        }
    }

    public void onStart() {
        super.onStop();
        this.zzblz = 2;
        for (zzqo onStart : this.vc.values()) {
            onStart.onStart();
        }
    }

    public void onStop() {
        super.onStop();
        this.zzblz = 3;
        for (zzqo onStop : this.vc.values()) {
            onStop.onStop();
        }
    }

    public <T extends zzqo> T zza(String str, Class<T> cls) {
        return (zzqo) cls.cast(this.vc.get(str));
    }

    public void zza(String str, @NonNull zzqo com_google_android_gms_internal_zzqo) {
        if (this.vc.containsKey(str)) {
            StringBuilder stringBuilder = new StringBuilder(59 + String.valueOf(str).length());
            stringBuilder.append("LifecycleCallback with tag ");
            stringBuilder.append(str);
            stringBuilder.append(" already added to this fragment.");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        this.vc.put(str, com_google_android_gms_internal_zzqo);
        zzb(str, com_google_android_gms_internal_zzqo);
    }

    public Activity zzaqp() {
        return getActivity();
    }
}
