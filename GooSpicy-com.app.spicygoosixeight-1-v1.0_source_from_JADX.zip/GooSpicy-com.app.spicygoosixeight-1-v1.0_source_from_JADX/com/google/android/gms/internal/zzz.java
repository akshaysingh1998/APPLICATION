package com.google.android.gms.internal;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolVersion;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicStatusLine;

public class zzz implements zzy {
    private final zza zzce;
    private final SSLSocketFactory zzcf;

    public interface zza {
        String zzh(String str);
    }

    public zzz() {
        this(null);
    }

    public zzz(zza com_google_android_gms_internal_zzz_zza) {
        this(com_google_android_gms_internal_zzz_zza, null);
    }

    public zzz(zza com_google_android_gms_internal_zzz_zza, SSLSocketFactory sSLSocketFactory) {
        this.zzce = com_google_android_gms_internal_zzz_zza;
        this.zzcf = sSLSocketFactory;
    }

    private HttpURLConnection zza(URL url, zzk<?> com_google_android_gms_internal_zzk_) throws IOException {
        HttpURLConnection zza = zza(url);
        int zzs = com_google_android_gms_internal_zzk_.zzs();
        zza.setConnectTimeout(zzs);
        zza.setReadTimeout(zzs);
        zza.setUseCaches(false);
        zza.setDoInput(true);
        if ("https".equals(url.getProtocol()) && this.zzcf != null) {
            ((HttpsURLConnection) zza).setSSLSocketFactory(this.zzcf);
        }
        return zza;
    }

    private static org.apache.http.HttpEntity zza(java.net.HttpURLConnection r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = new org.apache.http.entity.BasicHttpEntity;
        r0.<init>();
        r1 = r3.getInputStream();	 Catch:{ IOException -> 0x000a }
        goto L_0x000e;
    L_0x000a:
        r1 = r3.getErrorStream();
    L_0x000e:
        r0.setContent(r1);
        r1 = r3.getContentLength();
        r1 = (long) r1;
        r0.setContentLength(r1);
        r1 = r3.getContentEncoding();
        r0.setContentEncoding(r1);
        r3 = r3.getContentType();
        r0.setContentType(r3);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzz.zza(java.net.HttpURLConnection):org.apache.http.HttpEntity");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void zza(java.net.HttpURLConnection r2, com.google.android.gms.internal.zzk<?> r3) throws java.io.IOException, com.google.android.gms.internal.zza {
        /*
        r0 = r3.getMethod();
        switch(r0) {
            case -1: goto L_0x0030;
            case 0: goto L_0x002a;
            case 1: goto L_0x0021;
            case 2: goto L_0x001e;
            case 3: goto L_0x001b;
            case 4: goto L_0x0018;
            case 5: goto L_0x0015;
            case 6: goto L_0x0012;
            case 7: goto L_0x000f;
            default: goto L_0x0007;
        };
    L_0x0007:
        r2 = new java.lang.IllegalStateException;
        r3 = "Unknown method type.";
        r2.<init>(r3);
        throw r2;
    L_0x000f:
        r0 = "PATCH";
        goto L_0x0023;
    L_0x0012:
        r3 = "TRACE";
        goto L_0x002c;
    L_0x0015:
        r3 = "OPTIONS";
        goto L_0x002c;
    L_0x0018:
        r3 = "HEAD";
        goto L_0x002c;
    L_0x001b:
        r3 = "DELETE";
        goto L_0x002c;
    L_0x001e:
        r0 = "PUT";
        goto L_0x0023;
    L_0x0021:
        r0 = "POST";
    L_0x0023:
        r2.setRequestMethod(r0);
        zzb(r2, r3);
        return;
    L_0x002a:
        r3 = "GET";
    L_0x002c:
        r2.setRequestMethod(r3);
        return;
    L_0x0030:
        r0 = r3.zzl();
        if (r0 == 0) goto L_0x0057;
    L_0x0036:
        r1 = 1;
        r2.setDoOutput(r1);
        r1 = "POST";
        r2.setRequestMethod(r1);
        r1 = "Content-Type";
        r3 = r3.zzk();
        r2.addRequestProperty(r1, r3);
        r3 = new java.io.DataOutputStream;
        r2 = r2.getOutputStream();
        r3.<init>(r2);
        r3.write(r0);
        r3.close();
    L_0x0057:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzz.zza(java.net.HttpURLConnection, com.google.android.gms.internal.zzk):void");
    }

    private static void zzb(HttpURLConnection httpURLConnection, zzk<?> com_google_android_gms_internal_zzk_) throws IOException, zza {
        byte[] zzp = com_google_android_gms_internal_zzk_.zzp();
        if (zzp != null) {
            httpURLConnection.setDoOutput(true);
            httpURLConnection.addRequestProperty("Content-Type", com_google_android_gms_internal_zzk_.zzo());
            DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
            dataOutputStream.write(zzp);
            dataOutputStream.close();
        }
    }

    protected HttpURLConnection zza(URL url) throws IOException {
        return (HttpURLConnection) url.openConnection();
    }

    public HttpResponse zza(zzk<?> com_google_android_gms_internal_zzk_, Map<String, String> map) throws IOException, zza {
        String zzh;
        String url = com_google_android_gms_internal_zzk_.getUrl();
        HashMap hashMap = new HashMap();
        hashMap.putAll(com_google_android_gms_internal_zzk_.getHeaders());
        hashMap.putAll(map);
        if (this.zzce != null) {
            zzh = this.zzce.zzh(url);
            if (zzh == null) {
                zzh = "URL blocked by rewriter: ";
                url = String.valueOf(url);
                throw new IOException(url.length() != 0 ? zzh.concat(url) : new String(zzh));
            }
        }
        zzh = url;
        HttpURLConnection zza = zza(new URL(zzh), (zzk) com_google_android_gms_internal_zzk_);
        for (String str : hashMap.keySet()) {
            zza.addRequestProperty(str, (String) hashMap.get(str));
        }
        zza(zza, (zzk) com_google_android_gms_internal_zzk_);
        ProtocolVersion protocolVersion = new ProtocolVersion("HTTP", 1, 1);
        if (zza.getResponseCode() == -1) {
            throw new IOException("Could not retrieve response code from HttpUrlConnection.");
        }
        HttpResponse basicHttpResponse = new BasicHttpResponse(new BasicStatusLine(protocolVersion, zza.getResponseCode(), zza.getResponseMessage()));
        basicHttpResponse.setEntity(zza(zza));
        for (Entry entry : zza.getHeaderFields().entrySet()) {
            if (entry.getKey() != null) {
                basicHttpResponse.addHeader(new BasicHeader((String) entry.getKey(), (String) ((List) entry.getValue()).get(0)));
            }
        }
        return basicHttpResponse;
    }
}
