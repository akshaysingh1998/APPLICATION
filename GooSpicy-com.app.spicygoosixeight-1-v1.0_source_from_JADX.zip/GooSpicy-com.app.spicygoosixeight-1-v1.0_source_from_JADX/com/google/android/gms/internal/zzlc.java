package com.google.android.gms.internal;

import java.util.concurrent.Future;

public interface zzlc<A> extends Future<A> {
    void zzb(Runnable runnable);
}
