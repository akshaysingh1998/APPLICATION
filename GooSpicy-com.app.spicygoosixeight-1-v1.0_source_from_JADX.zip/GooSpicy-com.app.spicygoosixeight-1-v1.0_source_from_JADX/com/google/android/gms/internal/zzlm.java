package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.media.TransportMediator;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.zzg;
import com.google.android.gms.ads.internal.overlay.zzp;
import com.google.android.gms.ads.internal.zze;
import com.google.android.gms.ads.internal.zzu;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

@zzir
public class zzlm extends WebViewClient {
    private static final String[] zzcon = new String[]{"UNKNOWN", "HOST_LOOKUP", "UNSUPPORTED_AUTH_SCHEME", "AUTHENTICATION", "PROXY_AUTHENTICATION", "CONNECT", "IO", "TIMEOUT", "REDIRECT_LOOP", "UNSUPPORTED_SCHEME", "FAILED_SSL_HANDSHAKE", "BAD_URL", "FILE", "FILE_NOT_FOUND", "TOO_MANY_REQUESTS"};
    private static final String[] zzcoo = new String[]{"NOT_YET_VALID", "EXPIRED", "ID_MISMATCH", "UNTRUSTED", "DATE_INVALID", "INVALID"};
    private final Object zzail;
    private boolean zzari;
    private com.google.android.gms.ads.internal.client.zza zzati;
    protected zzll zzbgj;
    private zzeo zzbhq;
    private zzex zzbiv;
    private zze zzbix;
    private zzhe zzbiy;
    private zzev zzbja;
    private zzhk zzbqr;
    private zza zzbye;
    private final HashMap<String, List<zzet>> zzcop;
    private zzg zzcoq;
    private zzb zzcor;
    private boolean zzcos;
    private boolean zzcot;
    private zzp zzcou;
    private final zzhi zzcov;
    @Nullable
    protected zzjs zzcow;
    private boolean zzcox;
    private boolean zzcoy;
    private boolean zzcoz;
    private int zzcpa;

    class C04851 implements Runnable {
        final /* synthetic */ zzlm zzcpb;

        C04851(zzlm com_google_android_gms_internal_zzlm) {
            this.zzcpb = com_google_android_gms_internal_zzlm;
        }

        public void run() {
            if (this.zzcpb.zzcow != null) {
                this.zzcpb.zzcow.zzj(this.zzcpb.zzbgj.getView());
            }
        }
    }

    class C04862 implements Runnable {
        final /* synthetic */ zzlm zzcpb;

        C04862(zzlm com_google_android_gms_internal_zzlm) {
            this.zzcpb = com_google_android_gms_internal_zzlm;
        }

        public void run() {
            this.zzcpb.zzbgj.zzuv();
            com.google.android.gms.ads.internal.overlay.zzd zzui = this.zzcpb.zzbgj.zzui();
            if (zzui != null) {
                zzui.zznz();
            }
            if (this.zzcpb.zzcor != null) {
                this.zzcpb.zzcor.zzen();
                this.zzcpb.zzcor = null;
            }
        }
    }

    public interface zza {
        void zza(zzll com_google_android_gms_internal_zzll, boolean z);
    }

    public interface zzb {
        void zzen();
    }

    private static class zzc implements zzg {
        private zzg zzcoq;
        private zzll zzcpc;

        public zzc(zzll com_google_android_gms_internal_zzll, zzg com_google_android_gms_ads_internal_overlay_zzg) {
            this.zzcpc = com_google_android_gms_internal_zzll;
            this.zzcoq = com_google_android_gms_ads_internal_overlay_zzg;
        }

        public void onPause() {
        }

        public void onResume() {
        }

        public void zzdy() {
            this.zzcoq.zzdy();
            this.zzcpc.zzud();
        }

        public void zzdz() {
            this.zzcoq.zzdz();
            this.zzcpc.zzoc();
        }
    }

    private class zzd implements zzet {
        final /* synthetic */ zzlm zzcpb;

        private zzd(zzlm com_google_android_gms_internal_zzlm) {
            this.zzcpb = com_google_android_gms_internal_zzlm;
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            if (map.keySet().contains("start")) {
                this.zzcpb.zzvc();
            } else if (map.keySet().contains("stop")) {
                this.zzcpb.zzvd();
            } else {
                if (map.keySet().contains("cancel")) {
                    this.zzcpb.zzve();
                }
            }
        }
    }

    public zzlm(zzll com_google_android_gms_internal_zzll, boolean z) {
        this(com_google_android_gms_internal_zzll, z, new zzhi(com_google_android_gms_internal_zzll, com_google_android_gms_internal_zzll.zzug(), new zzcu(com_google_android_gms_internal_zzll.getContext())), null);
    }

    zzlm(zzll com_google_android_gms_internal_zzll, boolean z, zzhi com_google_android_gms_internal_zzhi, zzhe com_google_android_gms_internal_zzhe) {
        this.zzcop = new HashMap();
        this.zzail = new Object();
        this.zzcos = false;
        this.zzbgj = com_google_android_gms_internal_zzll;
        this.zzari = z;
        this.zzcov = com_google_android_gms_internal_zzhi;
        this.zzbiy = com_google_android_gms_internal_zzhe;
    }

    private void zza(Context context, String str, String str2, String str3) {
        if (((Boolean) zzdc.zzbat.get()).booleanValue()) {
            Bundle bundle = new Bundle();
            bundle.putString("err", str);
            bundle.putString("code", str2);
            bundle.putString("host", zzdb(str3));
            zzu.zzfq().zza(context, this.zzbgj.zzun().zzcs, "gmob-apps", bundle, true);
        }
    }

    private String zzdb(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        Uri parse = Uri.parse(str);
        return parse.getHost() != null ? parse.getHost() : "";
    }

    private static boolean zzh(Uri uri) {
        String scheme = uri.getScheme();
        if (!"http".equalsIgnoreCase(scheme)) {
            if (!"https".equalsIgnoreCase(scheme)) {
                return false;
            }
        }
        return true;
    }

    private void zzvc() {
        synchronized (this.zzail) {
            this.zzcot = true;
        }
        this.zzcpa++;
        zzvf();
    }

    private void zzvd() {
        this.zzcpa--;
        zzvf();
    }

    private void zzve() {
        this.zzcoz = true;
        zzvf();
    }

    public final void onLoadResource(WebView webView, String str) {
        String str2 = "Loading resource: ";
        String valueOf = String.valueOf(str);
        zzkh.m83v(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        Uri parse = Uri.parse(str);
        if ("gmsg".equalsIgnoreCase(parse.getScheme()) && "mobileads.google.com".equalsIgnoreCase(parse.getHost())) {
            zzi(parse);
        }
    }

    public final void onPageFinished(WebView webView, String str) {
        synchronized (this.zzail) {
            if (this.zzcox) {
                zzkh.m83v("Blank page loaded, 1...");
                this.zzbgj.zzup();
                return;
            }
            this.zzcoy = true;
            zzvf();
        }
    }

    public final void onReceivedError(WebView webView, int i, String str, String str2) {
        String str3;
        if (i < 0) {
            int i2 = (-i) - 1;
            if (i2 < zzcon.length) {
                str3 = zzcon[i2];
                zza(this.zzbgj.getContext(), "http_err", str3, str2);
                super.onReceivedError(webView, i, str, str2);
            }
        }
        str3 = String.valueOf(i);
        zza(this.zzbgj.getContext(), "http_err", str3, str2);
        super.onReceivedError(webView, i, str, str2);
    }

    public final void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, SslError sslError) {
        if (sslError != null) {
            int primaryError = sslError.getPrimaryError();
            String valueOf = (primaryError < 0 || primaryError >= zzcoo.length) ? String.valueOf(primaryError) : zzcoo[primaryError];
            zza(this.zzbgj.getContext(), "ssl_err", valueOf, zzu.zzfs().zza(sslError));
        }
        super.onReceivedSslError(webView, sslErrorHandler, sslError);
    }

    public final void reset() {
        if (this.zzcow != null) {
            this.zzcow.zzry();
            this.zzcow = null;
        }
        synchronized (this.zzail) {
            this.zzcop.clear();
            this.zzati = null;
            this.zzcoq = null;
            this.zzbye = null;
            this.zzbhq = null;
            this.zzcos = false;
            this.zzari = false;
            this.zzcot = false;
            this.zzbja = null;
            this.zzcou = null;
            this.zzcor = null;
            if (this.zzbiy != null) {
                this.zzbiy.zzs(true);
                this.zzbiy = null;
            }
        }
    }

    public boolean shouldOverrideKeyEvent(WebView webView, KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        if (!(keyCode == 79 || keyCode == 222)) {
            switch (keyCode) {
                case 85:
                case 86:
                case 87:
                case 88:
                case 89:
                case 90:
                case 91:
                    break;
                default:
                    switch (keyCode) {
                        case TransportMediator.KEYCODE_MEDIA_PLAY /*126*/:
                        case TransportMediator.KEYCODE_MEDIA_PAUSE /*127*/:
                        case 128:
                        case 129:
                        case TransportMediator.KEYCODE_MEDIA_RECORD /*130*/:
                            break;
                        default:
                            return false;
                    }
            }
        }
        return true;
    }

    public final boolean shouldOverrideUrlLoading(android.webkit.WebView r9, java.lang.String r10) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r8 = this;
        r0 = "AdWebView shouldOverrideUrlLoading: ";
        r1 = java.lang.String.valueOf(r10);
        r2 = r1.length();
        if (r2 == 0) goto L_0x0011;
    L_0x000c:
        r0 = r0.concat(r1);
        goto L_0x0017;
    L_0x0011:
        r1 = new java.lang.String;
        r1.<init>(r0);
        r0 = r1;
    L_0x0017:
        com.google.android.gms.internal.zzkh.m83v(r0);
        r0 = android.net.Uri.parse(r10);
        r1 = "gmsg";
        r2 = r0.getScheme();
        r1 = r1.equalsIgnoreCase(r2);
        if (r1 == 0) goto L_0x003b;
    L_0x002a:
        r1 = "mobileads.google.com";
        r2 = r0.getHost();
        r1 = r1.equalsIgnoreCase(r2);
        if (r1 == 0) goto L_0x003b;
    L_0x0036:
        r8.zzi(r0);
        goto L_0x00f7;
    L_0x003b:
        r1 = r8.zzcos;
        if (r1 == 0) goto L_0x0075;
    L_0x003f:
        r1 = r8.zzbgj;
        r1 = r1.getWebView();
        if (r9 != r1) goto L_0x0075;
    L_0x0047:
        r1 = zzh(r0);
        if (r1 == 0) goto L_0x0075;
    L_0x004d:
        r0 = r8.zzati;
        if (r0 == 0) goto L_0x0070;
    L_0x0051:
        r0 = com.google.android.gms.internal.zzdc.zzazs;
        r0 = r0.get();
        r0 = (java.lang.Boolean) r0;
        r0 = r0.booleanValue();
        if (r0 == 0) goto L_0x0070;
    L_0x005f:
        r0 = r8.zzati;
        r0.onAdClicked();
        r0 = r8.zzcow;
        if (r0 == 0) goto L_0x006d;
    L_0x0068:
        r0 = r8.zzcow;
        r0.zzcj(r10);
    L_0x006d:
        r0 = 0;
        r8.zzati = r0;
    L_0x0070:
        r9 = super.shouldOverrideUrlLoading(r9, r10);
        return r9;
    L_0x0075:
        r9 = r8.zzbgj;
        r9 = r9.getWebView();
        r9 = r9.willNotDraw();
        if (r9 != 0) goto L_0x00dd;
    L_0x0081:
        r9 = r8.zzbgj;	 Catch:{ zzat -> 0x009b }
        r9 = r9.zzum();	 Catch:{ zzat -> 0x009b }
        if (r9 == 0) goto L_0x00b5;	 Catch:{ zzat -> 0x009b }
    L_0x0089:
        r1 = r9.zzc(r0);	 Catch:{ zzat -> 0x009b }
        if (r1 == 0) goto L_0x00b5;	 Catch:{ zzat -> 0x009b }
    L_0x008f:
        r1 = r8.zzbgj;	 Catch:{ zzat -> 0x009b }
        r1 = r1.getContext();	 Catch:{ zzat -> 0x009b }
        r9 = r9.zzb(r0, r1);	 Catch:{ zzat -> 0x009b }
        r0 = r9;
        goto L_0x00b5;
    L_0x009b:
        r9 = "Unable to append parameter to URL: ";
        r1 = java.lang.String.valueOf(r10);
        r2 = r1.length();
        if (r2 == 0) goto L_0x00ac;
    L_0x00a7:
        r9 = r9.concat(r1);
        goto L_0x00b2;
    L_0x00ac:
        r1 = new java.lang.String;
        r1.<init>(r9);
        r9 = r1;
    L_0x00b2:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r9);
    L_0x00b5:
        r9 = r8.zzbix;
        if (r9 == 0) goto L_0x00c8;
    L_0x00b9:
        r9 = r8.zzbix;
        r9 = r9.zzem();
        if (r9 == 0) goto L_0x00c2;
    L_0x00c1:
        goto L_0x00c8;
    L_0x00c2:
        r9 = r8.zzbix;
        r9.zzt(r10);
        goto L_0x00f7;
    L_0x00c8:
        r9 = new com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
        r1 = "android.intent.action.VIEW";
        r2 = r0.toString();
        r3 = 0;
        r4 = 0;
        r5 = 0;
        r6 = 0;
        r7 = 0;
        r0 = r9;
        r0.<init>(r1, r2, r3, r4, r5, r6, r7);
        r8.zza(r9);
        goto L_0x00f7;
    L_0x00dd:
        r9 = "AdWebView unable to handle URL: ";
        r10 = java.lang.String.valueOf(r10);
        r0 = r10.length();
        if (r0 == 0) goto L_0x00ee;
    L_0x00e9:
        r9 = r9.concat(r10);
        goto L_0x00f4;
    L_0x00ee:
        r10 = new java.lang.String;
        r10.<init>(r9);
        r9 = r10;
    L_0x00f4:
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r9);
    L_0x00f7:
        r9 = 1;
        return r9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzlm.shouldOverrideUrlLoading(android.webkit.WebView, java.lang.String):boolean");
    }

    public void zza(int i, int i2, boolean z) {
        this.zzcov.zze(i, i2);
        if (this.zzbiy != null) {
            this.zzbiy.zza(i, i2, z);
        }
    }

    public void zza(com.google.android.gms.ads.internal.client.zza com_google_android_gms_ads_internal_client_zza, zzg com_google_android_gms_ads_internal_overlay_zzg, zzeo com_google_android_gms_internal_zzeo, zzp com_google_android_gms_ads_internal_overlay_zzp, boolean z, zzev com_google_android_gms_internal_zzev, @Nullable zzex com_google_android_gms_internal_zzex, zze com_google_android_gms_ads_internal_zze, zzhk com_google_android_gms_internal_zzhk, zzjs com_google_android_gms_internal_zzjs) {
        if (com_google_android_gms_ads_internal_zze == null) {
            com_google_android_gms_ads_internal_zze = new zze(this.zzbgj.getContext());
        }
        this.zzbiy = new zzhe(this.zzbgj, com_google_android_gms_internal_zzhk);
        this.zzcow = com_google_android_gms_internal_zzjs;
        zza("/appEvent", new zzen(com_google_android_gms_internal_zzeo));
        zza("/backButton", zzer.zzbib);
        zza("/refresh", zzer.zzbic);
        zza("/canOpenURLs", zzer.zzbhs);
        zza("/canOpenIntents", zzer.zzbht);
        zza("/click", zzer.zzbhu);
        zza("/close", zzer.zzbhv);
        zza("/customClose", zzer.zzbhx);
        zza("/instrument", zzer.zzbig);
        zza("/delayPageLoaded", new zzd());
        zza("/httpTrack", zzer.zzbhy);
        zza("/log", zzer.zzbhz);
        zza("/mraid", new zzez(com_google_android_gms_ads_internal_zze, this.zzbiy));
        zza("/mraidLoaded", this.zzcov);
        zza("/open", new zzfa(com_google_android_gms_internal_zzev, com_google_android_gms_ads_internal_zze, this.zzbiy));
        zza("/precache", zzer.zzbif);
        zza("/touch", zzer.zzbia);
        zza("/video", zzer.zzbid);
        zza("/videoMeta", zzer.zzbie);
        zza("/appStreaming", zzer.zzbhw);
        if (com_google_android_gms_internal_zzex != null) {
            zza("/setInterstitialProperties", new zzew(com_google_android_gms_internal_zzex));
        }
        this.zzati = com_google_android_gms_ads_internal_client_zza;
        this.zzcoq = com_google_android_gms_ads_internal_overlay_zzg;
        this.zzbhq = com_google_android_gms_internal_zzeo;
        this.zzbja = com_google_android_gms_internal_zzev;
        this.zzcou = com_google_android_gms_ads_internal_overlay_zzp;
        this.zzbix = com_google_android_gms_ads_internal_zze;
        this.zzbqr = com_google_android_gms_internal_zzhk;
        this.zzbiv = com_google_android_gms_internal_zzex;
        zzak(z);
    }

    public final void zza(AdLauncherIntentInfoParcel adLauncherIntentInfoParcel) {
        boolean zzuo = this.zzbgj.zzuo();
        com.google.android.gms.ads.internal.client.zza com_google_android_gms_ads_internal_client_zza = (!zzuo || this.zzbgj.zzdo().zzauq) ? this.zzati : null;
        zza(new AdOverlayInfoParcel(adLauncherIntentInfoParcel, com_google_android_gms_ads_internal_client_zza, zzuo ? null : this.zzcoq, this.zzcou, this.zzbgj.zzun()));
    }

    public void zza(AdOverlayInfoParcel adOverlayInfoParcel) {
        boolean z = false;
        boolean zzmy = this.zzbiy != null ? this.zzbiy.zzmy() : false;
        com.google.android.gms.ads.internal.overlay.zze zzfo = zzu.zzfo();
        Context context = this.zzbgj.getContext();
        if (!zzmy) {
            z = true;
        }
        zzfo.zza(context, adOverlayInfoParcel, z);
        if (this.zzcow != null) {
            String str = adOverlayInfoParcel.url;
            if (str == null && adOverlayInfoParcel.zzbtn != null) {
                str = adOverlayInfoParcel.zzbtn.url;
            }
            this.zzcow.zzcj(str);
        }
    }

    public void zza(zza com_google_android_gms_internal_zzlm_zza) {
        this.zzbye = com_google_android_gms_internal_zzlm_zza;
    }

    public void zza(zzb com_google_android_gms_internal_zzlm_zzb) {
        this.zzcor = com_google_android_gms_internal_zzlm_zzb;
    }

    public void zza(String str, zzet com_google_android_gms_internal_zzet) {
        synchronized (this.zzail) {
            List list = (List) this.zzcop.get(str);
            if (list == null) {
                list = new CopyOnWriteArrayList();
                this.zzcop.put(str, list);
            }
            list.add(com_google_android_gms_internal_zzet);
        }
    }

    public final void zza(boolean z, int i) {
        com.google.android.gms.ads.internal.client.zza com_google_android_gms_ads_internal_client_zza = (!this.zzbgj.zzuo() || this.zzbgj.zzdo().zzauq) ? this.zzati : null;
        zza(new AdOverlayInfoParcel(com_google_android_gms_ads_internal_client_zza, this.zzcoq, this.zzcou, this.zzbgj, z, i, this.zzbgj.zzun()));
    }

    public final void zza(boolean z, int i, String str) {
        boolean zzuo = this.zzbgj.zzuo();
        com.google.android.gms.ads.internal.client.zza com_google_android_gms_ads_internal_client_zza = (!zzuo || r0.zzbgj.zzdo().zzauq) ? r0.zzati : null;
        zza(new AdOverlayInfoParcel(com_google_android_gms_ads_internal_client_zza, zzuo ? null : new zzc(r0.zzbgj, r0.zzcoq), r0.zzbhq, r0.zzcou, r0.zzbgj, z, i, str, r0.zzbgj.zzun(), r0.zzbja));
    }

    public final void zza(boolean z, int i, String str, String str2) {
        boolean zzuo = this.zzbgj.zzuo();
        com.google.android.gms.ads.internal.client.zza com_google_android_gms_ads_internal_client_zza = (!zzuo || r0.zzbgj.zzdo().zzauq) ? r0.zzati : null;
        zza(new AdOverlayInfoParcel(com_google_android_gms_ads_internal_client_zza, zzuo ? null : new zzc(r0.zzbgj, r0.zzcoq), r0.zzbhq, r0.zzcou, r0.zzbgj, z, i, str, str2, r0.zzbgj.zzun(), r0.zzbja));
    }

    public void zzak(boolean z) {
        this.zzcos = z;
    }

    public void zzb(String str, zzet com_google_android_gms_internal_zzet) {
        synchronized (this.zzail) {
            List list = (List) this.zzcop.get(str);
            if (list == null) {
                return;
            }
            list.remove(com_google_android_gms_internal_zzet);
        }
    }

    public void zzd(int i, int i2) {
        if (this.zzbiy != null) {
            this.zzbiy.zzd(i, i2);
        }
    }

    public boolean zzho() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzari;
        }
        return z;
    }

    public void zzi(Uri uri) {
        String path = uri.getPath();
        List<zzet> list = (List) this.zzcop.get(path);
        if (list != null) {
            Map zzf = zzu.zzfq().zzf(uri);
            if (com.google.android.gms.ads.internal.util.client.zzb.zzaz(2)) {
                String str = "Received GMSG: ";
                path = String.valueOf(path);
                zzkh.m83v(path.length() != 0 ? str.concat(path) : new String(str));
                for (String str2 : zzf.keySet()) {
                    String str3 = (String) zzf.get(str2);
                    StringBuilder stringBuilder = new StringBuilder((4 + String.valueOf(str2).length()) + String.valueOf(str3).length());
                    stringBuilder.append("  ");
                    stringBuilder.append(str2);
                    stringBuilder.append(": ");
                    stringBuilder.append(str3);
                    zzkh.m83v(stringBuilder.toString());
                }
            }
            for (zzet zza : list) {
                zza.zza(this.zzbgj, zzf);
            }
            return;
        }
        String valueOf = String.valueOf(uri);
        StringBuilder stringBuilder2 = new StringBuilder(32 + String.valueOf(valueOf).length());
        stringBuilder2.append("No GMSG handler found for GMSG: ");
        stringBuilder2.append(valueOf);
        zzkh.m83v(stringBuilder2.toString());
    }

    public void zzm(zzll com_google_android_gms_internal_zzll) {
        this.zzbgj = com_google_android_gms_internal_zzll;
    }

    public final void zznz() {
        synchronized (this.zzail) {
            this.zzcos = false;
            this.zzari = true;
            zzu.zzfq().runOnUiThread(new C04862(this));
        }
    }

    public zze zzuy() {
        return this.zzbix;
    }

    public boolean zzuz() {
        boolean z;
        synchronized (this.zzail) {
            z = this.zzcot;
        }
        return z;
    }

    public void zzva() {
        synchronized (this.zzail) {
            zzkh.m83v("Loading blank page in WebView, 2...");
            this.zzcox = true;
            this.zzbgj.zzcz("about:blank");
        }
    }

    public void zzvb() {
        if (this.zzcow != null) {
            zzkl.zzclg.post(new C04851(this));
        }
    }

    public final void zzvf() {
        if (this.zzbye != null && ((this.zzcoy && this.zzcpa <= 0) || this.zzcoz)) {
            this.zzbye.zza(this.zzbgj, this.zzcoz ^ 1);
            this.zzbye = null;
        }
        this.zzbgj.zzuw();
    }
}
