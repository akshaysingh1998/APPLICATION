package com.google.android.gms.internal;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.overlay.zzd;
import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

@zzir
public final class zzer {
    public static final zzet zzbhr = new C08881();
    public static final zzet zzbhs = new C08925();
    public static final zzet zzbht = new C08936();
    public static final zzet zzbhu = new C08947();
    public static final zzet zzbhv = new C08958();
    public static final zzet zzbhw = new C08969();
    public static final zzet zzbhx = new zzet() {
        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            com_google_android_gms_internal_zzll.zzai("1".equals(map.get("custom_close")));
        }
    };
    public static final zzet zzbhy = new zzet() {
        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            String str = (String) map.get("u");
            if (str == null) {
                zzb.zzcy("URL missing from httpTrack GMSG.");
            } else {
                Future future = (Future) new zzku(com_google_android_gms_internal_zzll.getContext(), com_google_android_gms_internal_zzll.zzun().zzcs, str).zzpz();
            }
        }
    };
    public static final zzet zzbhz = new zzet() {
        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            String str = "Received log message: ";
            String valueOf = String.valueOf((String) map.get("string"));
            zzb.zzcx(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
    };
    public static final zzet zzbia = new C08892();
    public static final zzet zzbib = new C08903();
    public static final zzet zzbic = new C08914();
    public static final zzet zzbid = new zzfd();
    public static final zzet zzbie = new zzfe();
    public static final zzet zzbif = new zzfi();
    public static final zzet zzbig = new zzeq();
    public static final zzfb zzbih = new zzfb();

    class C08881 implements zzet {
        C08881() {
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        }
    }

    class C08892 implements zzet {
        C08892() {
        }

        public void zza(com.google.android.gms.internal.zzll r4, java.util.Map<java.lang.String, java.lang.String> r5) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            r0 = "tx";
            r0 = r5.get(r0);
            r0 = (java.lang.String) r0;
            r1 = "ty";
            r1 = r5.get(r1);
            r1 = (java.lang.String) r1;
            r2 = "td";
            r5 = r5.get(r2);
            r5 = (java.lang.String) r5;
            r0 = java.lang.Integer.parseInt(r0);	 Catch:{ NumberFormatException -> 0x0032 }
            r1 = java.lang.Integer.parseInt(r1);	 Catch:{ NumberFormatException -> 0x0032 }
            r5 = java.lang.Integer.parseInt(r5);	 Catch:{ NumberFormatException -> 0x0032 }
            r4 = r4.zzum();	 Catch:{ NumberFormatException -> 0x0032 }
            if (r4 == 0) goto L_0x0037;	 Catch:{ NumberFormatException -> 0x0032 }
        L_0x002a:
            r4 = r4.zzax();	 Catch:{ NumberFormatException -> 0x0032 }
            r4.zza(r0, r1, r5);	 Catch:{ NumberFormatException -> 0x0032 }
            return;
        L_0x0032:
            r4 = "Could not parse touch parameters from gmsg.";
            com.google.android.gms.ads.internal.util.client.zzb.zzcy(r4);
        L_0x0037:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzer.2.zza(com.google.android.gms.internal.zzll, java.util.Map):void");
        }
    }

    class C08903 implements zzet {
        C08903() {
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            if (((Boolean) zzdc.zzbay.get()).booleanValue()) {
                com_google_android_gms_internal_zzll.zzaj(Boolean.parseBoolean((String) map.get("disabled")) ^ 1);
            }
        }
    }

    class C08914 implements zzet {
        C08914() {
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            String str = (String) map.get("action");
            if ("pause".equals(str)) {
                com_google_android_gms_internal_zzll.zzeg();
                return;
            }
            if ("resume".equals(str)) {
                com_google_android_gms_internal_zzll.zzeh();
            }
        }
    }

    class C08925 implements zzet {
        C08925() {
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            String str = (String) map.get("urls");
            if (TextUtils.isEmpty(str)) {
                zzb.zzcy("URLs missing in canOpenURLs GMSG.");
                return;
            }
            String[] split = str.split(",");
            Map hashMap = new HashMap();
            PackageManager packageManager = com_google_android_gms_internal_zzll.getContext().getPackageManager();
            for (String str2 : split) {
                String[] split2 = str2.split(";", 2);
                boolean z = true;
                if (packageManager.resolveActivity(new Intent(split2.length > 1 ? split2[1].trim() : "android.intent.action.VIEW", Uri.parse(split2[0].trim())), 65536) == null) {
                    z = false;
                }
                hashMap.put(str2, Boolean.valueOf(z));
            }
            com_google_android_gms_internal_zzll.zza("openableURLs", hashMap);
        }
    }

    class C08936 implements zzet {
        C08936() {
        }

        public void zza(com.google.android.gms.internal.zzll r13, java.util.Map<java.lang.String, java.lang.String> r14) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r12 = this;
            r0 = r13.getContext();
            r0 = r0.getPackageManager();
            r1 = "data";
            r14 = r14.get(r1);
            r14 = (java.lang.String) r14;
            r1 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x00d1 }
            r1.<init>(r14);	 Catch:{ JSONException -> 0x00d1 }
            r14 = "intents";	 Catch:{ JSONException -> 0x00c6 }
            r14 = r1.getJSONArray(r14);	 Catch:{ JSONException -> 0x00c6 }
            r1 = new org.json.JSONObject;
            r1.<init>();
            r2 = 0;
            r3 = r2;
        L_0x0022:
            r4 = r14.length();
            if (r3 >= r4) goto L_0x00c0;
        L_0x0028:
            r4 = r14.getJSONObject(r3);	 Catch:{ JSONException -> 0x00b6 }
            r5 = "id";
            r5 = r4.optString(r5);
            r6 = "u";
            r6 = r4.optString(r6);
            r7 = "i";
            r7 = r4.optString(r7);
            r8 = "m";
            r8 = r4.optString(r8);
            r9 = "p";
            r9 = r4.optString(r9);
            r10 = "c";
            r10 = r4.optString(r10);
            r11 = "f";
            r4.optString(r11);
            r11 = "e";
            r4.optString(r11);
            r4 = new android.content.Intent;
            r4.<init>();
            r11 = android.text.TextUtils.isEmpty(r6);
            if (r11 != 0) goto L_0x006c;
        L_0x0065:
            r6 = android.net.Uri.parse(r6);
            r4.setData(r6);
        L_0x006c:
            r6 = android.text.TextUtils.isEmpty(r7);
            if (r6 != 0) goto L_0x0075;
        L_0x0072:
            r4.setAction(r7);
        L_0x0075:
            r6 = android.text.TextUtils.isEmpty(r8);
            if (r6 != 0) goto L_0x007e;
        L_0x007b:
            r4.setType(r8);
        L_0x007e:
            r6 = android.text.TextUtils.isEmpty(r9);
            if (r6 != 0) goto L_0x0087;
        L_0x0084:
            r4.setPackage(r9);
        L_0x0087:
            r6 = android.text.TextUtils.isEmpty(r10);
            r7 = 1;
            if (r6 != 0) goto L_0x00a4;
        L_0x008e:
            r6 = "/";
            r8 = 2;
            r6 = r10.split(r6, r8);
            r9 = r6.length;
            if (r9 != r8) goto L_0x00a4;
        L_0x0098:
            r8 = new android.content.ComponentName;
            r9 = r6[r2];
            r6 = r6[r7];
            r8.<init>(r9, r6);
            r4.setComponent(r8);
        L_0x00a4:
            r6 = 65536; // 0x10000 float:9.18355E-41 double:3.2379E-319;
            r4 = r0.resolveActivity(r4, r6);
            if (r4 == 0) goto L_0x00ad;
        L_0x00ac:
            goto L_0x00ae;
        L_0x00ad:
            r7 = r2;
        L_0x00ae:
            r1.put(r5, r7);	 Catch:{ JSONException -> 0x00b2 }
            goto L_0x00bc;
        L_0x00b2:
            r4 = move-exception;
            r5 = "Error constructing openable urls response.";
            goto L_0x00b9;
        L_0x00b6:
            r4 = move-exception;
            r5 = "Error parsing the intent data.";
        L_0x00b9:
            com.google.android.gms.ads.internal.util.client.zzb.zzb(r5, r4);
        L_0x00bc:
            r3 = r3 + 1;
            goto L_0x0022;
        L_0x00c0:
            r14 = "openableIntents";
            r13.zzb(r14, r1);
            return;
        L_0x00c6:
            r14 = "openableIntents";
            r0 = new org.json.JSONObject;
            r0.<init>();
            r13.zzb(r14, r0);
            return;
        L_0x00d1:
            r14 = "openableIntents";
            r0 = new org.json.JSONObject;
            r0.<init>();
            r13.zzb(r14, r0);
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzer.6.zza(com.google.android.gms.internal.zzll, java.util.Map):void");
        }
    }

    class C08947 implements zzet {
        C08947() {
        }

        public void zza(com.google.android.gms.internal.zzll r4, java.util.Map<java.lang.String, java.lang.String> r5) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r3 = this;
            r0 = "u";
            r5 = r5.get(r0);
            r5 = (java.lang.String) r5;
            if (r5 != 0) goto L_0x0010;
        L_0x000a:
            r4 = "URL missing from click GMSG.";
            com.google.android.gms.ads.internal.util.client.zzb.zzcy(r4);
            return;
        L_0x0010:
            r0 = android.net.Uri.parse(r5);
            r1 = r4.zzum();	 Catch:{ zzat -> 0x002a }
            if (r1 == 0) goto L_0x0043;	 Catch:{ zzat -> 0x002a }
        L_0x001a:
            r2 = r1.zzc(r0);	 Catch:{ zzat -> 0x002a }
            if (r2 == 0) goto L_0x0043;	 Catch:{ zzat -> 0x002a }
        L_0x0020:
            r2 = r4.getContext();	 Catch:{ zzat -> 0x002a }
            r1 = r1.zzb(r0, r2);	 Catch:{ zzat -> 0x002a }
            r0 = r1;
            goto L_0x0043;
        L_0x002a:
            r1 = "Unable to append parameter to URL: ";
            r5 = java.lang.String.valueOf(r5);
            r2 = r5.length();
            if (r2 == 0) goto L_0x003b;
        L_0x0036:
            r5 = r1.concat(r5);
            goto L_0x0040;
        L_0x003b:
            r5 = new java.lang.String;
            r5.<init>(r1);
        L_0x0040:
            com.google.android.gms.ads.internal.util.client.zzb.zzcy(r5);
        L_0x0043:
            r5 = r0.toString();
            r0 = new com.google.android.gms.internal.zzku;
            r1 = r4.getContext();
            r4 = r4.zzun();
            r4 = r4.zzcs;
            r0.<init>(r1, r4, r5);
            r4 = r0.zzpz();
            r4 = (java.util.concurrent.Future) r4;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzer.7.zza(com.google.android.gms.internal.zzll, java.util.Map):void");
        }
    }

    class C08958 implements zzet {
        C08958() {
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            zzd zzui = com_google_android_gms_internal_zzll.zzui();
            if (zzui != null) {
                zzui.close();
                return;
            }
            zzd zzuj = com_google_android_gms_internal_zzll.zzuj();
            if (zzuj != null) {
                zzuj.close();
            } else {
                zzb.zzcy("A GMSG tried to close something that wasn't an overlay.");
            }
        }
    }

    class C08969 implements zzet {
        C08969() {
        }

        private void zzc(com.google.android.gms.internal.zzll r5) {
            /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
            /*
            r4 = this;
            r0 = "Received support message, responding.";
            com.google.android.gms.ads.internal.util.client.zzb.zzcx(r0);
            r0 = r5.zzuh();
            if (r0 == 0) goto L_0x0018;
        L_0x000b:
            r0 = r0.zzakl;
            if (r0 == 0) goto L_0x0018;
        L_0x000f:
            r1 = r5.getContext();
            r0 = r0.zzr(r1);
            goto L_0x0019;
        L_0x0018:
            r0 = 0;
        L_0x0019:
            r1 = new org.json.JSONObject;
            r1.<init>();
            r2 = "event";	 Catch:{ Throwable -> 0x002f }
            r3 = "checkSupport";	 Catch:{ Throwable -> 0x002f }
            r1.put(r2, r3);	 Catch:{ Throwable -> 0x002f }
            r2 = "supports";	 Catch:{ Throwable -> 0x002f }
            r1.put(r2, r0);	 Catch:{ Throwable -> 0x002f }
            r0 = "appStreaming";	 Catch:{ Throwable -> 0x002f }
            r5.zzb(r0, r1);	 Catch:{ Throwable -> 0x002f }
        L_0x002f:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzer.9.zzc(com.google.android.gms.internal.zzll):void");
        }

        public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
            if ("checkSupport".equals(map.get("action"))) {
                zzc(com_google_android_gms_internal_zzll);
                return;
            }
            zzd zzui = com_google_android_gms_internal_zzll.zzui();
            if (zzui != null) {
                zzui.zzf(com_google_android_gms_internal_zzll, map);
            }
        }
    }
}
