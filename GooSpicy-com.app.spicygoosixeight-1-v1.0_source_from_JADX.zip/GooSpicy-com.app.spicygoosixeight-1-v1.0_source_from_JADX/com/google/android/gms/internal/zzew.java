package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.zzb;
import java.util.Map;

@zzir
public class zzew implements zzet {
    private final zzex zzbiv;

    public zzew(zzex com_google_android_gms_internal_zzex) {
        this.zzbiv = com_google_android_gms_internal_zzex;
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        boolean equals = "1".equals(map.get("transparentBackground"));
        boolean equals2 = "1".equals(map.get("blur"));
        float f = 0.0f;
        try {
            if (map.get("blurRadius") != null) {
                f = Float.parseFloat((String) map.get("blurRadius"));
            }
        } catch (Throwable e) {
            zzb.zzb("Fail to parse float", e);
        }
        this.zzbiv.zzg(equals);
        this.zzbiv.zza(equals2, f);
    }
}
