package com.google.android.gms.internal;

import android.content.Context;

public class zzac {
    public static zzl zza(Context context) {
        return zza(context, null);
    }

    public static com.google.android.gms.internal.zzl zza(android.content.Context r6, com.google.android.gms.internal.zzy r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = new java.io.File;
        r1 = r6.getCacheDir();
        r2 = "volley";
        r0.<init>(r1, r2);
        r1 = "volley/0";
        r2 = r6.getPackageName();	 Catch:{ NameNotFoundException -> 0x003c }
        r6 = r6.getPackageManager();	 Catch:{ NameNotFoundException -> 0x003c }
        r3 = 0;	 Catch:{ NameNotFoundException -> 0x003c }
        r6 = r6.getPackageInfo(r2, r3);	 Catch:{ NameNotFoundException -> 0x003c }
        r6 = r6.versionCode;	 Catch:{ NameNotFoundException -> 0x003c }
        r3 = new java.lang.StringBuilder;	 Catch:{ NameNotFoundException -> 0x003c }
        r4 = 12;	 Catch:{ NameNotFoundException -> 0x003c }
        r5 = java.lang.String.valueOf(r2);	 Catch:{ NameNotFoundException -> 0x003c }
        r5 = r5.length();	 Catch:{ NameNotFoundException -> 0x003c }
        r4 = r4 + r5;	 Catch:{ NameNotFoundException -> 0x003c }
        r3.<init>(r4);	 Catch:{ NameNotFoundException -> 0x003c }
        r3.append(r2);	 Catch:{ NameNotFoundException -> 0x003c }
        r2 = "/";	 Catch:{ NameNotFoundException -> 0x003c }
        r3.append(r2);	 Catch:{ NameNotFoundException -> 0x003c }
        r3.append(r6);	 Catch:{ NameNotFoundException -> 0x003c }
        r6 = r3.toString();	 Catch:{ NameNotFoundException -> 0x003c }
        goto L_0x003d;
    L_0x003c:
        r6 = r1;
    L_0x003d:
        if (r7 != 0) goto L_0x0054;
    L_0x003f:
        r7 = android.os.Build.VERSION.SDK_INT;
        r1 = 9;
        if (r7 < r1) goto L_0x004b;
    L_0x0045:
        r7 = new com.google.android.gms.internal.zzz;
        r7.<init>();
        goto L_0x0054;
    L_0x004b:
        r7 = new com.google.android.gms.internal.zzw;
        r6 = android.net.http.AndroidHttpClient.newInstance(r6);
        r7.<init>(r6);
    L_0x0054:
        r6 = new com.google.android.gms.internal.zzt;
        r6.<init>(r7);
        r7 = new com.google.android.gms.internal.zzl;
        r1 = new com.google.android.gms.internal.zzv;
        r1.<init>(r0);
        r7.<init>(r1, r6);
        r7.start();
        return r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzac.zza(android.content.Context, com.google.android.gms.internal.zzy):com.google.android.gms.internal.zzl");
    }
}
