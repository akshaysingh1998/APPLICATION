package com.google.android.gms.internal;

import com.google.android.gms.ads.formats.NativeCustomTemplateAd.OnCustomClickListener;
import com.google.android.gms.internal.zzeg.zza;

@zzir
public class zzel extends zza {
    private final OnCustomClickListener zzbho;

    public zzel(OnCustomClickListener onCustomClickListener) {
        this.zzbho = onCustomClickListener;
    }

    public void zza(zzec com_google_android_gms_internal_zzec, String str) {
        this.zzbho.onCustomClick(new zzed(com_google_android_gms_internal_zzec), str);
    }
}
