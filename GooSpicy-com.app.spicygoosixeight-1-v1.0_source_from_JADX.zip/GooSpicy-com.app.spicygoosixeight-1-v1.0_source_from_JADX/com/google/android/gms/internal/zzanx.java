package com.google.android.gms.internal;

public interface zzanx<T> {
    T mo2294a();
}
