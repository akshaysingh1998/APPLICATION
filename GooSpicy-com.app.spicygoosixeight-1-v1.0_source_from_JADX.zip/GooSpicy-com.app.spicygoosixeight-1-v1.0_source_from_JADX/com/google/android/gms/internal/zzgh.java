package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import com.google.ads.mediation.AdUrlAdapter;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeAdOptions.Builder;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.zzf;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamic.zze;
import com.google.android.gms.internal.zzgi.zza;
import java.util.List;
import org.json.JSONObject;

@zzir
public class zzgh implements zza {
    private final Context mContext;
    private final Object zzail = new Object();
    private final zzgn zzajz;
    private final NativeAdOptionsParcel zzali;
    private final List<String> zzalj;
    private final VersionInfoParcel zzalm;
    private AdRequestParcel zzana;
    private final AdSizeParcel zzang;
    private final boolean zzarj;
    private final boolean zzawl;
    private final String zzbog;
    private final long zzboh;
    private final zzge zzboi;
    private final zzgd zzboj;
    private zzgo zzbok;
    private int zzbol = -2;
    private zzgq zzbom;

    class C11052 extends zzgq.zza {
        final /* synthetic */ int zzbop;

        C11052(int i) {
            this.zzbop = i;
        }

        public int zzmo() throws RemoteException {
            return this.zzbop;
        }
    }

    public zzgh(Context context, String str, zzgn com_google_android_gms_internal_zzgn, zzge com_google_android_gms_internal_zzge, zzgd com_google_android_gms_internal_zzgd, AdRequestParcel adRequestParcel, AdSizeParcel adSizeParcel, VersionInfoParcel versionInfoParcel, boolean z, boolean z2, NativeAdOptionsParcel nativeAdOptionsParcel, List<String> list) {
        this.mContext = context;
        this.zzajz = com_google_android_gms_internal_zzgn;
        this.zzboj = com_google_android_gms_internal_zzgd;
        if ("com.google.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
            this.zzbog = zzmj();
        } else {
            this.zzbog = str;
        }
        this.zzboi = com_google_android_gms_internal_zzge;
        this.zzboh = com_google_android_gms_internal_zzge.zzbnp != -1 ? com_google_android_gms_internal_zzge.zzbnp : 10000;
        this.zzana = adRequestParcel;
        this.zzang = adSizeParcel;
        this.zzalm = versionInfoParcel;
        this.zzarj = z;
        this.zzawl = z2;
        this.zzali = nativeAdOptionsParcel;
        this.zzalj = list;
    }

    private long zza(long j, long j2, long j3, long j4) {
        while (this.zzbol == -2) {
            zzb(j, j2, j3, j4);
        }
        return zzu.zzfu().elapsedRealtime() - j;
    }

    private void zza(zzgg com_google_android_gms_internal_zzgg) {
        if ("com.google.ads.mediation.AdUrlAdapter".equals(this.zzbog)) {
            if (this.zzana.zzatu == null) {
                this.zzana = new zzf(this.zzana).zzc(new Bundle()).zzig();
            }
            Bundle bundle = this.zzana.zzatu.getBundle(this.zzbog);
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putString("sdk_less_network_id", this.zzboj.zzbmz);
            this.zzana.zzatu.putBundle(this.zzbog, bundle);
        }
        String zzbk = zzbk(this.zzboj.zzbng);
        try {
            if (this.zzalm.zzcnp >= 4100000) {
                zzgo com_google_android_gms_internal_zzgo;
                zzd zzae;
                AdRequestParcel adRequestParcel;
                String str;
                NativeAdOptionsParcel nativeAdOptionsParcel;
                List list;
                if (this.zzarj) {
                    com_google_android_gms_internal_zzgo = this.zzbok;
                    zzae = zze.zzae(this.mContext);
                    adRequestParcel = this.zzana;
                    str = this.zzboj.zzbmy;
                    nativeAdOptionsParcel = this.zzali;
                    list = this.zzalj;
                } else if (this.zzang.zzauq) {
                    this.zzbok.zza(zze.zzae(this.mContext), this.zzana, zzbk, this.zzboj.zzbmy, (zzgp) com_google_android_gms_internal_zzgg);
                    return;
                } else {
                    AdSizeParcel adSizeParcel;
                    AdRequestParcel adRequestParcel2;
                    String str2;
                    if (!this.zzawl) {
                        com_google_android_gms_internal_zzgo = this.zzbok;
                        zzae = zze.zzae(this.mContext);
                        adSizeParcel = this.zzang;
                        adRequestParcel2 = this.zzana;
                        str2 = this.zzboj.zzbmy;
                    } else if (this.zzboj.zzbnj != null) {
                        com_google_android_gms_internal_zzgo = this.zzbok;
                        zzae = zze.zzae(this.mContext);
                        adRequestParcel = this.zzana;
                        str = this.zzboj.zzbmy;
                        nativeAdOptionsParcel = new NativeAdOptionsParcel(zzbl(this.zzboj.zzbnn));
                        list = this.zzboj.zzbnm;
                    } else {
                        com_google_android_gms_internal_zzgo = this.zzbok;
                        zzae = zze.zzae(this.mContext);
                        adSizeParcel = this.zzang;
                        adRequestParcel2 = this.zzana;
                        str2 = this.zzboj.zzbmy;
                    }
                    com_google_android_gms_internal_zzgo.zza(zzae, adSizeParcel, adRequestParcel2, zzbk, str2, com_google_android_gms_internal_zzgg);
                    return;
                }
                com_google_android_gms_internal_zzgo.zza(zzae, adRequestParcel, zzbk, str, com_google_android_gms_internal_zzgg, nativeAdOptionsParcel, list);
            } else if (this.zzang.zzauq) {
                this.zzbok.zza(zze.zzae(this.mContext), this.zzana, zzbk, com_google_android_gms_internal_zzgg);
            } else {
                this.zzbok.zza(zze.zzae(this.mContext), this.zzang, this.zzana, zzbk, (zzgp) com_google_android_gms_internal_zzgg);
            }
        } catch (Throwable e) {
            zzb.zzd("Could not request ad from mediation adapter.", e);
            zzy(5);
        }
    }

    private static zzgq zzaa(int i) {
        return new C11052(i);
    }

    private void zzb(long r5, long r7, long r9, long r11) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = android.os.SystemClock.elapsedRealtime();
        r2 = r0 - r5;
        r5 = r7 - r2;
        r7 = r0 - r9;
        r9 = r11 - r7;
        r7 = 0;
        r11 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1));
        if (r11 <= 0) goto L_0x0025;
    L_0x0012:
        r11 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1));
        if (r11 > 0) goto L_0x0017;
    L_0x0016:
        goto L_0x0025;
    L_0x0017:
        r7 = r4.zzail;	 Catch:{ InterruptedException -> 0x0021 }
        r5 = java.lang.Math.min(r5, r9);	 Catch:{ InterruptedException -> 0x0021 }
        r7.wait(r5);	 Catch:{ InterruptedException -> 0x0021 }
        return;
    L_0x0021:
        r5 = -1;
        r4.zzbol = r5;
        return;
    L_0x0025:
        r5 = "Timed out waiting for adapter.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcx(r5);
        r5 = 3;
        r4.zzbol = r5;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgh.zzb(long, long, long, long):void");
    }

    private java.lang.String zzbk(java.lang.String r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        if (r3 == 0) goto L_0x0024;
    L_0x0002:
        r0 = r2.zzmm();
        if (r0 == 0) goto L_0x0024;
    L_0x0008:
        r0 = 2;
        r0 = r2.zzz(r0);
        if (r0 == 0) goto L_0x0010;
    L_0x000f:
        return r3;
    L_0x0010:
        r0 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x001f }
        r0.<init>(r3);	 Catch:{ JSONException -> 0x001f }
        r1 = "cpm_floor_cents";	 Catch:{ JSONException -> 0x001f }
        r0.remove(r1);	 Catch:{ JSONException -> 0x001f }
        r0 = r0.toString();	 Catch:{ JSONException -> 0x001f }
        return r0;
    L_0x001f:
        r0 = "Could not remove field. Returning the original value";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r0);
    L_0x0024:
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgh.zzbk(java.lang.String):java.lang.String");
    }

    private static NativeAdOptions zzbl(String str) {
        Builder builder = new Builder();
        if (str == null) {
            return builder.build();
        }
        try {
            JSONObject jSONObject = new JSONObject(str);
            builder.setRequestMultipleImages(jSONObject.optBoolean("multiple_images", false));
            builder.setReturnUrlsForImageAssets(jSONObject.optBoolean("only_urls", false));
            builder.setImageOrientation(zzbm(jSONObject.optString("native_image_orientation", "any")));
        } catch (Throwable e) {
            zzb.zzd("Exception occurred when creating native ad options", e);
        }
        return builder.build();
    }

    private static int zzbm(String str) {
        return "landscape".equals(str) ? 2 : "portrait".equals(str) ? 1 : 0;
    }

    private java.lang.String zzmj() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r0 = r2.zzboj;	 Catch:{ RemoteException -> 0x001c }
        r0 = r0.zzbnc;	 Catch:{ RemoteException -> 0x001c }
        r0 = android.text.TextUtils.isEmpty(r0);	 Catch:{ RemoteException -> 0x001c }
        if (r0 != 0) goto L_0x0021;	 Catch:{ RemoteException -> 0x001c }
    L_0x000a:
        r0 = r2.zzajz;	 Catch:{ RemoteException -> 0x001c }
        r1 = r2.zzboj;	 Catch:{ RemoteException -> 0x001c }
        r1 = r1.zzbnc;	 Catch:{ RemoteException -> 0x001c }
        r0 = r0.zzbo(r1);	 Catch:{ RemoteException -> 0x001c }
        if (r0 == 0) goto L_0x0019;	 Catch:{ RemoteException -> 0x001c }
    L_0x0016:
        r0 = "com.google.android.gms.ads.mediation.customevent.CustomEventAdapter";	 Catch:{ RemoteException -> 0x001c }
        return r0;	 Catch:{ RemoteException -> 0x001c }
    L_0x0019:
        r0 = "com.google.ads.mediation.customevent.CustomEventAdapter";	 Catch:{ RemoteException -> 0x001c }
        return r0;
    L_0x001c:
        r0 = "Fail to determine the custom event's version, assuming the old one.";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r0);
    L_0x0021:
        r0 = "com.google.ads.mediation.customevent.CustomEventAdapter";
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgh.zzmj():java.lang.String");
    }

    private com.google.android.gms.internal.zzgq zzmk() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = r1.zzbol;
        if (r0 != 0) goto L_0x002f;
    L_0x0004:
        r0 = r1.zzmm();
        if (r0 != 0) goto L_0x000b;
    L_0x000a:
        goto L_0x002f;
    L_0x000b:
        r0 = 4;
        r0 = r1.zzz(r0);	 Catch:{ RemoteException -> 0x0021 }
        if (r0 == 0) goto L_0x0026;	 Catch:{ RemoteException -> 0x0021 }
    L_0x0012:
        r0 = r1.zzbom;	 Catch:{ RemoteException -> 0x0021 }
        if (r0 == 0) goto L_0x0026;	 Catch:{ RemoteException -> 0x0021 }
    L_0x0016:
        r0 = r1.zzbom;	 Catch:{ RemoteException -> 0x0021 }
        r0 = r0.zzmo();	 Catch:{ RemoteException -> 0x0021 }
        if (r0 == 0) goto L_0x0026;	 Catch:{ RemoteException -> 0x0021 }
    L_0x001e:
        r0 = r1.zzbom;	 Catch:{ RemoteException -> 0x0021 }
        return r0;
    L_0x0021:
        r0 = "Could not get cpm value from MediationResponseMetadata";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r0);
    L_0x0026:
        r0 = r1.zzmn();
        r0 = zzaa(r0);
        return r0;
    L_0x002f:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgh.zzmk():com.google.android.gms.internal.zzgq");
    }

    private zzgo zzml() {
        String str = "Instantiating mediation adapter: ";
        String valueOf = String.valueOf(this.zzbog);
        zzb.zzcx(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        if (!this.zzarj) {
            if (((Boolean) zzdc.zzbbc.get()).booleanValue() && "com.google.ads.mediation.admob.AdMobAdapter".equals(this.zzbog)) {
                return zza(new AdMobAdapter());
            }
            if (((Boolean) zzdc.zzbbd.get()).booleanValue() && "com.google.ads.mediation.AdUrlAdapter".equals(this.zzbog)) {
                return zza(new AdUrlAdapter());
            }
            if ("com.google.ads.mediation.admob.AdMobCustomTabsAdapter".equals(this.zzbog)) {
                return new zzgu(new zzhc());
            }
        }
        try {
            return this.zzajz.zzbn(this.zzbog);
        } catch (Throwable e) {
            valueOf = "Could not instantiate mediation adapter: ";
            String valueOf2 = String.valueOf(this.zzbog);
            zzb.zza(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf), e);
            return null;
        }
    }

    private boolean zzmm() {
        return this.zzboi.zzbnz != -1;
    }

    private int zzmn() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = r4.zzboj;
        r0 = r0.zzbng;
        r1 = 0;
        if (r0 != 0) goto L_0x0008;
    L_0x0007:
        return r1;
    L_0x0008:
        r0 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x003a }
        r2 = r4.zzboj;	 Catch:{ JSONException -> 0x003a }
        r2 = r2.zzbng;	 Catch:{ JSONException -> 0x003a }
        r0.<init>(r2);	 Catch:{ JSONException -> 0x003a }
        r2 = "com.google.ads.mediation.admob.AdMobAdapter";
        r3 = r4.zzbog;
        r2 = r2.equals(r3);
        if (r2 == 0) goto L_0x0022;
    L_0x001b:
        r2 = "cpm_cents";
        r0 = r0.optInt(r2, r1);
        return r0;
    L_0x0022:
        r2 = 2;
        r2 = r4.zzz(r2);
        if (r2 == 0) goto L_0x0030;
    L_0x0029:
        r2 = "cpm_floor_cents";
        r2 = r0.optInt(r2, r1);
        goto L_0x0031;
    L_0x0030:
        r2 = r1;
    L_0x0031:
        if (r2 != 0) goto L_0x0039;
    L_0x0033:
        r2 = "penalized_average_cpm_cents";
        r2 = r0.optInt(r2, r1);
    L_0x0039:
        return r2;
    L_0x003a:
        r0 = "Could not convert to json. Returning 0";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r0);
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgh.zzmn():int");
    }

    private boolean zzz(int r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = 0;
        r1 = r3.zzarj;	 Catch:{ RemoteException -> 0x002c }
        if (r1 == 0) goto L_0x000c;	 Catch:{ RemoteException -> 0x002c }
    L_0x0005:
        r1 = r3.zzbok;	 Catch:{ RemoteException -> 0x002c }
        r1 = r1.zzmt();	 Catch:{ RemoteException -> 0x002c }
        goto L_0x001f;	 Catch:{ RemoteException -> 0x002c }
    L_0x000c:
        r1 = r3.zzang;	 Catch:{ RemoteException -> 0x002c }
        r1 = r1.zzauq;	 Catch:{ RemoteException -> 0x002c }
        if (r1 == 0) goto L_0x0019;	 Catch:{ RemoteException -> 0x002c }
    L_0x0012:
        r1 = r3.zzbok;	 Catch:{ RemoteException -> 0x002c }
        r1 = r1.getInterstitialAdapterInfo();	 Catch:{ RemoteException -> 0x002c }
        goto L_0x001f;	 Catch:{ RemoteException -> 0x002c }
    L_0x0019:
        r1 = r3.zzbok;	 Catch:{ RemoteException -> 0x002c }
        r1 = r1.zzms();	 Catch:{ RemoteException -> 0x002c }
    L_0x001f:
        if (r1 == 0) goto L_0x002b;
    L_0x0021:
        r2 = "capabilities";
        r1 = r1.getInt(r2, r0);
        r1 = r1 & r4;
        if (r1 != r4) goto L_0x002b;
    L_0x002a:
        r0 = 1;
    L_0x002b:
        return r0;
    L_0x002c:
        r4 = "Could not get adapter info. Returning false";
        com.google.android.gms.ads.internal.util.client.zzb.zzcy(r4);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzgh.zzz(int):boolean");
    }

    public void cancel() {
        synchronized (this.zzail) {
            try {
                if (this.zzbok != null) {
                    this.zzbok.destroy();
                }
            } catch (Throwable e) {
                zzb.zzd("Could not destroy mediation adapter.", e);
            }
            this.zzbol = -1;
            this.zzail.notify();
        }
    }

    public zzgi zza(long j, long j2) {
        zzgi com_google_android_gms_internal_zzgi;
        synchronized (this.zzail) {
            try {
                long elapsedRealtime = SystemClock.elapsedRealtime();
                final zzgg com_google_android_gms_internal_zzgg = new zzgg();
                zzkl.zzclg.post(new Runnable(r10) {
                    final /* synthetic */ zzgh zzboo;

                    public void run() {
                        synchronized (this.zzboo.zzail) {
                            if (this.zzboo.zzbol != -2) {
                                return;
                            }
                            this.zzboo.zzbok = this.zzboo.zzml();
                            if (this.zzboo.zzbok == null) {
                                this.zzboo.zzy(4);
                            } else if (!this.zzboo.zzmm() || this.zzboo.zzz(1)) {
                                com_google_android_gms_internal_zzgg.zza(this.zzboo);
                                this.zzboo.zza(com_google_android_gms_internal_zzgg);
                            } else {
                                String zzf = this.zzboo.zzbog;
                                StringBuilder stringBuilder = new StringBuilder(56 + String.valueOf(zzf).length());
                                stringBuilder.append("Ignoring adapter ");
                                stringBuilder.append(zzf);
                                stringBuilder.append(" as delayed impression is not supported");
                                zzb.zzcy(stringBuilder.toString());
                                this.zzboo.zzy(2);
                            }
                        }
                    }
                });
                long zza = zza(elapsedRealtime, r10.zzboh, j, j2);
                zzgd com_google_android_gms_internal_zzgd = r10.zzboj;
                zzgo com_google_android_gms_internal_zzgo = r10.zzbok;
                String str = r10.zzbog;
                zzgg com_google_android_gms_internal_zzgg2 = com_google_android_gms_internal_zzgg;
                com_google_android_gms_internal_zzgi = new zzgi(com_google_android_gms_internal_zzgd, com_google_android_gms_internal_zzgo, str, com_google_android_gms_internal_zzgg2, r10.zzbol, zzmk(), zza);
            } catch (Throwable th) {
                Throwable th2 = th;
            }
        }
        return com_google_android_gms_internal_zzgi;
    }

    protected zzgo zza(MediationAdapter mediationAdapter) {
        return new zzgu(mediationAdapter);
    }

    public void zza(int i, zzgq com_google_android_gms_internal_zzgq) {
        synchronized (this.zzail) {
            this.zzbol = i;
            this.zzbom = com_google_android_gms_internal_zzgq;
            this.zzail.notify();
        }
    }

    public void zzy(int i) {
        synchronized (this.zzail) {
            this.zzbol = i;
            this.zzail.notify();
        }
    }
}
