package com.google.android.gms.internal;

import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.google.android.gms.internal.zzhs.zza;

@zzir
public final class zzhx extends zza {
    private final InAppPurchaseListener zzawf;

    public zzhx(InAppPurchaseListener inAppPurchaseListener) {
        this.zzawf = inAppPurchaseListener;
    }

    public void zza(zzhr com_google_android_gms_internal_zzhr) {
        this.zzawf.onInAppPurchaseRequested(new zzia(com_google_android_gms_internal_zzhr));
    }
}
