package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.reward.client.RewardedVideoAdRequestParcel;
import com.google.android.gms.ads.internal.reward.client.zzb.zza;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzd;
import com.google.android.gms.dynamic.zze;

@zzir
public class zzji extends zza {
    private final Context mContext;
    private final Object zzail = new Object();
    private final VersionInfoParcel zzalm;
    private final zzjj zzchj;

    public zzji(Context context, zzd com_google_android_gms_ads_internal_zzd, zzgn com_google_android_gms_internal_zzgn, VersionInfoParcel versionInfoParcel) {
        this.mContext = context;
        this.zzalm = versionInfoParcel;
        this.zzchj = new zzjj(context, com_google_android_gms_ads_internal_zzd, AdSizeParcel.zzii(), com_google_android_gms_internal_zzgn, versionInfoParcel);
    }

    public void destroy() {
        zzh(null);
    }

    public boolean isLoaded() {
        boolean isLoaded;
        synchronized (this.zzail) {
            isLoaded = this.zzchj.isLoaded();
        }
        return isLoaded;
    }

    public void pause() {
        zzf(null);
    }

    public void resume() {
        zzg(null);
    }

    public void setUserId(String str) {
        zzb.zzcy("RewardedVideoAd.setUserId() is deprecated. Please do not call this method.");
    }

    public void show() {
        synchronized (this.zzail) {
            this.zzchj.zzrr();
        }
    }

    public void zza(RewardedVideoAdRequestParcel rewardedVideoAdRequestParcel) {
        synchronized (this.zzail) {
            this.zzchj.zza(rewardedVideoAdRequestParcel);
        }
    }

    public void zza(com.google.android.gms.ads.internal.reward.client.zzd com_google_android_gms_ads_internal_reward_client_zzd) {
        synchronized (this.zzail) {
            this.zzchj.zza(com_google_android_gms_ads_internal_reward_client_zzd);
        }
    }

    public void zzf(com.google.android.gms.dynamic.zzd com_google_android_gms_dynamic_zzd) {
        synchronized (this.zzail) {
            this.zzchj.pause();
        }
    }

    public void zzg(com.google.android.gms.dynamic.zzd com_google_android_gms_dynamic_zzd) {
        synchronized (this.zzail) {
            Context context;
            if (com_google_android_gms_dynamic_zzd == null) {
                context = null;
            } else {
                try {
                    context = (Context) zze.zzad(com_google_android_gms_dynamic_zzd);
                } catch (Throwable e) {
                    zzb.zzd("Unable to extract updated context.", e);
                }
            }
            if (context != null) {
                this.zzchj.onContextChanged(context);
            }
            this.zzchj.resume();
        }
    }

    public void zzh(com.google.android.gms.dynamic.zzd com_google_android_gms_dynamic_zzd) {
        synchronized (this.zzail) {
            this.zzchj.destroy();
        }
    }
}
