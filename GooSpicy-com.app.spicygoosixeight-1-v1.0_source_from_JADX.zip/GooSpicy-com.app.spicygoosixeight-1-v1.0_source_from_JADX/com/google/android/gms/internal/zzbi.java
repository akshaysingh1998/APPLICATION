package com.google.android.gms.internal;

import com.google.android.gms.internal.zzae.zza;
import java.util.concurrent.Callable;

public class zzbi implements Callable {
    private final zzax zzaey;
    private final zza zzaha;

    public zzbi(zzax com_google_android_gms_internal_zzax, zza com_google_android_gms_internal_zzae_zza) {
        this.zzaey = com_google_android_gms_internal_zzax;
        this.zzaha = com_google_android_gms_internal_zzae_zza;
    }

    public /* synthetic */ Object call() throws Exception {
        return zzcy();
    }

    public java.lang.Void zzcy() throws java.lang.Exception {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r3.zzaey;
        r0 = r0.zzcn();
        if (r0 == 0) goto L_0x0011;
    L_0x0008:
        r0 = r3.zzaey;
        r0 = r0.zzcn();
        r0.get();
    L_0x0011:
        r0 = r3.zzaey;
        r0 = r0.zzcm();
        if (r0 == 0) goto L_0x002a;
    L_0x0019:
        r1 = r3.zzaha;	 Catch:{ zzapb -> 0x002a }
        monitor-enter(r1);	 Catch:{ zzapb -> 0x002a }
        r2 = r3.zzaha;	 Catch:{ all -> 0x0027 }
        r0 = com.google.android.gms.internal.zzapc.zzf(r0);	 Catch:{ all -> 0x0027 }
        com.google.android.gms.internal.zzapc.zza(r2, r0);	 Catch:{ all -> 0x0027 }
        monitor-exit(r1);	 Catch:{ all -> 0x0027 }
        goto L_0x002a;	 Catch:{ all -> 0x0027 }
    L_0x0027:
        r0 = move-exception;	 Catch:{ all -> 0x0027 }
        monitor-exit(r1);	 Catch:{ all -> 0x0027 }
        throw r0;	 Catch:{ zzapb -> 0x002a }
    L_0x002a:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzbi.zzcy():java.lang.Void");
    }
}
