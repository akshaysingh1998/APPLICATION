package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IBinder;
import com.google.android.gms.ads.formats.NativeAd.Image;
import com.google.android.gms.ads.formats.NativeContentAd;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzdu.zza;
import java.util.ArrayList;
import java.util.List;

@zzir
public class zzeb extends NativeContentAd {
    private final List<Image> zzbhh = new ArrayList();
    private final zzea zzbhj;
    private final zzdv zzbhk;

    public zzeb(zzea com_google_android_gms_internal_zzea) {
        zzdu zze;
        this.zzbhj = com_google_android_gms_internal_zzea;
        try {
            List<Object> images = this.zzbhj.getImages();
            if (images != null) {
                for (Object zze2 : images) {
                    zze = zze(zze2);
                    if (zze != null) {
                        this.zzbhh.add(new zzdv(zze));
                    }
                }
            }
        } catch (Throwable e) {
            zzb.zzb("Failed to get image.", e);
        }
        zzdv com_google_android_gms_internal_zzdv = null;
        try {
            zze = this.zzbhj.zzla();
            if (zze != null) {
                com_google_android_gms_internal_zzdv = new zzdv(zze);
            }
        } catch (Throwable e2) {
            zzb.zzb("Failed to get icon.", e2);
        }
        this.zzbhk = com_google_android_gms_internal_zzdv;
    }

    public void destroy() {
        try {
            this.zzbhj.destroy();
        } catch (Throwable e) {
            zzb.zzb("Failed to destroy", e);
        }
    }

    public CharSequence getAdvertiser() {
        try {
            return this.zzbhj.getAdvertiser();
        } catch (Throwable e) {
            zzb.zzb("Failed to get attribution.", e);
            return null;
        }
    }

    public CharSequence getBody() {
        try {
            return this.zzbhj.getBody();
        } catch (Throwable e) {
            zzb.zzb("Failed to get body.", e);
            return null;
        }
    }

    public CharSequence getCallToAction() {
        try {
            return this.zzbhj.getCallToAction();
        } catch (Throwable e) {
            zzb.zzb("Failed to get call to action.", e);
            return null;
        }
    }

    public Bundle getExtras() {
        try {
            return this.zzbhj.getExtras();
        } catch (Throwable e) {
            zzb.zzd("Failed to get extras", e);
            return null;
        }
    }

    public CharSequence getHeadline() {
        try {
            return this.zzbhj.getHeadline();
        } catch (Throwable e) {
            zzb.zzb("Failed to get headline.", e);
            return null;
        }
    }

    public List<Image> getImages() {
        return this.zzbhh;
    }

    public Image getLogo() {
        return this.zzbhk;
    }

    protected /* synthetic */ Object zzdh() {
        return zzkx();
    }

    zzdu zze(Object obj) {
        return obj instanceof IBinder ? zza.zzy((IBinder) obj) : null;
    }

    protected zzd zzkx() {
        try {
            return this.zzbhj.zzkx();
        } catch (Throwable e) {
            zzb.zzb("Failed to retrieve native ad engine.", e);
            return null;
        }
    }
}
