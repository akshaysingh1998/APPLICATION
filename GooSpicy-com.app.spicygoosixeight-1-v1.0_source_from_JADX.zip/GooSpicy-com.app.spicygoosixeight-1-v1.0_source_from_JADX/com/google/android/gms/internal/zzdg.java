package com.google.android.gms.internal;

import android.support.annotation.Nullable;

@zzir
public class zzdg {
    @Nullable
    public static zzdi zza(@Nullable zzdk com_google_android_gms_internal_zzdk, long j) {
        return com_google_android_gms_internal_zzdk == null ? null : com_google_android_gms_internal_zzdk.zzc(j);
    }

    public static boolean zza(@Nullable zzdk com_google_android_gms_internal_zzdk, @Nullable zzdi com_google_android_gms_internal_zzdi, long j, String... strArr) {
        if (com_google_android_gms_internal_zzdk != null) {
            if (com_google_android_gms_internal_zzdi != null) {
                return com_google_android_gms_internal_zzdk.zza(com_google_android_gms_internal_zzdi, j, strArr);
            }
        }
        return false;
    }

    public static boolean zza(@Nullable zzdk com_google_android_gms_internal_zzdk, @Nullable zzdi com_google_android_gms_internal_zzdi, String... strArr) {
        if (com_google_android_gms_internal_zzdk != null) {
            if (com_google_android_gms_internal_zzdi != null) {
                return com_google_android_gms_internal_zzdk.zza(com_google_android_gms_internal_zzdi, strArr);
            }
        }
        return false;
    }

    @Nullable
    public static zzdi zzb(@Nullable zzdk com_google_android_gms_internal_zzdk) {
        return com_google_android_gms_internal_zzdk == null ? null : com_google_android_gms_internal_zzdk.zzkg();
    }
}
