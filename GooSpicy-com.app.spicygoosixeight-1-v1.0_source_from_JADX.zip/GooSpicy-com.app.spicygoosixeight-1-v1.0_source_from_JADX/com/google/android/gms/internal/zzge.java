package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzir
public final class zzge {
    public final List<zzgd> zzbno;
    public final long zzbnp;
    public final List<String> zzbnq;
    public final List<String> zzbnr;
    public final List<String> zzbns;
    public final List<String> zzbnt;
    public final boolean zzbnu;
    public final String zzbnv;
    public final long zzbnw;
    public final String zzbnx;
    public final int zzbny;
    public final int zzbnz;
    public final long zzboa;
    public final boolean zzbob;
    public int zzboc;
    public int zzbod;

    public zzge(String str) throws JSONException {
        JSONObject jSONObject = new JSONObject(str);
        if (zzb.zzaz(2)) {
            String str2 = "Mediation Response JSON: ";
            str = String.valueOf(jSONObject.toString(2));
            zzkh.m83v(str.length() != 0 ? str2.concat(str) : new String(str2));
        }
        JSONArray jSONArray = jSONObject.getJSONArray("ad_networks");
        List arrayList = new ArrayList(jSONArray.length());
        int i = -1;
        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
            zzgd com_google_android_gms_internal_zzgd = new zzgd(jSONArray.getJSONObject(i2));
            arrayList.add(com_google_android_gms_internal_zzgd);
            if (i < 0 && zza(com_google_android_gms_internal_zzgd)) {
                i = i2;
            }
        }
        this.zzboc = i;
        this.zzbod = jSONArray.length();
        this.zzbno = Collections.unmodifiableList(arrayList);
        this.zzbnv = jSONObject.getString("qdata");
        this.zzbnz = jSONObject.optInt("fs_model_type", -1);
        long j = -1;
        this.zzboa = jSONObject.optLong("timeout_ms", -1);
        JSONObject optJSONObject = jSONObject.optJSONObject("settings");
        if (optJSONObject != null) {
            this.zzbnp = optJSONObject.optLong("ad_network_timeout_millis", -1);
            this.zzbnq = zzu.zzgf().zza(optJSONObject, "click_urls");
            this.zzbnr = zzu.zzgf().zza(optJSONObject, "imp_urls");
            this.zzbns = zzu.zzgf().zza(optJSONObject, "nofill_urls");
            this.zzbnt = zzu.zzgf().zza(optJSONObject, "remote_ping_urls");
            this.zzbnu = optJSONObject.optBoolean("render_in_browser", false);
            long optLong = optJSONObject.optLong("refresh", -1);
            if (optLong > 0) {
                j = 1000 * optLong;
            }
            this.zzbnw = j;
            RewardItemParcel zza = RewardItemParcel.zza(optJSONObject.optJSONArray("rewards"));
            if (zza == null) {
                this.zzbnx = null;
                this.zzbny = 0;
            } else {
                this.zzbnx = zza.type;
                this.zzbny = zza.zzcih;
            }
            this.zzbob = optJSONObject.optBoolean("use_displayed_impression", false);
            return;
        }
        this.zzbnp = -1;
        this.zzbnq = null;
        this.zzbnr = null;
        this.zzbns = null;
        this.zzbnt = null;
        this.zzbnw = -1;
        this.zzbnx = null;
        this.zzbny = 0;
        this.zzbob = false;
        this.zzbnu = false;
    }

    public zzge(List<zzgd> list, long j, List<String> list2, List<String> list3, List<String> list4, List<String> list5, boolean z, String str, long j2, int i, int i2, String str2, int i3, int i4, long j3, boolean z2) {
        this.zzbno = list;
        this.zzbnp = j;
        this.zzbnq = list2;
        this.zzbnr = list3;
        this.zzbns = list4;
        this.zzbnt = list5;
        this.zzbnu = z;
        this.zzbnv = str;
        this.zzbnw = j2;
        this.zzboc = i;
        this.zzbod = i2;
        this.zzbnx = str2;
        this.zzbny = i3;
        this.zzbnz = i4;
        this.zzboa = j3;
        this.zzbob = z2;
    }

    private boolean zza(zzgd com_google_android_gms_internal_zzgd) {
        for (String equals : com_google_android_gms_internal_zzgd.zzbna) {
            if (equals.equals("com.google.ads.mediation.admob.AdMobAdapter")) {
                return true;
            }
        }
        return false;
    }
}
