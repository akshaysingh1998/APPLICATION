package com.google.android.gms.internal;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.MotionEvent;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzu;
import java.util.Map;

@zzir
public class zzko {
    private final Context mContext;
    private int mState;
    private final float zzbri;
    private String zzclp;
    private float zzclq;
    private float zzclr;
    private float zzcls;

    class C04802 implements OnClickListener {
        final /* synthetic */ zzko zzclu;

        C04802(zzko com_google_android_gms_internal_zzko) {
            this.zzclu = com_google_android_gms_internal_zzko;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
        }
    }

    public zzko(Context context) {
        this.mState = 0;
        this.mContext = context;
        this.zzbri = context.getResources().getDisplayMetrics().density;
    }

    public zzko(Context context, String str) {
        this(context);
        this.zzclp = str;
    }

    private void showDialog() {
        if (this.mContext instanceof Activity) {
            final Object zzcu = zzcu(this.zzclp);
            Builder builder = new Builder(this.mContext);
            builder.setMessage(zzcu);
            builder.setTitle("Ad Information");
            builder.setPositiveButton("Share", new OnClickListener(this) {
                final /* synthetic */ zzko zzclu;

                public void onClick(DialogInterface dialogInterface, int i) {
                    zzu.zzfq().zzb(this.zzclu.mContext, Intent.createChooser(new Intent("android.intent.action.SEND").setType("text/plain").putExtra("android.intent.extra.TEXT", zzcu), "Share via"));
                }
            });
            builder.setNegativeButton("Close", new C04802(this));
            builder.create().show();
            return;
        }
        zzb.zzcx("Can not create dialog without Activity Context");
    }

    static String zzcu(String str) {
        if (TextUtils.isEmpty(str)) {
            return "No debug information";
        }
        Uri build = new Uri.Builder().encodedQuery(str.replaceAll("\\+", "%20")).build();
        StringBuilder stringBuilder = new StringBuilder();
        Map zzf = zzu.zzfq().zzf(build);
        for (String str2 : zzf.keySet()) {
            stringBuilder.append(str2);
            stringBuilder.append(" = ");
            stringBuilder.append((String) zzf.get(str2));
            stringBuilder.append("\n\n");
        }
        Object trim = stringBuilder.toString().trim();
        return !TextUtils.isEmpty(trim) ? trim : "No debug information";
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    void zza(int r5, float r6, float r7) {
        /*
        r4 = this;
        if (r5 != 0) goto L_0x000c;
    L_0x0002:
        r5 = 0;
        r4.mState = r5;
        r4.zzclq = r6;
        r4.zzclr = r7;
        r4.zzcls = r7;
        return;
    L_0x000c:
        r0 = r4.mState;
        r1 = -1;
        if (r0 != r1) goto L_0x0012;
    L_0x0011:
        return;
    L_0x0012:
        r0 = 2;
        r2 = 1;
        if (r5 != r0) goto L_0x0089;
    L_0x0016:
        r5 = r4.zzclr;
        r5 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1));
        if (r5 <= 0) goto L_0x001f;
    L_0x001c:
        r4.zzclr = r7;
        goto L_0x0027;
    L_0x001f:
        r5 = r4.zzcls;
        r5 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1));
        if (r5 >= 0) goto L_0x0027;
    L_0x0025:
        r4.zzcls = r7;
    L_0x0027:
        r5 = r4.zzclr;
        r7 = r4.zzcls;
        r5 = r5 - r7;
        r7 = 1106247680; // 0x41f00000 float:30.0 double:5.465589745E-315;
        r3 = r4.zzbri;
        r7 = r7 * r3;
        r5 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1));
        if (r5 <= 0) goto L_0x0038;
    L_0x0035:
        r4.mState = r1;
        return;
    L_0x0038:
        r5 = r4.mState;
        r7 = 3;
        if (r5 == 0) goto L_0x0058;
    L_0x003d:
        r5 = r4.mState;
        if (r5 != r0) goto L_0x0042;
    L_0x0041:
        goto L_0x0058;
    L_0x0042:
        r5 = r4.mState;
        if (r5 == r2) goto L_0x004a;
    L_0x0046:
        r5 = r4.mState;
        if (r5 != r7) goto L_0x006c;
    L_0x004a:
        r5 = r4.zzclq;
        r5 = r6 - r5;
        r1 = -1035468800; // 0xffffffffc2480000 float:-50.0 double:NaN;
        r3 = r4.zzbri;
        r1 = r1 * r3;
        r5 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1));
        if (r5 > 0) goto L_0x006c;
    L_0x0057:
        goto L_0x0065;
    L_0x0058:
        r5 = r4.zzclq;
        r5 = r6 - r5;
        r1 = 1112014848; // 0x42480000 float:50.0 double:5.49408334E-315;
        r3 = r4.zzbri;
        r1 = r1 * r3;
        r5 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1));
        if (r5 < 0) goto L_0x006c;
    L_0x0065:
        r4.zzclq = r6;
        r5 = r4.mState;
        r5 = r5 + r2;
        r4.mState = r5;
    L_0x006c:
        r5 = r4.mState;
        if (r5 == r2) goto L_0x0080;
    L_0x0070:
        r5 = r4.mState;
        if (r5 != r7) goto L_0x0075;
    L_0x0074:
        goto L_0x0080;
    L_0x0075:
        r5 = r4.mState;
        if (r5 != r0) goto L_0x0093;
    L_0x0079:
        r5 = r4.zzclq;
        r5 = (r6 > r5 ? 1 : (r6 == r5 ? 0 : -1));
        if (r5 >= 0) goto L_0x0093;
    L_0x007f:
        goto L_0x0086;
    L_0x0080:
        r5 = r4.zzclq;
        r5 = (r6 > r5 ? 1 : (r6 == r5 ? 0 : -1));
        if (r5 <= 0) goto L_0x0093;
    L_0x0086:
        r4.zzclq = r6;
        return;
    L_0x0089:
        if (r5 != r2) goto L_0x0093;
    L_0x008b:
        r5 = r4.mState;
        r6 = 4;
        if (r5 != r6) goto L_0x0093;
    L_0x0090:
        r4.showDialog();
    L_0x0093:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzko.zza(int, float, float):void");
    }

    public void zzct(String str) {
        this.zzclp = str;
    }

    public void zze(MotionEvent motionEvent) {
        int historySize = motionEvent.getHistorySize();
        for (int i = 0; i < historySize; i++) {
            zza(motionEvent.getActionMasked(), motionEvent.getHistoricalX(0, i), motionEvent.getHistoricalY(0, i));
        }
        zza(motionEvent.getActionMasked(), motionEvent.getX(), motionEvent.getY());
    }
}
