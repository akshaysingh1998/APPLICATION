package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzanu {
    public static zzanu bff;

    public abstract void zzi(zzaop com_google_android_gms_internal_zzaop) throws IOException;
}
