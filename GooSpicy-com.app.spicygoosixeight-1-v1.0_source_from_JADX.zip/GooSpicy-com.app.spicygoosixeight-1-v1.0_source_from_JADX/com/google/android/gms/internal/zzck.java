package com.google.android.gms.internal;

import android.view.View;

public interface zzck {
    View zzhh();

    boolean zzhi();

    zzck zzhj();
}
