package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.ResultTransform;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.TransformedResult;
import com.google.android.gms.common.internal.zzab;
import com.google.android.gms.common.internal.zzr;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;

public abstract class zzpt<R extends Result> extends PendingResult<R> {
    static final ThreadLocal<Boolean> sI = new C05021();
    private final Object sJ;
    protected final zza<R> sK;
    protected final WeakReference<GoogleApiClient> sL;
    private final ArrayList<com.google.android.gms.common.api.PendingResult.zza> sM;
    private ResultCallback<? super R> sN;
    private zzb sO;
    private volatile boolean sP;
    private boolean sQ;
    private zzr sR;
    private volatile zzrc<R> sS;
    private boolean sT;
    private R sc;
    private boolean zzak;
    private final CountDownLatch zzalc;

    class C05021 extends ThreadLocal<Boolean> {
        C05021() {
        }

        protected /* synthetic */ Object initialValue() {
            return zzaov();
        }

        protected Boolean zzaov() {
            return Boolean.valueOf(false);
        }
    }

    public static class zza<R extends Result> extends Handler {
        public zza() {
            this(Looper.getMainLooper());
        }

        public zza(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    Pair pair = (Pair) message.obj;
                    zzb((ResultCallback) pair.first, (Result) pair.second);
                    return;
                case 2:
                    ((zzpt) message.obj).zzaa(Status.sj);
                    return;
                default:
                    int i = message.what;
                    StringBuilder stringBuilder = new StringBuilder(45);
                    stringBuilder.append("Don't know how to handle message: ");
                    stringBuilder.append(i);
                    Log.wtf("BasePendingResult", stringBuilder.toString(), new Exception());
                    return;
            }
        }

        public void zza(ResultCallback<? super R> resultCallback, R r) {
            sendMessage(obtainMessage(1, new Pair(resultCallback, r)));
        }

        public void zza(zzpt<R> com_google_android_gms_internal_zzpt_R, long j) {
            sendMessageDelayed(obtainMessage(2, com_google_android_gms_internal_zzpt_R), j);
        }

        public void zzaow() {
            removeMessages(2);
        }

        protected void zzb(ResultCallback<? super R> resultCallback, R r) {
            try {
                resultCallback.onResult(r);
            } catch (RuntimeException e) {
                zzpt.zze(r);
                throw e;
            }
        }
    }

    private final class zzb {
        final /* synthetic */ zzpt sU;

        private zzb(zzpt com_google_android_gms_internal_zzpt) {
            this.sU = com_google_android_gms_internal_zzpt;
        }

        protected void finalize() throws Throwable {
            zzpt.zze(this.sU.sc);
            super.finalize();
        }
    }

    @Deprecated
    zzpt() {
        this.sJ = new Object();
        this.zzalc = new CountDownLatch(1);
        this.sM = new ArrayList();
        this.sT = false;
        this.sK = new zza(Looper.getMainLooper());
        this.sL = new WeakReference(null);
    }

    @Deprecated
    protected zzpt(Looper looper) {
        this.sJ = new Object();
        this.zzalc = new CountDownLatch(1);
        this.sM = new ArrayList();
        this.sT = false;
        this.sK = new zza(looper);
        this.sL = new WeakReference(null);
    }

    protected zzpt(GoogleApiClient googleApiClient) {
        this.sJ = new Object();
        this.zzalc = new CountDownLatch(1);
        this.sM = new ArrayList();
        this.sT = false;
        this.sK = new zza(googleApiClient != null ? googleApiClient.getLooper() : Looper.getMainLooper());
        this.sL = new WeakReference(googleApiClient);
    }

    private R get() {
        R r;
        synchronized (this.sJ) {
            zzab.zza(this.sP ^ true, (Object) "Result has already been consumed.");
            zzab.zza(isReady(), (Object) "Result is not ready.");
            r = this.sc;
            this.sc = null;
            this.sN = null;
            this.sP = true;
        }
        zzaop();
        return r;
    }

    private void zzd(R r) {
        this.sc = r;
        this.sR = null;
        this.zzalc.countDown();
        Status status = this.sc.getStatus();
        if (this.zzak) {
            this.sN = null;
        } else if (this.sN != null) {
            this.sK.zzaow();
            this.sK.zza(this.sN, get());
        } else if (this.sc instanceof Releasable) {
            this.sO = new zzb();
        }
        Iterator it = this.sM.iterator();
        while (it.hasNext()) {
            ((com.google.android.gms.common.api.PendingResult.zza) it.next()).zzv(status);
        }
        this.sM.clear();
    }

    public static void zze(Result result) {
        if (result instanceof Releasable) {
            try {
                ((Releasable) result).release();
            } catch (Throwable e) {
                String valueOf = String.valueOf(result);
                StringBuilder stringBuilder = new StringBuilder(18 + String.valueOf(valueOf).length());
                stringBuilder.append("Unable to release ");
                stringBuilder.append(valueOf);
                Log.w("BasePendingResult", stringBuilder.toString(), e);
            }
        }
    }

    public final R await() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = android.os.Looper.myLooper();
        r1 = android.os.Looper.getMainLooper();
        r2 = 0;
        r3 = 1;
        if (r0 == r1) goto L_0x000e;
    L_0x000c:
        r0 = r3;
        goto L_0x000f;
    L_0x000e:
        r0 = r2;
    L_0x000f:
        r1 = "await must not be called on the UI thread";
        com.google.android.gms.common.internal.zzab.zza(r0, r1);
        r0 = r4.sP;
        r0 = r0 ^ r3;
        r1 = "Result has already been consumed";
        com.google.android.gms.common.internal.zzab.zza(r0, r1);
        r0 = r4.sS;
        if (r0 != 0) goto L_0x0021;
    L_0x0020:
        r2 = r3;
    L_0x0021:
        r0 = "Cannot await if then() has been called.";
        com.google.android.gms.common.internal.zzab.zza(r2, r0);
        r0 = r4.zzalc;	 Catch:{ InterruptedException -> 0x002c }
        r0.await();	 Catch:{ InterruptedException -> 0x002c }
        goto L_0x0031;
    L_0x002c:
        r0 = com.google.android.gms.common.api.Status.sh;
        r4.zzaa(r0);
    L_0x0031:
        r0 = r4.isReady();
        r1 = "Result is not ready.";
        com.google.android.gms.common.internal.zzab.zza(r0, r1);
        r0 = r4.get();
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzpt.await():R");
    }

    public final R await(long r5, java.util.concurrent.TimeUnit r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r4 = this;
        r0 = 0;
        r2 = (r5 > r0 ? 1 : (r5 == r0 ? 0 : -1));
        r0 = 0;
        r1 = 1;
        if (r2 <= 0) goto L_0x0015;
    L_0x0008:
        r2 = android.os.Looper.myLooper();
        r3 = android.os.Looper.getMainLooper();
        if (r2 == r3) goto L_0x0013;
    L_0x0012:
        goto L_0x0015;
    L_0x0013:
        r2 = r0;
        goto L_0x0016;
    L_0x0015:
        r2 = r1;
    L_0x0016:
        r3 = "await must not be called on the UI thread when time is greater than zero.";
        com.google.android.gms.common.internal.zzab.zza(r2, r3);
        r2 = r4.sP;
        r2 = r2 ^ r1;
        r3 = "Result has already been consumed.";
        com.google.android.gms.common.internal.zzab.zza(r2, r3);
        r2 = r4.sS;
        if (r2 != 0) goto L_0x0028;
    L_0x0027:
        r0 = r1;
    L_0x0028:
        r1 = "Cannot await if then() has been called.";
        com.google.android.gms.common.internal.zzab.zza(r0, r1);
        r0 = r4.zzalc;	 Catch:{ InterruptedException -> 0x003b }
        r5 = r0.await(r5, r7);	 Catch:{ InterruptedException -> 0x003b }
        if (r5 != 0) goto L_0x0040;	 Catch:{ InterruptedException -> 0x003b }
    L_0x0035:
        r5 = com.google.android.gms.common.api.Status.sj;	 Catch:{ InterruptedException -> 0x003b }
        r4.zzaa(r5);	 Catch:{ InterruptedException -> 0x003b }
        goto L_0x0040;
    L_0x003b:
        r5 = com.google.android.gms.common.api.Status.sh;
        r4.zzaa(r5);
    L_0x0040:
        r5 = r4.isReady();
        r6 = "Result is not ready.";
        com.google.android.gms.common.internal.zzab.zza(r5, r6);
        r5 = r4.get();
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzpt.await(long, java.util.concurrent.TimeUnit):R");
    }

    public void cancel() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r0 = r2.sJ;
        monitor-enter(r0);
        r1 = r2.zzak;	 Catch:{ all -> 0x002a }
        if (r1 != 0) goto L_0x0028;	 Catch:{ all -> 0x002a }
    L_0x0007:
        r1 = r2.sP;	 Catch:{ all -> 0x002a }
        if (r1 == 0) goto L_0x000c;	 Catch:{ all -> 0x002a }
    L_0x000b:
        goto L_0x0028;	 Catch:{ all -> 0x002a }
    L_0x000c:
        r1 = r2.sR;	 Catch:{ all -> 0x002a }
        if (r1 == 0) goto L_0x0015;
    L_0x0010:
        r1 = r2.sR;	 Catch:{ RemoteException -> 0x0015 }
        r1.cancel();	 Catch:{ RemoteException -> 0x0015 }
    L_0x0015:
        r1 = r2.sc;	 Catch:{ all -> 0x002a }
        zze(r1);	 Catch:{ all -> 0x002a }
        r1 = 1;	 Catch:{ all -> 0x002a }
        r2.zzak = r1;	 Catch:{ all -> 0x002a }
        r1 = com.google.android.gms.common.api.Status.sk;	 Catch:{ all -> 0x002a }
        r1 = r2.zzc(r1);	 Catch:{ all -> 0x002a }
        r2.zzd(r1);	 Catch:{ all -> 0x002a }
        monitor-exit(r0);	 Catch:{ all -> 0x002a }
        return;	 Catch:{ all -> 0x002a }
    L_0x0028:
        monitor-exit(r0);	 Catch:{ all -> 0x002a }
        return;	 Catch:{ all -> 0x002a }
    L_0x002a:
        r1 = move-exception;	 Catch:{ all -> 0x002a }
        monitor-exit(r0);	 Catch:{ all -> 0x002a }
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzpt.cancel():void");
    }

    public boolean isCanceled() {
        boolean z;
        synchronized (this.sJ) {
            z = this.zzak;
        }
        return z;
    }

    public final boolean isReady() {
        return this.zzalc.getCount() == 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void setResultCallback(com.google.android.gms.common.api.ResultCallback<? super R> r5) {
        /*
        r4 = this;
        r0 = r4.sJ;
        monitor-enter(r0);
        if (r5 != 0) goto L_0x000c;
    L_0x0005:
        r5 = 0;
        r4.sN = r5;	 Catch:{ all -> 0x000a }
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        return;
    L_0x000a:
        r5 = move-exception;
        goto L_0x003c;
    L_0x000c:
        r1 = r4.sP;	 Catch:{ all -> 0x000a }
        r2 = 1;
        r1 = r1 ^ r2;
        r3 = "Result has already been consumed.";
        com.google.android.gms.common.internal.zzab.zza(r1, r3);	 Catch:{ all -> 0x000a }
        r1 = r4.sS;	 Catch:{ all -> 0x000a }
        if (r1 != 0) goto L_0x001a;
    L_0x0019:
        goto L_0x001b;
    L_0x001a:
        r2 = 0;
    L_0x001b:
        r1 = "Cannot set callbacks if then() has been called.";
        com.google.android.gms.common.internal.zzab.zza(r2, r1);	 Catch:{ all -> 0x000a }
        r1 = r4.isCanceled();	 Catch:{ all -> 0x000a }
        if (r1 == 0) goto L_0x0028;
    L_0x0026:
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        return;
    L_0x0028:
        r1 = r4.isReady();	 Catch:{ all -> 0x000a }
        if (r1 == 0) goto L_0x0038;
    L_0x002e:
        r1 = r4.sK;	 Catch:{ all -> 0x000a }
        r2 = r4.get();	 Catch:{ all -> 0x000a }
        r1.zza(r5, r2);	 Catch:{ all -> 0x000a }
        goto L_0x003a;
    L_0x0038:
        r4.sN = r5;	 Catch:{ all -> 0x000a }
    L_0x003a:
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        return;
    L_0x003c:
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        throw r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzpt.setResultCallback(com.google.android.gms.common.api.ResultCallback):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void setResultCallback(com.google.android.gms.common.api.ResultCallback<? super R> r5, long r6, java.util.concurrent.TimeUnit r8) {
        /*
        r4 = this;
        r0 = r4.sJ;
        monitor-enter(r0);
        if (r5 != 0) goto L_0x000c;
    L_0x0005:
        r5 = 0;
        r4.sN = r5;	 Catch:{ all -> 0x000a }
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        return;
    L_0x000a:
        r5 = move-exception;
        goto L_0x0045;
    L_0x000c:
        r1 = r4.sP;	 Catch:{ all -> 0x000a }
        r2 = 1;
        r1 = r1 ^ r2;
        r3 = "Result has already been consumed.";
        com.google.android.gms.common.internal.zzab.zza(r1, r3);	 Catch:{ all -> 0x000a }
        r1 = r4.sS;	 Catch:{ all -> 0x000a }
        if (r1 != 0) goto L_0x001a;
    L_0x0019:
        goto L_0x001b;
    L_0x001a:
        r2 = 0;
    L_0x001b:
        r1 = "Cannot set callbacks if then() has been called.";
        com.google.android.gms.common.internal.zzab.zza(r2, r1);	 Catch:{ all -> 0x000a }
        r1 = r4.isCanceled();	 Catch:{ all -> 0x000a }
        if (r1 == 0) goto L_0x0028;
    L_0x0026:
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        return;
    L_0x0028:
        r1 = r4.isReady();	 Catch:{ all -> 0x000a }
        if (r1 == 0) goto L_0x0038;
    L_0x002e:
        r6 = r4.sK;	 Catch:{ all -> 0x000a }
        r7 = r4.get();	 Catch:{ all -> 0x000a }
        r6.zza(r5, r7);	 Catch:{ all -> 0x000a }
        goto L_0x0043;
    L_0x0038:
        r4.sN = r5;	 Catch:{ all -> 0x000a }
        r5 = r4.sK;	 Catch:{ all -> 0x000a }
        r6 = r8.toMillis(r6);	 Catch:{ all -> 0x000a }
        r5.zza(r4, r6);	 Catch:{ all -> 0x000a }
    L_0x0043:
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        return;
    L_0x0045:
        monitor-exit(r0);	 Catch:{ all -> 0x000a }
        throw r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzpt.setResultCallback(com.google.android.gms.common.api.ResultCallback, long, java.util.concurrent.TimeUnit):void");
    }

    public <S extends Result> TransformedResult<S> then(ResultTransform<? super R, ? extends S> resultTransform) {
        TransformedResult<S> then;
        zzab.zza(this.sP ^ true, (Object) "Result has already been consumed.");
        synchronized (this.sJ) {
            boolean z = false;
            zzab.zza(this.sS == null, (Object) "Cannot call then() twice.");
            if (this.sN == null) {
                z = true;
            }
            zzab.zza(z, (Object) "Cannot call then() if callbacks are set.");
            this.sT = true;
            this.sS = new zzrc(this.sL);
            then = this.sS.then(resultTransform);
            if (isReady()) {
                this.sK.zza(this.sS, get());
            } else {
                this.sN = this.sS;
            }
        }
        return then;
    }

    public final void zza(com.google.android.gms.common.api.PendingResult.zza com_google_android_gms_common_api_PendingResult_zza) {
        boolean z = true;
        zzab.zza(this.sP ^ true, (Object) "Result has already been consumed.");
        if (com_google_android_gms_common_api_PendingResult_zza == null) {
            z = false;
        }
        zzab.zzb(z, (Object) "Callback cannot be null.");
        synchronized (this.sJ) {
            if (isReady()) {
                com_google_android_gms_common_api_PendingResult_zza.zzv(this.sc.getStatus());
            } else {
                this.sM.add(com_google_android_gms_common_api_PendingResult_zza);
            }
        }
    }

    protected final void zza(zzr com_google_android_gms_common_internal_zzr) {
        synchronized (this.sJ) {
            this.sR = com_google_android_gms_common_internal_zzr;
        }
    }

    public final void zzaa(Status status) {
        synchronized (this.sJ) {
            if (!isReady()) {
                zzc(zzc(status));
                this.sQ = true;
            }
        }
    }

    public Integer zzaog() {
        return null;
    }

    protected void zzaop() {
    }

    public boolean zzaos() {
        boolean isCanceled;
        synchronized (this.sJ) {
            if (((GoogleApiClient) this.sL.get()) == null || !this.sT) {
                cancel();
            }
            isCanceled = isCanceled();
        }
        return isCanceled;
    }

    public void zzaot() {
        boolean z;
        if (!this.sT) {
            if (!((Boolean) sI.get()).booleanValue()) {
                z = false;
                this.sT = z;
            }
        }
        z = true;
        this.sT = z;
    }

    boolean zzaou() {
        return false;
    }

    protected abstract R zzc(Status status);

    public final void zzc(R r) {
        synchronized (this.sJ) {
            if (!(this.sQ || this.zzak)) {
                if (!isReady() || !zzaou()) {
                    zzab.zza(isReady() ^ 1, (Object) "Results have already been set");
                    zzab.zza(this.sP ^ 1, (Object) "Result has already been consumed");
                    zzd(r);
                    return;
                }
            }
            zze(r);
        }
    }
}
