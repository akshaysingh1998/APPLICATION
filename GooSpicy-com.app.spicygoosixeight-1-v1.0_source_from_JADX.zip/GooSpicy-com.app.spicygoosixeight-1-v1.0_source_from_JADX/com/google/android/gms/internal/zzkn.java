package com.google.android.gms.internal;

@zzir
public interface zzkn<T> {
    void cancel();

    T zzpz();
}
