package com.google.android.gms.internal;

public interface zzle<T> {

    public interface zza {
        void run();
    }

    public interface zzc<T> {
        void zzd(T t);
    }

    public static class zzb implements zza {
        public void run() {
        }
    }

    void zza(zzc<T> com_google_android_gms_internal_zzle_zzc_T, zza com_google_android_gms_internal_zzle_zza);

    void zzg(T t);
}
