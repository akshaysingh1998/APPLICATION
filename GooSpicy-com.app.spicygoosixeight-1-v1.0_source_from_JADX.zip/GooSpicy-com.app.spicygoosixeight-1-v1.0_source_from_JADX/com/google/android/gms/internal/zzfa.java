package com.google.android.gms.internal;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.net.Uri.Builder;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.overlay.AdLauncherIntentInfoParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zze;
import com.google.android.gms.ads.internal.zzu;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@zzir
public final class zzfa implements zzet {
    private final zze zzbix;
    private final zzhe zzbiy;
    private final zzev zzbja;

    public static class zza {
        private final zzll zzbgj;

        public zza(zzll com_google_android_gms_internal_zzll) {
            this.zzbgj = com_google_android_gms_internal_zzll;
        }

        public Intent zza(Intent intent, ResolveInfo resolveInfo) {
            Intent intent2 = new Intent(intent);
            intent2.setClassName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
            return intent2;
        }

        public ResolveInfo zza(Context context, Intent intent) {
            return zza(context, intent, new ArrayList());
        }

        public ResolveInfo zza(Context context, Intent intent, ArrayList<ResolveInfo> arrayList) {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                return null;
            }
            Collection queryIntentActivities = packageManager.queryIntentActivities(intent, 65536);
            ResolveInfo resolveActivity = packageManager.resolveActivity(intent, 65536);
            if (!(queryIntentActivities == null || resolveActivity == null)) {
                for (int i = 0; i < queryIntentActivities.size(); i++) {
                    ResolveInfo resolveInfo = (ResolveInfo) queryIntentActivities.get(i);
                    if (resolveActivity != null && resolveActivity.activityInfo.name.equals(resolveInfo.activityInfo.name)) {
                        break;
                    }
                }
            }
            resolveActivity = null;
            arrayList.addAll(queryIntentActivities);
            return resolveActivity;
        }

        public Intent zzc(Context context, Map<String, String> map) {
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            String str = (String) map.get("u");
            Uri uri = null;
            if (TextUtils.isEmpty(str)) {
                return null;
            }
            Builder buildUpon;
            String str2;
            ArrayList arrayList;
            Intent zze;
            Intent zze2;
            ResolveInfo zza;
            ResolveInfo zza2;
            List<RunningAppProcessInfo> runningAppProcesses;
            Iterator it;
            ResolveInfo resolveInfo;
            if (this.zzbgj != null) {
                str = zzu.zzfq().zza(this.zzbgj, str);
            }
            Uri parse = Uri.parse(str);
            boolean parseBoolean = Boolean.parseBoolean((String) map.get("use_first_package"));
            boolean parseBoolean2 = Boolean.parseBoolean((String) map.get("use_running_process"));
            if ("http".equalsIgnoreCase(parse.getScheme())) {
                buildUpon = parse.buildUpon();
                str2 = "https";
            } else {
                if ("https".equalsIgnoreCase(parse.getScheme())) {
                    buildUpon = parse.buildUpon();
                    str2 = "http";
                }
                arrayList = new ArrayList();
                zze = zze(parse);
                zze2 = zze(uri);
                zza = zza(context, zze, arrayList);
                if (zza != null) {
                    return zza(zze, zza);
                }
                if (zze2 != null) {
                    zza2 = zza(context, zze2);
                    if (zza2 != null) {
                        zze2 = zza(zze, zza2);
                        if (zza(context, zze2) != null) {
                            return zze2;
                        }
                    }
                }
                if (arrayList.size() == 0) {
                    return zze;
                }
                if (parseBoolean2 && activityManager != null) {
                    runningAppProcesses = activityManager.getRunningAppProcesses();
                    if (runningAppProcesses != null) {
                        it = arrayList.iterator();
                        while (it.hasNext()) {
                            resolveInfo = (ResolveInfo) it.next();
                            for (RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
                                if (runningAppProcessInfo.processName.equals(resolveInfo.activityInfo.packageName)) {
                                    return zza(zze, resolveInfo);
                                }
                            }
                        }
                    }
                }
                return parseBoolean ? zza(zze, (ResolveInfo) arrayList.get(0)) : zze;
            }
            uri = buildUpon.scheme(str2).build();
            arrayList = new ArrayList();
            zze = zze(parse);
            zze2 = zze(uri);
            zza = zza(context, zze, arrayList);
            if (zza != null) {
                return zza(zze, zza);
            }
            if (zze2 != null) {
                zza2 = zza(context, zze2);
                if (zza2 != null) {
                    zze2 = zza(zze, zza2);
                    if (zza(context, zze2) != null) {
                        return zze2;
                    }
                }
            }
            if (arrayList.size() == 0) {
                return zze;
            }
            runningAppProcesses = activityManager.getRunningAppProcesses();
            if (runningAppProcesses != null) {
                it = arrayList.iterator();
                while (it.hasNext()) {
                    resolveInfo = (ResolveInfo) it.next();
                    while (r3.hasNext()) {
                        if (runningAppProcessInfo.processName.equals(resolveInfo.activityInfo.packageName)) {
                            return zza(zze, resolveInfo);
                        }
                    }
                }
            }
            if (parseBoolean) {
            }
        }

        public Intent zze(Uri uri) {
            if (uri == null) {
                return null;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addFlags(268435456);
            intent.setData(uri);
            intent.setAction("android.intent.action.VIEW");
            return intent;
        }
    }

    public zzfa(zzev com_google_android_gms_internal_zzev, zze com_google_android_gms_ads_internal_zze, zzhe com_google_android_gms_internal_zzhe) {
        this.zzbja = com_google_android_gms_internal_zzev;
        this.zzbix = com_google_android_gms_ads_internal_zze;
        this.zzbiy = com_google_android_gms_internal_zzhe;
    }

    private static boolean zzc(Map<String, String> map) {
        return "1".equals(map.get("custom_close"));
    }

    private static int zzd(Map<String, String> map) {
        String str = (String) map.get("o");
        if (str != null) {
            if ("p".equalsIgnoreCase(str)) {
                return zzu.zzfs().zztl();
            }
            if ("l".equalsIgnoreCase(str)) {
                return zzu.zzfs().zztk();
            }
            if ("c".equalsIgnoreCase(str)) {
                return zzu.zzfs().zztm();
            }
        }
        return -1;
    }

    private static void zze(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        Context context = com_google_android_gms_internal_zzll.getContext();
        if (TextUtils.isEmpty((String) map.get("u"))) {
            zzb.zzcy("Destination url cannot be empty.");
            return;
        }
        try {
            com_google_android_gms_internal_zzll.zzuk().zza(new AdLauncherIntentInfoParcel(new zza(com_google_android_gms_internal_zzll).zzc(context, map)));
        } catch (ActivityNotFoundException e) {
            zzb.zzcy(e.getMessage());
        }
    }

    private void zzr(boolean z) {
        if (this.zzbiy != null) {
            this.zzbiy.zzs(z);
        }
    }

    public void zza(zzll com_google_android_gms_internal_zzll, Map<String, String> map) {
        String str = (String) map.get("a");
        if (str == null) {
            zzb.zzcy("Action missing from an open GMSG.");
        } else if (this.zzbix == null || this.zzbix.zzem()) {
            zzlm zzuk = com_google_android_gms_internal_zzll.zzuk();
            if ("expand".equalsIgnoreCase(str)) {
                if (com_google_android_gms_internal_zzll.zzuo()) {
                    zzb.zzcy("Cannot expand WebView that is already expanded.");
                    return;
                }
                zzr(false);
                zzuk.zza(zzc(map), zzd(map));
            } else if ("webapp".equalsIgnoreCase(str)) {
                r11 = (String) map.get("u");
                zzr(false);
                if (r11 != null) {
                    zzuk.zza(zzc(map), zzd(map), r11);
                } else {
                    zzuk.zza(zzc(map), zzd(map), (String) map.get("html"), (String) map.get("baseurl"));
                }
            } else if ("in_app_purchase".equalsIgnoreCase(str)) {
                r11 = (String) map.get(Param.PRODUCT_ID);
                String str2 = (String) map.get("report_urls");
                if (this.zzbja != null) {
                    if (str2 == null || str2.isEmpty()) {
                        this.zzbja.zza(r11, new ArrayList());
                        return;
                    }
                    this.zzbja.zza(r11, new ArrayList(Arrays.asList(str2.split(" "))));
                }
            } else if ("app".equalsIgnoreCase(str) && "true".equalsIgnoreCase((String) map.get("system_browser"))) {
                zzr(true);
                zze(com_google_android_gms_internal_zzll, map);
            } else {
                zzr(true);
                str = (String) map.get("u");
                if (!TextUtils.isEmpty(str)) {
                    str = zzu.zzfq().zza(com_google_android_gms_internal_zzll, str);
                }
                zzuk.zza(new AdLauncherIntentInfoParcel((String) map.get("i"), str, (String) map.get("m"), (String) map.get("p"), (String) map.get("c"), (String) map.get("f"), (String) map.get("e")));
            }
        } else {
            this.zzbix.zzt((String) map.get("u"));
        }
    }
}
