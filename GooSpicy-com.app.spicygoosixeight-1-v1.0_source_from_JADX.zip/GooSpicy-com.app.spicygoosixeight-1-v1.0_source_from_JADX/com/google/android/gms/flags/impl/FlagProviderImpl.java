package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.flags.impl.zza.zzb;
import com.google.android.gms.flags.impl.zza.zzc;
import com.google.android.gms.flags.impl.zza.zzd;
import com.google.android.gms.internal.zzug.zza;

@DynamiteApi
public class FlagProviderImpl extends zza {
    private boolean zzamr = false;
    private SharedPreferences zzaxs;

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        return !this.zzamr ? z : zza.zza.zza(this.zzaxs, str, Boolean.valueOf(z)).booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        return !this.zzamr ? i : zzb.zza(this.zzaxs, str, Integer.valueOf(i)).intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        return !this.zzamr ? j : zzc.zza(this.zzaxs, str, Long.valueOf(j)).longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        return !this.zzamr ? str2 : zzd.zza(this.zzaxs, str, str2);
    }

    public void init(com.google.android.gms.dynamic.zzd r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r2 = this;
        r3 = com.google.android.gms.dynamic.zze.zzad(r3);
        r3 = (android.content.Context) r3;
        r0 = r2.zzamr;
        if (r0 == 0) goto L_0x000b;
    L_0x000a:
        return;
    L_0x000b:
        r0 = "com.google.android.gms";	 Catch:{ NameNotFoundException -> 0x001b }
        r1 = 0;	 Catch:{ NameNotFoundException -> 0x001b }
        r3 = r3.createPackageContext(r0, r1);	 Catch:{ NameNotFoundException -> 0x001b }
        r3 = com.google.android.gms.flags.impl.zzb.zzn(r3);	 Catch:{ NameNotFoundException -> 0x001b }
        r2.zzaxs = r3;	 Catch:{ NameNotFoundException -> 0x001b }
        r3 = 1;	 Catch:{ NameNotFoundException -> 0x001b }
        r2.zzamr = r3;	 Catch:{ NameNotFoundException -> 0x001b }
    L_0x001b:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.flags.impl.FlagProviderImpl.init(com.google.android.gms.dynamic.zzd):void");
    }
}
