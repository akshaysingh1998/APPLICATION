package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.internal.zzui;
import java.util.concurrent.Callable;

public class zzb {
    private static SharedPreferences QA;

    class C03871 implements Callable<SharedPreferences> {
        final /* synthetic */ Context zzaky;

        C03871(Context context) {
            this.zzaky = context;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzbfv();
        }

        public SharedPreferences zzbfv() {
            return this.zzaky.getSharedPreferences("google_sdk_flags", 1);
        }
    }

    public static SharedPreferences zzn(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            if (QA == null) {
                QA = (SharedPreferences) zzui.zzb(new C03871(context));
            }
            sharedPreferences = QA;
        }
        return sharedPreferences;
    }
}
